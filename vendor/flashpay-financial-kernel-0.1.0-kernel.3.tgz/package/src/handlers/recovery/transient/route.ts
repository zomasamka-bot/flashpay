import { createHash, randomUUID, timingSafeEqual } from "crypto"
import { after, type NextRequest, NextResponse } from "next/server"

import { redis, isRedisConfigured } from "../../../lib/redis"
import { executeA2URecovery } from "../../../lib/a2u-recovery-service"
import { isStage1OnlySettlementDispatchCandidate } from "../../../lib/a2u-locked-executor"
import { ensureAutomaticRefundIntent, readAutomaticRefundDrainHead, runAutomaticRefundPass, runAutomaticRefundPreparationStep, runAutomaticRefundFinalizationStep } from "../../../lib/refund-auto-orchestrator"
import { query, listOutstandingSettlementCheckpointIds, getSettlementCheckpointAuthoritative, listRecoverableU2AIngressCheckpointIds, getDurableU2AIngressAuthoritative, recordSettlementU2ACompletedCheckpoint, verifySettlementRefundAuthorityExclusion, readDr11RefundCertificationHold, claimSettlementPiMutationAttempt } from "../../../lib/db"
import { isRefundEligible as checkRefundEligibility } from "../../../lib/types"
import { reconcileIncompleteA2UPayment } from "../../../lib/pi-reconciliation"
import { isPaymentFinal } from "../../../lib/payment-status"
import { compareAndSwapPaymentProjection } from "../../../lib/payment-projection-cas"
import { serverConfig } from "../../../lib/server-config"
import type { Payment } from "../../../lib/types"
import { listDurableMerchantHistoryIdentities, readDurableOriginalPaymentCreationTime, readMerchantHistoryCoverage } from "../../../lib/merchant-history-durable"

export const dynamic = "force-dynamic"
export const runtime = "nodejs"

const MAX_ATTEMPTS = 5
const BOUNDED_PIPELINE_CONCURRENCY = 2
const WALLET_DRAIN_BURST_LIMIT: number | null = null
const WALLET_DRAIN_BURST_BUDGET_MS = 60_000
const IMMEDIATE_DRAIN_KICK_KEY = "flashpay:settlement:immediate-drain-kick:v1"
const READY_SEQUENCE_KEY = "flashpay:settlement:ready:v1:sequence"
const READY_BASELINE_SCAN_SEEN_KEY = "flashpay:settlement:ready:v1:authority-baseline-scan-seen"
const READY_BASELINE_COVERAGE_KEY = "flashpay:settlement:ready:v1:authority-baseline-coverage"
const CONTINUATION_MODE = "continuation-kick"
const IMMEDIATE_DRAIN_MODE = "immediate-drain"
const RECOVERY_SECRET_ENV = "FLASHPAY_TRANSIENT_RECOVERY_SECRET"
const runtimeEnv = process.env
const DRAIN_LEASE_KEY = "flashpay:recovery:transient:drain-lease:v1"
const DRAIN_LEASE_TTL_SECONDS = 900
const PI_CREATE_BACKPRESSURE_KEY = "flashpay:recovery:pi-create-backpressure:v1"
const RECOVERY_WAKE_HEALTH_KEY = "flashpay:operations:recovery-last-wake:v1"
const PI_CREATE_BACKPRESSURE_FALLBACK_MS = 15 * 60_000
const DRAIN_LEASE_RELEASE_SCRIPT = `
local current = redis.call("GET", KEYS[1])
if current == ARGV[1] then return redis.call("DEL", KEYS[1]) end
return 0
`
const DRAIN_LEASE_RENEW_SCRIPT = `
local current = redis.call("GET", KEYS[1])
if current ~= ARGV[1] then return 0 end
return redis.call("EXPIRE", KEYS[1], ARGV[2])
`

const MERCHANT_HISTORY_BOOTSTRAP_KEY = "flashpay:merchant-history:v1:bootstrap"

type MerchantHistoryRecovery = { state: "already_certified" | "rebuilt"; scanned: number; indexed: number }

async function recoverMerchantHistoryProjectionAfterRedisLoss(): Promise<MerchantHistoryRecovery> {
  // Fail closed: PostgreSQL determines membership; Redis is a projection only.
  const durableIdentities = await listDurableMerchantHistoryIdentities()
  const byId = new Map(durableIdentities.map(identity => [identity.paymentId, identity]))
  const marker = await redis.get(MERCHANT_HISTORY_BOOTSTRAP_KEY)
  if (marker !== null && marker !== "done") throw new Error("Merchant history bootstrap marker contradictory")

  // Verify all durable projections before attempting any index repair.
  for (const identity of durableIdentities) {
    const payment = parsePayment(await redis.get(`payment:${identity.paymentId}`))
    if (!payment || payment.id !== identity.paymentId ||
        payment.merchantId !== identity.merchantId ||
        payment.merchantUid !== identity.merchantUid ||
        payment.amount !== identity.amount ||
        payment.createdAt !== identity.createdAt) {
      throw new Error("Merchant history durable projection absent or contradictory")
    }
  }

  // Scan for unaccounted projections even when a stale marker says "done".
  // Preserve orphans as evidence: never delete, index, or certify them.
  let cursor = "0"
  let scanned = 0
  const seen = new Set<string>()
  do {
    const page = await redis.scan(cursor, { match: "payment:*", count: 200 })
    if (!Array.isArray(page) || page.length !== 2 || !Array.isArray(page[1])) throw new Error("Merchant history scan indeterminate")
    const rawCursor = page[0]
    const next = typeof rawCursor === "string" && /^[0-9]+$/.test(rawCursor) ? rawCursor :
      typeof rawCursor === "number" && Number.isSafeInteger(rawCursor) && rawCursor >= 0 ? String(rawCursor) : null
    if (next === null) throw new Error("Merchant history scan cursor indeterminate")
    for (const key of page[1]) {
      if (typeof key !== "string" || !key.startsWith("payment:")) throw new Error("Merchant history scan key invalid")
      const paymentId = key.slice("payment:".length)
      if (!paymentId || paymentId !== paymentId.trim()) throw new Error("Merchant history payment id invalid")
      const identity = byId.get(paymentId)
      if (!identity) throw new Error("Merchant history Redis orphan without durable identity")
      const payment = parsePayment(await redis.get(key))
      if (!payment || payment.id !== paymentId || payment.merchantId !== identity.merchantId ||
          payment.merchantUid !== identity.merchantUid || payment.amount !== identity.amount ||
          payment.createdAt !== identity.createdAt) throw new Error("Merchant history projection contradictory")
      seen.add(paymentId)
      scanned++
      if (scanned > 100000) throw new Error("Merchant history rebuild bound exceeded")
    }
    cursor = next
  } while (cursor !== "0")
  if (seen.size !== byId.size) throw new Error("Merchant history Redis scan incomplete")

  // Read the full bounded merchant indexes; reject extra members and bad scores.
  const byMerchant = new Map<string, Map<string, number>>()
  for (const identity of durableIdentities) {
    let members = byMerchant.get(identity.merchantId)
    if (!members) { members = new Map(); byMerchant.set(identity.merchantId, members) }
    members.set(identity.paymentId, identity.createdAtMs)
  }
  let indexed = 0
  for (const [merchantId, members] of byMerchant) {
    const indexKey = `flashpay:merchant:${merchantId}:payments:v1`
    const current = await redis.zrange<string[]>(indexKey, 0, 2000)
    if (!Array.isArray(current) || current.length > 2000 ||
        current.some(id => typeof id !== "string" || !members.has(id))) {
      throw new Error("Merchant history index contains unverified membership")
    }
    for (const [paymentId, scoreMs] of members) {
      const score = await redis.zscore(indexKey, paymentId)
      if (score !== null && (typeof score !== "number" || score !== scoreMs)) {
        throw new Error("Merchant history durable index score contradictory")
      }
      if (score === null) {
        if (marker === "done") throw new Error("Merchant history certified index incomplete")
        // Conditional Redis mutation: only an absent index member, only after
        // durable identity and projection validation. Never rewrite scores.
        const added = await redis.eval<[string, string, string, string, string, string], number>(
          "local raw=redis.call('GET',KEYS[1]); if not raw then return -1 end; local ok,p=pcall(cjson.decode,raw); if not ok or type(p)~='table' then return -1 end; if p.id~=ARGV[1] or p.merchantId~=ARGV[2] or p.merchantUid~=ARGV[3] or tonumber(p.amount)~=tonumber(ARGV[4]) or p.createdAt~=ARGV[5] then return -1 end; local s=redis.call('ZSCORE',KEYS[2],ARGV[1]); if s then if tonumber(s)==tonumber(ARGV[6]) then return 0 else return -1 end end; return redis.call('ZADD',KEYS[2],'NX',ARGV[6],ARGV[1])",
          [`payment:${paymentId}`, indexKey], [paymentId, merchantId, byId.get(paymentId)!.merchantUid,
            String(byId.get(paymentId)!.amount), byId.get(paymentId)!.createdAt, String(scoreMs)])
        if (added !== 0 && added !== 1) throw new Error("Merchant history index repair conflict")
        indexed += added
      }
    }
    const verified = await redis.zrange<string[]>(indexKey, 0, 2000)
    if (!Array.isArray(verified) || verified.length !== members.size ||
        verified.some(id => typeof id !== "string" || !members.has(id))) {
      throw new Error("Merchant history index coverage contradictory")
    }
    for (const [id, expected] of members) {
      if (await redis.zscore(indexKey, id) !== expected) throw new Error("Merchant history index verification failed")
    }
  }
  if (marker === "done") return { state: "already_certified", scanned, indexed: 0 }
  const certified = await redis.set(MERCHANT_HISTORY_BOOTSTRAP_KEY, "done", { nx: true })
  if (certified !== "OK") throw new Error("Merchant history bootstrap certification race")
  console.warn("[DR56 MERCHANT HISTORY RECOVERY] certified", { scanned, indexed, source: "postgresql_durable_identities", financialAuthorityMutated: false })
  return { state: "rebuilt", scanned, indexed }
}

type DurableU2AIngressRepopulation = {
  scanned:number
  repopulated:number
  healed:number
  indexed:number
  deferredNoAccessToken:number
  verifiedOnly:number
  piCompletionReconciled:number
  piReadUncertain:number
  excludedRefundAuthority:number
  conflicts:number
  conflictReasons:Record<string,number>
  conflictSamples:Array<{paymentId:string;reason:string}>
}

/**
 * F2-3: PostgreSQL-driven rediscovery for pre-A2U U2A ingress.
 *
 * This function never creates Settlement/Refund blockchain movement. It can
 * restore a missing Redis projection from exact durable U2A identity. F2-4 lets
 * a fully reconstructed accessToken="" projection regain ready membership; the
 * locked executor still must prove exact PostgreSQL + Pi server authority before
 * any A2U creation is allowed.
 */
async function repopulateDurableU2AIngressWork():Promise<DurableU2AIngressRepopulation>{
  const page=await listRecoverableU2AIngressCheckpointIds(200)
  if(page.outcome!=='FOUND')throw new Error(page.error)
  const result:DurableU2AIngressRepopulation={scanned:page.paymentIds.length,repopulated:0,healed:0,indexed:0,deferredNoAccessToken:0,verifiedOnly:0,piCompletionReconciled:0,piReadUncertain:0,excludedRefundAuthority:0,conflicts:0,conflictReasons:{},conflictSamples:[]}
  const conflict=(paymentId:string,reason:string)=>{
    result.conflicts++;result.conflictReasons[reason]=(result.conflictReasons[reason]??0)+1
    if(result.conflictSamples.length<20)result.conflictSamples.push({paymentId,reason})
  }
  for(const paymentId of page.paymentIds){
    // DR59: an owner-armed DR11 payment is held out of Settlement rediscovery
    // until /complete atomically consumes its exact-payment marker and persists
    // durable Refund authority. A failed Lua EVAL rolls back marker deletion, so
    // this also closes the post-Pi-completion crash window without authorizing
    // any financial movement from Redis. Ordinary payments have no such marker.
    const dr11DurableHold=await readDr11RefundCertificationHold(paymentId)
    if(dr11DurableHold.outcome==='INDETERMINATE'){conflict(paymentId,'dr11_durable_hold_indeterminate');continue}
    if(dr11DurableHold.outcome==='HELD'){result.excludedRefundAuthority++;continue}
    const authority=await verifySettlementRefundAuthorityExclusion(paymentId)
    if(authority.outcome!=='CLEAR'){conflict(paymentId,`authority_${authority.outcome.toLowerCase()}`);continue}
    // A durable Refund authority is an expected XOR exclusion, not a Settlement
    // recovery conflict. Never rebuild or schedule Settlement work for it.
    if(authority.refundActive){result.excludedRefundAuthority++;continue}
    let durable=await getDurableU2AIngressAuthoritative(paymentId)
    if(durable.outcome==='ABSENT')continue // It may have advanced to the existing Stage1+ recovery lane concurrently.
    if(durable.outcome!=='FOUND')throw new Error(durable.error)

    // F2-7 closes both U2A crash windows from durable exact identity. The worker
    // may call Pi /complete only after GET-proving the exact durable payment/txid,
    // then it refetches and trusts only Pi's resulting developer_completed state.
    if(durable.checkpoint.completedAt===null){
      const ingress=durable.checkpoint
      if(!serverConfig.piApiKey){result.piReadUncertain++;continue}
      const readExactPiU2A=async():Promise<{dto:Record<string,unknown>;status:Record<string,unknown>;transaction:Record<string,unknown>}|null>=>{
        let response:Response
        try{
          response=await fetch(`https://api.minepi.com/v2/payments/${encodeURIComponent(ingress.u2aIdentifier)}`,{
            method:'GET',headers:{Authorization:`Key ${serverConfig.piApiKey}`,Accept:'application/json'},cache:'no-store',redirect:'error',
          })
        }catch{return null}
        if(!response.ok)return null
        const dto=asRecord(await response.json().catch(()=>null)),status=dto?asRecord(dto.status):null,transaction=dto?asRecord(dto.transaction):null,metadata=dto?asRecord(dto.metadata):null
        const payerUid=dto&&typeof dto.user_uid==='string'&&dto.user_uid.trim()!==''&&dto.user_uid===dto.user_uid.trim()?dto.user_uid:''
        // The durable ingress contract is Testnet-only, as in /api/pi/complete.
        // Check both the initial read and the post-completion refetch before claiming or recording.
        if(!dto||!status||!transaction||dto.network!=='Pi Testnet'||dto.identifier!==ingress.u2aIdentifier||dto.direction!=='user_to_app'||Number(dto.amount)!==ingress.customerAmount||
          metadata?.paymentId!==paymentId||transaction.txid!==ingress.u2aTxid||transaction.verified!==true||payerUid!==ingress.payerUid||
          status.developer_approved!==true||status.transaction_verified!==true||status.cancelled===true||status.user_cancelled===true)return null
        return{dto,status,transaction}
      }
      let pi=await readExactPiU2A()
      if(!pi){result.piReadUncertain++;continue}
      if(pi.status.developer_completed!==true){
        const completionAttempt=await claimSettlementPiMutationAttempt({kind:'u2a_complete',paymentId,externalPaymentId:ingress.u2aIdentifier,txid:ingress.u2aTxid})
        if(completionAttempt.outcome!=='RECORDED'){result.piReadUncertain++;continue}
        try{
          await fetch(`https://api.minepi.com/v2/payments/${encodeURIComponent(ingress.u2aIdentifier)}/complete`,{
            method:'POST',headers:{Authorization:`Key ${serverConfig.piApiKey}`,'Content-Type':'application/json'},body:JSON.stringify({txid:ingress.u2aTxid}),cache:'no-store',redirect:'error',
          })
        }catch{}
        // A lost/non-2xx response is never treated as truth; refetch exact Pi state.
        pi=await readExactPiU2A()
        if(!pi||pi.status.developer_completed!==true){result.piReadUncertain++;continue}
      }
      const completion=await recordSettlementU2ACompletedCheckpoint({
        paymentId,merchantId:ingress.merchantId,merchantUid:ingress.merchantUid,customerAmount:ingress.customerAmount,
        u2aIdentifier:ingress.u2aIdentifier,u2aTxid:ingress.u2aTxid,payerUid:ingress.payerUid,
      })
      if(completion.outcome!=='RECORDED'&&completion.outcome!=='REPLAYED'){conflict(paymentId,`u2a_completion_${completion.outcome.toLowerCase()}`);continue}
      result.piCompletionReconciled++
      durable=await getDurableU2AIngressAuthoritative(paymentId)
      if(durable.outcome!=='FOUND'||durable.checkpoint.completedAt===null){conflict(paymentId,'u2a_completion_readback');continue}
    }

    const d=durable.checkpoint
    let existing=parsePayment(await redis.get(`payment:${paymentId}`))

    if(existing&&(existing.status==='settlement_pending'||existing.status==='settled_to_merchant'||existing.a2uPaymentId!==undefined||existing.a2uTxid!==undefined||existing.a2uPreparedEnvelopeXdr!==undefined||existing.a2uPreparedTxHash!==undefined||existing.a2uPreparedSequence!==undefined||existing.horizonSuccessFlag===true||existing.piCompletionPending===true||existing.piCompleted===true||existing.requiresDbReconciliation===true||existing.dbRecorded===true)){
      const advanced=await getSettlementCheckpointAuthoritative(paymentId)
      if(advanced.outcome==='FOUND')continue
      conflict(paymentId,'advanced_projection_without_durable_settlement')
      continue
    }

    if(existing){
      const healed=await redis.eval<[string,string,string,string,string,string,string,string,string],number>(`
local raw=redis.call('GET',KEYS[1]); if not raw then return 0 end
local ok,current=pcall(cjson.decode,raw); if not ok or type(current)~='table' then return -1 end
local amount=tonumber(ARGV[4]); if not amount then return -1 end
if current.id~=ARGV[1] or current.merchantId~=ARGV[2] or current.merchantUid~=ARGV[3] or current.amount~=amount then return -1 end
if current.customerAmount~=nil and current.customerAmount~=amount then return -1 end
if current.piPaymentId~=nil and current.piPaymentId~=ARGV[5] then return -1 end
if current.u2aTxid~=nil and current.u2aTxid~=ARGV[6] then return -1 end
if current.payerUid~=nil and current.payerUid~=ARGV[7] then return -1 end
if current.status~='pending' and current.status~='paid_to_app' then return -1 end
if current.a2uPaymentId~=nil or current.a2uTxid~=nil or current.a2uPreparedEnvelopeXdr~=nil or current.a2uPreparedTxHash~=nil or current.a2uPreparedSequence~=nil then return -1 end
if current.horizonSuccessFlag==true or current.piCompletionPending==true or current.piCompleted==true or current.requiresDbReconciliation==true or current.dbRecorded==true then return -1 end
if current.refundPaymentId~=nil or current.refundTxid~=nil or current.refundProof~=nil or current.refundStatus~=nil then return -1 end
local projectionVersion=current.redisProjectionVersion; if projectionVersion==nil then projectionVersion=0 end
if type(projectionVersion)~='number' or projectionVersion<0 or projectionVersion~=math.floor(projectionVersion) then return -1 end
if current.accessToken==nil then current.accessToken='' elseif type(current.accessToken)~='string' then return -1 elseif current.accessToken~='' and current.accessToken~=string.match(current.accessToken,'^%s*(.-)%s*$') then return -1 end
current.customerAmount=amount; current.piPaymentId=ARGV[5]; current.u2aTxid=ARGV[6]; current.payerUid=ARGV[7]; current.payerUidSource='verified_u2a'; current.payerUidCapturedAt=ARGV[8]
if ARGV[9]~='' then current.status='paid_to_app'; current.paidAt=ARGV[9]; current.settlementDispatchRequestedAt=ARGV[9] end
current.redisProjectionVersion=projectionVersion+1
redis.call('SET',KEYS[1],cjson.encode(current)); return 1
`,[`payment:${paymentId}`],[paymentId,d.merchantId,d.merchantUid,String(d.customerAmount),d.u2aIdentifier,d.u2aTxid,d.payerUid,d.verifiedAt,d.completedAt??''])
      if(healed!==1){conflict(paymentId,healed===0?'projection_heal_race':'projection_heal_rejected');continue}
      result.healed++
    }else{
      const projection:Payment={
        id:d.paymentId,merchantId:d.merchantId,merchantUid:d.merchantUid,accessToken:'',redisProjectionVersion:1,amount:d.customerAmount,customerAmount:d.customerAmount,
        note:'',status:d.completedAt?'paid_to_app':'pending',createdAt:d.createdAt,piPaymentId:d.u2aIdentifier,u2aTxid:d.u2aTxid,
        payerUid:d.payerUid,payerUidSource:'verified_u2a',payerUidCapturedAt:d.verifiedAt,
        ...(d.completedAt?{paidAt:d.completedAt,settlementDispatchRequestedAt:d.completedAt}:{}),
      }
      const created=await redis.set(`payment:${paymentId}`,JSON.stringify(projection),{nx:true})
      if(created==='OK')result.repopulated++
    }

    const readback=parsePayment(await redis.get(`payment:${paymentId}`))
    if(!readback||readback.id!==paymentId||readback.merchantId!==d.merchantId||readback.merchantUid!==d.merchantUid||readback.amount!==d.customerAmount||
      readback.customerAmount!==d.customerAmount||readback.piPaymentId!==d.u2aIdentifier||readback.u2aTxid!==d.u2aTxid||readback.payerUid!==d.payerUid||readback.payerUidSource!=='verified_u2a'||readback.payerUidCapturedAt!==d.verifiedAt||(d.completedAt!==null&&(readback.paidAt!==d.completedAt||readback.settlementDispatchRequestedAt!==d.completedAt))||!hasSettlementMerchantProjectionAuthority(readback)){
      conflict(paymentId,'projection_readback_mismatch');continue
    }
    if(!d.completedAt){result.verifiedOnly++;continue}

    // No new financial authority is invented here. Only an already executable
    // original Redis projection may regain lost active/ready membership.
    if(isFreshSettlementDispatchCandidate(readback,Date.now())){
      const indexed=await restoreSettlementReadyMembership(paymentId)
      if(indexed!==1&&indexed!==2)throw new Error('F2-3 ready index reconstruction unavailable')
      result.indexed++
    }else{
      // Not a canonical fresh-dispatch projection. No financial authority is
      // inferred here; leave it discoverable but unscheduled.
      result.deferredNoAccessToken++
    }
  }
  return result
}

/** D: validate all Redis key types and exact sequence bounds before mutation.
 * Lua errors do not roll back earlier writes; reject corruption before SADD/INCR. */
async function restoreSettlementReadyMembership(paymentId:string):Promise<number>{
  return redis.eval<[string],number>(`
local expected={'set','zset','string'}
for i=1,3 do local t=redis.call('TYPE',KEYS[i]).ok; if t~='none' and t~=expected[i] then return -1 end end
local top=redis.call('ZRANGE',KEYS[2],-1,-1,'WITHSCORES')
if #top~=0 and #top~=2 then return -1 end
local maximum=9007199254740990
local topScore=0
if #top==2 then topScore=tonumber(top[2]); if not topScore or topScore<1 or topScore>maximum or topScore~=math.floor(topScore) then return -1 end end
local sequence=redis.call('GET',KEYS[3])
local base=topScore
if sequence then
  if sequence~='0' and not string.match(sequence,'^[1-9][0-9]*$') then return -1 end
  base=tonumber(sequence)
  if not base or base<topScore or base>maximum or base~=math.floor(base) then return -1 end
end
local score=redis.call('ZSCORE',KEYS[2],ARGV[1])
if score then local n=tonumber(score); if not n or n<1 or n>maximum or n~=math.floor(n) then return -1 end
elseif base>=maximum then return -1 end
redis.call('SADD',KEYS[1],ARGV[1])
if score then return 1 end
if not sequence then redis.call('SET',KEYS[3],string.format('%.0f',base)) end
local nextSequence=redis.call('INCR',KEYS[3])
redis.call('ZADD',KEYS[2],'NX',nextSequence,ARGV[1])
return 2
`,['flashpay:recovery:active-payments:v1','flashpay:settlement:ready:v1',READY_SEQUENCE_KEY],[paymentId])
}

async function repopulateDurableSettlementWork():Promise<{repopulated:number;conflicts:number}>{
  const page=await listOutstandingSettlementCheckpointIds(200)
  if(page.outcome!=='FOUND')throw new Error(page.error)
  let repopulated=0,conflicts=0
  for(const paymentId of page.paymentIds){
    const authority=await verifySettlementRefundAuthorityExclusion(paymentId)
    if(authority.outcome!=='CLEAR'||authority.refundActive){conflicts++;continue}
    const durable=await getSettlementCheckpointAuthoritative(paymentId)
    if(durable.outcome!=='FOUND')throw new Error('Durable Settlement projection unavailable')
    const d=durable.checkpoint
    const dbDone=d.stage==='db_finalized'
    const moved=d.stage==='horizon_confirmed'||d.stage==='pi_completed'||dbDone
    const piDone=d.stage==='pi_completed'||dbDone
    const prepared=d.stage!=='a2u_created'
    const terminalProjection:Payment={id:d.paymentId,merchantId:d.merchantId,merchantUid:d.merchantUid,accessToken:'',redisProjectionVersion:1,amount:d.customerAmount,customerAmount:d.customerAmount,merchantAmount:d.merchantAmount,note:'',status:dbDone?'settled_to_merchant':moved||prepared?'settlement_pending':'paid_to_app',createdAt:d.createdAt,piPaymentId:d.u2aIdentifier,u2aTxid:d.u2aTxid,a2uPaymentId:d.a2uPaymentId,a2uFromAddress:d.a2uFromAddress,a2uToAddress:d.a2uToAddress,settlementFailureState:'none',appCommission:0,...(prepared?{a2uPreparedEnvelopeXdr:d.preparedEnvelopeXdr,a2uPreparedTxHash:d.preparedTxHash,a2uPreparedSequence:d.preparedSequence}:{}),...(moved?{a2uTxid:d.a2uTxid,horizonSuccessFlag:true,horizonFeeCharged:d.horizonFeeStroops!/10_000_000,appNetImpact:d.customerAmount-d.merchantAmount-d.horizonFeeStroops!/10_000_000,piCompletionPending:!piDone,piCompleted:piDone,requiresDbReconciliation:piDone&&!dbDone,dbRecorded:dbDone}:{})}
    const rawExisting=await redis.get(`payment:${paymentId}`)
    const existing=parsePayment(rawExisting)
    // An absent projection may be rebuilt only with the original timestamp
    // attested by an exact payment_create_intent. A checkpoint timestamp is
    // merely the checkpoint's own event time and must NEVER be substituted.
    if (!existing) {
      terminalProjection.createdAt = await readDurableOriginalPaymentCreationTime(
        d.paymentId, d.merchantId, d.merchantUid, d.customerAmount)
    }
    if(dbDone){
      if(existing){
        if(existing.id!==d.paymentId||existing.merchantId!==d.merchantId||existing.merchantUid!==d.merchantUid||existing.piPaymentId!==d.u2aIdentifier||existing.u2aTxid!==d.u2aTxid||existing.a2uPaymentId!==d.a2uPaymentId||existing.a2uTxid!==d.a2uTxid||existing.refundPaymentId!==undefined||existing.refundTxid!==undefined){conflicts++;continue}
        if(existing.status!=='settled_to_merchant'||existing.dbRecorded!==true||existing.requiresDbReconciliation===true){
          const next:Payment={...existing,...terminalProjection,accessToken:"",createdAt:existing.createdAt,redisProjectionVersion:existing.redisProjectionVersion,settledAt:existing.settledAt??new Date().toISOString()}
          const cas=await compareAndSwapPaymentProjection(paymentId,existing,next)
          if(cas.outcome!=='UPDATED'&&!(cas.outcome==='CONFLICT'&&cas.current?.status==='settled_to_merchant'&&cas.current.dbRecorded===true)){conflicts++;continue}
        }
      }else{
        const created=await redis.set(`payment:${paymentId}`,JSON.stringify({...terminalProjection,settledAt:new Date().toISOString()}),{nx:true})
        if(created==='OK')repopulated++
        const readback=parsePayment(await redis.get(`payment:${paymentId}`))
        if(!readback||readback.status!=='settled_to_merchant'||readback.dbRecorded!==true||readback.a2uTxid!==d.a2uTxid){conflicts++;continue}
      }
      await redis.eval<[string],number>("redis.call('SREM',KEYS[1],ARGV[1]); redis.call('ZREM',KEYS[2],ARGV[1]); return 1",['flashpay:recovery:active-payments:v1','flashpay:settlement:ready:v1'],[paymentId])
      continue
    }
    if(existing){await redis.sadd('flashpay:recovery:active-payments:v1',paymentId);continue}
    const created=await redis.set(`payment:${paymentId}`,JSON.stringify(terminalProjection),{nx:true})
    if(created==='OK')repopulated++
    const parsed=parsePayment(await redis.get(`payment:${paymentId}`))
    if(!parsed||parsed.id!==paymentId||parsed.a2uPaymentId!==d.a2uPaymentId)throw new Error('Durable Settlement repopulation readback failed')
    const indexed=await restoreSettlementReadyMembership(paymentId)
    if(indexed!==1&&indexed!==2)throw new Error('Settlement ready sequence unavailable')
  }
  return{repopulated,conflicts}
}

type DrainLease = {
  state: "acquired"
  renew: () => Promise<boolean>
  release: () => Promise<boolean>
} | { state: "busy" } | { state: "unavailable" }

type BoundedPipelineTaskResult<T> = { value?: T; stop?: boolean }
type RecoveryPipelineValue = { paymentId: string; ok: boolean; status?: string; error?: string }
type WalletDrainFairnessClass = "fresh" | "reconciling" | "refund"
type WalletDrainLane = "prepared" | WalletDrainFairnessClass

const WALLET_DRAIN_FAIRNESS_ORDER: readonly WalletDrainFairnessClass[] = ["fresh", "reconciling", "refund"]

function walletDrainFairnessClassForGeneration(generation: number | null): WalletDrainFairnessClass | null {
  if (generation === null || !Number.isSafeInteger(generation) || generation < 1) return null
  return WALLET_DRAIN_FAIRNESS_ORDER[(generation - 1) % WALLET_DRAIN_FAIRNESS_ORDER.length]
}

async function runBoundedOrderedPipeline<T>(items: string[], handler: (id: string) => Promise<BoundedPipelineTaskResult<T>>): Promise<{ values: T[]; peakInFlight: number }> {
  if (items.length === 0) return { values: [], peakInFlight: 0 }

  const ordered: Array<T | undefined> = new Array(items.length)
  let nextIndex = 0
  let stopped = false
  let inFlight = 0
  let peakInFlight = 0

  const runWorker = async () => {
    while (true) {
      if (stopped) return
      const index = nextIndex
      if (index >= items.length) return
      nextIndex++
      inFlight++
      peakInFlight = Math.max(peakInFlight, inFlight)
      try {
        const result = await handler(items[index])
        if (result.value !== undefined) ordered[index] = result.value
        if (result.stop === true) stopped = true
      } finally {
        inFlight--
      }
    }
  }

  const workers: Promise<void>[] = []
  const workerCount = Math.min(BOUNDED_PIPELINE_CONCURRENCY, items.length)
  for (let workerIndex = 0; workerIndex < workerCount; workerIndex++) workers.push(runWorker())
  const outcomes = await Promise.allSettled(workers)
  for (const outcome of outcomes) if (outcome.status === "rejected") throw outcome.reason

  const values: T[] = []
  for (const value of ordered) if (value !== undefined) values.push(value)
  return { values, peakInFlight }
}

type PiCreateBackpressureState =
  | { state: "inactive" }
  | { state: "active"; untilMs: number }
  | { state: "unavailable" }

async function readPiCreateBackpressure(now: number): Promise<PiCreateBackpressureState> {
  try {
    const value = await redis.get<unknown>(PI_CREATE_BACKPRESSURE_KEY)
    if (value === null) return { state: "inactive" }
    // Upstash deserializes the raw decimal written by the Lua writer as a
    // number. Accept that exact scalar as well as the legacy string encoding.
    const untilMs = typeof value === "number" ? value :
      typeof value === "string" && /^[0-9]+$/.test(value) ? Number(value) : NaN
    if (!Number.isSafeInteger(untilMs) || untilMs < 0) return { state: "unavailable" }
    return untilMs > now ? { state: "active", untilMs } : { state: "inactive" }
  } catch {
    return { state: "unavailable" }
  }
}

async function extendPiCreateBackpressure(nextRetryAt: string | undefined, now: number): Promise<number | null> {
  const parsedRetryAt = typeof nextRetryAt === "string" && nextRetryAt.trim() !== "" && nextRetryAt === nextRetryAt.trim() ? Date.parse(nextRetryAt) : NaN
  const candidateUntilMs = Math.max(now + PI_CREATE_BACKPRESSURE_FALLBACK_MS, Number.isFinite(parsedRetryAt) && parsedRetryAt > now ? parsedRetryAt : 0)
  try {
    const result = await redis.eval<[string, string], number>(`
local candidate=tonumber(ARGV[1])
local now=tonumber(ARGV[2])
if not candidate or not now or candidate <= now then return -1 end
local current=redis.call("GET",KEYS[1])
if current then
  local currentNumber=tonumber(current)
  if not currentNumber then return -1 end
  if currentNumber > candidate then candidate=currentNumber end
end
local ttl=math.ceil((candidate-now)/1000)
if ttl < 1 then ttl=1 end
redis.call("SET",KEYS[1],tostring(candidate),"EX",ttl)
return candidate
`, [PI_CREATE_BACKPRESSURE_KEY], [String(candidateUntilMs), String(now)])
    return Number.isSafeInteger(result) && result > now ? result : null
  } catch {
    return null
  }
}

function isPiCreateBackpressureSignal(payment: Payment): boolean {
  return payment.a2uErrorCode === "too_many_payments" || payment.a2uErrorCode === "uid_verification_429" || payment.a2uErrorCode === "a2u_rate_limited_post_ambiguous"
}

async function acquireTransientDrainLease(): Promise<DrainLease> {
  const token = randomUUID()
  try {
    const acquired = await redis.set(DRAIN_LEASE_KEY, token, { nx: true, ex: DRAIN_LEASE_TTL_SECONDS })
    if (acquired !== "OK") return { state: "busy" }
  } catch {
    return { state: "unavailable" }
  }

  let released = false
  return {
    state: "acquired",
    renew: async () => {
      if (released) return false
      try {
        const result = await redis.eval<[string, string], number>(DRAIN_LEASE_RENEW_SCRIPT, [DRAIN_LEASE_KEY], [token, String(DRAIN_LEASE_TTL_SECONDS)])
        return result === 1
      } catch {
        return false
      }
    },
    release: async () => {
      if (released) return true
      released = true
      try {
        const result = await redis.eval<[string], number>(DRAIN_LEASE_RELEASE_SCRIPT, [DRAIN_LEASE_KEY], [token])
        return result === 1
      } catch {
        return false
      }
    },
  }
}

function constantTimeSecretEqual(expected: string | undefined, provided: string | null): boolean {
  if (!expected || !provided) return false
  const expectedBuffer = Buffer.from(expected)
  const providedBuffer = Buffer.from(provided)
  if (expectedBuffer.length !== providedBuffer.length) return false
  return timingSafeEqual(expectedBuffer, providedBuffer)
}

function hasValidSecret(request: NextRequest): boolean {
  // Existing trusted internal/external scheduler authority.
  if (constantTimeSecretEqual(runtimeEnv[RECOVERY_SECRET_ENV], request.headers.get("x-flashpay-transient-recovery-secret"))) return true

  // DR-8: independent Vercel Cron authority. Vercel sends CRON_SECRET as
  // `Authorization: Bearer <CRON_SECRET>`. Keep this fail-closed when the
  // environment variable is absent; never trust a user-agent or source IP.
  const authorization = request.headers.get("authorization")
  const cronSecret = runtimeEnv.CRON_SECRET
  const cronBearer = authorization?.startsWith("Bearer ") ? authorization.slice(7) : null
  return constantTimeSecretEqual(cronSecret, cronBearer)
}


function scheduleTrustedTransientRequest(target: "drain" | "continuation-kick"): boolean {
  const recoverySecret = runtimeEnv[RECOVERY_SECRET_ENV]
  const productionHost = runtimeEnv.VERCEL_PROJECT_PRODUCTION_URL || runtimeEnv.VERCEL_URL
  if (runtimeEnv.VERCEL_ENV !== "production" || !recoverySecret || !productionHost || !/^[A-Za-z0-9.-]+$/.test(productionHost)) return false
  try {
    after(async () => {
      try {
        const url = new URL("/api/recovery/transient", `https://${productionHost}`)
        if (target === "continuation-kick") url.searchParams.set("mode", CONTINUATION_MODE)
        else url.searchParams.set("mode", IMMEDIATE_DRAIN_MODE)
        const response = await fetch(url.toString(), {
          method: "POST",
          headers: { "x-flashpay-transient-recovery-secret": recoverySecret },
          cache: "no-store",
          redirect: "error",
        })
        if (!response.ok) console.warn("[P7J12D CONTINUATION] transient request returned non-OK", { target, status: response.status })
      } catch (error) {
        console.warn("[P7J12D CONTINUATION] transient request failed", { target, error: error instanceof Error ? error.message : String(error) })
      }
    })
    return true
  } catch (error) {
    console.warn("[P7J12D CONTINUATION] scheduling failed", { target, error: error instanceof Error ? error.message : String(error) })
    return false
  }
}

function parsePayment(value: unknown): Payment | null {
  if (!value) return null
  try {
    const parsed = typeof value === "string" ? JSON.parse(value) : value
    return parsed && typeof parsed === "object" ? (parsed as Payment) : null
  } catch {
    return null
  }
}

function hasExcludedState(payment: Payment): boolean {
  return (
    payment.settlementFailureState === "held" ||
    payment.settlementFailureState === "manual_review_required" ||
    payment.settlementFailureState === "refund_pending" ||
    payment.settlementFailureState === "refunded" ||
    payment.refundStatus === "pending" ||
    payment.refundStatus === "submitted" ||
    payment.refundStatus === "completed" ||
    payment.refundStatus === "manual_review_required"
  )
}

function isReadyIndexTerminalEgressCandidate(payment: Payment): boolean {
  if (isPaymentFinal(payment)) return true
  return payment.status === "paid_to_app" && payment.settlementFailureState === "held" && payment.refundStatus === "manual_review_required"
}

function isReadyIndexReadyOnlyEgressCandidate(payment: Payment): boolean {
  if (payment.status === "pending" || payment.status === "failed" || payment.status === "cancelled" || payment.status === "settlement_failed" || payment.status === "refund_pending" || payment.status === "refunded") return true
  return (payment.status === "paid_to_app" || payment.status === "settlement_pending") && hasExcludedState(payment)
}

function readyOtherDiagnosticFingerprint(payment: Payment): string {
  const status = (() => {
    switch (payment.status as unknown) {
      case "pending":
      case "paid_to_app":
      case "settlement_pending":
      case "settled_to_merchant":
      case "settlement_failed":
      case "failed":
      case "cancelled":
      case "refund_pending":
      case "refunded":
        return payment.status
      default:
        return "unknown"
    }
  })()
  const failure = (() => {
    switch (payment.settlementFailureState as unknown) {
      case undefined:
        return "unset"
      case "none":
      case "retryable":
      case "reconciling":
      case "held":
      case "manual_review_required":
      case "refund_pending":
      case "refunded":
        return payment.settlementFailureState
      default:
        return "unknown"
    }
  })()
  const refund = (() => {
    switch (payment.refundStatus as unknown) {
      case undefined:
        return "unset"
      case "not_started":
      case "pending":
      case "submitted":
      case "completed":
      case "failed":
      case "manual_review_required":
        return payment.refundStatus
      default:
        return "unknown"
    }
  })()
  const prepared = payment.a2uPreparedEnvelopeXdr !== undefined || payment.a2uPreparedTxHash !== undefined || payment.a2uPreparedSequence !== undefined
  const refundEvidence = payment.refundPaymentId !== undefined || payment.refundTxid !== undefined || payment.refundProof !== undefined
  return [
    `status=${status}`,
    `failure=${failure}`,
    `refund=${refund}`,
    `a2uPayment=${payment.a2uPaymentId !== undefined ? 1 : 0}`,
    `a2uTxid=${payment.a2uTxid !== undefined ? 1 : 0}`,
    `prepared=${prepared ? 1 : 0}`,
    `horizon=${payment.horizonSuccessFlag === true ? 1 : 0}`,
    `piPending=${payment.piCompletionPending === true ? 1 : 0}`,
    `piCompleted=${payment.piCompleted === true ? 1 : 0}`,
    `dbRequired=${payment.requiresDbReconciliation === true ? 1 : 0}`,
    `dbRecorded=${payment.dbRecorded === true ? 1 : 0}`,
    `refundEligible=${payment.payerRefundEligible === true ? 1 : 0}`,
    `refundEvidence=${refundEvidence ? 1 : 0}`,
  ].join("|")
}


function hasSettlementMerchantProjectionAuthority(payment: Payment): boolean {
  if (typeof payment.accessToken !== "string") return false
  // Non-empty token = normal authenticated projection. Empty string is the exact
  // F2-3 total-Redis-loss placeholder and is only executable after F2-4 durable
  // PostgreSQL + Pi proof inside the shared payment-operation lock.
  return payment.accessToken === "" || (payment.accessToken.trim() !== "" && payment.accessToken === payment.accessToken.trim())
}

function readyOtherFreshPrerequisiteFingerprint(payment: Payment, now: number): string {
  const missing: string[] = []
  const dispatchAt = typeof payment.settlementDispatchRequestedAt === "string" && payment.settlementDispatchRequestedAt.trim() !== "" && payment.settlementDispatchRequestedAt === payment.settlementDispatchRequestedAt.trim() ? Date.parse(payment.settlementDispatchRequestedAt) : NaN
  const paidAt = typeof payment.paidAt === "string" && payment.paidAt.trim() !== "" && payment.paidAt === payment.paidAt.trim() ? Date.parse(payment.paidAt) : NaN
  if (!(Number.isFinite(dispatchAt) && Number.isFinite(paidAt) && dispatchAt === paidAt && dispatchAt <= now)) missing.push("dispatch")
  if (!(typeof payment.amount === "number" && Number.isFinite(payment.amount) && payment.amount > 0 && typeof payment.customerAmount === "number" && Number.isFinite(payment.customerAmount) && payment.customerAmount > 0 && payment.amount === payment.customerAmount)) missing.push("amount")
  if (!(typeof payment.piPaymentId === "string" && payment.piPaymentId.trim() !== "" && payment.piPaymentId === payment.piPaymentId.trim())) missing.push("piId")
  if (!(typeof payment.merchantId === "string" && payment.merchantId.trim() !== "" && payment.merchantId === payment.merchantId.trim())) missing.push("merchantId")
  if (!(typeof payment.merchantUid === "string" && payment.merchantUid.trim() !== "" && payment.merchantUid === payment.merchantUid.trim())) missing.push("merchantUid")
  if (!hasSettlementMerchantProjectionAuthority(payment)) missing.push("merchantAuthority")
  if (!(typeof payment.payerUid === "string" && payment.payerUid.trim() !== "" && payment.payerUid === payment.payerUid.trim())) missing.push("payerUid")
  if (payment.payerUidSource !== "verified_u2a") missing.push("payerSource")
  if (!(typeof payment.payerUidCapturedAt === "string" && payment.payerUidCapturedAt.trim() !== "" && payment.payerUidCapturedAt === payment.payerUidCapturedAt.trim() && Number.isFinite(Date.parse(payment.payerUidCapturedAt)) && Date.parse(payment.payerUidCapturedAt) <= now)) missing.push("payerAt")
  if (!(typeof payment.u2aTxid === "string" && payment.u2aTxid === payment.u2aTxid.trim() && /^[0-9a-f]{64}$/.test(payment.u2aTxid))) missing.push("u2aTxid")
  return missing.length === 0 ? "none" : missing.join(",")
}


const LEGACY_READY_QUARANTINE_LIMIT = 5
const LEGACY_READY_CAPTURE_LAG_MS = 5 * 60_000

function asRecord(value: unknown): Record<string, unknown> | null {
  return value !== null && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : null
}

function hasNoSettlementOrRefundMovementEvidence(payment: Payment): boolean {
  return payment.a2uPaymentId === undefined && payment.a2uTxid === undefined && payment.a2uPreparedEnvelopeXdr === undefined && payment.a2uPreparedTxHash === undefined && payment.a2uPreparedSequence === undefined &&
    payment.horizonSuccessFlag !== true && payment.piCompletionPending !== true && payment.piCompleted !== true && payment.requiresDbReconciliation !== true && payment.dbRecorded !== true &&
    payment.refundPaymentId === undefined && payment.refundTxid === undefined && payment.refundProof === undefined
}

function isLegacyReadyUnrepairedCandidate(payment: Payment, now: number): boolean {
  return payment.status === "paid_to_app" &&
    readyOtherFreshPrerequisiteFingerprint(payment, now) === "dispatch,payerUid,payerSource,payerAt" &&
    payment.settlementFailureState === undefined && payment.refundStatus === undefined &&
    hasNoSettlementOrRefundMovementEvidence(payment)
}

function isLegacyReadyPreviouslyRepairedCandidate(payment: Payment, now: number): boolean {
  const paidAt = typeof payment.paidAt === "string" && payment.paidAt.trim() !== "" && payment.paidAt === payment.paidAt.trim() ? Date.parse(payment.paidAt) : NaN
  const capturedAt = typeof payment.payerUidCapturedAt === "string" && payment.payerUidCapturedAt.trim() !== "" && payment.payerUidCapturedAt === payment.payerUidCapturedAt.trim() ? Date.parse(payment.payerUidCapturedAt) : NaN
  return payment.status === "paid_to_app" &&
    typeof payment.settlementDispatchRequestedAt === "string" && payment.settlementDispatchRequestedAt === payment.paidAt &&
    typeof payment.payerUid === "string" && payment.payerUid.trim() !== "" && payment.payerUid === payment.payerUid.trim() && payment.payerUidSource === "verified_u2a" &&
    Number.isFinite(paidAt) && Number.isFinite(capturedAt) && capturedAt <= now && capturedAt - paidAt >= LEGACY_READY_CAPTURE_LAG_MS &&
    payment.settlementFailureState === undefined && payment.refundStatus === undefined && payment.retryCount === undefined && payment.lastAttemptAt === undefined && payment.nextRetryAt === undefined &&
    hasNoSettlementOrRefundMovementEvidence(payment)
}

async function quarantinePreviouslyRepairedLegacyReadyCandidate(paymentId: string): Promise<boolean> {
  const raw = await redis.get(`payment:${paymentId}`)
  const payment = parsePayment(raw)
  const now = Date.now()
  if (!payment || payment.id !== paymentId || !isLegacyReadyPreviouslyRepairedCandidate(payment, now)) return false
  const result = await redis.eval<[string], number>(`
local latest=redis.call('GET',KEYS[1]); if not latest then return 0 end
local ok,current=pcall(cjson.decode,latest); if not ok or type(current)~='table' then return 0 end
if current.id~=ARGV[1] or current.status~='paid_to_app' then return 0 end
if current.settlementFailureState~=nil or current.refundStatus~=nil or current.retryCount~=nil or current.lastAttemptAt~=nil or current.nextRetryAt~=nil then return 0 end
if current.payerUidSource~='verified_u2a' or current.payerUid==nil or current.payerUidCapturedAt==nil or current.paidAt==nil or current.settlementDispatchRequestedAt~=current.paidAt then return 0 end
if current.a2uPaymentId~=nil or current.a2uTxid~=nil or current.a2uPreparedEnvelopeXdr~=nil or current.a2uPreparedTxHash~=nil or current.a2uPreparedSequence~=nil then return 0 end
if current.horizonSuccessFlag==true or current.piCompletionPending==true or current.piCompleted==true or current.requiresDbReconciliation==true or current.dbRecorded==true then return 0 end
if current.refundPaymentId~=nil or current.refundTxid~=nil or current.refundProof~=nil then return 0 end
local projectionVersion=current.redisProjectionVersion; if projectionVersion==nil then projectionVersion=0 end
if type(projectionVersion)~='number' or projectionVersion<0 or projectionVersion~=math.floor(projectionVersion) then return 0 end
current.settlementDispatchRequestedAt=nil; current.settlementFailureState='held'; current.refundStatus='manual_review_required'; current.a2uErrorCode='legacy_merchant_authority_reverification_required'; current.a2uErrorMessage='Legacy merchant authorization must be reverified before settlement'; current.redisProjectionVersion=projectionVersion+1
redis.call('SET',KEYS[1],cjson.encode(current)); redis.call('SREM',KEYS[2],ARGV[1]); redis.call('ZREM',KEYS[3],ARGV[1]); return 1
`, [`payment:${paymentId}`, "flashpay:recovery:active-payments:v1", "flashpay:settlement:ready:v1"], [paymentId])
  return result === 1
}

async function quarantineLegacyReadyCandidate(paymentId: string): Promise<boolean> {
  const alreadyRepaired = await quarantinePreviouslyRepairedLegacyReadyCandidate(paymentId)
  if (alreadyRepaired) return true
  if (!serverConfig.isPiApiKeyConfigured) return false
  const raw = await redis.get(`payment:${paymentId}`)
  const payment = parsePayment(raw)
  const now = Date.now()
  if (!payment || payment.id !== paymentId || !isLegacyReadyUnrepairedCandidate(payment, now)) return false
  const piPaymentId = payment.piPaymentId
  const u2aTxid = payment.u2aTxid
  const paidAt = payment.paidAt
  if (typeof piPaymentId !== "string" || typeof u2aTxid !== "string" || typeof paidAt !== "string") return false
  let response: Response
  try {
    response = await fetch(`https://api.minepi.com/v2/payments/${encodeURIComponent(piPaymentId)}`, {
      method: "GET",
      headers: { Authorization: `Key ${serverConfig.piApiKey}`, "Content-Type": "application/json" },
      cache: "no-store",
    })
  } catch {
    return false
  }
  if (!response.ok) return false
  const dto = asRecord(await response.json().catch(() => null))
  const status = dto ? asRecord(dto.status) : null
  const transaction = dto ? asRecord(dto.transaction) : null
  const metadata = dto ? asRecord(dto.metadata) : null
  const user = dto ? asRecord(dto.user) : null
  const payerUid = typeof dto?.user_uid === "string" ? dto.user_uid : typeof user?.uid === "string" ? user.uid : null
  const authoritative = dto !== null &&
    dto.identifier === piPaymentId && dto.direction === "user_to_app" &&
    typeof dto.amount === "number" && dto.amount === payment.customerAmount && dto.amount === payment.amount &&
    metadata?.paymentId === paymentId && transaction?.txid === u2aTxid &&
    status?.transaction_verified === true && status?.developer_completed === true && status?.cancelled !== true && status?.user_cancelled !== true &&
    typeof payerUid === "string" && payerUid.trim() !== "" && payerUid === payerUid.trim()
  if (!authoritative || payerUid === null) return false
  const capturedAt = new Date().toISOString()
  const result = await redis.eval<[string, string, string, string, string, string], number>(`
local latest=redis.call('GET',KEYS[1]); if not latest then return 0 end
local ok,current=pcall(cjson.decode,latest); if not ok or type(current)~='table' then return 0 end
if current.id~=ARGV[1] or current.status~='paid_to_app' then return 0 end
if current.piPaymentId~=ARGV[2] or current.u2aTxid~=ARGV[3] or current.paidAt~=ARGV[4] then return 0 end
if current.payerUid~=nil or current.payerUidSource~=nil or current.payerUidCapturedAt~=nil or current.settlementDispatchRequestedAt~=nil then return 0 end
if current.settlementFailureState~=nil or current.refundStatus~=nil then return 0 end
if current.a2uPaymentId~=nil or current.a2uTxid~=nil or current.a2uPreparedEnvelopeXdr~=nil or current.a2uPreparedTxHash~=nil or current.a2uPreparedSequence~=nil then return 0 end
if current.horizonSuccessFlag==true or current.piCompletionPending==true or current.piCompleted==true or current.requiresDbReconciliation==true or current.dbRecorded==true then return 0 end
if current.refundPaymentId~=nil or current.refundTxid~=nil or current.refundProof~=nil then return 0 end
local projectionVersion=current.redisProjectionVersion; if projectionVersion==nil then projectionVersion=0 end
if type(projectionVersion)~='number' or projectionVersion<0 or projectionVersion~=math.floor(projectionVersion) then return 0 end
current.payerUid=ARGV[5]; current.payerUidSource='verified_u2a'; current.payerUidCapturedAt=ARGV[6]; current.settlementFailureState='held'; current.refundStatus='manual_review_required'; current.a2uErrorCode='legacy_merchant_authority_reverification_required'; current.a2uErrorMessage='Legacy merchant authorization must be reverified before settlement'; current.redisProjectionVersion=projectionVersion+1
redis.call('SET',KEYS[1],cjson.encode(current)); redis.call('SREM',KEYS[2],ARGV[1]); redis.call('ZREM',KEYS[3],ARGV[1]); return 1
`, [`payment:${paymentId}`, "flashpay:recovery:active-payments:v1", "flashpay:settlement:ready:v1"], [paymentId, piPaymentId, u2aTxid, paidAt, payerUid, capturedAt])
  return result === 1
}

function isPiA2USlotReleasedForDbPending(payment: Payment | null): payment is Payment {
  if (payment === null) return false
  const a2uPaymentIdValid = typeof payment.a2uPaymentId === "string" && payment.a2uPaymentId.trim() !== "" && payment.a2uPaymentId === payment.a2uPaymentId.trim()
  const a2uTxidValid = typeof payment.a2uTxid === "string" && /^[0-9a-f]{64}$/.test(payment.a2uTxid)
  const amountsValid = typeof payment.customerAmount === "number" && Number.isFinite(payment.customerAmount) && payment.customerAmount > 0 && typeof payment.merchantAmount === "number" && Number.isFinite(payment.merchantAmount) && payment.merchantAmount === payment.customerAmount
  const feeValid = typeof payment.horizonFeeCharged === "number" && Number.isFinite(payment.horizonFeeCharged) && payment.horizonFeeCharged >= 0
  const netValid = payment.appCommission === 0 && typeof payment.appNetImpact === "number" && Number.isFinite(payment.appNetImpact) && amountsValid && feeValid && payment.appNetImpact === payment.customerAmount! - payment.merchantAmount! - payment.horizonFeeCharged!
  return payment.status === "settlement_pending" && payment.piCompleted === true && payment.piCompletionPending === false && payment.horizonSuccessFlag === true && payment.requiresDbReconciliation === true && payment.dbRecorded !== true && a2uPaymentIdValid && a2uTxidValid && amountsValid && feeValid && netValid
}

function isFreshSettlementDispatchCandidate(payment: Payment, now: number): boolean {
  if (isLegacyReadyPreviouslyRepairedCandidate(payment, now)) return false
  const dispatchAt = typeof payment.settlementDispatchRequestedAt === "string" && payment.settlementDispatchRequestedAt.trim() !== "" && payment.settlementDispatchRequestedAt === payment.settlementDispatchRequestedAt.trim() ? Date.parse(payment.settlementDispatchRequestedAt) : NaN
  const paidAt = typeof payment.paidAt === "string" && payment.paidAt.trim() !== "" && payment.paidAt === payment.paidAt.trim() ? Date.parse(payment.paidAt) : NaN
  const u2aTxid = payment.u2aTxid
  return (
    payment.status === "paid_to_app" &&
    typeof payment.settlementDispatchRequestedAt === "string" && typeof payment.paidAt === "string" &&
    Number.isFinite(dispatchAt) && Number.isFinite(paidAt) && dispatchAt === paidAt && dispatchAt <= now &&
    typeof payment.amount === "number" && Number.isFinite(payment.amount) && payment.amount > 0 &&
    typeof payment.customerAmount === "number" && Number.isFinite(payment.customerAmount) && payment.customerAmount > 0 && payment.amount === payment.customerAmount &&
    typeof payment.piPaymentId === "string" && payment.piPaymentId.trim() !== "" && payment.piPaymentId === payment.piPaymentId.trim() &&
    typeof payment.merchantId === "string" && payment.merchantId.trim() !== "" && payment.merchantId === payment.merchantId.trim() &&
    typeof payment.merchantUid === "string" && payment.merchantUid.trim() !== "" && payment.merchantUid === payment.merchantUid.trim() &&
    hasSettlementMerchantProjectionAuthority(payment) &&
    typeof payment.payerUid === "string" && payment.payerUid.trim() !== "" && payment.payerUid === payment.payerUid.trim() &&
    payment.payerUidSource === "verified_u2a" &&
    typeof payment.payerUidCapturedAt === "string" && payment.payerUidCapturedAt.trim() !== "" && payment.payerUidCapturedAt === payment.payerUidCapturedAt.trim() && Number.isFinite(Date.parse(payment.payerUidCapturedAt)) && Date.parse(payment.payerUidCapturedAt) <= now &&
    typeof u2aTxid === "string" && u2aTxid === u2aTxid.trim() && /^[0-9a-f]{64}$/.test(u2aTxid) &&
    payment.a2uTxid === undefined &&
    payment.settlementFailureState === undefined && payment.retryCount === undefined && payment.lastAttemptAt === undefined && payment.nextRetryAt === undefined &&
    payment.a2uPaymentId === undefined && payment.a2uPreparedEnvelopeXdr === undefined && payment.a2uPreparedTxHash === undefined && payment.a2uPreparedSequence === undefined && payment.a2uFromAddress === undefined && payment.a2uToAddress === undefined &&
    payment.merchantAmount === undefined && payment.horizonFeeCharged === undefined && payment.appCommission === undefined && payment.appNetImpact === undefined && payment.a2uErrorCode === undefined && payment.a2uErrorMessage === undefined && payment.a2uErrorBody === undefined && payment.horizonSuccessAt === undefined && payment.settledAt === undefined &&
    payment.refundPaymentId === undefined && payment.refundTxid === undefined && payment.refundStatus === undefined && payment.refundFailureCode === undefined && payment.refundProof === undefined && payment.payerRefundEligible !== true &&
    payment.horizonSuccessFlag !== true && payment.piCompletionPending !== true && payment.piCompleted !== true && payment.requiresDbReconciliation !== true && payment.dbRecorded !== true &&
    !hasExcludedState(payment)
  )
}

function isStaleFreshReconcilingCandidate(payment: Payment, now: number): boolean {
  const lastAttemptAt = typeof payment.lastAttemptAt === "string" && payment.lastAttemptAt.trim() !== "" && payment.lastAttemptAt === payment.lastAttemptAt.trim() ? Date.parse(payment.lastAttemptAt) : NaN
  const dispatchAt = typeof payment.settlementDispatchRequestedAt === "string" && payment.settlementDispatchRequestedAt.trim() !== "" && payment.settlementDispatchRequestedAt === payment.settlementDispatchRequestedAt.trim() ? Date.parse(payment.settlementDispatchRequestedAt) : NaN
  const paidAt = typeof payment.paidAt === "string" && payment.paidAt.trim() !== "" && payment.paidAt === payment.paidAt.trim() ? Date.parse(payment.paidAt) : NaN
  const u2aTxid = payment.u2aTxid
  return (
    payment.status === "paid_to_app" &&
    typeof payment.settlementDispatchRequestedAt === "string" && typeof payment.paidAt === "string" &&
    Number.isFinite(dispatchAt) && Number.isFinite(paidAt) && dispatchAt === paidAt && dispatchAt <= now &&
    typeof payment.amount === "number" && Number.isFinite(payment.amount) && payment.amount > 0 &&
    typeof payment.customerAmount === "number" && Number.isFinite(payment.customerAmount) && payment.customerAmount > 0 && payment.amount === payment.customerAmount &&
    typeof payment.piPaymentId === "string" && payment.piPaymentId.trim() !== "" && payment.piPaymentId === payment.piPaymentId.trim() &&
    typeof payment.merchantId === "string" && payment.merchantId.trim() !== "" && payment.merchantId === payment.merchantId.trim() &&
    typeof payment.merchantUid === "string" && payment.merchantUid.trim() !== "" && payment.merchantUid === payment.merchantUid.trim() &&
    hasSettlementMerchantProjectionAuthority(payment) &&
    typeof payment.payerUid === "string" && payment.payerUid.trim() !== "" && payment.payerUid === payment.payerUid.trim() &&
    payment.payerUidSource === "verified_u2a" &&
    typeof payment.payerUidCapturedAt === "string" && payment.payerUidCapturedAt.trim() !== "" && payment.payerUidCapturedAt === payment.payerUidCapturedAt.trim() && Number.isFinite(Date.parse(payment.payerUidCapturedAt)) && Date.parse(payment.payerUidCapturedAt) <= now &&
    typeof u2aTxid === "string" && u2aTxid === u2aTxid.trim() && /^[0-9a-f]{64}$/.test(u2aTxid) &&
    payment.a2uTxid === undefined &&
    payment.settlementFailureState === "reconciling" && payment.retryCount === 1 && payment.nextRetryAt === undefined &&
    Number.isFinite(lastAttemptAt) && lastAttemptAt <= now - 660000 &&
    payment.a2uPaymentId === undefined && payment.a2uPreparedEnvelopeXdr === undefined && payment.a2uPreparedTxHash === undefined && payment.a2uPreparedSequence === undefined && payment.a2uFromAddress === undefined && payment.a2uToAddress === undefined &&
    payment.merchantAmount === undefined && payment.horizonFeeCharged === undefined && payment.appCommission === undefined && payment.appNetImpact === undefined && payment.a2uErrorCode === undefined && payment.a2uErrorMessage === undefined && payment.a2uErrorBody === undefined && payment.horizonSuccessAt === undefined && payment.settledAt === undefined &&
    payment.refundPaymentId === undefined && payment.refundTxid === undefined && payment.refundStatus === undefined && payment.refundFailureCode === undefined && payment.refundProof === undefined && payment.payerRefundEligible !== true &&
    payment.horizonSuccessFlag !== true && payment.piCompletionPending !== true && payment.piCompleted !== true && payment.requiresDbReconciliation !== true && payment.dbRecorded !== true &&
    !hasExcludedState(payment)
  )
}

function isStaleRetryReconcilingCandidate(payment: Payment, now: number): boolean {
  const lastAttemptAt = typeof payment.lastAttemptAt === "string" && payment.lastAttemptAt.trim() !== "" && payment.lastAttemptAt === payment.lastAttemptAt.trim() ? Date.parse(payment.lastAttemptAt) : NaN
  const nextRetryAt = typeof payment.nextRetryAt === "string" && payment.nextRetryAt.trim() !== "" && payment.nextRetryAt === payment.nextRetryAt.trim() ? Date.parse(payment.nextRetryAt) : NaN
  const dispatchAt = typeof payment.settlementDispatchRequestedAt === "string" && payment.settlementDispatchRequestedAt.trim() !== "" && payment.settlementDispatchRequestedAt === payment.settlementDispatchRequestedAt.trim() ? Date.parse(payment.settlementDispatchRequestedAt) : NaN
  const paidAt = typeof payment.paidAt === "string" && payment.paidAt.trim() !== "" && payment.paidAt === payment.paidAt.trim() ? Date.parse(payment.paidAt) : NaN
  const u2aTxid = payment.u2aTxid
  return (
    payment.status === "paid_to_app" &&
    typeof payment.settlementDispatchRequestedAt === "string" && typeof payment.paidAt === "string" &&
    Number.isFinite(dispatchAt) && Number.isFinite(paidAt) && dispatchAt === paidAt && dispatchAt <= now &&
    typeof payment.amount === "number" && Number.isFinite(payment.amount) && payment.amount > 0 &&
    typeof payment.customerAmount === "number" && Number.isFinite(payment.customerAmount) && payment.customerAmount > 0 && payment.amount === payment.customerAmount &&
    typeof payment.piPaymentId === "string" && payment.piPaymentId.trim() !== "" && payment.piPaymentId === payment.piPaymentId.trim() &&
    typeof payment.merchantId === "string" && payment.merchantId.trim() !== "" && payment.merchantId === payment.merchantId.trim() &&
    typeof payment.merchantUid === "string" && payment.merchantUid.trim() !== "" && payment.merchantUid === payment.merchantUid.trim() &&
    hasSettlementMerchantProjectionAuthority(payment) &&
    typeof payment.payerUid === "string" && payment.payerUid.trim() !== "" && payment.payerUid === payment.payerUid.trim() &&
    payment.payerUidSource === "verified_u2a" &&
    typeof payment.payerUidCapturedAt === "string" && payment.payerUidCapturedAt.trim() !== "" && payment.payerUidCapturedAt === payment.payerUidCapturedAt.trim() && Number.isFinite(Date.parse(payment.payerUidCapturedAt)) && Date.parse(payment.payerUidCapturedAt) <= now &&
    typeof u2aTxid === "string" && u2aTxid === u2aTxid.trim() && /^[0-9a-f]{64}$/.test(u2aTxid) &&
    payment.a2uTxid === undefined &&
    payment.settlementFailureState === "reconciling" && typeof payment.retryCount === "number" && Number.isInteger(payment.retryCount) && payment.retryCount >= 2 &&
    Number.isFinite(lastAttemptAt) && lastAttemptAt <= now - 660000 && Number.isFinite(nextRetryAt) && nextRetryAt <= lastAttemptAt &&
    payment.a2uPaymentId === undefined && payment.a2uPreparedEnvelopeXdr === undefined && payment.a2uPreparedTxHash === undefined && payment.a2uPreparedSequence === undefined && payment.a2uFromAddress === undefined && payment.a2uToAddress === undefined &&
    payment.merchantAmount === undefined && payment.horizonFeeCharged === undefined && payment.appCommission === undefined && payment.appNetImpact === undefined && (payment.a2uErrorCode === undefined || typeof payment.a2uErrorCode === "string" && payment.a2uErrorCode.trim() !== "") && (payment.a2uErrorMessage === undefined || typeof payment.a2uErrorMessage === "string" && payment.a2uErrorMessage.trim() !== "") && (payment.a2uErrorBody === undefined || typeof payment.a2uErrorBody === "string" && payment.a2uErrorBody.trim() !== "") && payment.horizonSuccessAt === undefined && payment.settledAt === undefined &&
    payment.refundPaymentId === undefined && payment.refundTxid === undefined && (payment.refundStatus === undefined || payment.refundStatus === "not_started") && payment.refundFailureCode === undefined && payment.refundProof === undefined && payment.payerRefundEligible !== true &&
    payment.horizonSuccessFlag !== true && payment.piCompletionPending !== true && payment.piCompleted !== true && payment.requiresDbReconciliation !== true && payment.dbRecorded !== true &&
    !hasExcludedState(payment)
  )
}

function isPreparedSubmitEligible(payment: Payment): boolean {
  return (
    payment.status === "settlement_pending" &&
    typeof payment.a2uPaymentId === "string" && payment.a2uPaymentId.trim() !== "" && payment.a2uPaymentId === payment.a2uPaymentId.trim() &&
    typeof payment.a2uPreparedEnvelopeXdr === "string" && payment.a2uPreparedEnvelopeXdr.trim() !== "" && payment.a2uPreparedEnvelopeXdr === payment.a2uPreparedEnvelopeXdr.trim() &&
    typeof payment.a2uFromAddress === "string" && payment.a2uFromAddress.trim() !== "" && payment.a2uFromAddress === payment.a2uFromAddress.trim() &&
    typeof payment.a2uToAddress === "string" && payment.a2uToAddress.trim() !== "" && payment.a2uToAddress === payment.a2uToAddress.trim() &&
    typeof payment.a2uPreparedTxHash === "string" && /^[0-9a-f]{64}$/.test(payment.a2uPreparedTxHash) && payment.a2uPreparedTxHash === payment.a2uPreparedTxHash.trim() &&
    typeof payment.a2uPreparedSequence === "string" && /^[1-9][0-9]*$/.test(payment.a2uPreparedSequence) &&
    typeof payment.customerAmount === "number" && Number.isFinite(payment.customerAmount) && payment.customerAmount > 0 &&
    typeof payment.merchantAmount === "number" && Number.isFinite(payment.merchantAmount) && payment.merchantAmount > 0 &&
    payment.a2uTxid === undefined &&
    payment.horizonSuccessFlag !== true &&
    payment.piCompletionPending !== true &&
    payment.piCompleted !== true &&
    payment.requiresDbReconciliation !== true &&
    payment.dbRecorded !== true &&
    payment.refundPaymentId === undefined &&
    payment.refundTxid === undefined &&
    (payment.refundStatus === undefined || payment.refundStatus === "not_started") &&
    !hasExcludedState(payment)
  )
}

function isEligible(payment: Payment, now: number): boolean {
  const nextRetryAt = payment.nextRetryAt ? Date.parse(payment.nextRetryAt) : NaN

  return (
    payment.status === "paid_to_app" &&
    payment.settlementFailureState === "retryable" &&
    typeof payment.retryCount === "number" &&
    Number.isFinite(payment.retryCount) &&
    payment.retryCount > 0 &&
    Number.isFinite(nextRetryAt) &&
    nextRetryAt <= now &&
    !payment.a2uTxid &&
    payment.horizonSuccessFlag !== true &&
    !hasExcludedState(payment)
  )
}

function isPostHorizonEligible(payment: Payment, now: number): boolean {
  const nextRetryAt = payment.nextRetryAt === undefined ? now : typeof payment.nextRetryAt === "string" && payment.nextRetryAt !== "" && payment.nextRetryAt === payment.nextRetryAt.trim() && Number.isFinite(Date.parse(payment.nextRetryAt)) ? Date.parse(payment.nextRetryAt) : NaN

  return (
    payment.status === "settlement_pending" &&
    Boolean(payment.a2uPaymentId) &&
    Boolean(payment.a2uTxid) &&
    payment.horizonSuccessFlag === true &&
    !hasExcludedState(payment) &&
    Number.isFinite(nextRetryAt) &&
    nextRetryAt <= now &&
    ((payment.piCompletionPending === true && payment.piCompleted !== true) ||
      (payment.piCompleted === true && payment.dbRecorded !== true))
  )
}

/** Vercel Cron invokes this configured path with GET. Preserve the existing
 * financial executor and all its guards: only a valid CRON_SECRET bearer can
 * enter through GET. QStash remains POST with its forwarded recovery secret.
 */
export async function GET(request: NextRequest) {
  const authorization = request.headers.get("authorization")
  const bearer = authorization?.startsWith("Bearer ") ? authorization.slice(7) : null
  if (!constantTimeSecretEqual(runtimeEnv.CRON_SECRET, bearer)) {
    console.warn("[TRANSIENT WAKE] cron GET rejected: authorization failed")
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
  }
  return POST(request)
}

export async function POST(request: NextRequest) {
  if (!hasValidSecret(request)) {
    // Distinguishes a delivered-but-unauthorized QStash wake from no delivery.
    // Never log the submitted token, full headers, body, or external identity.
    console.warn("[TRANSIENT WAKE] POST rejected: authorization failed")
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
  }

  // An old, delayed continuation must never enter the global drain during rollout.
  if ((process.env.FLASHPAY_RECOVERY_SCOPE === "observe_new" || process.env.FLASHPAY_RECOVERY_SCOPE === "admitted_new"))
    return NextResponse.json({ state: "global_recovery_held" }, { status: 423 })

  if (!isRedisConfigured) {
    return NextResponse.json({ error: "Redis not configured" }, { status: 500 })
  }

  const requestedMode = new URL(request.url).searchParams.get("mode")
  if (requestedMode === CONTINUATION_MODE) {
    const scheduled = scheduleTrustedTransientRequest("drain")
    return NextResponse.json({ state: scheduled ? "continuation_scheduled" : "continuation_unavailable" }, { status: scheduled ? 202 : 503 })
  }
  if (requestedMode !== null && requestedMode !== IMMEDIATE_DRAIN_MODE) return NextResponse.json({ error: "Invalid transient recovery mode" }, { status: 400 })
  const immediateDrainMode = requestedMode === IMMEDIATE_DRAIN_MODE

  const drainLease = await acquireTransientDrainLease()
  if (drainLease.state === "unavailable") return NextResponse.json({ error: "Transient drain lease unavailable" }, { status: 503 })
  if (drainLease.state === "busy") {
    console.log("[P7J5 LEASE] overlap blocked")
    return NextResponse.json({ processed: 0, state: "overlap_blocked" })
  }

  console.log("[P7J5 LEASE] acquired")
  try {
  const initialPiCreateBackpressure = await readPiCreateBackpressure(Date.now())
  let piCreateBackpressureUnavailable = initialPiCreateBackpressure.state === "unavailable"
  let piCreateBackpressureUntilMs = initialPiCreateBackpressure.state === "active" ? initialPiCreateBackpressure.untilMs : null
  const piCreateBackpressureActive = () => piCreateBackpressureUnavailable || (piCreateBackpressureUntilMs !== null && piCreateBackpressureUntilMs > Date.now())
  const registerPiCreateBackpressure = async (payment: Payment) => {
    if (!isPiCreateBackpressureSignal(payment)) return false
    const observedAt = Date.now()
    const parsedRetryAt = typeof payment.nextRetryAt === "string" && payment.nextRetryAt.trim() !== "" && payment.nextRetryAt === payment.nextRetryAt.trim() ? Date.parse(payment.nextRetryAt) : NaN
    const localUntil = Math.max(observedAt + PI_CREATE_BACKPRESSURE_FALLBACK_MS, Number.isFinite(parsedRetryAt) && parsedRetryAt > observedAt ? parsedRetryAt : 0)
    piCreateBackpressureUntilMs = piCreateBackpressureUntilMs === null ? localUntil : Math.max(piCreateBackpressureUntilMs, localUntil)
    const extended = await extendPiCreateBackpressure(payment.nextRetryAt, observedAt)
    if (extended === null) {
      piCreateBackpressureUnavailable = true
    } else {
      piCreateBackpressureUntilMs = Math.max(piCreateBackpressureUntilMs, extended)
    }
    return true
  }
  const wakeStartedAt = Date.now()
  const discoveryStartedAt = Date.now()
  let keys: string[]
  let activeSetSize = 0
  let scanStartToken = "c:0"
  let scanNextToken = "c:0"
  // N-FIN-10F + F2-3: periodic wake repairs both Stage1+ Settlement work and
  // verified pre-A2U U2A ingress from PostgreSQL authority. F2-3 performs no
  // Pi/Horizon/Settlement/Refund movement; fully lost Redis projections remain
  // execution-deferred until F2-4 removes the access-token dependency.
  let durableU2AIngressRepopulation:DurableU2AIngressRepopulation
  try {
    await repopulateDurableSettlementWork()
    durableU2AIngressRepopulation=await repopulateDurableU2AIngressWork()
  } catch (error) {
    // Financial rediscovery errors remain fatal: never bypass financial authority.
    console.error("[DR56 RECOVERY BOOTSTRAP] unavailable", { error: error instanceof Error ? error.message : String(error) })
    return NextResponse.json({ error: "Durable financial work repopulation unavailable" }, { status: 503 })
  }
  console.log("[F2-3 DURABLE REDISCOVERY]", durableU2AIngressRepopulation)

  // Merchant History is a read-side projection, not a prerequisite for the
  // PostgreSQL/Horizon-authoritative financial drain. Preserve any contradictory
  // history keys as evidence and do not certify or alter them on failure.
  // The /api/payments/history reader separately requires the bootstrap marker
  // and exact durable membership; it must continue failing closed.
  try {
    // PostgreSQL membership and original-time coverage are separate facts.
    // Never set the Redis "done" certification for incomplete chronology.
    const coverage = await readMerchantHistoryCoverage()
    if (!coverage.completeChronology) {
      const existingMarker = await redis.get(MERCHANT_HISTORY_BOOTSTRAP_KEY)
      if (existingMarker !== null && existingMarker !== "done")
        throw new Error("Merchant history bootstrap marker contradictory")
      // A pre-existing "done" marker is NOT trusted as proof of history coverage.
      // Retain it unchanged for forensic review, and do not write any index keys.
      console.warn("[DR56 MERCHANT HISTORY RECOVERY] original time evidence incomplete; no history certification", {
        durableCheckpointIdentities: coverage.totalCheckpointIdentities,
        certifiedOriginalTimes: coverage.originalTimeCertified,
        missingOriginalTimes: coverage.originalTimeMissing,
        existingMarkerPresent: existingMarker === "done",
        financialAuthorityMutated: false,
      })
    } else {
      const merchantHistoryRecovery: MerchantHistoryRecovery = await recoverMerchantHistoryProjectionAfterRedisLoss()
      console.log("[DR56 MERCHANT HISTORY RECOVERY]", merchantHistoryRecovery)
    }
  } catch (error) {
    console.error("[DR56 MERCHANT HISTORY RECOVERY] unavailable; financial wake continues", {
      error: error instanceof Error ? error.message : String(error),
    })
  }

  let readyBaselineAlreadyCertified = false
  let readyBaselineCoverageCertified = false
  try {
    const markers = await Promise.all([
      redis.get("flashpay:recovery:active-payments:v1:bootstrap"),
      redis.get("flashpay:recovery:active-payments:v1:prune-pending"),
      redis.get("flashpay:recovery:active-payments:v1:prune-final-settlement"),
    ])
    // DR-10: these three keys are legacy Redis bootstrap certificates, not financial authority.
    // A total Redis loss legitimately removes them. PostgreSQL durable rediscovery above
    // reconstructs financial work, and the exact ready-baseline certification below
    // re-certifies the rebuilt Redis indexes. Reject only contradictory marker values.
    if (markers.some((marker) => marker !== null && marker !== "done")) return NextResponse.json({ error: "Active recovery index not ready" }, { status: 503 })

    const storedCursor = await redis.get("flashpay:recovery:active-payments:v1:scan-cursor")
    if (storedCursor !== null && (typeof storedCursor !== "string" || !/^c:[0-9]+$/.test(storedCursor))) return NextResponse.json({ error: "Active recovery index unavailable" }, { status: 503 })
    const [storedReadyBaseline, storedReadyBaselineCoverage] = await Promise.all([
      redis.get("flashpay:settlement:ready:v1:authority-baseline"),
      redis.get(READY_BASELINE_COVERAGE_KEY),
    ])
    if (storedReadyBaseline !== null && storedReadyBaseline !== "done") return NextResponse.json({ error: "Settlement ready authority unavailable" }, { status: 503 })
    if (storedReadyBaselineCoverage !== null && storedReadyBaselineCoverage !== "done") return NextResponse.json({ error: "Settlement ready authority unavailable" }, { status: 503 })
    readyBaselineAlreadyCertified = storedReadyBaseline === "done"
    readyBaselineCoverageCertified = readyBaselineAlreadyCertified || storedReadyBaselineCoverage === "done"
    scanStartToken = storedCursor ?? "c:0"
    if (!readyBaselineCoverageCertified && scanStartToken === "c:0") {
      try { await redis.del(READY_BASELINE_SCAN_SEEN_KEY) } catch { return NextResponse.json({ error: "Active recovery index unavailable" }, { status: 503 }) }
    }
    let pageCursor = scanStartToken.slice(2)
    const activePaymentIds: string[] = []
    const seenActivePaymentIds = new Set<string>()
    for (let page = 0; page < 4; page += 1) {
      const scanResult = await redis.sscan("flashpay:recovery:active-payments:v1", pageCursor, { count: 200 })
      if (!Array.isArray(scanResult) || scanResult.length !== 2) return NextResponse.json({ error: "Active recovery index unavailable" }, { status: 503 })
      const [nextCursor, members] = scanResult
      if (typeof nextCursor !== "string" || !/^[0-9]+$/.test(nextCursor) || !Array.isArray(members)) return NextResponse.json({ error: "Active recovery index unavailable" }, { status: 503 })
      for (const member of members) {
        if (typeof member !== "string" || member.length === 0 || member !== member.trim()) return NextResponse.json({ error: "Active recovery index unavailable" }, { status: 503 })
        if (!seenActivePaymentIds.has(member)) {
          seenActivePaymentIds.add(member)
          activePaymentIds.push(member)
        }
      }
      pageCursor = nextCursor
      scanNextToken = `c:${nextCursor}`
      if (nextCursor === "0") break
    }
    activeSetSize = Number(await redis.scard("flashpay:recovery:active-payments:v1"))
    keys = activePaymentIds.map((paymentId) => `payment:${paymentId}`)
  } catch {
    return NextResponse.json({ error: "Active recovery index unavailable" }, { status: 503 })
  }
  const readyResidencyIds: string[] = []
  let readyResidencyCount: number | null = null
  let readyResidencyMissing: number | null = null
  let readyResidencySourceValid = true
  const postHorizonIds: string[] = []
  const preparedSubmitIds: string[] = []
  const retryableIds: string[] = []
  const freshDispatchIds: string[] = []
  const settlementReconcilingDiscoveryIds: string[] = []
  const staleRetryReconcilingDiscoveryIds: string[] = []
  const refundCandidateIds: string[] = []
  const now = Date.now()

  for (let index = 0; index < keys.length; index += 200) {
    const batchKeys = keys.slice(index, index + 200)
    let values: unknown[]
    try {
      const batchValues = await redis.mget<unknown[]>(batchKeys)
      if (!Array.isArray(batchValues) || batchValues.length !== batchKeys.length) return NextResponse.json({ error: "Active recovery index unavailable" }, { status: 503 })
      values = batchValues
    } catch {
      return NextResponse.json({ error: "Active recovery index unavailable" }, { status: 503 })
    }

    for (let valueIndex = 0; valueIndex < batchKeys.length; valueIndex += 1) {
      const key = batchKeys[valueIndex]
      const payment = parsePayment(values[valueIndex])
      if (!payment) {
        readyResidencySourceValid = false
        continue
      }

      const paymentId = key.slice("payment:".length)
      if (payment.id === paymentId && checkRefundEligibility(payment)) {
        refundCandidateIds.push(paymentId)
      }
      if (payment.id !== paymentId) {
        readyResidencySourceValid = false
        continue
      }
      if ((payment.status === "paid_to_app" || payment.status === "settlement_pending") && !hasExcludedState(payment)) readyResidencyIds.push(paymentId)
      if (isFreshSettlementDispatchCandidate(payment, now) || isStage1OnlySettlementDispatchCandidate(payment, now)) freshDispatchIds.push(paymentId)
      if (isStaleFreshReconcilingCandidate(payment, now)) settlementReconcilingDiscoveryIds.push(paymentId)
      if (isStaleRetryReconcilingCandidate(payment, now)) staleRetryReconcilingDiscoveryIds.push(paymentId)
      if (isPostHorizonEligible(payment, now)) {
        postHorizonIds.push(paymentId)
      } else if (isPreparedSubmitEligible(payment)) {
        preparedSubmitIds.push(paymentId)
      } else if (isEligible(payment, now)) {
        retryableIds.push(paymentId)
      }
    }
  }
  const readyCoverageAllIds = [...new Set([...postHorizonIds, ...preparedSubmitIds, ...retryableIds, ...freshDispatchIds, ...settlementReconcilingDiscoveryIds, ...staleRetryReconcilingDiscoveryIds])]
  const readyCoverageTruncated = readyCoverageAllIds.length > 800
  let readyCoverageIndexed: number | null = null
  let readyCoverageMissing: number | null = null
  if (readyCoverageTruncated) {
    console.warn("[P7H CAPACITY] settlement ready coverage truncated")
  } else {
    try {
      let indexed = 0
      let missing = 0
      for (let batchStart = 0; batchStart < readyCoverageAllIds.length; batchStart += 200) {
        const batch = readyCoverageAllIds.slice(batchStart, batchStart + 200)
        const scores = await redis.zmscore("flashpay:settlement:ready:v1", batch)
        if (!Array.isArray(scores) || scores.length !== batch.length || scores.some((score) => score !== null && (typeof score !== "number" || !Number.isSafeInteger(score) || score < 0))) throw new Error("Invalid settlement ready coverage")
        indexed += scores.filter((score) => score !== null).length
        missing += scores.filter((score) => score === null).length
      }
      readyCoverageIndexed = indexed
      readyCoverageMissing = missing
    } catch {
      console.warn("[P7H CAPACITY] settlement ready coverage unavailable")
    }
  }
  let readyHeadTruncated: boolean | null = null
  let readyCoverageOutsideHead: number | null = null
  const readySample = freshDispatchIds.slice(0, 200)
  let readySetSize: number | null = null
  let readyIndexed: number | null = null
  let readyMissing: number | null = null
  try {
    const indexedSetSize = await redis.zcard("flashpay:settlement:ready:v1")
    if (typeof indexedSetSize !== "number" || !Number.isSafeInteger(indexedSetSize) || indexedSetSize < 0) throw new Error("Invalid settlement ready set size")
    readySetSize = indexedSetSize
    if (readySample.length === 0) {
      readyIndexed = 0
      readyMissing = 0
    } else {
      const readyScores = await redis.zmscore("flashpay:settlement:ready:v1", readySample)
      if (!Array.isArray(readyScores) || readyScores.length !== readySample.length || readyScores.some((score) => score !== null && (typeof score !== "number" || !Number.isFinite(score) || score < 0))) throw new Error("Invalid settlement ready scores")
      readyIndexed = readyScores.filter((score) => score !== null).length
      readyMissing = readyScores.filter((score) => score === null).length
    }
  } catch {
    console.warn("[P7H CAPACITY] settlement ready telemetry unavailable")
  }
  let readyOrderedCount: number | null = null
  let readyFirstScore: number | null = null
  let readyLastScore: number | null = null
  let readyStrictlyIncreasing: boolean | null = null
  let readyOrderedValid = false
  const readyOrderedIds: string[] = []
  let readyRotationStart: string | null = null
  let readyRotationNext: string | null = null
  let readyRotationCas: number | null = null
  let readyRotationCycleMax: number | null = null
  let readyRotationCycleGeneration: number | null = null
  try {
    const storedRotation = await redis.get<unknown>("flashpay:settlement:ready:v1:authority-cursor")
    if (storedRotation !== null && typeof storedRotation !== "string") throw new Error("Invalid settlement ready authority cursor")
    const rotationStart = storedRotation ?? "r:0"
    if (!/^r:[0-9]+$/.test(rotationStart)) throw new Error("Invalid settlement ready authority cursor")
    const rotationScore = Number(rotationStart.slice(2))
    if (!Number.isSafeInteger(rotationScore) || rotationScore < 0 || rotationScore >= Number.MAX_SAFE_INTEGER) throw new Error("Invalid settlement ready authority cursor")
    const cycleStateResult = await redis.eval<[string], string>("local max=redis.call('GET',KEYS[1]); local generation=redis.call('GET',KEYS[2]); if max then local value=tonumber(max); if not value or value < 0 or value >= 9007199254740990 or value ~= math.floor(value) then return '-1' end; if generation then local gen=tonumber(generation); if not gen or gen < 0 or gen >= 9007199254740990 or gen ~= math.floor(gen) then return '-1' end else redis.call('SET',KEYS[2],'1'); generation='1' end; return max..':'..generation end; if ARGV[1] ~= 'r:0' then return '-1' end; local gen=0; if generation then gen=tonumber(generation); if not gen or gen < 0 or gen >= 9007199254740990 or gen ~= math.floor(gen) then return '-1' end end; if gen >= 9007199254740989 then return '-1' end; gen=gen+1; local top=redis.call('ZRANGE',KEYS[3],-1,-1,'WITHSCORES'); if #top ~= 0 and #top ~= 2 then return '-1' end; local base=0; if #top == 2 then local score=tonumber(top[2]); if not score or score < 0 or score >= 9007199254740990 or score ~= math.floor(score) then return '-1' end; base=score end; if base > 9007199254740990 then return '-1' end; redis.call('SET',KEYS[2],gen); redis.call('SET',KEYS[1],base); return tostring(base)..':'..tostring(gen)", ["flashpay:settlement:ready:v1:authority-cycle-max", "flashpay:settlement:ready:v1:authority-cycle-generation", "flashpay:settlement:ready:v1"], [rotationStart])
    const cycleParts = cycleStateResult.split(":")
    if (cycleParts.length !== 2 || !/^[0-9]+$/.test(cycleParts[0]) || !/^[0-9]+$/.test(cycleParts[1])) throw new Error("Invalid settlement ready authority cycle state")
    const cycleMax = Number(cycleParts[0])
    const cycleGeneration = Number(cycleParts[1])
    if (!Number.isSafeInteger(cycleMax) || cycleMax < 0 || cycleMax >= Number.MAX_SAFE_INTEGER || !Number.isSafeInteger(cycleGeneration) || cycleGeneration < 0 || cycleGeneration >= Number.MAX_SAFE_INTEGER || (rotationScore !== 0 && cycleMax < rotationScore)) throw new Error("Invalid settlement ready authority cycle state")
    readyRotationCycleMax = cycleMax
    readyRotationCycleGeneration = cycleGeneration
    const orderedIds: string[] = []
    let firstScore: number | null = null
    let strictlyIncreasing = true
    let previousScore: number | null = null
    let pageStartScore = rotationScore === 0 ? 0 : rotationScore + 1
    let headTruncated = false
    let rotationEnded = false
    for (let page = 0; page < 4; page += 1) {
      const readyOrdered = await redis.zrange("flashpay:settlement:ready:v1", pageStartScore, cycleMax, { byScore: true, withScores: true, offset: 0, count: 201 })
      if (!Array.isArray(readyOrdered) || readyOrdered.length > 402 || readyOrdered.length % 2 !== 0) throw new Error("Invalid ordered settlement ready telemetry")
      const pairCount = readyOrdered.length / 2
      if (page === 3 && pairCount === 201) headTruncated = true
      for (let index = 0; index < readyOrdered.length; index += 2) {
        const member = readyOrdered[index]
        const score = readyOrdered[index + 1]
        if (typeof member !== "string" || member.length === 0 || member !== member.trim() || typeof score !== "number" || !Number.isSafeInteger(score) || score < 1 || score < pageStartScore) throw new Error("Invalid ordered settlement ready telemetry")
        if (previousScore !== null && score <= previousScore) throw new Error("Invalid ordered settlement ready telemetry")
        if (index / 2 < 200) {
          orderedIds.push(member)
          if (firstScore === null) firstScore = score
          previousScore = score
        } else if (pairCount < 201 || previousScore === null || score <= previousScore) {
          throw new Error("Invalid ordered settlement ready telemetry")
        }
      }
      rotationEnded = pairCount <= 200
      if (rotationEnded) break
      if (previousScore === null || previousScore >= Number.MAX_SAFE_INTEGER) throw new Error("Invalid ordered settlement ready telemetry")
      pageStartScore = previousScore + 1
    }
    if (orderedIds.length > 800) throw new Error("Invalid ordered settlement ready telemetry")
    readyOrderedIds.push(...orderedIds)
    readyOrderedCount = orderedIds.length
    readyFirstScore = firstScore
    readyLastScore = previousScore
    readyStrictlyIncreasing = strictlyIncreasing
    readyHeadTruncated = headTruncated
    readyRotationStart = rotationStart
    readyRotationNext = rotationEnded ? "r:0" : `r:${previousScore}`
    readyOrderedValid = true
  } catch {
    console.warn("[P7H CAPACITY] ordered settlement ready telemetry unavailable")
  }

  if (readyOrderedValid === true && readyCoverageTruncated === false && readyCoverageMissing === 0) {
    const readyHeadIds = new Set(readyOrderedIds)
    readyCoverageOutsideHead = readyCoverageAllIds.filter((id) => !readyHeadIds.has(id)).length
  }

  let readyClassInvalid: number | null = null
  let readyClassPostHorizon: number | null = null
  let readyClassPrepared: number | null = null
  let readyClassRetryable: number | null = null
  let readyClassFresh: number | null = null
  let readyClassStage1Only: number | null = null
  let readyClassReconciling: number | null = null
  let readyClassTerminalEgress: number | null = null
  let readyTerminalEgressIds: string[] = []
  let readyClassReadyOnlyEgress: number | null = null
  let readyReadyOnlyEgressIds: string[] = []
  let readyClassOther: number | null = null
  let readyOtherDiagnosticPatterns: Record<string, number> | null = null
  let readyOtherFreshMissingPatterns: Record<string, number> | null = null
  let readyLegacyQuarantineIds: string[] = []
  let readyShadowEligibleIds: string[] | null = null
  let readyShadowPostHorizonIds: string[] | null = null
  let readyShadowPreparedIds: string[] | null = null
  let readyShadowRetryableIds: string[] | null = null
  let readyShadowFreshIds: string[] | null = null
  let readyShadowFreshCreateIds: string[] | null = null
  let readyShadowStage1OnlyIds: string[] | null = null
  let readyShadowReconcilingIds: string[] | null = null
  let walletDrainShadowCount: number | null = null
  let walletDrainShadowHeadPaymentId: string | null = null
  let walletDrainShadowHeadRefundId: string | null = null
  let walletDrainShadowHeadKind: "settlement" | "refund" | null = null
  let walletDrainSelectedHeadKind: "settlement" | "refund" | null = null
  let walletDrainSelectedHeadPaymentId: string | null = null
  let walletDrainSelectedHeadRefundId: string | null = null
  let walletDrainSelectedHeadParity: boolean | null = null
  let walletDrainNonEmptyParity: boolean | null = null
  let walletDrainNonMoneyCertification = false
  let walletDrainPreExecutionHeadKind: "settlement" | "refund" | null = null
  let walletDrainPreExecutionHeadPaymentId: string | null = null
  let walletDrainPreExecutionHeadRefundId: string | null = null
  let readyEligibleSetParity: boolean | null = null
  let readyFreshSetParity: boolean | null = null
  let readyReconcilingSetParity: boolean | null = null
  try {
    let classInvalid = 0
    const shadowPostHorizonIds: string[] = []
    const shadowPreparedIds: string[] = []
    const shadowRetryableIds: string[] = []
    const shadowFreshDispatchIds: string[] = []
    const shadowFreshCreateIds: string[] = []
    const shadowStage1OnlyIds: string[] = []
    const shadowReconcilingIds: string[] = []
    let classPostHorizon = 0
    let classPrepared = 0
    let classRetryable = 0
    let classFresh = 0
    let classStage1Only = 0
    let classReconciling = 0
    let classTerminalEgress = 0
    const terminalEgressIds: string[] = []
    let classReadyOnlyEgress = 0
    const readyOnlyEgressIds: string[] = []
    let classOther = 0
    const otherDiagnosticPatterns: Record<string, number> = {}
    const otherFreshMissingPatterns: Record<string, number> = {}
    const legacyQuarantineIds: string[] = []
    if (!readyOrderedValid) {
      throw new Error("Ordered settlement ready telemetry unavailable")
    }
    if (readyOrderedIds.length > 0) {
      for (let batchStart = 0; batchStart < readyOrderedIds.length; batchStart += 200) {
        const batchIds = readyOrderedIds.slice(batchStart, batchStart + 200)
        const readyValues = await redis.mget<unknown[]>(batchIds.map((id) => `payment:${id}`))
        if (!Array.isArray(readyValues) || readyValues.length !== batchIds.length) throw new Error("Invalid ordered settlement ready payment telemetry")
        for (let index = 0; index < batchIds.length; index += 1) {
          const payment = parsePayment(readyValues[index])
          const paymentId = batchIds[index]
          if (!payment || payment.id !== paymentId) {
            classInvalid++
          } else if (isReadyIndexTerminalEgressCandidate(payment)) {
            classTerminalEgress++
            terminalEgressIds.push(paymentId)
          } else if (isReadyIndexReadyOnlyEgressCandidate(payment)) {
            classReadyOnlyEgress++
            readyOnlyEgressIds.push(paymentId)
          } else if (isPostHorizonEligible(payment, now)) {
          classPostHorizon++
          shadowPostHorizonIds.push(paymentId)
        } else if (isPreparedSubmitEligible(payment)) {
          classPrepared++
          shadowPreparedIds.push(paymentId)
        } else if (isEligible(payment, now)) {
          classRetryable++
          shadowRetryableIds.push(paymentId)
        } else if (isFreshSettlementDispatchCandidate(payment, now)) {
          classFresh++
          shadowFreshDispatchIds.push(paymentId)
          shadowFreshCreateIds.push(paymentId)
        } else if (isStage1OnlySettlementDispatchCandidate(payment, now)) {
          classStage1Only++
          shadowFreshDispatchIds.push(paymentId)
          shadowStage1OnlyIds.push(paymentId)
        } else if (isStaleFreshReconcilingCandidate(payment, now) || isStaleRetryReconcilingCandidate(payment, now)) {
          classReconciling++
          shadowReconcilingIds.push(paymentId)
        } else {
          classOther++
          const fingerprint = readyOtherDiagnosticFingerprint(payment)
          if (otherDiagnosticPatterns[fingerprint] !== undefined) {
            otherDiagnosticPatterns[fingerprint] += 1
          } else if (Object.keys(otherDiagnosticPatterns).length < 32) {
            otherDiagnosticPatterns[fingerprint] = 1
          } else {
            otherDiagnosticPatterns.overflow = (otherDiagnosticPatterns.overflow ?? 0) + 1
          }
          const freshMissing = readyOtherFreshPrerequisiteFingerprint(payment, now)
          if ((isLegacyReadyUnrepairedCandidate(payment, now) || isLegacyReadyPreviouslyRepairedCandidate(payment, now)) && legacyQuarantineIds.length < LEGACY_READY_QUARANTINE_LIMIT) legacyQuarantineIds.push(paymentId)
          if (otherFreshMissingPatterns[freshMissing] !== undefined) otherFreshMissingPatterns[freshMissing] += 1
          else if (Object.keys(otherFreshMissingPatterns).length < 16) otherFreshMissingPatterns[freshMissing] = 1
          else otherFreshMissingPatterns.overflow = (otherFreshMissingPatterns.overflow ?? 0) + 1
        }
      }
    }
    }
    if (readyHeadTruncated === false && readyCoverageTruncated === false && readyCoverageMissing === 0 && readyCoverageOutsideHead === 0 && classInvalid === 0) {
      const eligibleSet = new Set([...postHorizonIds, ...preparedSubmitIds, ...retryableIds])
      const shadowEligibleSet = new Set([...shadowPostHorizonIds, ...shadowPreparedIds, ...shadowRetryableIds])
      readyEligibleSetParity = eligibleSet.size === shadowEligibleSet.size && [...eligibleSet].every((id) => shadowEligibleSet.has(id))
      const freshSet = new Set(freshDispatchIds)
      const shadowFreshSet = new Set(shadowFreshDispatchIds)
      readyFreshSetParity = freshSet.size === shadowFreshSet.size && [...freshSet].every((id) => shadowFreshSet.has(id))
      const reconcilingSet = new Set([...settlementReconcilingDiscoveryIds, ...staleRetryReconcilingDiscoveryIds])
      const shadowReconcilingSet = new Set(shadowReconcilingIds)
      readyReconcilingSetParity = reconcilingSet.size === shadowReconcilingSet.size && [...reconcilingSet].every((id) => shadowReconcilingSet.has(id))
    }
    readyClassInvalid = classInvalid
    readyClassPostHorizon = classPostHorizon
    readyClassPrepared = classPrepared
    readyClassRetryable = classRetryable
    readyClassFresh = classFresh
    readyClassStage1Only = classStage1Only
    readyClassReconciling = classReconciling
    readyClassOther = classOther
    readyOtherDiagnosticPatterns = otherDiagnosticPatterns
    readyOtherFreshMissingPatterns = otherFreshMissingPatterns
    readyLegacyQuarantineIds = legacyQuarantineIds
    readyTerminalEgressIds = terminalEgressIds
    readyClassTerminalEgress = classTerminalEgress
    readyReadyOnlyEgressIds = readyOnlyEgressIds
    readyClassReadyOnlyEgress = classReadyOnlyEgress
    readyShadowEligibleIds = classInvalid === 0 ? [...shadowPostHorizonIds, ...shadowPreparedIds, ...shadowRetryableIds] : null
    readyShadowPostHorizonIds = classInvalid === 0 ? shadowPostHorizonIds.slice(0, MAX_ATTEMPTS) : null
    readyShadowPreparedIds = classInvalid === 0 ? shadowPreparedIds : null
    readyShadowRetryableIds = classInvalid === 0 ? shadowRetryableIds : null
    readyShadowFreshIds = shadowFreshDispatchIds
    const readyFreshWindow = new Set(readyShadowFreshIds)
    readyShadowFreshCreateIds = classInvalid === 0 ? shadowFreshCreateIds.filter((id) => readyFreshWindow.has(id)) : null
    readyShadowStage1OnlyIds = classInvalid === 0 ? shadowStage1OnlyIds.filter((id) => readyFreshWindow.has(id)) : null
    readyShadowReconcilingIds = shadowReconcilingIds.slice(0, 1)
    if (classInvalid === 0) walletDrainShadowCount = classPrepared + classRetryable + classFresh + classStage1Only + classReconciling
  } catch {
    console.warn("[P7H CAPACITY] ordered settlement ready classification unavailable")
  }

  if (readyOrderedValid === true && readyClassInvalid === 0 && readyShadowEligibleIds !== null && readyShadowPostHorizonIds !== null && readyShadowRetryableIds !== null && readyShadowFreshIds !== null && readyShadowFreshCreateIds !== null && readyShadowStage1OnlyIds !== null && readyShadowReconcilingIds !== null && readyRotationStart !== null && readyRotationNext !== null && readyRotationCycleMax !== null && readyRotationCycleGeneration !== null) {
    try {
      const rotationCas = await redis.eval<[string, string, string, string], number>("local current=redis.call('GET',KEYS[1]); if not current then current='r:0' end; local cycle=redis.call('GET',KEYS[2]); local generation=redis.call('GET',KEYS[3]); if current==ARGV[1] and cycle==ARGV[3] and generation==ARGV[4] then if ARGV[2]=='r:0' then redis.call('SET',KEYS[1],ARGV[2]); redis.call('DEL',KEYS[2]); return 1 end; return redis.call('SET',KEYS[1],ARGV[2]) and 1 or 0 end; return 0", ["flashpay:settlement:ready:v1:authority-cursor", "flashpay:settlement:ready:v1:authority-cycle-max", "flashpay:settlement:ready:v1:authority-cycle-generation"], [readyRotationStart, readyRotationNext, String(readyRotationCycleMax), String(readyRotationCycleGeneration)])
      if (rotationCas !== 0 && rotationCas !== 1) throw new Error("Invalid settlement ready authority cursor CAS")
      readyRotationCas = rotationCas
    } catch {
      console.warn("[P7H CAPACITY] settlement ready authority cursor unavailable")
    }
  }

  let readyResidencyBackfilled: number | null = null
  if (readyResidencySourceValid === true) {
    try {
      let missing = 0
      const missingIds: string[] = []
      for (let batchStart = 0; batchStart < readyResidencyIds.length; batchStart += 200) {
        const batch = readyResidencyIds.slice(batchStart, batchStart + 200)
        const scores = await redis.zmscore("flashpay:settlement:ready:v1", batch)
        if (!Array.isArray(scores) || scores.length !== batch.length || scores.some((score) => score !== null && (typeof score !== "number" || !Number.isSafeInteger(score) || score < 1))) throw new Error("Invalid settlement ready residency telemetry")
        scores.forEach((score, index) => { if (score === null) missingIds.push(batch[index]) })
        missing += scores.filter((score) => score === null).length
      }
      readyResidencyCount = readyResidencyIds.length
      readyResidencyMissing = missing
      if (missingIds.length === 0) {
        readyResidencyBackfilled = 0
      } else {
        const backfilled = await redis.eval<string[], number>("local top=redis.call('ZRANGE',KEYS[1],-1,-1,'WITHSCORES'); if #top ~= 0 and #top ~= 2 then return -1 end; local topScore=0; if #top == 2 then topScore=tonumber(top[2]); if not topScore or topScore < 1 or topScore > 9007199254740990 or topScore ~= math.floor(topScore) then return -1 end end; local seq=redis.call('GET',KEYS[2]); local base=topScore; if seq then base=tonumber(seq); if not base or base < 0 or base > 9007199254740990 or base ~= math.floor(base) or base < topScore then return -1 end end; if base + #ARGV > 9007199254740990 then return -1 end; if not seq then redis.call('SET',KEYS[2],base) end; local added=0; for _,id in ipairs(ARGV) do if redis.call('SISMEMBER',KEYS[3],id)==1 and not redis.call('ZSCORE',KEYS[1],id) then local next=redis.call('INCR',KEYS[2]); redis.call('ZADD',KEYS[1],'NX',next,id); added=added+1 end end; return added", ["flashpay:settlement:ready:v1", "flashpay:settlement:ready:v1:sequence", "flashpay:recovery:active-payments:v1"], missingIds)
        if (!Number.isSafeInteger(backfilled) || backfilled < 0 || backfilled > missingIds.length) throw new Error("Invalid settlement ready residency backfill")
        readyResidencyBackfilled = backfilled
      }
    } catch {
      console.warn("[P7H CAPACITY] settlement ready residency telemetry unavailable")
    }
  }


  if (!readyBaselineCoverageCertified && readyResidencySourceValid === true && readyResidencyMissing !== null && readyResidencyBackfilled !== null && readyResidencyBackfilled === readyResidencyMissing) {
    try {
      const observedActiveIds = keys.map((key) => key.slice("payment:".length))
      for (let batchStart = 0; batchStart < observedActiveIds.length; batchStart += 200) {
        const batch = observedActiveIds.slice(batchStart, batchStart + 200)
        if (batch.length > 0) await redis.eval<string[], number>("for _,id in ipairs(ARGV) do redis.call('SADD',KEYS[1],id) end; return #ARGV", [READY_BASELINE_SCAN_SEEN_KEY], batch)
      }
    } catch {
      readyResidencySourceValid = false
    }
  }

  let readyLegacyQuarantineAttempted = 0
  let readyLegacyQuarantineSucceeded = 0
  for (const paymentId of readyLegacyQuarantineIds) {
    readyLegacyQuarantineAttempted += 1
    try { if (await quarantineLegacyReadyCandidate(paymentId)) readyLegacyQuarantineSucceeded += 1 } catch { /* fail closed; leave canonical state unchanged */ }
  }

  const discoveryDurationMs = Date.now() - discoveryStartedAt

  let readyAuthorityCertified = readyBaselineCoverageCertified
  if (!readyBaselineCoverageCertified && readyResidencySourceValid === true && scanNextToken === "c:0" && Number.isSafeInteger(activeSetSize) && activeSetSize >= 0 && readyResidencyMissing !== null && readyResidencyBackfilled !== null && readyResidencyBackfilled === readyResidencyMissing) {
    try {
      const exactBaselineCoverage = await redis.eval<[], number>("local missing=redis.call('SDIFFSTORE',KEYS[3],KEYS[1],KEYS[2]); local stale=redis.call('SDIFFSTORE',KEYS[4],KEYS[2],KEYS[1]); redis.call('DEL',KEYS[3]); redis.call('DEL',KEYS[4]); if missing==0 and stale==0 then redis.call('SET',KEYS[5],'done'); return 1 end; return 0", ["flashpay:recovery:active-payments:v1", READY_BASELINE_SCAN_SEEN_KEY, `${READY_BASELINE_SCAN_SEEN_KEY}:missing`, `${READY_BASELINE_SCAN_SEEN_KEY}:stale`, READY_BASELINE_COVERAGE_KEY], [])
      if (exactBaselineCoverage !== 0 && exactBaselineCoverage !== 1) throw new Error("Invalid settlement ready baseline coverage")
      readyAuthorityCertified = exactBaselineCoverage === 1
      if (readyAuthorityCertified) {
        readyBaselineCoverageCertified = true
        try { await redis.del(READY_BASELINE_SCAN_SEEN_KEY) } catch { console.warn("[P7H CAPACITY] settlement ready baseline scan cleanup unavailable") }
      }
    } catch {
      console.warn("[P7H CAPACITY] settlement ready baseline coverage unavailable")
    }
  }
  const readySchedulerUsable = readyAuthorityCertified && readyRotationStart === "r:0" && readyStrictlyIncreasing === true && readyClassInvalid === 0 && readyEligibleSetParity === true && readyFreshSetParity === true && readyReconcilingSetParity === true && readyShadowEligibleIds !== null && readyShadowPostHorizonIds !== null && readyShadowRetryableIds !== null && readyShadowFreshIds !== null && readyShadowFreshCreateIds !== null && readyShadowStage1OnlyIds !== null && readyShadowReconcilingIds !== null
  let readyBaselineCertified: boolean | null = null
  try {
    const baselineResult = await redis.eval<[string], number>("local current=redis.call('GET',KEYS[1]); if current=='done' then return 1 end; if current then return -1 end; if ARGV[1]=='1' then redis.call('SET',KEYS[1],'done'); return 1 end; return 0", ["flashpay:settlement:ready:v1:authority-baseline"], [readySchedulerUsable ? "1" : "0"])
    if (baselineResult !== -1 && baselineResult !== 0 && baselineResult !== 1) throw new Error("Invalid settlement ready authority baseline")
    if (baselineResult === -1) {
      console.warn("[P7H CAPACITY] settlement ready authority baseline mismatch")
    } else {
      readyBaselineCertified = baselineResult === 1
      if (!readyBaselineAlreadyCertified && readyBaselineCertified) {
        try { await redis.del(READY_BASELINE_SCAN_SEEN_KEY); await redis.del(READY_BASELINE_COVERAGE_KEY) } catch { console.warn("[P7H CAPACITY] settlement ready baseline cleanup unavailable") }
      }
    }
  } catch {
    console.warn("[P7H CAPACITY] settlement ready authority baseline unavailable")
  }
  const readyWindowCertified = readyBaselineCertified === true && readyRotationCas === 1 && readyOrderedValid === true && readyStrictlyIncreasing === true && readyClassInvalid === 0 && readyResidencySourceValid === true && readyResidencyMissing === 0 && readyResidencyBackfilled === 0 && readyShadowEligibleIds !== null && readyShadowPostHorizonIds !== null && readyShadowRetryableIds !== null && readyShadowFreshIds !== null && readyShadowFreshCreateIds !== null && readyShadowStage1OnlyIds !== null && readyShadowReconcilingIds !== null
  const useReadyExecution = readyWindowCertified === true
  const eligibleIds = readyShadowEligibleIds !== null && useReadyExecution ? readyShadowEligibleIds : [...postHorizonIds, ...preparedSubmitIds, ...retryableIds].slice(0, MAX_ATTEMPTS)
  const freshExecutionIds = readyShadowFreshIds !== null && useReadyExecution ? readyShadowFreshIds : freshDispatchIds.slice(0, MAX_ATTEMPTS)
  const settlementReconcilingExecutionIds = readyShadowReconcilingIds !== null && useReadyExecution ? readyShadowReconcilingIds : [...new Set([...settlementReconcilingDiscoveryIds, ...staleRetryReconcilingDiscoveryIds])].slice(0, 1)
  const retryableIdSet = new Set(retryableIds)
  const walletDrainFairnessClass = useReadyExecution ? walletDrainFairnessClassForGeneration(readyRotationCycleGeneration) : null
  const walletFreshExecutionIds = useReadyExecution && readyShadowRetryableIds !== null && readyShadowFreshIds !== null && readyShadowFreshCreateIds !== null && readyShadowStage1OnlyIds !== null
    ? immediateDrainMode
      ? (piCreateBackpressureActive() ? readyShadowStage1OnlyIds : [...readyShadowRetryableIds, ...readyShadowFreshIds])
      : readyShadowStage1OnlyIds
    : []

  const selectWalletDrainHead = (preparedIds: string[], eligibleIds: string[], freshIds: string[], reconcilingIds: string[], refundPaymentId: string | null, refundId: string | null, fairnessClass: WalletDrainFairnessClass | null): { kind: "settlement" | "refund" | null; paymentId: string | null; refundId: string | null; lane: WalletDrainLane | null } => {
    const preparedHead = eligibleIds.find((id) => preparedIds.includes(id))
    if (preparedHead !== undefined) return { kind: "settlement", paymentId: preparedHead, refundId: null, lane: "prepared" }
    if (fairnessClass === null) return { kind: null, paymentId: null, refundId: null, lane: null }

    const candidates: Record<WalletDrainFairnessClass, { kind: "settlement" | "refund"; paymentId: string; refundId: string | null } | null> = {
      fresh: freshIds[0] !== undefined ? { kind: "settlement", paymentId: freshIds[0], refundId: null } : null,
      reconciling: reconcilingIds[0] !== undefined ? { kind: "settlement", paymentId: reconcilingIds[0], refundId: null } : null,
      refund: refundPaymentId !== null && refundId !== null ? { kind: "refund", paymentId: refundPaymentId, refundId } : null,
    }
    const startIndex = WALLET_DRAIN_FAIRNESS_ORDER.indexOf(fairnessClass)
    for (let offset = 0; offset < WALLET_DRAIN_FAIRNESS_ORDER.length; offset += 1) {
      const lane = WALLET_DRAIN_FAIRNESS_ORDER[(startIndex + offset) % WALLET_DRAIN_FAIRNESS_ORDER.length]
      const candidate = candidates[lane]
      if (candidate !== null) return { ...candidate, lane }
    }
    return { kind: null, paymentId: null, refundId: null, lane: null }
  }

  let refundAccountingReady: boolean | null = null
  const refundResults: Array<Awaited<ReturnType<typeof ensureAutomaticRefundIntent>>> = []
  let refundIntakePeakInFlight = 0

  // Prepare newly eligible automatic refunds before wallet-head selection. These steps may
  // create/recover the Pi refund payment identifier, but are hard-gated from blockchain
  // submission. The existing wallet scheduler remains the sole authority for money movement.
  if (refundCandidateIds.length > 0) {
    refundAccountingReady = (await query("SELECT 1 FROM refund_accounting_records LIMIT 0")) !== null
    if (refundAccountingReady) {
      for (const paymentId of refundCandidateIds.slice(0, MAX_ATTEMPTS)) {
        let intake: Awaited<ReturnType<typeof ensureAutomaticRefundIntent>>
        try {
          intake = await ensureAutomaticRefundIntent(paymentId)
        } catch {
          intake = { outcome: "blocked", paymentId, reason: "intake_exception" }
        }
        refundResults.push(intake)
        refundIntakePeakInFlight = 1
        if (intake.outcome === "blocked" || typeof intake.refundId !== "string") continue

        for (let prepareStep = 0; prepareStep < 3; prepareStep += 1) {
          const prepared = await runAutomaticRefundPreparationStep(paymentId, intake.refundId)
          if (prepared.state !== "ok" || prepared.result.outcome !== "success") break
        }

        // A prior wake may already have blockchain-confirmed this refund. If so, complete
        // only its non-wallet checkpoints now; this helper refuses all pre-confirmation stages.
        for (let finalizeStep = 0; finalizeStep < 5; finalizeStep += 1) {
          const latestRefundPayment = parsePayment(await redis.get(`payment:${paymentId}`))
          if (latestRefundPayment?.id === paymentId && latestRefundPayment.status === "refunded" && latestRefundPayment.refundStatus === "completed" && latestRefundPayment.settlementFailureState === "refunded") break
          const finalized = await runAutomaticRefundFinalizationStep(paymentId, intake.refundId)
          if (finalized.state !== "ok" || finalized.result.outcome !== "success") break
        }
      }
    }
  }

  const preRefundDrain = await readAutomaticRefundDrainHead(MAX_ATTEMPTS)
  if (preRefundDrain.state === "ok") {
    const preTelemetryHead = selectWalletDrainHead(useReadyExecution && readyShadowPreparedIds !== null ? readyShadowPreparedIds : preparedSubmitIds, eligibleIds, walletFreshExecutionIds, settlementReconcilingExecutionIds, preRefundDrain.refundDrainHeadPaymentId, preRefundDrain.refundDrainHeadRefundId, walletDrainFairnessClass)
    walletDrainPreExecutionHeadKind = preTelemetryHead.kind
    walletDrainPreExecutionHeadPaymentId = preTelemetryHead.paymentId
    walletDrainPreExecutionHeadRefundId = preTelemetryHead.refundId
  }

  let preHead: ReturnType<typeof selectWalletDrainHead> | null = null
  if (useReadyExecution && readyShadowPreparedIds !== null && preRefundDrain.state === "ok") {
    preHead = selectWalletDrainHead(readyShadowPreparedIds, eligibleIds, walletFreshExecutionIds, settlementReconcilingExecutionIds, preRefundDrain.refundDrainHeadPaymentId, preRefundDrain.refundDrainHeadRefundId, walletDrainFairnessClass)
  }
  console.log("[transient-wake] scheduler wallet authority", { ready: preHead !== null, schedulerWalletPaymentId: preHead?.kind === "settlement" ? preHead.paymentId : null, refundPaymentId: preHead?.kind === "refund" ? preHead.paymentId : null, refundId: preHead?.kind === "refund" ? preHead.refundId : null })

  if (!await drainLease.renew()) return NextResponse.json({ error: "Transient drain lease ownership lost" }, { status: 503 })
  console.log("[P7J5 LEASE] renewed before work")

  const workStartedAt = Date.now()
  const results: Array<{ paymentId: string; ok: boolean; status?: string; error?: string }> = []
  const preparedExecutionIds = useReadyExecution && readyShadowPreparedIds !== null ? readyShadowPreparedIds : preparedSubmitIds
  const preparedExecutionSet = new Set(useReadyExecution ? preparedExecutionIds : [])

  const nonAuthoritativeEligibleIds = useReadyExecution && readyShadowPostHorizonIds !== null
    ? readyShadowPostHorizonIds
    : eligibleIds.filter((paymentId) => !preparedExecutionSet.has(paymentId) && !retryableIdSet.has(paymentId))
  const eligiblePipeline = await runBoundedOrderedPipeline<RecoveryPipelineValue>(nonAuthoritativeEligibleIds, async (paymentId) => {
    const result = await executeA2URecovery(paymentId, null)
    const latest = parsePayment(await redis.get(`payment:${paymentId}`))
    const backpressureTriggered = retryableIdSet.has(paymentId) && latest !== null ? await registerPiCreateBackpressure(latest) : false
    return {
      value: { paymentId, ok: result.status === "success" || result.status === "db_reconciled", status: latest?.status, error: result.details?.error },
      stop: backpressureTriggered,
    }
  })
  results.push(...eligiblePipeline.values)

  const walletDrainAttemptedSettlementIds = new Set<string>()
  const walletDrainAttemptedRefundIds = new Set<string>()
  const walletDrainBurstLanes: WalletDrainLane[] = []
  let walletDrainBurstSettlementAttempts = 0
  let walletDrainBurstRefundAttempts = 0
  let walletDrainBurstStopReason: string | null = null
  let walletDrainFairnessOffset = 0
  let walletDrainBudgetExhausted = false
  let walletDrainDeferredDbCount = 0
  let currentRefundDrain = preRefundDrain
  const walletDrainBurstStartedAt = Date.now()

  if (useReadyExecution && readyShadowPreparedIds !== null && readyShadowFreshIds !== null && readyShadowStage1OnlyIds !== null && walletDrainFairnessClass !== null && currentRefundDrain.state === "ok") {
    const fairnessStartIndex = WALLET_DRAIN_FAIRNESS_ORDER.indexOf(walletDrainFairnessClass)
    while (true) {
      if (Date.now() - walletDrainBurstStartedAt >= WALLET_DRAIN_BURST_BUDGET_MS) {
        walletDrainBudgetExhausted = true
        break
      }
      if (!await drainLease.renew()) return NextResponse.json({ error: "Transient drain lease ownership lost" }, { status: 503 })
      if (currentRefundDrain.state !== "ok") break

      const attemptFairnessClass = WALLET_DRAIN_FAIRNESS_ORDER[(fairnessStartIndex + walletDrainFairnessOffset) % WALLET_DRAIN_FAIRNESS_ORDER.length]
      const attemptFreshIds = (piCreateBackpressureActive() && readyShadowStage1OnlyIds !== null ? readyShadowStage1OnlyIds : readyShadowFreshIds).filter((id) => !walletDrainAttemptedSettlementIds.has(id))
      const attemptHead = selectWalletDrainHead(
        readyShadowPreparedIds.filter((id) => !walletDrainAttemptedSettlementIds.has(id)),
        eligibleIds.filter((id) => !walletDrainAttemptedSettlementIds.has(id)),
        attemptFreshIds,
        settlementReconcilingExecutionIds.filter((id) => !walletDrainAttemptedSettlementIds.has(id)),
        currentRefundDrain.refundDrainHeadPaymentId !== null && currentRefundDrain.refundDrainHeadRefundId !== null && !walletDrainAttemptedRefundIds.has(currentRefundDrain.refundDrainHeadRefundId) ? currentRefundDrain.refundDrainHeadPaymentId : null,
        currentRefundDrain.refundDrainHeadPaymentId !== null && currentRefundDrain.refundDrainHeadRefundId !== null && !walletDrainAttemptedRefundIds.has(currentRefundDrain.refundDrainHeadRefundId) ? currentRefundDrain.refundDrainHeadRefundId : null,
        attemptFairnessClass,
      )
      if (attemptHead.kind === null || attemptHead.lane === null) break
      walletDrainBurstLanes.push(attemptHead.lane)

      if (attemptHead.kind === "settlement" && attemptHead.paymentId !== null) {
        walletDrainAttemptedSettlementIds.add(attemptHead.paymentId)
        walletDrainBurstSettlementAttempts += 1
        const selectedNeedsPiCreateBackpressureObservation = readyShadowFreshCreateIds?.includes(attemptHead.paymentId) === true || readyShadowRetryableIds?.includes(attemptHead.paymentId) === true
        const result = await executeA2URecovery(attemptHead.paymentId, attemptHead.paymentId)
        const latest = parsePayment(await redis.get(`payment:${attemptHead.paymentId}`))
        if (selectedNeedsPiCreateBackpressureObservation && latest !== null) await registerPiCreateBackpressure(latest)
        const canonicalFinal = latest !== null && isPaymentFinal(latest)
        const piSlotReleasedDbPending = isPiA2USlotReleasedForDbPending(latest) && result.status === "pi_completed_db_pending"
        const value: RecoveryPipelineValue = { paymentId: attemptHead.paymentId, ok: canonicalFinal, status: latest?.status, error: result.details?.error }
        const existingIndex = results.findIndex((item) => item.paymentId === attemptHead.paymentId)
        if (existingIndex >= 0) results[existingIndex] = value
        else results.push(value)
        if (piSlotReleasedDbPending) walletDrainDeferredDbCount += 1
        const settlementSafeToContinue = canonicalFinal || piSlotReleasedDbPending
        if (!settlementSafeToContinue) {
          walletDrainBurstStopReason = `settlement_${result.state}`
          break
        }
      } else if (attemptHead.kind === "refund" && attemptHead.paymentId !== null && attemptHead.refundId !== null) {
        if (refundAccountingReady === null) refundAccountingReady = (await query("SELECT 1 FROM refund_accounting_records LIMIT 0")) !== null
        if (!refundAccountingReady) break
        walletDrainAttemptedRefundIds.add(attemptHead.refundId)
        walletDrainBurstRefundAttempts += 1
        let authorizedRefundPass: Awaited<ReturnType<typeof runAutomaticRefundPass>>
        try {
          authorizedRefundPass = await runAutomaticRefundPass(MAX_ATTEMPTS, { paymentId: attemptHead.paymentId, refundId: attemptHead.refundId })
        } catch {
          authorizedRefundPass = { state: "blocked" }
        }
        if (authorizedRefundPass.state !== "ok") {
          walletDrainBurstStopReason = "refund_pass_blocked"
          break
        }
        const authorizedRefundResult = authorizedRefundPass.results.find((item) => item.refundId === attemptHead.refundId && item.paymentId === attemptHead.paymentId && item.action === "execute")
        if (authorizedRefundResult?.outcome !== "success") {
          walletDrainBurstStopReason = `refund_${authorizedRefundResult?.reason ?? authorizedRefundResult?.outcome ?? "unresolved"}`
          break
        }

        // Once the wallet-authorized refund movement has durably succeeded, finish only this
        // refund's non-wallet checkpoints in the same wake. Every step re-reads the canonical
        // checkpoint and uses the existing executor/accounting guards. Any uncertainty stops
        // immediately and leaves the durable checkpoint for the next external wake.
        for (let finalizeStep = 0; finalizeStep < 5; finalizeStep += 1) {
          const latestRefundPayment = parsePayment(await redis.get(`payment:${attemptHead.paymentId}`))
          if (latestRefundPayment?.id === attemptHead.paymentId && latestRefundPayment.status === "refunded" && latestRefundPayment.refundStatus === "completed" && latestRefundPayment.settlementFailureState === "refunded") break
          if (Date.now() - walletDrainBurstStartedAt >= WALLET_DRAIN_BURST_BUDGET_MS) break
          const targeted = await runAutomaticRefundFinalizationStep(attemptHead.paymentId, attemptHead.refundId)
          if (targeted.state !== "ok" || targeted.result.outcome !== "success") {
            walletDrainBurstStopReason = `refund_finalize_${targeted.state === "ok" ? targeted.result.reason ?? targeted.result.outcome : "blocked"}`
            break
          }
        }
        if (walletDrainBurstStopReason !== null) break
        currentRefundDrain = await readAutomaticRefundDrainHead(MAX_ATTEMPTS)
        if (currentRefundDrain.state !== "ok") {
          walletDrainBurstStopReason = "refund_head_unavailable"
          break
        }
      }

      if (attemptHead.lane !== "prepared") {
        const selectedFairnessIndex = WALLET_DRAIN_FAIRNESS_ORDER.indexOf(attemptHead.lane)
        walletDrainFairnessOffset = (selectedFairnessIndex - fairnessStartIndex + 1 + WALLET_DRAIN_FAIRNESS_ORDER.length) % WALLET_DRAIN_FAIRNESS_ORDER.length
      }
    }
  }
  const walletDrainBurstDurationMs = Date.now() - walletDrainBurstStartedAt

  const nonAuthoritativeFreshExecutionIds: string[] = []
  const freshPipeline = await runBoundedOrderedPipeline<RecoveryPipelineValue>(nonAuthoritativeFreshExecutionIds, async (id) => {
    const payment = parsePayment(await redis.get(`payment:${id}`))
    if (payment?.id !== id) return {}
    const handlerNow = Date.now()
    const freshCreate = isFreshSettlementDispatchCandidate(payment, handlerNow)
    const stage1Only = isStage1OnlySettlementDispatchCandidate(payment, handlerNow)
    if (!freshCreate && !stage1Only) return {}
    if (freshCreate && piCreateBackpressureActive()) return { value: { paymentId: id, ok: false, status: payment.status, error: "pi_create_backpressure" } }
    const result = await executeA2URecovery(id, null)
    const latest = parsePayment(await redis.get(`payment:${id}`))
    const backpressureTriggered = freshCreate && latest !== null ? await registerPiCreateBackpressure(latest) : false
    return {
      value: { paymentId: id, ok: result.status === "success", status: latest?.status, error: result.details?.error },
      stop: backpressureTriggered,
    }
  })
  results.push(...freshPipeline.values)

  const reconcilingPipeline = await runBoundedOrderedPipeline<RecoveryPipelineValue>(settlementReconcilingExecutionIds.filter((id) => !walletDrainAttemptedSettlementIds.has(id)), async (id) => {
    const payment = parsePayment(await redis.get(`payment:${id}`))
    if (payment?.id !== id || (!isStaleFreshReconcilingCandidate(payment, Date.now()) && !isStaleRetryReconcilingCandidate(payment, Date.now()))) return {}
    const result = await executeA2URecovery(id, null)
    const latest = parsePayment(await redis.get(`payment:${id}`))
    return { value: { paymentId: id, ok: result.status === "success", status: latest?.status, error: result.details?.error } }
  })
  results.push(...reconcilingPipeline.values)
  const settlementPipelinePeakInFlight = Math.max(eligiblePipeline.peakInFlight, freshPipeline.peakInFlight, reconcilingPipeline.peakInFlight)

  if (!await drainLease.renew()) return NextResponse.json({ error: "Transient drain lease ownership lost" }, { status: 503 })
  console.log("[P7J5 LEASE] renewed before refund drain")

  let refundPass: Awaited<ReturnType<typeof runAutomaticRefundPass>>
  if (refundAccountingReady === null) refundAccountingReady = (await query("SELECT 1 FROM refund_accounting_records LIMIT 0")) !== null
  if (refundAccountingReady) {
    try {
      refundPass = await runAutomaticRefundPass(MAX_ATTEMPTS, null)
    } catch {
      refundPass = { state: "blocked" }
    }
  } else {
    refundPass = { state: "blocked" }
  }

  if (walletDrainShadowCount !== null && refundPass.state === "ok" && (!useReadyExecution || readyShadowPreparedIds !== null)) {
    walletDrainShadowCount += refundPass.refundDrainCount
    const preparedIds = useReadyExecution && readyShadowPreparedIds !== null ? readyShadowPreparedIds : preparedSubmitIds
    const shadowHead = selectWalletDrainHead(preparedIds, eligibleIds, walletFreshExecutionIds, settlementReconcilingExecutionIds, refundPass.refundDrainHeadPaymentId, refundPass.refundDrainHeadRefundId, walletDrainFairnessClass)
    walletDrainShadowHeadPaymentId = shadowHead.paymentId
    walletDrainShadowHeadRefundId = shadowHead.refundId
    walletDrainShadowHeadKind = shadowHead.kind
  } else {
    walletDrainShadowCount = null
    walletDrainShadowHeadPaymentId = null
    walletDrainShadowHeadRefundId = null
    walletDrainShadowHeadKind = null
  }

  if (walletDrainShadowCount !== null && refundPass.state === "ok" && (!useReadyExecution || readyShadowPreparedIds !== null)) {
    const preparedIds = useReadyExecution && readyShadowPreparedIds !== null ? readyShadowPreparedIds : preparedSubmitIds
    const selectedHead = selectWalletDrainHead(preparedIds, eligibleIds, walletFreshExecutionIds, settlementReconcilingExecutionIds, refundPass.refundDrainHeadPaymentId, refundPass.refundDrainHeadRefundId, walletDrainFairnessClass)
    walletDrainSelectedHeadKind = selectedHead.kind
    walletDrainSelectedHeadPaymentId = selectedHead.paymentId
    walletDrainSelectedHeadRefundId = selectedHead.refundId
    walletDrainSelectedHeadParity = selectedHead.kind === walletDrainShadowHeadKind && selectedHead.paymentId === walletDrainShadowHeadPaymentId && selectedHead.refundId === walletDrainShadowHeadRefundId
  } else {
    walletDrainSelectedHeadKind = null
    walletDrainSelectedHeadPaymentId = null
    walletDrainSelectedHeadRefundId = null
    walletDrainSelectedHeadParity = null
  }

  const shadowHeadValid = (walletDrainShadowHeadKind === "settlement" && walletDrainShadowHeadPaymentId !== null && walletDrainShadowHeadRefundId === null) || (walletDrainShadowHeadKind === "refund" && walletDrainShadowHeadPaymentId !== null && walletDrainShadowHeadRefundId !== null)
  const selectedHeadValid = (walletDrainSelectedHeadKind === "settlement" && walletDrainSelectedHeadPaymentId !== null && walletDrainSelectedHeadRefundId === null) || (walletDrainSelectedHeadKind === "refund" && walletDrainSelectedHeadPaymentId !== null && walletDrainSelectedHeadRefundId !== null)
  if (walletDrainShadowCount !== null && walletDrainShadowCount > 0 && walletDrainSelectedHeadParity !== null && shadowHeadValid && selectedHeadValid) walletDrainNonEmptyParity = walletDrainSelectedHeadParity
  const certificationA = selectWalletDrainHead(["p"], ["p"], ["f"], ["q"], "rp", "r", "refund")
  const certificationB = selectWalletDrainHead([], [], ["f"], ["q"], "rp", "r", "fresh")
  const certificationC = selectWalletDrainHead([], [], ["f"], ["q"], "rp", "r", "reconciling")
  const certificationD = selectWalletDrainHead([], [], ["f"], ["q"], "rp", "r", "refund")
  const certificationE = selectWalletDrainHead([], [], ["f"], [], null, null, "refund")
  walletDrainNonMoneyCertification = certificationA.lane === "prepared" && certificationA.paymentId === "p" && certificationB.lane === "fresh" && certificationB.paymentId === "f" && certificationC.lane === "reconciling" && certificationC.paymentId === "q" && certificationD.lane === "refund" && certificationD.paymentId === "rp" && certificationD.refundId === "r" && certificationE.lane === "fresh" && certificationE.paymentId === "f"

  const settlementReconcilingEvidence = { FOUND: 0, CONFIRMED_NONE: 0, INDETERMINATE: 0, skipped: 0 }
  const settlementReconcilingEvidenceIds = [...new Set([...settlementReconcilingDiscoveryIds, ...staleRetryReconcilingDiscoveryIds])].slice(0, 1)
  for (const id of settlementReconcilingEvidenceIds) {
    const payment = parsePayment(await redis.get(`payment:${id}`))
    if (!payment || payment.id !== id || (!isStaleFreshReconcilingCandidate(payment, Date.now()) && !isStaleRetryReconcilingCandidate(payment, Date.now()))) {
      settlementReconcilingEvidence.skipped++
      continue
    }
    const customerAmount = payment.customerAmount
    const merchantUid = payment.merchantUid
    if (typeof customerAmount !== "number" || !Number.isFinite(customerAmount) || customerAmount <= 0 || typeof merchantUid !== "string" || merchantUid.trim() === "" || merchantUid !== merchantUid.trim()) {
      settlementReconcilingEvidence.skipped++
      continue
    }
    const evidence = await reconcileIncompleteA2UPayment(id, customerAmount, merchantUid)
    settlementReconcilingEvidence[evidence.outcome]++
  }

  if (!await drainLease.renew()) return NextResponse.json({ error: "Transient drain lease ownership lost" }, { status: 503 })
  console.log("[P7J5 LEASE] renewed before cursor handoff")

  let readyTerminalEgressPrunedCount = 0
  let readyReadyOnlyEgressPrunedCount = 0
  if (readyTerminalEgressIds.length > 0) {
    try {
      const pruned = await redis.eval<string[], number>("local removed=0; for _,id in ipairs(ARGV) do local a=redis.call('SREM',KEYS[1],id); local r=redis.call('ZREM',KEYS[2],id); if a==1 or r==1 then removed=removed+1 end end; return removed", ["flashpay:recovery:active-payments:v1", "flashpay:settlement:ready:v1"], readyTerminalEgressIds)
      if (!Number.isSafeInteger(pruned) || pruned < 0 || pruned > readyTerminalEgressIds.length) throw new Error("Invalid terminal egress prune result")
      readyTerminalEgressPrunedCount = pruned
    } catch (error) {
      console.warn("[P7J12K HYGIENE] terminal ready/active prune unavailable", error)
    }
  }
  if (readyReadyOnlyEgressIds.length > 0) {
    try {
      const pruned = await redis.eval<string[], number>("local removed=0; for _,id in ipairs(ARGV) do removed=removed+redis.call('ZREM',KEYS[1],id) end; return removed", ["flashpay:settlement:ready:v1"], readyReadyOnlyEgressIds)
      if (!Number.isSafeInteger(pruned) || pruned < 0 || pruned > readyReadyOnlyEgressIds.length) throw new Error("Invalid ready-only egress prune result")
      readyReadyOnlyEgressPrunedCount = pruned
    } catch (error) {
      console.warn("[P7J12K HYGIENE] ready-only settlement prune unavailable", error)
    }
  }

  try {
    const cursorCasResult = await redis.eval<[string, string], number>(`local current = redis.call('GET', KEYS[1]) or 'c:0'
if current ~= ARGV[1] then return 0 end
redis.call('SET', KEYS[1], ARGV[2])
return 1`, ["flashpay:recovery:active-payments:v1:scan-cursor"], [scanStartToken, scanNextToken])
    if (cursorCasResult !== 0 && cursorCasResult !== 1) return NextResponse.json({ error: "Active recovery index unavailable" }, { status: 503 })
  } catch {
    return NextResponse.json({ error: "Active recovery index unavailable" }, { status: 503 })
  }

  let walletDrainContinuationScheduled = false
  let walletDrainKickGateReleased = false
  let walletDrainKickGateReleaseDeferred = false
  const periodicFreshCreateDetected = !immediateDrainMode && useReadyExecution && !piCreateBackpressureActive() && ((readyShadowFreshCreateIds?.length ?? 0) > 0 || (readyShadowRetryableIds?.length ?? 0) > 0)
  // DR-21: Pi-create backpressure suppresses only work that could create a new Pi
  // payment identity. It must never suppress continuation for already-authorized
  // non-create work (prepared/stage1-only/reconciling/refund). Otherwise a long
  // rate-limit window plus an exhausted burst could strand durable financial work
  // until an unrelated external wake. Determine remaining non-create work from the
  // exact post-burst attempted sets and the canonical refund head.
  const backpressureNonCreateContinuationDetected = piCreateBackpressureActive() && (
    (readyShadowPreparedIds?.some((id) => !walletDrainAttemptedSettlementIds.has(id)) ?? false) ||
    (readyShadowStage1OnlyIds?.some((id) => !walletDrainAttemptedSettlementIds.has(id)) ?? false) ||
    settlementReconcilingExecutionIds.some((id) => !walletDrainAttemptedSettlementIds.has(id)) ||
    (currentRefundDrain.state === "ok" && currentRefundDrain.refundDrainHeadRefundId !== null && !walletDrainAttemptedRefundIds.has(currentRefundDrain.refundDrainHeadRefundId))
  )
  const continuationNeeded = useReadyExecution && walletDrainBurstStopReason === null && (readyLegacyQuarantineSucceeded > 0 || periodicFreshCreateDetected || walletDrainDeferredDbCount > 0 || backpressureNonCreateContinuationDetected || (!piCreateBackpressureActive() && (walletDrainBudgetExhausted || (readyRotationNext !== null && readyRotationNext !== "r:0"))))
  if (continuationNeeded) {
    walletDrainContinuationScheduled = scheduleTrustedTransientRequest("continuation-kick")
  } else if (useReadyExecution && walletDrainBurstStopReason === null && !piCreateBackpressureActive()) {
    try {
      const sequenceValue = await redis.get<unknown>(READY_SEQUENCE_KEY)
      const sequenceText = typeof sequenceValue === "number" && Number.isSafeInteger(sequenceValue) && sequenceValue >= 0 ? String(sequenceValue) : typeof sequenceValue === "string" && /^[0-9]+$/.test(sequenceValue) ? sequenceValue : null
      if (sequenceText !== null) {
        const gateReleaseResult = await redis.eval<[string], number>("local current=redis.call('GET',KEYS[2]); if current ~= ARGV[1] then return 0 end; redis.call('DEL',KEYS[1]); return 1", [IMMEDIATE_DRAIN_KICK_KEY, READY_SEQUENCE_KEY], [sequenceText])
        if (gateReleaseResult === 1) {
          walletDrainKickGateReleased = true
        } else if (gateReleaseResult === 0) {
          walletDrainKickGateReleaseDeferred = true
          walletDrainContinuationScheduled = scheduleTrustedTransientRequest("continuation-kick")
        } else {
          throw new Error("Invalid immediate drain gate release result")
        }
      }
    } catch {
      console.warn("[P7J12D CONTINUATION] immediate drain kick gate cleanup unavailable; TTL safety retained")
    }
  }

  const workDurationMs = Date.now() - workStartedAt
  const wakeDurationMs = Date.now() - wakeStartedAt
  // R101-10: observation-only queue throughput instrumentation.
  // These counters are derived from work already performed by this wake; they
  // do not select work, mutate financial authority, or alter retry behavior.
  const queueThroughputObserved = {
    activeSetSize,
    activeScanObserved: keys.length,
    durableU2AScanned: durableU2AIngressRepopulation.scanned,
    durableU2ARepopulated: durableU2AIngressRepopulation.repopulated,
    readySetSize,
    readyWindowObserved: readyOrderedCount,
    settlementAttempts: walletDrainBurstSettlementAttempts,
    refundAttempts: walletDrainBurstRefundAttempts,
    completedResults: results.filter((item) => item.ok).length + (refundPass.state === "ok" ? refundPass.results.filter((item) => item.outcome === "success").length : 0),
    deferredDbCount: walletDrainDeferredDbCount,
    budgetExhausted: walletDrainBudgetExhausted,
    continuationScheduled: walletDrainContinuationScheduled,
    piCreateBackpressureActive: piCreateBackpressureActive(),
    wakeDurationMs,
    workDurationMs,
  }
  console.log("[R101-10 QUEUE THROUGHPUT]", queueThroughputObserved)
  console.log("[P7J12 OTHER PREREQ]", { readyClassOther, readyOtherFreshMissingPatterns, readyLegacyQuarantineAttempted, readyLegacyQuarantineSucceeded })
  console.log("[P7H CAPACITY] transient wake", { discoveryDurationMs, workDurationMs, wakeDurationMs, activeSetSize, keys: keys.length, postHorizonIds: postHorizonIds.length, preparedSubmitIds: preparedSubmitIds.length, retryableIds: retryableIds.length, freshDispatchIds: freshDispatchIds.length, settlementReconcilingDiscoveryIds: settlementReconcilingDiscoveryIds.length, staleRetryReconcilingDiscoveryIds: staleRetryReconcilingDiscoveryIds.length, refundCandidateIds: refundCandidateIds.length, eligibleIds: eligibleIds.length, results: results.length, refundResults: refundResults.length, boundedPipelineConcurrency: BOUNDED_PIPELINE_CONCURRENCY, settlementPipelinePeakInFlight, refundIntakePeakInFlight, piCreateBackpressureActive: piCreateBackpressureActive(), piCreateBackpressureUntilMs, piCreateBackpressureUnavailable, walletDrainFairnessClass, walletDrainFairnessSelectedLane: preHead?.lane ?? null, walletDrainFairnessPreparedOverride: preHead?.lane === "prepared", walletDrainFairnessFreshCreateSuppressed: piCreateBackpressureActive() && (readyShadowFreshCreateIds?.length ?? 0) > 0, walletDrainBurstLimit: WALLET_DRAIN_BURST_LIMIT, walletDrainBurstBudgetMs: WALLET_DRAIN_BURST_BUDGET_MS, walletDrainBurstDurationMs, walletDrainBudgetExhausted, immediateDrainMode, periodicFreshCreateDetected, backpressureNonCreateContinuationDetected, walletDrainDeferredDbCount, walletDrainBurstSettlementAttempts, walletDrainBurstRefundAttempts, walletDrainBurstStopReason, walletDrainBurstLanes, walletDrainContinuationScheduled, walletDrainKickGateReleased, walletDrainKickGateReleaseDeferred, readySampleSize: readySample.length, readySetSize, readyIndexed, readyMissing, readyOrderedCount, readyFirstScore, readyLastScore, readyStrictlyIncreasing, readyClassInvalid, readyClassPostHorizon, readyClassPrepared, readyClassRetryable, readyClassFresh, readyClassStage1Only, readyClassReconciling, readyClassTerminalEgress, readyTerminalEgressPrunedCount, readyClassReadyOnlyEgress, readyReadyOnlyEgressPrunedCount, readyClassOther, readyOtherDiagnosticPatterns, readyOtherFreshMissingPatterns, readyLegacyQuarantineAttempted, readyLegacyQuarantineSucceeded, readyShadowEligibleIds, readyShadowPreparedIds, readyShadowFreshIds, readyShadowReconcilingIds, walletDrainShadowCount, walletDrainShadowHeadPaymentId, walletDrainShadowHeadRefundId, walletDrainShadowHeadKind, walletDrainSelectedHeadKind, walletDrainSelectedHeadPaymentId, walletDrainSelectedHeadRefundId, walletDrainSelectedHeadParity, walletDrainPreExecutionHeadKind, walletDrainPreExecutionHeadPaymentId, walletDrainPreExecutionHeadRefundId, walletDrainNonEmptyParity, walletDrainNonMoneyCertification, readyCoverageCount: readyCoverageAllIds.length, readyCoverageTruncated, readyCoverageIndexed, readyCoverageMissing, readyHeadTruncated, readyCoverageOutsideHead, readyResidencyCount, readyResidencyMissing, readyResidencyBackfilled, readyEligibleSetParity, readyFreshSetParity, readyReconcilingSetParity, readyAuthorityCertified, readySchedulerUsable, readyBaselineCertified, readyRotationStart, readyRotationNext, readyRotationCas, readyRotationCycleMax, readyRotationCycleGeneration, readyWindowCertified, readyExecutionSource: useReadyExecution ? "ready" : "legacy" })

  // R100-10: freshness proves a fully completed trusted drain, not merely request arrival.
  // Early 503, busy-lease, and continuation-only requests must not create false health.
  try {
    await redis.set(RECOVERY_WAKE_HEALTH_KEY, new Date().toISOString(), { ex: 7 * 24 * 60 * 60 })
  } catch {
    console.warn("[R100-10 MONITORING] completed wake health marker unavailable")
  }

  return NextResponse.json({ processed: results.length, results, refundIntake: { processed: refundResults.length, results: refundResults }, refundPass, settlementDispatchDiscovery: { count: freshDispatchIds.length }, settlementReconcilingDiscovery: { count: settlementReconcilingDiscoveryIds.length }, staleRetryReconcilingDiscovery: { count: staleRetryReconcilingDiscoveryIds.length }, settlementReconcilingEvidence, boundedPipeline: { concurrency: BOUNDED_PIPELINE_CONCURRENCY, settlementPeakInFlight: settlementPipelinePeakInFlight, refundIntakePeakInFlight }, piCreateBackpressure: { active: piCreateBackpressureActive(), untilMs: piCreateBackpressureUntilMs, unavailable: piCreateBackpressureUnavailable }, readyHygiene: { terminalEgressClassified: readyClassTerminalEgress, terminalEgressPruned: readyTerminalEgressPrunedCount, readyOnlyEgressClassified: readyClassReadyOnlyEgress, readyOnlyEgressPruned: readyReadyOnlyEgressPrunedCount, other: readyClassOther, otherDiagnosticPatterns: readyOtherDiagnosticPatterns, otherFreshMissingPatterns: readyOtherFreshMissingPatterns, legacyQuarantineAttempted: readyLegacyQuarantineAttempted, legacyQuarantineSucceeded: readyLegacyQuarantineSucceeded }, walletDrainFairness: { class: walletDrainFairnessClass, selectedLane: preHead?.lane ?? null, preparedOverride: preHead?.lane === "prepared", freshCreateSuppressed: piCreateBackpressureActive() && (readyShadowFreshCreateIds?.length ?? 0) > 0 }, walletDrainBurst: { limit: WALLET_DRAIN_BURST_LIMIT, budgetMs: WALLET_DRAIN_BURST_BUDGET_MS, durationMs: walletDrainBurstDurationMs, budgetExhausted: walletDrainBudgetExhausted, immediateDrainMode, periodicFreshCreateDetected, backpressureNonCreateContinuationDetected, deferredDbCount: walletDrainDeferredDbCount, settlementAttempts: walletDrainBurstSettlementAttempts, refundAttempts: walletDrainBurstRefundAttempts, stopReason: walletDrainBurstStopReason, lanes: walletDrainBurstLanes, continuationScheduled: walletDrainContinuationScheduled, kickGateReleased: walletDrainKickGateReleased, kickGateReleaseDeferred: walletDrainKickGateReleaseDeferred }, drainLease: "acquired" })
  } finally {
    const released = await drainLease.release()
    if (released) console.log("[P7J5 LEASE] released")
    else console.warn("[P7J5 LEASE] release skipped or ownership changed")
  }
}

