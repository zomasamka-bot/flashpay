import {deployment} from '../../../deployment'
import { type NextRequest, NextResponse } from "next/server"

// Force dynamic rendering for this route
export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

import { redis, isRedisConfigured as isKvConfigured } from "../../../lib/redis"
import { isPaymentFinal } from "../../../lib/payment-status"
import { authorizeFromHeader } from "../../../lib/merchant-auth"
import { getDurableU2AIngressAuthoritative, getSettlementCheckpointAuthoritative, probeDurablePaymentIdentity, readSettlementRefundAuthority, readSettlementU2AApprovalOwnership } from "../../../lib/db"
import { getRefundCheckpointsByPaymentIds } from "../../../lib/refund-checkpoint-store"
import { compareAndSwapPaymentProjection } from "../../../lib/payment-projection-cas"

// Helper: Check if origin is allowed for CORS
function isOriginAllowed(origin: string | null): boolean {
  if (!origin) return false
  
  // Allow flashpay-two.vercel.app
  if (origin === deployment().publicOrigin) return true
  
  // Allow vusercontent.net origins matching pattern
  if (/^https:\/\/[a-z0-9-]+\.vusercontent\.net$/i.test(origin)) return true
  
  return false
}

// Helper: Add CORS headers to response
function addCorsHeaders(response: NextResponse, origin: string): NextResponse {
  response.headers.set('Access-Control-Allow-Origin', origin)
  response.headers.set('Vary', 'Origin')
  return response
}

interface Payment {
  id: string
  merchantId?: string
  merchantAddress?: string
  merchantUid?: string
  accessToken: string
  amount: number
  note: string
  status: "pending" | "failed" | "cancelled" | "paid_to_app" | "settlement_pending" | "settled_to_merchant" | "settlement_failed" | "refund_pending" | "refunded"
  createdAt: string
  paidAt?: string
  settledAt?: string
  txid?: string
  a2uPaymentId?: string
  a2uTxid?: string
}

// Helper: Filter payment to only include public-safe fields
function getPublicPayment(payment: any) {
  return {
    id: payment.id,
    merchantId: payment.merchantId,
    merchantAddress: payment.merchantAddress,
    amount: payment.amount,
    note: payment.note,
    status: payment.status === "settled_to_merchant" && !isPaymentFinal(payment) ? "settlement_pending" : payment.status,
    createdAt: payment.createdAt,
    paidAt: payment.paidAt,
    txid: payment.u2aTxid || payment.a2uTxid,
  }
}

// GET /api/payments/[id] - Retrieve a specific payment
export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const origin = request.headers.get("origin")
  const allowCors = isOriginAllowed(origin)

  try {
    const { id } = await params
    
    console.log("[API] GET /api/payments/[id] called for:", id)

    if (!isKvConfigured) {
      const errorResponse = NextResponse.json({ 
        error: "Redis not configured",
        paymentId: id,
      }, { status: 500 })
      if (allowCors && origin) {
        return addCorsHeaders(errorResponse, origin)
      }
      return errorResponse
    }

    console.log("[API][ID] ========================================")
    console.log("[API][ID] RETRIEVING PAYMENT")
    console.log("[API][ID] Payment ID:", id)
    console.log("[API][ID] Redis Key:", `payment:${id}`)
    console.log("[API][ID] Instance ID:", process.env.VERCEL_REGION || "local")
    
    const data = await redis.get(`payment:${id}`)
    const payment = data ? (typeof data === 'string' ? JSON.parse(data) : data) : null
    console.log("[API][ID] Redis result:", payment ? "FOUND ✅" : "NOT FOUND ❌")
    console.log("[API][ID] ========================================")

    if (payment && (typeof payment.id !== "string" || payment.id !== id)) {
      const conflictResponse = NextResponse.json({ error: "Payment identity conflict", paymentId: id }, { status: 409 })
      if (allowCors && origin) {
        return addCorsHeaders(conflictResponse, origin)
      }
      return conflictResponse
    }

    // F3 durable public-status authority. This route is read-only with respect
    // to financial movement; PostgreSQL decides branch ownership when Redis is
    // stale or missing. Unknown/conflicting authority always fails closed.
    const authority = await readSettlementRefundAuthority(id)
    if (authority.outcome !== "CLEAR") {
      const response = NextResponse.json({ error: "Payment status temporarily unavailable", paymentId: id }, { status: authority.outcome === "INDETERMINATE" ? 503 : 409 })
      return allowCors && origin ? addCorsHeaders(response, origin) : response
    }

    // Pre-review hardening: a missing Redis projection is not proof that the
    // payment does not exist. Serve only statuses proven by durable branch
    // authority. A bare durable payment identity is existence evidence only and
    // therefore returns 503 rather than inventing pending/failed/refund state.
    if (!payment) {
      if (authority.settlementActive) {
        const durable = await getSettlementCheckpointAuthoritative(id)
        if (durable.outcome !== "FOUND") {
          const response = NextResponse.json({ error: "Payment status temporarily unavailable", paymentId: id }, { status: 503 })
          return allowCors && origin ? addCorsHeaders(response, origin) : response
        }
        const durableStatus = durable.checkpoint.stage === "db_finalized" ? "settled_to_merchant" : "settlement_pending"
        const confirmation = await readSettlementRefundAuthority(id)
        if (confirmation.outcome !== "CLEAR" || !confirmation.settlementActive || confirmation.refundActive) {
          const response = NextResponse.json({ error: "Payment status temporarily unavailable", paymentId: id }, { status: confirmation.outcome === "INDETERMINATE" ? 503 : 409 })
          return allowCors && origin ? addCorsHeaders(response, origin) : response
        }
        const publicPayment = {
          id: durable.checkpoint.paymentId,
          merchantId: durable.checkpoint.merchantId,
          amount: durable.checkpoint.customerAmount,
          note: "",
          status: durableStatus,
          createdAt: durable.checkpoint.createdAt,
          paidAt: durable.checkpoint.paidAt ?? undefined,
          txid: durable.checkpoint.a2uTxid || durable.checkpoint.u2aTxid,
        }
        const successResponse = NextResponse.json({ success: true, payment: publicPayment })
        return allowCors && origin ? addCorsHeaders(successResponse, origin) : successResponse
      }

      if (authority.refundActive) {
        const ingress = await getDurableU2AIngressAuthoritative(id)
        const durable = await getRefundCheckpointsByPaymentIds([id])
        const checkpoint = durable.state === "ok" ? durable.checkpoints.get(id) : undefined
        if (ingress.outcome !== "FOUND" || ingress.checkpoint.completedAt === null || durable.state !== "ok" || !checkpoint || checkpoint.status === "manual_review_required") {
          const response = NextResponse.json({ error: "Payment status temporarily unavailable", paymentId: id }, { status: 503 })
          return allowCors && origin ? addCorsHeaders(response, origin) : response
        }
        const durableStatus = checkpoint.status === "completed" && checkpoint.stage === "audit_recorded" ? "refunded" : "refund_pending"
        const confirmation = await readSettlementRefundAuthority(id)
        if (confirmation.outcome !== "CLEAR" || confirmation.settlementActive || !confirmation.refundActive) {
          const response = NextResponse.json({ error: "Payment status temporarily unavailable", paymentId: id }, { status: confirmation.outcome === "INDETERMINATE" ? 503 : 409 })
          return allowCors && origin ? addCorsHeaders(response, origin) : response
        }
        const publicPayment = {
          id: ingress.checkpoint.paymentId,
          merchantId: ingress.checkpoint.merchantId,
          amount: ingress.checkpoint.customerAmount,
          note: "",
          status: durableStatus,
          createdAt: ingress.checkpoint.createdAt,
          paidAt: ingress.checkpoint.completedAt,
          txid: checkpoint.refundTxid || ingress.checkpoint.u2aTxid,
        }
        const successResponse = NextResponse.json({ success: true, payment: publicPayment })
        return allowCors && origin ? addCorsHeaders(successResponse, origin) : successResponse
      }

      // FIN100B B-D05-R2: a 404 requires absence across ALL durable identity
      // families, including legacy transactions and create intents. Uncertain
      // reads never become false 404s; this probe does not infer payment status.
      const identity = await probeDurablePaymentIdentity(id)
      const refundEvidence = await getRefundCheckpointsByPaymentIds([id])
      if (identity === "INDETERMINATE" || refundEvidence.state !== "ok") {
        const response = NextResponse.json({ error: "Payment status temporarily unavailable", paymentId: id }, { status: 503 })
        return allowCors && origin ? addCorsHeaders(response, origin) : response
      }
      if (identity === "EXISTS" || refundEvidence.checkpoints.has(id)) {
        const response = NextResponse.json({ error: "Payment status temporarily unavailable", paymentId: id }, { status: 503 })
        return allowCors && origin ? addCorsHeaders(response, origin) : response
      }

      console.log("[API][ID] ❌ Payment absent from Redis and durable authorities:", id)
      const notFoundResponse = NextResponse.json({ 
        error: "Payment not found",
        paymentId: id,
      }, { status: 404 })
      return allowCors && origin ? addCorsHeaders(notFoundResponse, origin) : notFoundResponse
    }

    console.log("[API] Payment retrieved:", id, "status:", payment.status)

    // DR87: expose only a boolean derived from durable PostgreSQL approval ownership.
    // Never expose the Pi identifier. Uncertainty fails closed before a pending payment can be retried.
    const approvalOwnership = await readSettlementU2AApprovalOwnership(id)
    if (approvalOwnership.outcome === "INDETERMINATE") {
      const response = NextResponse.json({ error: "Payment status temporarily unavailable", paymentId: id }, { status: 503 })
      return allowCors && origin ? addCorsHeaders(response, origin) : response
    }

    // A structurally plausible Redis projection is never proof of a financial
    // transition. With no branch owner, only verified durable U2A ingress may
    // establish paid_to_app; later states require their own durable branch.
    if (!authority.settlementActive && !authority.refundActive &&
        !["pending", "failed", "cancelled"].includes(payment.status)) {
      const ingress = payment.status === "paid_to_app" ? await getDurableU2AIngressAuthoritative(id) : null
      if (!ingress || ingress.outcome !== "FOUND" || ingress.checkpoint.completedAt === null ||
          ingress.checkpoint.paymentId !== id || ingress.checkpoint.merchantId !== payment.merchantId ||
          ingress.checkpoint.merchantUid !== payment.merchantUid || ingress.checkpoint.customerAmount !== payment.amount ||
          ingress.checkpoint.u2aIdentifier !== payment.piPaymentId || ingress.checkpoint.u2aTxid !== payment.u2aTxid) {
        const response = NextResponse.json({ error: "Payment status temporarily unavailable", paymentId: id }, { status: 503 })
        return allowCors && origin ? addCorsHeaders(response, origin) : response
      }
    }

    let publicPayment = { ...getPublicPayment(payment), piPaymentInitiated: approvalOwnership.outcome === "CLAIMED" }
    if (authority.settlementActive) {
      const durable = await getSettlementCheckpointAuthoritative(id)
      if (durable.outcome !== "FOUND") {
        const response = NextResponse.json({ error: "Payment status temporarily unavailable", paymentId: id }, { status: 503 })
        return allowCors && origin ? addCorsHeaders(response, origin) : response
      }
      if (durable.checkpoint.paymentId !== id || durable.checkpoint.merchantId !== payment.merchantId ||
          durable.checkpoint.merchantUid !== payment.merchantUid || durable.checkpoint.customerAmount !== payment.amount ||
          (payment.piPaymentId != null && durable.checkpoint.u2aIdentifier !== payment.piPaymentId)) {
        const response = NextResponse.json({ error: "Payment identity conflict", paymentId: id }, { status: 409 })
        return allowCors && origin ? addCorsHeaders(response, origin) : response
      }
      const durableStatus = durable.checkpoint.stage === "db_finalized" ? "settled_to_merchant" : "settlement_pending"
      publicPayment = {...publicPayment,status:durableStatus,txid:durable.checkpoint.a2uTxid || publicPayment.txid}
      if (payment.status !== durableStatus || (durable.checkpoint.a2uTxid && payment.a2uTxid !== durable.checkpoint.a2uTxid)) {
        await compareAndSwapPaymentProjection(id, payment, {
          ...payment,
          status: durableStatus,
          ...(durable.checkpoint.a2uTxid ? { a2uTxid: durable.checkpoint.a2uTxid } : {}),
          ...(durable.checkpoint.stage === "db_finalized" ? { dbRecorded: true, requiresDbReconciliation: false } : {}),
        })
      }
    } else if (authority.refundActive) {
      const durable = await getRefundCheckpointsByPaymentIds([id])
      const checkpoint = durable.state === "ok" ? durable.checkpoints.get(id) : undefined
      const ingress = await getDurableU2AIngressAuthoritative(id)
      if (durable.state !== "ok" || !checkpoint || checkpoint.status === "manual_review_required" ||
          ingress.outcome !== "FOUND" || ingress.checkpoint.completedAt === null ||
          ingress.checkpoint.paymentId !== id || ingress.checkpoint.merchantId !== payment.merchantId ||
          ingress.checkpoint.merchantUid !== payment.merchantUid || ingress.checkpoint.customerAmount !== payment.amount ||
          checkpoint.paymentId !== id || checkpoint.amount !== ingress.checkpoint.customerAmount ||
          checkpoint.payerUid !== ingress.checkpoint.payerUid) {
        const response = NextResponse.json({ error: "Payment status temporarily unavailable", paymentId: id }, { status: 503 })
        return allowCors && origin ? addCorsHeaders(response, origin) : response
      }
      const durableStatus = checkpoint.status === "completed" && checkpoint.stage === "audit_recorded" ? "refunded" : "refund_pending"
      publicPayment = {...publicPayment,status:durableStatus,txid:checkpoint.refundTxid || publicPayment.txid}
      // DR67: refund_pending is a customer-facing presentation state, not the
      // pre-submission source-of-funds state used by the refund executor. Do not
      // write presentation status back into Redis here. The refund executor owns
      // internal projection transitions after canonical refund evidence exists.
    }
    // Recheck the immutable branch choice before publishing/caching finality.
    const confirmedAuthority = await readSettlementRefundAuthority(id)
    if (confirmedAuthority.outcome !== "CLEAR" || confirmedAuthority.settlementActive !== authority.settlementActive ||
        confirmedAuthority.refundActive !== authority.refundActive) {
      return NextResponse.json({ error: "Payment status temporarily unavailable", paymentId: id }, { status: 503 })
    }
    const successResponse = NextResponse.json({
      success: true,
      payment: publicPayment,
    })
    if (allowCors && origin) {
      return addCorsHeaders(successResponse, origin)
    }
    return successResponse
  } catch (error) {
    console.error("[API] Error fetching payment:", error)
    const errorResponse = NextResponse.json({ error: "Failed to fetch payment" }, { status: 500 })
    if (allowCors && origin) {
      return addCorsHeaders(errorResponse, origin)
    }
    return errorResponse
  }
}

export async function PATCH(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!isKvConfigured) return NextResponse.json({ error: "Redis not configured" }, { status: 503 })

  const { id } = await params
  const verifiedPayer = await authorizeFromHeader(request.headers.get("authorization"))
  if (!verifiedPayer) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const raw = await redis.get(`payment:${id}`)
  const payment: any = raw ? (typeof raw === "string" ? JSON.parse(raw) : raw) : null
  if (!payment) return NextResponse.json({ error: "Payment not found" }, { status: 404 })
  if (payment.id !== id) return NextResponse.json({ error: "Payment identity conflict" }, { status: 409 })

  // Presentation identity can be projected only after authoritative U2A identity capture.
  // It never changes payment status, settlement authority, refund eligibility, or accounting.
  if (payment.payerUidSource !== "verified_u2a" || payment.payerUid !== verifiedPayer.uid) {
    return NextResponse.json({ error: "Payer identity not verified for this payment" }, { status: 403 })
  }

  const username = verifiedPayer.username.trim()
  if (!username) return NextResponse.json({ error: "Verified username unavailable" }, { status: 409 })

  const updated = await redis.eval<[string, string, string], number>(`
local latest=redis.call('GET',KEYS[1]); if not latest then return 0 end
local ok,current=pcall(cjson.decode,latest); if not ok or type(current)~='table' then return 0 end
if current.id~=ARGV[1] or current.payerUidSource~='verified_u2a' or current.payerUid~=ARGV[2] then return 0 end
if current.payerUsername~=nil and current.payerUsername~=ARGV[3] then return -1 end
local projectionVersion=current.redisProjectionVersion; if projectionVersion==nil then projectionVersion=0 end
if type(projectionVersion)~='number' or projectionVersion<0 or projectionVersion~=math.floor(projectionVersion) then return 0 end
current.payerUsername=ARGV[3]; current.redisProjectionVersion=projectionVersion+1
redis.call('SET',KEYS[1],cjson.encode(current)); return 1
`, [`payment:${id}`], [id, verifiedPayer.uid, username])

  if (updated === -1) return NextResponse.json({ error: "Payer username conflict" }, { status: 409 })
  if (updated !== 1) return NextResponse.json({ error: "Payer identity projection unavailable" }, { status: 409 })
  return NextResponse.json({ success: true })
}
