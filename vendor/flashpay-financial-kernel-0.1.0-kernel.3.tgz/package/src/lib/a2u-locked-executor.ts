import {currentRecoveryRight} from './r36-recovery-scope'
import { readDurableSettlementProjection } from "./settlement-durable-projection"
import { verifyPreparedWalletAuthority, claimFirstWalletSubmission } from "./financial-wallet-authority"
import { redis, isRedisConfigured } from "./redis"
import { executeA2U, persistCheckpointMerged } from "./a2u-executor"
import { buildA2USuccessResponse } from "./a2u-response"
import type { Payment } from "./types"
import { findRefundCheckpointByPaymentId } from "./refund-checkpoint-store"
import { getSettlementCheckpointAuthoritative, getDurableU2AIngressAuthoritative, recordSettlementA2UCreatedCheckpoint, recordSettlementHorizonCheckpoint, verifySettlementRefundAuthorityExclusion } from "./db"
import { readSettlementCreatePiEvidence } from "./financial-recovery-settlement-create-pi-reader"
import { evaluateFinancialRecoverySettlementCreateReadBinding } from "./financial-recovery-settlement-create-read-binding"
import { executeFinancialRecoverySettlementSubmitReplay } from "./financial-recovery-settlement-submit-replay-orchestration"
import { logSettlementSubmitRuntimeDiagnostic } from "./settlement-submit-runtime-diagnostic"
import { acquirePiWalletSubmitLock, claimPiWalletIntent, readPiWalletIntent, replacePiWalletIntent, releasePiWalletIntent } from "./pi-wallet-submit-lock"
import * as StellarSDK from "@stellar/stellar-sdk"
import crypto from "crypto"
import { serverConfig } from "./server-config"
import { reconcileIncompleteA2UPayment } from "./pi-reconciliation"

/**
 * SHARED CONCURRENCY LOCK FOR A2U EXECUTION
 * ============================================
 * 
 * ONE concurrency boundary for all A2U execution paths:
 * - /api/pi/a2u (A2U direct)
 * - /api/pi/complete (U2A completion)
 * - /api/recovery/[id] (recovery orchestration)
 * 
 * NO caller may invoke executeA2U directly.
 * 
 * Shared Payment-Operation Lock Strategy:
 * - Key: flashpay:payment:operation:${paymentId}
 * - Shared with Refund so Settlement and Refund cannot overlap for one paymentId
 * - NX + EX 600s + unique token; token-checked renewal every 180s and atomic release
 * - Lease expiry/loss is never financial authorization: PostgreSQL durable branch authority,
 *   persistent source-wallet intent, and exact Horizon reconciliation remain fail-closed guards
 * - Source-wallet submission is separately serialized by flashpay:wallet:submit:${sourceAddress}
 * - If the payment-operation lock cannot be acquired: reread only; never execute a competing move
 */

function horizonFeePiToExactStroops(value: number): number | null {
  if (!Number.isFinite(value) || value < 0) return null
  const stroops = Math.round(value * 10_000_000)
  if (!Number.isSafeInteger(stroops) || stroops < 0) return null
  return stroops / 10_000_000 === value ? stroops : null
}

interface LockedExecutorParams {
  paymentId: string
  isRecovery: boolean
  recoveryOperation?: "SETTLEMENT_CREATE" | "SETTLEMENT_SUBMIT" | "SETTLEMENT_RECONCILE" | "SETTLEMENT_DISPATCH"
  schedulerWalletPaymentId?: string | null
}

function hasRecoverableMerchantProjectionAuthority(payment: Payment): boolean {
  return payment.accessToken === undefined || payment.accessToken === "" ||
    (typeof payment.accessToken === "string" && payment.accessToken.trim() !== "" && payment.accessToken === payment.accessToken.trim())
}

function asRecord(value: unknown): Record<string, unknown> | null {
  return value !== null && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : null
}

function isF24PreA2UTimestampRepairSafe(payment: Payment): boolean {
  const version = payment.redisProjectionVersion
  return payment.status === "paid_to_app" && Number.isSafeInteger(version) && Number(version) >= 0 &&
    payment.a2uPaymentId === undefined && payment.a2uTxid === undefined && payment.a2uPreparedEnvelopeXdr === undefined &&
    payment.a2uPreparedTxHash === undefined && payment.a2uPreparedSequence === undefined && payment.a2uFromAddress === undefined &&
    payment.a2uToAddress === undefined && payment.merchantAmount === undefined && payment.horizonFeeCharged === undefined &&
    payment.appCommission === undefined && payment.appNetImpact === undefined && payment.horizonSuccessAt === undefined &&
    payment.settledAt === undefined && payment.refundPaymentId === undefined && payment.refundTxid === undefined &&
    payment.refundStatus === undefined && payment.refundFailureCode === undefined && payment.refundProof === undefined &&
    payment.settlementFailureState === undefined && payment.retryCount === undefined && payment.lastAttemptAt === undefined &&
    payment.nextRetryAt === undefined && payment.a2uErrorCode === undefined && payment.a2uErrorMessage === undefined &&
    payment.a2uErrorBody === undefined && (payment.payerRefundEligible === undefined || payment.payerRefundEligible === false) &&
    (payment.horizonSuccessFlag === undefined || payment.horizonSuccessFlag === false) &&
    (payment.piCompletionPending === undefined || payment.piCompletionPending === false) &&
    (payment.piCompleted === undefined || payment.piCompleted === false) &&
    (payment.requiresDbReconciliation === undefined || payment.requiresDbReconciliation === false) &&
    (payment.dbRecorded === undefined || payment.dbRecorded === false)
}

async function canonicalizeF24DurableTimestamps(paymentId: string, payment: Payment, verifiedAt: string, completedAt: string): Promise<Payment | null> {
  if (!isF24PreA2UTimestampRepairSafe(payment)) return null
  if (typeof payment.merchantUid !== "string" || payment.merchantUid.trim() === "" || payment.merchantUid !== payment.merchantUid.trim() ||
      typeof payment.customerAmount !== "number" || !Number.isFinite(payment.customerAmount) || payment.customerAmount <= 0 ||
      typeof payment.piPaymentId !== "string" || payment.piPaymentId.trim() === "" || payment.piPaymentId !== payment.piPaymentId.trim() ||
      typeof payment.u2aTxid !== "string" || !/^[0-9a-f]{64}$/.test(payment.u2aTxid) ||
      typeof payment.payerUid !== "string" || payment.payerUid.trim() === "" || payment.payerUid !== payment.payerUid.trim()) return null
  const expectedVersion = Number(payment.redisProjectionVersion)
  const repairArgs: [string, string, string, string, string, string, string, string, string, string] = [
    payment.id, payment.merchantId, payment.merchantUid, String(payment.customerAmount), payment.piPaymentId, payment.u2aTxid, payment.payerUid,
    String(expectedVersion), verifiedAt, completedAt,
  ]
  const repaired = await redis.eval<[string, string, string, string, string, string, string, string, string, string], number>(`
local raw=redis.call('GET',KEYS[1]); if not raw then return 0 end
local ok,current=pcall(cjson.decode,raw); if not ok or type(current)~='table' then return -1 end
local amount=tonumber(ARGV[4]); local version=tonumber(ARGV[8]); if not amount or not version then return -1 end
if current.redisProjectionVersion~=version then return 0 end
if current.id~=ARGV[1] or current.merchantId~=ARGV[2] or current.merchantUid~=ARGV[3] or current.amount~=amount or current.customerAmount~=amount then return -1 end
if current.piPaymentId~=ARGV[5] or current.u2aTxid~=ARGV[6] or current.payerUid~=ARGV[7] or current.payerUidSource~='verified_u2a' or current.status~='paid_to_app' then return -1 end
if current.a2uPaymentId~=nil or current.a2uTxid~=nil or current.a2uPreparedEnvelopeXdr~=nil or current.a2uPreparedTxHash~=nil or current.a2uPreparedSequence~=nil or current.a2uFromAddress~=nil or current.a2uToAddress~=nil then return -1 end
if current.merchantAmount~=nil or current.horizonFeeCharged~=nil or current.appCommission~=nil or current.appNetImpact~=nil or current.horizonSuccessAt~=nil or current.settledAt~=nil then return -1 end
if current.refundPaymentId~=nil or current.refundTxid~=nil or current.refundStatus~=nil or current.refundFailureCode~=nil or current.refundProof~=nil then return -1 end
if current.settlementFailureState~=nil or current.retryCount~=nil or current.lastAttemptAt~=nil or current.nextRetryAt~=nil or current.a2uErrorCode~=nil or current.a2uErrorMessage~=nil or current.a2uErrorBody~=nil then return -1 end
if current.payerRefundEligible==true or current.horizonSuccessFlag==true or current.piCompletionPending==true or current.piCompleted==true or current.requiresDbReconciliation==true or current.dbRecorded==true then return -1 end
current.payerUidCapturedAt=ARGV[9]; current.paidAt=ARGV[10]; current.settlementDispatchRequestedAt=ARGV[10]; current.redisProjectionVersion=version+1
redis.call('SET',KEYS[1],cjson.encode(current)); return 1
`, [`payment:${paymentId}`], repairArgs)
  if (repaired !== 1) return null
  const readbackRaw = await redis.get(`payment:${paymentId}`)
  if (!readbackRaw) return null
  let readback: Payment
  try { readback = (typeof readbackRaw === "string" ? JSON.parse(readbackRaw) : readbackRaw) as Payment } catch { return null }
  if (readback.id !== paymentId || readback.payerUidCapturedAt !== verifiedAt || readback.paidAt !== completedAt || readback.settlementDispatchRequestedAt !== completedAt) return null
  console.warn("[F2-4 DURABLE TIMESTAMP HOTPATH REPAIR] canonicalized pre-A2U projection", { paymentId, financialAuthorityMutated: false, financialMovementExecuted: false })
  return readback
}

async function verifyF24DurableMerchantAuthority(paymentId: string, payment: Payment): Promise<Payment | null> {
  if (!serverConfig.isPiApiKeyConfigured) return null
  const durable = await getDurableU2AIngressAuthoritative(paymentId)
  if (durable.outcome !== "FOUND") return null
  const d = durable.checkpoint
  const completedAt = d.completedAt
  if (completedAt === null) return null
  if (
    payment.id !== d.paymentId ||
    payment.merchantId !== d.merchantId || payment.merchantUid !== d.merchantUid ||
    payment.amount !== d.customerAmount || payment.customerAmount !== d.customerAmount ||
    payment.piPaymentId !== d.u2aIdentifier || payment.u2aTxid !== d.u2aTxid ||
    payment.payerUid !== d.payerUid || payment.payerUidSource !== "verified_u2a" ||
    payment.status !== "paid_to_app"
  ) return null

  let response: Response
  try {
    response = await fetch(`https://api.minepi.com/v2/payments/${encodeURIComponent(d.u2aIdentifier)}`, {
      method: "GET",
      headers: { Authorization: `Key ${serverConfig.piApiKey}`, Accept: "application/json" },
      cache: "no-store",
      redirect: "error",
    })
  } catch { return null }
  if (!response.ok) return null
  const dto = asRecord(await response.json().catch(() => null))
  const metadata = dto ? asRecord(dto.metadata) : null
  const transaction = dto ? asRecord(dto.transaction) : null
  const status = dto ? asRecord(dto.status) : null
  const exactPiAuthority = dto !== null &&
    dto.identifier === d.u2aIdentifier && dto.direction === "user_to_app" &&
    dto.amount === d.customerAmount && dto.user_uid === d.payerUid &&
    metadata?.paymentId === paymentId && transaction?.txid === d.u2aTxid && transaction?.verified === true &&
    status?.developer_approved === true && status?.transaction_verified === true && status?.developer_completed === true &&
    status?.cancelled !== true && status?.user_cancelled !== true
  if (!exactPiAuthority) return null

  if (payment.payerUidCapturedAt === d.verifiedAt && payment.paidAt === completedAt && payment.settlementDispatchRequestedAt === completedAt) return payment
  return canonicalizeF24DurableTimestamps(paymentId, payment, d.verifiedAt, completedAt)
}

function isSettlementDispatchCandidate(payment: Payment, now: number): boolean {
  const dispatchAt = typeof payment.settlementDispatchRequestedAt === "string" && payment.settlementDispatchRequestedAt.trim() !== "" && payment.settlementDispatchRequestedAt === payment.settlementDispatchRequestedAt.trim() ? Date.parse(payment.settlementDispatchRequestedAt) : NaN
  const paidAt = typeof payment.paidAt === "string" && payment.paidAt.trim() !== "" && payment.paidAt === payment.paidAt.trim() ? Date.parse(payment.paidAt) : NaN
  const u2aTxid = payment.u2aTxid
  return payment.status === "paid_to_app" && Number.isFinite(dispatchAt) && Number.isFinite(paidAt) && dispatchAt === paidAt && payment.settlementDispatchRequestedAt === payment.paidAt && dispatchAt <= now && typeof payment.amount === "number" && Number.isFinite(payment.amount) && payment.amount > 0 && typeof payment.customerAmount === "number" && Number.isFinite(payment.customerAmount) && payment.customerAmount > 0 && payment.amount === payment.customerAmount && typeof payment.piPaymentId === "string" && payment.piPaymentId.trim() !== "" && payment.piPaymentId === payment.piPaymentId.trim() && typeof payment.merchantId === "string" && payment.merchantId.trim() !== "" && payment.merchantId === payment.merchantId.trim() && typeof payment.merchantUid === "string" && payment.merchantUid.trim() !== "" && payment.merchantUid === payment.merchantUid.trim() && hasRecoverableMerchantProjectionAuthority(payment) && typeof payment.payerUid === "string" && payment.payerUid.trim() !== "" && payment.payerUid === payment.payerUid.trim() && payment.payerUidSource === "verified_u2a" && typeof payment.payerUidCapturedAt === "string" && payment.payerUidCapturedAt.trim() !== "" && payment.payerUidCapturedAt === payment.payerUidCapturedAt.trim() && Number.isFinite(Date.parse(payment.payerUidCapturedAt)) && Date.parse(payment.payerUidCapturedAt) <= now && typeof u2aTxid === "string" && u2aTxid === u2aTxid.trim() && /^[0-9a-f]{64}$/.test(u2aTxid) && payment.a2uTxid === undefined && payment.settlementFailureState === undefined && payment.retryCount === undefined && payment.lastAttemptAt === undefined && payment.nextRetryAt === undefined && payment.a2uPaymentId === undefined && payment.a2uPreparedEnvelopeXdr === undefined && payment.a2uPreparedTxHash === undefined && payment.a2uPreparedSequence === undefined && payment.a2uFromAddress === undefined && payment.a2uToAddress === undefined && payment.merchantAmount === undefined && payment.horizonFeeCharged === undefined && payment.appCommission === undefined && payment.appNetImpact === undefined && payment.a2uErrorCode === undefined && payment.a2uErrorMessage === undefined && payment.a2uErrorBody === undefined && payment.horizonSuccessAt === undefined && payment.settledAt === undefined && payment.refundPaymentId === undefined && payment.refundTxid === undefined && payment.refundStatus === undefined && payment.refundFailureCode === undefined && payment.refundProof === undefined && (payment.payerRefundEligible === undefined || payment.payerRefundEligible === false) && (payment.horizonSuccessFlag === undefined || payment.horizonSuccessFlag === false) && (payment.piCompletionPending === undefined || payment.piCompletionPending === false) && (payment.piCompleted === undefined || payment.piCompleted === false) && (payment.requiresDbReconciliation === undefined || payment.requiresDbReconciliation === false) && (payment.dbRecorded === undefined || payment.dbRecorded === false)
}

function isSettlementReconcileCandidate(payment: Payment, now: number): boolean {
  const dispatchAt = typeof payment.settlementDispatchRequestedAt === "string" && payment.settlementDispatchRequestedAt.trim() !== "" && payment.settlementDispatchRequestedAt === payment.settlementDispatchRequestedAt.trim() ? Date.parse(payment.settlementDispatchRequestedAt) : NaN
  const paidAt = typeof payment.paidAt === "string" && payment.paidAt.trim() !== "" && payment.paidAt === payment.paidAt.trim() ? Date.parse(payment.paidAt) : NaN
  const lastAttemptAt = typeof payment.lastAttemptAt === "string" && payment.lastAttemptAt.trim() !== "" && payment.lastAttemptAt === payment.lastAttemptAt.trim() ? Date.parse(payment.lastAttemptAt) : NaN
  const nextRetryAt = payment.nextRetryAt === undefined ? NaN : typeof payment.nextRetryAt === "string" && payment.nextRetryAt.trim() !== "" && payment.nextRetryAt === payment.nextRetryAt.trim() ? Date.parse(payment.nextRetryAt) : NaN
  const u2aTxid = payment.u2aTxid
  const common = payment.status === "paid_to_app" && Number.isFinite(dispatchAt) && Number.isFinite(paidAt) && dispatchAt === paidAt && payment.settlementDispatchRequestedAt === payment.paidAt && dispatchAt <= now && Number.isFinite(lastAttemptAt) && lastAttemptAt >= paidAt && typeof payment.amount === "number" && Number.isFinite(payment.amount) && payment.amount > 0 && typeof payment.customerAmount === "number" && Number.isFinite(payment.customerAmount) && payment.customerAmount > 0 && payment.amount === payment.customerAmount && typeof payment.piPaymentId === "string" && payment.piPaymentId.trim() !== "" && payment.piPaymentId === payment.piPaymentId.trim() && typeof payment.merchantId === "string" && payment.merchantId.trim() !== "" && payment.merchantId === payment.merchantId.trim() && typeof payment.merchantUid === "string" && payment.merchantUid.trim() !== "" && payment.merchantUid === payment.merchantUid.trim() && hasRecoverableMerchantProjectionAuthority(payment) && typeof payment.payerUid === "string" && payment.payerUid.trim() !== "" && payment.payerUid === payment.payerUid.trim() && payment.payerUidSource === "verified_u2a" && typeof payment.payerUidCapturedAt === "string" && payment.payerUidCapturedAt.trim() !== "" && payment.payerUidCapturedAt === payment.payerUidCapturedAt.trim() && Number.isFinite(Date.parse(payment.payerUidCapturedAt)) && Date.parse(payment.payerUidCapturedAt) <= now && typeof u2aTxid === "string" && u2aTxid === u2aTxid.trim() && /^[0-9a-f]{64}$/.test(u2aTxid) && payment.a2uTxid === undefined && payment.a2uPaymentId === undefined && payment.a2uPreparedEnvelopeXdr === undefined && payment.a2uPreparedTxHash === undefined && payment.a2uPreparedSequence === undefined && payment.a2uFromAddress === undefined && payment.a2uToAddress === undefined && payment.merchantAmount === undefined && payment.horizonFeeCharged === undefined && payment.appCommission === undefined && payment.appNetImpact === undefined && payment.horizonSuccessAt === undefined && payment.settledAt === undefined && payment.refundPaymentId === undefined && payment.refundTxid === undefined && payment.refundFailureCode === undefined && payment.refundProof === undefined && (payment.payerRefundEligible === undefined || payment.payerRefundEligible === false) && (payment.horizonSuccessFlag === undefined || payment.horizonSuccessFlag === false) && (payment.piCompletionPending === undefined || payment.piCompletionPending === false) && (payment.piCompleted === undefined || payment.piCompleted === false) && (payment.dbRecorded === undefined || payment.dbRecorded === false) && (payment.requiresDbReconciliation === undefined || payment.requiresDbReconciliation === false)
  const freshAttempt = payment.settlementFailureState === "reconciling" && payment.retryCount === 1 && payment.nextRetryAt === undefined && lastAttemptAt <= now - 660000 && payment.refundStatus === undefined && payment.a2uErrorCode === undefined && payment.a2uErrorMessage === undefined && payment.a2uErrorBody === undefined
  const retryAttempt = payment.settlementFailureState === "reconciling" && typeof payment.retryCount === "number" && Number.isInteger(payment.retryCount) && payment.retryCount >= 2 && Number.isFinite(nextRetryAt) && nextRetryAt <= lastAttemptAt && lastAttemptAt <= now - 660000 && (payment.refundStatus === undefined || payment.refundStatus === "not_started") && (payment.a2uErrorCode === undefined || typeof payment.a2uErrorCode === "string" && payment.a2uErrorCode.trim() !== "") && (payment.a2uErrorMessage === undefined || typeof payment.a2uErrorMessage === "string" && payment.a2uErrorMessage.trim() !== "") && (payment.a2uErrorBody === undefined || typeof payment.a2uErrorBody === "string" && payment.a2uErrorBody.trim() !== "")
  return common && (freshAttempt || retryAttempt)
}

export function isStage1OnlySettlementDispatchCandidate(payment: Payment, now: number): boolean {
  const dispatchAt = typeof payment.settlementDispatchRequestedAt === "string" && payment.settlementDispatchRequestedAt.trim() !== "" && payment.settlementDispatchRequestedAt === payment.settlementDispatchRequestedAt.trim() ? Date.parse(payment.settlementDispatchRequestedAt) : NaN
  const paidAt = typeof payment.paidAt === "string" && payment.paidAt.trim() !== "" && payment.paidAt === payment.paidAt.trim() ? Date.parse(payment.paidAt) : NaN
  const lastAttemptAt = typeof payment.lastAttemptAt === "string" && payment.lastAttemptAt.trim() !== "" && payment.lastAttemptAt === payment.lastAttemptAt.trim() ? Date.parse(payment.lastAttemptAt) : NaN
  const u2aTxid = payment.u2aTxid
  return (payment.status === "paid_to_app" || payment.status === "settlement_pending") && payment.settlementFailureState === "none" &&
    Number.isFinite(dispatchAt) && Number.isFinite(paidAt) && dispatchAt === paidAt && payment.settlementDispatchRequestedAt === payment.paidAt && dispatchAt <= now &&
    Number.isFinite(lastAttemptAt) && lastAttemptAt >= paidAt && lastAttemptAt <= now &&
    typeof payment.amount === "number" && Number.isFinite(payment.amount) && payment.amount > 0 &&
    typeof payment.customerAmount === "number" && Number.isFinite(payment.customerAmount) && payment.customerAmount === payment.amount &&
    typeof payment.piPaymentId === "string" && payment.piPaymentId.trim() !== "" && payment.piPaymentId === payment.piPaymentId.trim() &&
    typeof payment.merchantId === "string" && payment.merchantId.trim() !== "" && payment.merchantId === payment.merchantId.trim() &&
    typeof payment.merchantUid === "string" && payment.merchantUid.trim() !== "" && payment.merchantUid === payment.merchantUid.trim() &&
    hasRecoverableMerchantProjectionAuthority(payment) &&
    typeof payment.payerUid === "string" && payment.payerUid.trim() !== "" && payment.payerUid === payment.payerUid.trim() && payment.payerUidSource === "verified_u2a" &&
    typeof payment.payerUidCapturedAt === "string" && payment.payerUidCapturedAt.trim() !== "" && payment.payerUidCapturedAt === payment.payerUidCapturedAt.trim() && Number.isFinite(Date.parse(payment.payerUidCapturedAt)) && Date.parse(payment.payerUidCapturedAt) <= now &&
    typeof u2aTxid === "string" && /^[0-9a-f]{64}$/.test(u2aTxid) && u2aTxid === u2aTxid.trim() &&
    typeof payment.a2uPaymentId === "string" && payment.a2uPaymentId.trim() !== "" && payment.a2uPaymentId === payment.a2uPaymentId.trim() &&
    typeof payment.a2uFromAddress === "string" && payment.a2uFromAddress.trim() !== "" && payment.a2uFromAddress === payment.a2uFromAddress.trim() &&
    typeof payment.a2uToAddress === "string" && payment.a2uToAddress.trim() !== "" && payment.a2uToAddress === payment.a2uToAddress.trim() &&
    typeof payment.merchantAmount === "number" && Number.isFinite(payment.merchantAmount) && payment.merchantAmount === payment.customerAmount &&
    payment.a2uTxid === undefined && payment.a2uPreparedEnvelopeXdr === undefined && payment.a2uPreparedTxHash === undefined && payment.a2uPreparedSequence === undefined &&
    payment.horizonFeeCharged === undefined && payment.appNetImpact === undefined && payment.horizonSuccessAt === undefined && payment.settledAt === undefined &&
    payment.refundPaymentId === undefined && payment.refundTxid === undefined && payment.refundProof === undefined &&
    (payment.refundStatus === undefined || payment.refundStatus === "not_started") && (payment.payerRefundEligible === undefined || payment.payerRefundEligible === false) &&
    (payment.horizonSuccessFlag === undefined || payment.horizonSuccessFlag === false) &&
    (payment.piCompletionPending === undefined || payment.piCompletionPending === false) &&
    (payment.piCompleted === undefined || payment.piCompleted === false) &&
    (payment.requiresDbReconciliation === undefined || payment.requiresDbReconciliation === false) &&
    (payment.dbRecorded === undefined || payment.dbRecorded === false)
}

async function verifyStage1OnlyDurableAuthority(paymentId: string, payment: Payment): Promise<boolean> {
  const durable = await getSettlementCheckpointAuthoritative(paymentId)
  if (durable.outcome !== "FOUND" || durable.checkpoint.stage !== "a2u_created") return false
  const d = durable.checkpoint
  return payment.id === d.paymentId &&
    payment.merchantId === d.merchantId && payment.merchantUid === d.merchantUid &&
    payment.customerAmount === d.customerAmount && payment.merchantAmount === d.merchantAmount &&
    payment.piPaymentId === d.u2aIdentifier && payment.u2aTxid === d.u2aTxid &&
    payment.a2uPaymentId === d.a2uPaymentId && payment.a2uFromAddress === d.a2uFromAddress && payment.a2uToAddress === d.a2uToAddress &&
    payment.a2uTxid === undefined && payment.a2uPreparedEnvelopeXdr === undefined && payment.a2uPreparedTxHash === undefined && payment.a2uPreparedSequence === undefined &&
    payment.horizonSuccessFlag !== true && payment.piCompleted !== true && payment.dbRecorded !== true &&
    payment.refundPaymentId === undefined && payment.refundTxid === undefined && payment.refundStatus !== "completed"
}

async function verifySettlementSubmitDurablePreparedAuthority(paymentId: string, payment: Payment): Promise<boolean> {
  const durable = await getSettlementCheckpointAuthoritative(paymentId)
  if (durable.outcome !== "FOUND" || durable.checkpoint.stage !== "prepared") return false
  const d = durable.checkpoint
  return payment.id === d.paymentId &&
    payment.merchantId === d.merchantId && payment.merchantUid === d.merchantUid &&
    payment.customerAmount === d.customerAmount && payment.merchantAmount === d.merchantAmount &&
    payment.piPaymentId === d.u2aIdentifier && payment.u2aTxid === d.u2aTxid &&
    payment.a2uPaymentId === d.a2uPaymentId && payment.a2uFromAddress === d.a2uFromAddress && payment.a2uToAddress === d.a2uToAddress &&
    payment.a2uPreparedEnvelopeXdr === d.preparedEnvelopeXdr && payment.a2uPreparedTxHash === d.preparedTxHash && payment.a2uPreparedSequence === d.preparedSequence &&
    payment.a2uTxid === undefined && payment.horizonSuccessFlag !== true && payment.piCompleted !== true && payment.dbRecorded !== true &&
    payment.refundPaymentId === undefined && payment.refundTxid === undefined && payment.refundStatus !== "completed"
}

/**
 * Execute A2U under ONE shared concurrency lock.
 * If lock acquisition fails, reread payment and return its current state.
 * CRITICAL: Inside lock, any valid a2uTxid or horizonSuccessFlag permanently skips Stage 2.
 * ALL returns MUST be numeric HTTP status codes (never string | number).
 */
export async function executeA2ULocked(params: LockedExecutorParams) {
  const { paymentId } = params
  
  const lockToken = crypto.randomUUID()
  // Shared with refund intent creation: A2U and refund cannot overlap.
  const lockKey = `flashpay:payment:operation:${paymentId}`
  const lockTtl = 600 // 10 minutes

  console.log("[A2U Locked Executor] Acquiring concurrency lock for paymentId:", paymentId)

  if (!isRedisConfigured) {
    console.error("[A2U Locked Executor] Redis not configured")
    return { ok: false, status: 500, error: "Server not configured" }
  }

  let lockAcquired = false
  let lockRenewalTimer: ReturnType<typeof setInterval> | null = null
  let lockRenewalInFlight = false
  try {
    const lockResult = await redis.set(lockKey, lockToken, { nx: true, ex: lockTtl })
    lockAcquired = lockResult === "OK"
    if (lockAcquired) {
      lockRenewalTimer = setInterval(async () => {
        if (lockRenewalInFlight) return
        lockRenewalInFlight = true
        try {
          const renewed = await redis.eval<[string, string], number>(
            'if redis.call("get",KEYS[1])~=ARGV[1] then return 0 end; return redis.call("expire",KEYS[1],ARGV[2])',
            [lockKey], [lockToken, String(lockTtl)],
          )
          if (renewed !== 1 && lockRenewalTimer) { clearInterval(lockRenewalTimer); lockRenewalTimer = null }
        } catch {
          // Never renew without exact token ownership; durable authorities remain fail-closed.
        } finally { lockRenewalInFlight = false }
      }, 180_000)
      lockRenewalTimer.unref?.()
    }
  } catch (lockError) {
    console.error("[A2U Locked Executor] Lock acquisition error:", lockError)
  }

  const releaseLockAtomic = async () => {
    if (lockRenewalTimer) { clearInterval(lockRenewalTimer); lockRenewalTimer = null }
    if (!lockAcquired || !isRedisConfigured) return
    try {
      const luaScript = `
        if redis.call('get', KEYS[1]) == ARGV[1] then
          return redis.call('del', KEYS[1])
        else
          return 0
        end
      `
      await redis.eval(luaScript, [lockKey], [lockToken])
    } catch (error) {
      console.warn("[A2U Locked Executor] Failed to release lock atomically:", error)
    }
  }

  try {
    if (!lockAcquired) {
      console.warn("[A2U Locked Executor] Could not acquire lock - rereading current state")

      const paymentCheck = await redis.get(`payment:${paymentId}`)
      const payment = paymentCheck ? (typeof paymentCheck === "string" ? JSON.parse(paymentCheck) : paymentCheck) : null

      if (!payment) {
        console.error("[A2U Locked Executor] Payment not found")
        return { ok: false, status: 404, error: "Payment not found" }
      }

      // A denied Redis coordination lock cannot establish PostgreSQL finality.
      // Never return a potentially stale final success from this branch.
      console.warn("[A2U Locked Executor] Payment operation already in progress", { paymentId })
      return { ok: false, status: 409, error: "Payment operation in progress; retry status after recovery" }
    }

    console.log("[A2U Locked Executor] ✓ Lock acquired")

    const durableAuthority = await verifySettlementRefundAuthorityExclusion(paymentId)
    if (durableAuthority.outcome !== "CLEAR") {
      return { ok:false, status:409, error:durableAuthority.error }
    }

    // Inside lock: reload LATEST payment checkpoint
    let paymentData = await redis.get(`payment:${paymentId}`)
    if (!paymentData && params.isRecovery === true) {
      const projection = await readDurableSettlementProjection(paymentId)
      if (projection) {
        await redis.set(`payment:${paymentId}`,JSON.stringify(projection),{nx:true})
        paymentData=await redis.get(`payment:${paymentId}`)
      }
    }
    if (!paymentData) {
      console.error("[A2U Locked Executor] Payment projection unavailable after durable recovery")
      return { ok: false, status: 409, error: "Payment state could not be durably reconstructed" }
    }

    let latestPayment: Payment
    try {
      latestPayment = (typeof paymentData === "string" ? JSON.parse(paymentData) : paymentData) as Payment
    } catch {
      return { ok: false, status: 409, error: "Payment state could not be verified" }
    }
    if (!latestPayment || typeof latestPayment !== "object" || latestPayment.id !== paymentId) {
      return { ok: false, status: 409, error: "Payment state could not be verified" }
    }

    const refundLookup = await findRefundCheckpointByPaymentId(paymentId)
    if (refundLookup.state !== 'absent' && params.recoveryOperation !== "SETTLEMENT_CREATE") {
      return { ok: false, status: 409, error: refundLookup.state === 'present' ? "Refund operation owns this payment" : "Refund state could not be verified" }
    }

    // R101-6: after completed U2A, the durable PostgreSQL + canonical Pi
    // binding is the authority for fresh A2U creation in both normal drain and
    // recovery. Legacy Redis bearer values are tolerated but never consulted.
    let merchantAuthority: "durable_u2a" = "durable_u2a"
    if (!latestPayment.a2uPaymentId) {
      const verifiedPayment = await verifyF24DurableMerchantAuthority(paymentId, latestPayment)
      if (!verifiedPayment) return { ok: false, status: 409, error: "Durable merchant authority could not be verified" }
      latestPayment = verifiedPayment
      console.log("[R101-6 DURABLE MERCHANT AUTHORITY] verified", { paymentId, merchantId: latestPayment.merchantId, merchantUid: latestPayment.merchantUid, recoveryOperation: params.recoveryOperation ?? "normal" })
    }

    const scopedRight = currentRecoveryRight()
    if (scopedRight && (scopedRight.kind !== 'settlement' || scopedRight.id !== paymentId ||
        latestPayment.id !== paymentId || scopedRight.op !== latestPayment.a2uPaymentId ||
        scopedRight.hash !== latestPayment.a2uPreparedTxHash || scopedRight.seq !== latestPayment.a2uPreparedSequence ||
        scopedRight.wallet !== latestPayment.a2uFromAddress ||
        (params.recoveryOperation !== undefined && params.recoveryOperation !== 'SETTLEMENT_SUBMIT') ||
        (params.recoveryOperation === undefined && latestPayment.a2uTxid !== scopedRight.hash)))
      return {ok:false,status:409,error:"Scoped prepared identity unavailable"}

    if (params.recoveryOperation === "SETTLEMENT_DISPATCH") {
      const now = Date.now()
      const freshDispatch = isSettlementDispatchCandidate(latestPayment, now)
      const stage1OnlyDispatch = isStage1OnlySettlementDispatchCandidate(latestPayment, now)
      if (!(params.isRecovery === true && latestPayment.id === paymentId && (freshDispatch || stage1OnlyDispatch))) {
        return { ok: false, status: 409, error: "Settlement dispatch proof could not be verified" }
      }
      // F2-7 closure: a Stage1-only Redis projection is executable only when
      // PostgreSQL independently proves the exact same immutable A2U identity
      // at durable stage=a2u_created. This deliberately ignores stale retry
      // bookkeeping while refusing any prepared/Horizon/Refund evidence.
      if (stage1OnlyDispatch) {
        if (!(await verifyStage1OnlyDurableAuthority(paymentId, latestPayment))) {
          return { ok: false, status: 409, error: "Settlement Stage1 durable authority could not be verified" }
        }
        console.log("[F2-7 STAGE1 DURABLE RESUME]", { paymentId, a2uPaymentId: latestPayment.a2uPaymentId })
      }
    }

    if (params.recoveryOperation === "SETTLEMENT_RECONCILE") {
      if (params.isRecovery !== true || latestPayment.id !== paymentId || !isSettlementReconcileCandidate(latestPayment, Date.now())) {
        return { ok: false, status: 409, error: "Settlement reconcile proof could not be verified" }
      }

      // PLAN F: this lane exists only to recover an A2U identity whose Pi create
      // may have succeeded before the process could checkpoint the response. It
      // must never issue another Pi create or reach Horizon. Absence from Pi's
      // incomplete list is deliberately not strong enough to authorize a retry.
      const reconciliation = await reconcileIncompleteA2UPayment(paymentId, latestPayment.customerAmount!, latestPayment.merchantUid!)
      if (reconciliation.outcome !== "FOUND" || !reconciliation.dto) {
        return { ok: false, status: 409, error: reconciliation.outcome === "CONFIRMED_NONE" ? "Settlement reconcile found no strongly proven A2U identity" : "Settlement reconcile evidence is indeterminate" }
      }
      const dto = reconciliation.dto
      const metadata = asRecord(dto.metadata)
      const transaction = asRecord(dto.transaction)
      const status = asRecord(dto.status)
      const identifier = dto.identifier
      const fromAddress = dto.from_address
      const toAddress = dto.to_address
      const unmovedExactIdentity =
        typeof identifier === "string" && identifier.trim() !== "" && identifier === identifier.trim() &&
        typeof fromAddress === "string" && fromAddress.trim() !== "" && fromAddress === fromAddress.trim() &&
        typeof toAddress === "string" && toAddress.trim() !== "" && toAddress === toAddress.trim() &&
        dto.network === "Pi Testnet" && dto.direction === "app_to_user" && dto.amount === latestPayment.customerAmount &&
        dto.user_uid === latestPayment.merchantUid && metadata?.type === "a2u_settlement" && metadata?.paymentId === paymentId &&
        typeof dto.txid !== "string" && typeof dto.transaction_id !== "string" && dto.completed !== true && dto.cancelled !== true && dto.rejected !== true &&
        typeof transaction?.txid !== "string" && transaction?.verified !== true &&
        status?.transaction_verified !== true && status?.developer_completed !== true && status?.cancelled !== true && status?.user_cancelled !== true
      if (!unmovedExactIdentity) {
        return { ok: false, status: 409, error: "Settlement reconcile found A2U evidence requiring manual movement review" }
      }

      let reconciledProjection: Payment
      try {
        reconciledProjection = await persistCheckpointMerged(paymentId, {
          a2uPaymentId: identifier as string,
          a2uFromAddress: fromAddress as string,
          a2uToAddress: toAddress as string,
          merchantAmount: latestPayment.customerAmount,
          settlementFailureState: "none",
        })
      } catch {
        return { ok: false, status: 500, error: "Settlement reconciled A2U projection persistence failed" }
      }
      const durableStage1 = await recordSettlementA2UCreatedCheckpoint({
        paymentId, merchantId: reconciledProjection.merchantId, merchantUid: reconciledProjection.merchantUid!,
        customerAmount: reconciledProjection.customerAmount!, merchantAmount: reconciledProjection.merchantAmount!,
        u2aIdentifier: reconciledProjection.piPaymentId!, u2aTxid: reconciledProjection.u2aTxid!,
        a2uPaymentId: identifier as string, a2uFromAddress: fromAddress as string, a2uToAddress: toAddress as string,
      })
      if (durableStage1.outcome !== "RECORDED" && durableStage1.outcome !== "REPLAYED") {
        return { ok: false, status: 409, error: "Settlement reconciled A2U durable checkpoint not proven" }
      }
      return { ok: true, status: 202 }
    }

    if (params.recoveryOperation === undefined) {
      const canonicalA2UPaymentId = typeof latestPayment.a2uPaymentId === "string" && latestPayment.a2uPaymentId.trim() !== "" && latestPayment.a2uPaymentId === latestPayment.a2uPaymentId.trim()
      const canonicalA2UTxid = typeof latestPayment.a2uTxid === "string" && /^[0-9a-f]{64}$/.test(latestPayment.a2uTxid) && latestPayment.a2uTxid === latestPayment.a2uTxid.trim()
      const canonicalPreparedHash = typeof latestPayment.a2uPreparedTxHash === "string" && /^[0-9a-f]{64}$/.test(latestPayment.a2uPreparedTxHash) && latestPayment.a2uPreparedTxHash === latestPayment.a2uPreparedTxHash.trim()
      const canonicalPreparedSequence = typeof latestPayment.a2uPreparedSequence === "string" && /^[1-9][0-9]*$/.test(latestPayment.a2uPreparedSequence) && latestPayment.a2uPreparedSequence === latestPayment.a2uPreparedSequence.trim()
      const preparedPairAbsent = latestPayment.a2uPreparedTxHash === undefined && latestPayment.a2uPreparedSequence === undefined
      const preparedPairCanonical = canonicalPreparedHash && canonicalPreparedSequence
      const canonicalPreparedEnvelope = typeof latestPayment.a2uPreparedEnvelopeXdr === "string" && latestPayment.a2uPreparedEnvelopeXdr.trim() !== "" && latestPayment.a2uPreparedEnvelopeXdr === latestPayment.a2uPreparedEnvelopeXdr.trim()
      const preparedRecoveryException = params.isRecovery === true && latestPayment.status === "settlement_pending" && canonicalA2UTxid && latestPayment.a2uTxid === latestPayment.a2uPreparedTxHash && latestPayment.horizonSuccessFlag === true && latestPayment.piCompletionPending === true && latestPayment.piCompleted !== true && canonicalPreparedEnvelope && canonicalPreparedHash && canonicalPreparedSequence
      const dbRecoveryException = params.isRecovery === true && latestPayment.status === "settlement_pending" && latestPayment.requiresDbReconciliation === true && latestPayment.dbRecorded !== true && canonicalA2UPaymentId && canonicalA2UTxid && latestPayment.a2uTxid === latestPayment.a2uPreparedTxHash && latestPayment.horizonSuccessFlag === true && latestPayment.piCompletionPending === false && latestPayment.piCompleted === true && canonicalPreparedEnvelope && canonicalPreparedHash && canonicalPreparedSequence && typeof latestPayment.customerAmount === "number" && Number.isFinite(latestPayment.customerAmount) && latestPayment.customerAmount > 0 && typeof latestPayment.merchantAmount === "number" && Number.isFinite(latestPayment.merchantAmount) && latestPayment.merchantAmount === latestPayment.customerAmount && typeof latestPayment.horizonFeeCharged === "number" && Number.isFinite(latestPayment.horizonFeeCharged) && latestPayment.horizonFeeCharged >= 0 && latestPayment.appCommission === 0 && typeof latestPayment.appNetImpact === "number" && Number.isFinite(latestPayment.appNetImpact) && latestPayment.appNetImpact === latestPayment.customerAmount - latestPayment.merchantAmount - latestPayment.horizonFeeCharged
      const completionCheckpointRecoveryException = params.isRecovery === true && latestPayment.status === "settlement_pending" && latestPayment.requiresDbReconciliation !== true && latestPayment.dbRecorded !== true && canonicalA2UPaymentId && canonicalA2UTxid && latestPayment.a2uTxid === latestPayment.a2uPreparedTxHash && latestPayment.horizonSuccessFlag === true && latestPayment.piCompletionPending === false && latestPayment.piCompleted === true && canonicalPreparedEnvelope && canonicalPreparedHash && canonicalPreparedSequence && typeof latestPayment.customerAmount === "number" && Number.isFinite(latestPayment.customerAmount) && latestPayment.customerAmount > 0 && typeof latestPayment.merchantAmount === "number" && Number.isFinite(latestPayment.merchantAmount) && latestPayment.merchantAmount === latestPayment.customerAmount && typeof latestPayment.horizonFeeCharged === "number" && Number.isFinite(latestPayment.horizonFeeCharged) && latestPayment.horizonFeeCharged >= 0
      const preparedStateRecoveryException = preparedRecoveryException || dbRecoveryException || completionCheckpointRecoveryException
      if (
        (!preparedStateRecoveryException && !preparedPairAbsent && !preparedPairCanonical) ||
        (!preparedStateRecoveryException && latestPayment.a2uPreparedEnvelopeXdr !== undefined && (!canonicalPreparedEnvelope || latestPayment.a2uPreparedTxHash === undefined || latestPayment.a2uPreparedSequence === undefined || !canonicalPreparedHash || !canonicalPreparedSequence || latestPayment.a2uTxid !== latestPayment.a2uPreparedTxHash || latestPayment.status !== "settled_to_merchant")) ||
        (!preparedStateRecoveryException && latestPayment.a2uPreparedTxHash !== undefined && latestPayment.status !== "settled_to_merchant") ||
        (!preparedStateRecoveryException && latestPayment.a2uPreparedSequence !== undefined && latestPayment.status !== "settled_to_merchant") ||
        (!preparedStateRecoveryException && latestPayment.a2uPreparedTxHash !== undefined && latestPayment.a2uTxid !== latestPayment.a2uPreparedTxHash) ||
        (latestPayment.a2uPaymentId !== undefined && (!canonicalA2UPaymentId || !canonicalA2UTxid)) ||
        (latestPayment.a2uPaymentId === undefined && (latestPayment.a2uTxid !== undefined || (latestPayment.horizonSuccessFlag !== undefined && latestPayment.horizonSuccessFlag !== false)))
      ) {
        return { ok: false, status: 409, error: "Payment state could not be verified" }
      }
      if (preparedRecoveryException) {
        const cleanupIntent = await readPiWalletIntent(latestPayment.a2uFromAddress)
        if (cleanupIntent.state === "unavailable") return { ok: false, status: 409, error: "Settlement submit proof could not be verified" }
        if (cleanupIntent.state === "present" && cleanupIntent.owner.paymentId === paymentId && (cleanupIntent.owner.kind !== "settlement_prepared" || cleanupIntent.owner.preparedHash !== latestPayment.a2uPreparedTxHash || cleanupIntent.owner.preparedSequence !== latestPayment.a2uPreparedSequence)) return { ok: false, status: 409, error: "Settlement submit proof could not be verified" }
        if (cleanupIntent.state === "present" && cleanupIntent.owner.paymentId === paymentId) {
          const cleanupLock = await acquirePiWalletSubmitLock(latestPayment.a2uFromAddress)
          if (!cleanupLock) return { ok: false, status: 409, error: "Settlement submit proof could not be verified" }
          try {
            const lockedIntent = await readPiWalletIntent(latestPayment.a2uFromAddress)
            if (lockedIntent.state !== "present" || lockedIntent.owner.kind !== "settlement_prepared" || lockedIntent.owner.paymentId !== paymentId || lockedIntent.owner.preparedHash !== latestPayment.a2uPreparedTxHash || lockedIntent.owner.preparedSequence !== latestPayment.a2uPreparedSequence) return { ok: false, status: 409, error: "Settlement submit proof could not be verified" }
            const cleanupReplay = await executeFinancialRecoverySettlementSubmitReplay({ payment: latestPayment, paymentId })
            if (cleanupReplay.outcome !== "MOVEMENT_VERIFIED" || cleanupReplay.moneyMovementProven !== true || cleanupReplay.authorizesFinancialAction !== false || cleanupReplay.paymentId !== paymentId || cleanupReplay.merchantUid !== latestPayment.merchantUid || cleanupReplay.reference.preparedHash !== latestPayment.a2uPreparedTxHash || cleanupReplay.reference.preparedSequence !== latestPayment.a2uPreparedSequence || cleanupReplay.reference.a2uPaymentId !== latestPayment.a2uPaymentId || cleanupReplay.reference.fromAddress !== latestPayment.a2uFromAddress || cleanupReplay.reference.toAddress !== latestPayment.a2uToAddress || cleanupReplay.reference.amount !== latestPayment.merchantAmount || cleanupReplay.reference.envelopeXdr !== latestPayment.a2uPreparedEnvelopeXdr || !Number.isFinite(cleanupReplay.horizonFeeCharged) || cleanupReplay.horizonFeeCharged < 0) return { ok: false, status: 409, error: "Settlement submit proof could not be verified" }
            if (!await releasePiWalletIntent(latestPayment.a2uFromAddress, { kind: "settlement_prepared", paymentId, preparedHash: latestPayment.a2uPreparedTxHash, preparedSequence: latestPayment.a2uPreparedSequence })) return { ok: false, status: 500, error: "Settlement wallet intent release failed" }
          } finally {
            await cleanupLock.release()
          }
        }
      }
    }

    console.log("[A2U Locked Executor] Latest payment status:", latestPayment.status)

    if (params.recoveryOperation === "SETTLEMENT_CREATE") {
      const customerAmount = latestPayment.customerAmount
      const piPaymentId = latestPayment.piPaymentId
      const u2aTxid = latestPayment.u2aTxid
      const payerUid = latestPayment.payerUid
      const merchantUid = latestPayment.merchantUid
      const retryCount = latestPayment.retryCount
      const nextRetryAt = latestPayment.nextRetryAt
      if (
        params.isRecovery !== true ||
        latestPayment.status !== "paid_to_app" ||
        latestPayment.id !== paymentId ||
        typeof piPaymentId !== "string" || !piPaymentId.trim() || piPaymentId !== piPaymentId.trim() ||
        typeof u2aTxid !== "string" || !u2aTxid.trim() || u2aTxid !== u2aTxid.trim() ||
        typeof payerUid !== "string" || !payerUid.trim() || payerUid !== payerUid.trim() ||
        typeof merchantUid !== "string" || !merchantUid.trim() || merchantUid !== merchantUid.trim() ||
        typeof customerAmount !== "number" || !Number.isFinite(customerAmount) || customerAmount <= 0 ||
        latestPayment.settlementFailureState !== "retryable" ||
        typeof retryCount !== "number" || !Number.isInteger(retryCount) || retryCount <= 0 ||
        typeof nextRetryAt !== "string" || !nextRetryAt.trim() || nextRetryAt !== nextRetryAt.trim() || !Number.isFinite(Date.parse(nextRetryAt)) || Date.parse(nextRetryAt) > Date.now() ||
        latestPayment.a2uPaymentId !== undefined || latestPayment.a2uTxid !== undefined ||
        latestPayment.a2uPreparedTxHash !== undefined || latestPayment.a2uPreparedSequence !== undefined || latestPayment.a2uPreparedEnvelopeXdr !== undefined ||
        latestPayment.refundPaymentId !== undefined || latestPayment.refundTxid !== undefined ||
        (latestPayment.refundStatus !== undefined && latestPayment.refundStatus !== "not_started") ||
        (latestPayment.horizonSuccessFlag !== undefined && latestPayment.horizonSuccessFlag !== false) ||
        (latestPayment.piCompletionPending !== undefined && latestPayment.piCompletionPending !== false) ||
        (latestPayment.piCompleted !== undefined && latestPayment.piCompleted !== false) ||
        (latestPayment.dbRecorded !== undefined && latestPayment.dbRecorded !== false) ||
        (latestPayment.requiresDbReconciliation !== undefined && latestPayment.requiresDbReconciliation !== false)
      ) {
        return { ok: false, status: 409, error: "Settlement create prerequisites could not be verified" }
      }

      const read = await readSettlementCreatePiEvidence(piPaymentId)
      const readBinding = evaluateFinancialRecoverySettlementCreateReadBinding({
        read,
        decisionInput: {
          paymentId,
          currentState: "app_funds_confirmed",
          targetState: "settlement_created",
          reconciliationOutcome: "NOT_ATTEMPTED",
          reconciliationSource: null,
          prerequisitesConfirmed: true,
          targetPaymentIdPresent: false,
          targetTxidPresent: false,
          targetMoneyMovementProof: null,
          malformed: false,
          multipleCandidates: false,
          unknown: [],
          missing: [],
          conflicts: [],
        },
        expected: { paymentId, piPaymentId, u2aTxid, amount: customerAmount, payerUid, merchantUid },
        queriedPaymentId: paymentId,
        refundCheckpoint: refundLookup,
      })
      if (readBinding.outcome !== "BOUND" || readBinding.result.outcome !== "GATE_RESULT" || readBinding.result.gate.allow !== true) {
        return { ok: false, status: 409, error: "Settlement create proof could not be verified" }
      }
    }

    if (params.recoveryOperation === "SETTLEMENT_SUBMIT") {
      if (params.isRecovery !== true || latestPayment.id !== paymentId) {
        return { ok: false, status: 409, error: "Settlement submit proof could not be verified" }
      }
      // FIN7: Redis may contain a prepared XDR before the PostgreSQL prepared checkpoint is durable.
      // Recovery must never promote wallet intent or authorize Horizon from that projection alone.
      if (!await verifySettlementSubmitDurablePreparedAuthority(paymentId, latestPayment)) {
        return { ok: false, status: 409, error: "Settlement durable prepared authority could not be verified" }
      }
      const walletLock = await acquirePiWalletSubmitLock(latestPayment.a2uFromAddress)
      if (!walletLock) {
        return { ok: false, status: 409, error: "Settlement submit proof could not be verified" }
      }
      try {
        let walletIntent = await readPiWalletIntent(latestPayment.a2uFromAddress)
        if (walletIntent.state === "unavailable") return { ok: false, status: 409, error: "Settlement submit proof could not be verified" }
        if (walletIntent.state === "present" && walletIntent.owner.kind === "settlement_prepared" && (walletIntent.owner.paymentId !== paymentId || walletIntent.owner.preparedHash !== latestPayment.a2uPreparedTxHash || walletIntent.owner.preparedSequence !== latestPayment.a2uPreparedSequence)) return { ok: false, status: 409, error: "Settlement submit proof could not be verified" }
        if (walletIntent.state === "present" && walletIntent.owner.kind === "settlement_claim") {
          if (walletIntent.owner.paymentId !== paymentId || typeof latestPayment.a2uPreparedEnvelopeXdr !== "string" || !latestPayment.a2uPreparedEnvelopeXdr.trim() || latestPayment.a2uPreparedEnvelopeXdr !== latestPayment.a2uPreparedEnvelopeXdr.trim() || typeof latestPayment.a2uPreparedTxHash !== "string" || !/^[0-9a-f]{64}$/.test(latestPayment.a2uPreparedTxHash) || typeof latestPayment.a2uPreparedSequence !== "string" || !/^[1-9][0-9]*$/.test(latestPayment.a2uPreparedSequence)) return { ok: false, status: 409, error: "Settlement submit proof could not be verified" }
          const promoted = await replacePiWalletIntent(latestPayment.a2uFromAddress, walletIntent.owner, { kind: "settlement_prepared", paymentId, preparedHash: latestPayment.a2uPreparedTxHash, preparedSequence: latestPayment.a2uPreparedSequence })
          if (!promoted) return { ok: false, status: 409, error: "Settlement submit proof could not be verified" }
          walletIntent = await readPiWalletIntent(latestPayment.a2uFromAddress)
        }
        if (walletIntent.state === "present" && walletIntent.owner.kind !== "settlement_prepared" && walletIntent.owner.kind !== "settlement_claim") return { ok: false, status: 409, error: "Settlement submit proof could not be verified" }
        const replay = await executeFinancialRecoverySettlementSubmitReplay({ payment: latestPayment, paymentId })
        if (walletIntent.state === "absent") {
          // DR54: a total Redis loss may erase only the source-wallet ownership projection.
          // Reconstruct it under the source-wallet submit lock only after the durable exact-XDR
          // replay gate has independently proved Settlement authority, Refund absence, Horizon
          // sequence safety and exact prepared identity. Never reconstruct from Redis projection alone.
          if (replay.outcome !== "ALLOW_EXACT_REPLAY" || replay.mode !== "EXACT_STORED_XDR_ONLY" || replay.authorizesFinancialAction !== true) {
            if (replay.outcome !== "MOVEMENT_VERIFIED") return { ok: false, status: 409, error: "Settlement submit proof could not be verified" }
          } else {
            const reconstructed = await claimPiWalletIntent(latestPayment.a2uFromAddress, { kind: "settlement_prepared", paymentId, preparedHash: latestPayment.a2uPreparedTxHash, preparedSequence: latestPayment.a2uPreparedSequence })
            if (!reconstructed) return { ok: false, status: 409, error: "Settlement submit proof could not be verified" }
            walletIntent = await readPiWalletIntent(latestPayment.a2uFromAddress)
          }
        }
        const preparedIntent = await readPiWalletIntent(latestPayment.a2uFromAddress)
        if (replay.outcome !== "MOVEMENT_VERIFIED" && (preparedIntent.state !== "present" || preparedIntent.owner.kind !== "settlement_prepared" || preparedIntent.owner.paymentId !== paymentId || preparedIntent.owner.preparedHash !== latestPayment.a2uPreparedTxHash || preparedIntent.owner.preparedSequence !== latestPayment.a2uPreparedSequence)) return { ok: false, status: 409, error: "Settlement submit proof could not be verified" }
        if (replay.outcome === "MOVEMENT_VERIFIED") {
          if (
            replay.moneyMovementProven !== true ||
            replay.authorizesFinancialAction !== false ||
            replay.paymentId !== paymentId ||
            replay.merchantUid !== latestPayment.merchantUid ||
            replay.reference.preparedHash !== latestPayment.a2uPreparedTxHash ||
            replay.reference.preparedSequence !== latestPayment.a2uPreparedSequence ||
            replay.reference.a2uPaymentId !== latestPayment.a2uPaymentId ||
            replay.reference.fromAddress !== latestPayment.a2uFromAddress ||
            replay.reference.toAddress !== latestPayment.a2uToAddress ||
            replay.reference.amount !== latestPayment.merchantAmount ||
            replay.reference.envelopeXdr !== latestPayment.a2uPreparedEnvelopeXdr ||
            !Number.isFinite(replay.horizonFeeCharged) ||
            replay.horizonFeeCharged < 0
          ) {
            return { ok: false, status: 409, error: "Settlement submit proof could not be verified" }
          }
          const replayFeeStroops = horizonFeePiToExactStroops(replay.horizonFeeCharged)
          if (replayFeeStroops === null) return { ok: false, status: 409, error: "Settlement Horizon fee proof could not be verified" }
          const durableHorizon = await recordSettlementHorizonCheckpoint({
            paymentId,
            a2uPaymentId: replay.reference.a2uPaymentId,
            preparedTxHash: replay.reference.preparedHash,
            preparedSequence: replay.reference.preparedSequence,
            a2uTxid: replay.reference.preparedHash,
            horizonFeeStroops: replayFeeStroops,
          })
          if (durableHorizon.outcome !== "RECORDED" && durableHorizon.outcome !== "REPLAYED") return { ok: false, status: 409, error: "Settlement Horizon durable checkpoint unavailable" }
          try {
            await persistCheckpointMerged(paymentId, {
              a2uTxid: replay.reference.preparedHash,
              horizonSuccessFlag: true,
              horizonSuccessAt: new Date().toISOString(),
              status: "settlement_pending",
              horizonFeeCharged: replay.horizonFeeCharged,
              piCompletionPending: true,
            })
          } catch {
            return { ok: false, status: 500, error: "Settlement movement checkpoint persistence failed" }
          }
          if (walletIntent.state === "present" && !await releasePiWalletIntent(latestPayment.a2uFromAddress, { kind: "settlement_prepared", paymentId, preparedHash: latestPayment.a2uPreparedTxHash, preparedSequence: latestPayment.a2uPreparedSequence })) return { ok: false, status: 500, error: "Settlement wallet intent release failed" }
        return { ok: true, status: 202 }
        }
        if (replay.outcome !== "ALLOW_EXACT_REPLAY" || replay.mode !== "EXACT_STORED_XDR_ONLY" || replay.authorizesFinancialAction !== true) {
          await logSettlementSubmitRuntimeDiagnostic(latestPayment, `pre_replay_gate:${replay.outcome}`)
          return { ok: false, status: 409, error: "Settlement submit proof could not be verified" }
        }
        const allowed = replay.reference
        const intent = allowed.reference
        if (
          allowed.paymentId !== latestPayment.id ||
          allowed.merchantUid !== latestPayment.merchantUid ||
          intent.a2uPaymentId !== latestPayment.a2uPaymentId ||
          intent.fromAddress !== latestPayment.a2uFromAddress ||
          intent.toAddress !== latestPayment.a2uToAddress ||
          intent.amount !== latestPayment.merchantAmount ||
          intent.envelopeXdr !== latestPayment.a2uPreparedEnvelopeXdr ||
          intent.preparedHash !== latestPayment.a2uPreparedTxHash ||
          intent.preparedSequence !== latestPayment.a2uPreparedSequence
        ) {
          return { ok: false, status: 409, error: "Settlement submit proof could not be verified" }
        }
        try {
          const transaction = StellarSDK.TransactionBuilder.fromXDR(intent.envelopeXdr, "Pi Testnet")
          if (
            !(transaction instanceof StellarSDK.Transaction) ||
            transaction.toXDR() !== intent.envelopeXdr ||
            Buffer.from(transaction.hash()).toString("hex") !== intent.preparedHash ||
            transaction.sequence !== intent.preparedSequence ||
            transaction.source !== intent.fromAddress
          ) {
            return { ok: false, status: 409, error: "Settlement submit proof could not be verified" }
          }
          if (params.schedulerWalletPaymentId !== undefined && params.schedulerWalletPaymentId !== paymentId) return { ok: false, status: 409, error: "wallet_drain_not_selected" }
          // R36: stale owners must not submit after a detected Redis lease transfer.
          // Do not replace the immutable prepared XDR or bypass durable replay authority.
          if (!await walletLock.verifyOwned()) {
            return { ok: false, status: 409, error: "Settlement wallet submit ownership lost" }
          }
          // R36: fail closed if PostgreSQL durable owner differs from this exact prepared intent.
          if (!await verifyPreparedWalletAuthority({
            network: 'Pi Testnet', sourceWallet: intent.fromAddress, paymentId,
            operationKind: 'settlement', operationId: intent.a2uPaymentId,
            preparedHash: intent.preparedHash, preparedSequence: intent.preparedSequence,
          })) return { ok: false, status: 409, error: "Durable settlement wallet authority not proven" }
          // One-shot PostgreSQL admission: even same stored XDR cannot be POSTed
          // twice after a crash, Redis loss, or a competing recovery worker.
          if (!await claimFirstWalletSubmission({
            network: 'Pi Testnet', sourceWallet: intent.fromAddress, paymentId,
            operationKind: 'settlement', operationId: intent.a2uPaymentId,
            preparedHash: intent.preparedHash, preparedSequence: intent.preparedSequence,
          })) return { ok: false, status: 409, error: "Settlement one-shot submission already used or unavailable" }
          const horizon = new StellarSDK.Horizon.Server("https://api.testnet.minepi.com", { allowHttp: false })
          const submitted = await horizon.submitTransaction(transaction)
          if (submitted.hash !== latestPayment.a2uPreparedTxHash) {
            return { ok: false, status: 409, error: "Settlement submit proof could not be verified" }
          }
        } catch (submitError) {
          console.error("[SETTLEMENT_SUBMIT_DIAGNOSTIC]", { paymentId, stage: "horizon_submit_exception", error: submitError instanceof Error ? submitError.message : "unknown", authorizesFinancialAction: false })
          await logSettlementSubmitRuntimeDiagnostic(latestPayment, "post_submit_exception")
          // Submit outcome is ambiguous. Do not resubmit here: the exact read-only replay
          // reconciliation below must prove movement before any durable/projection advance.
        }
        const verifiedReplay = await executeFinancialRecoverySettlementSubmitReplay({ payment: latestPayment, paymentId })
        if (verifiedReplay.outcome !== "MOVEMENT_VERIFIED") {
          await logSettlementSubmitRuntimeDiagnostic(latestPayment, `post_submit_verify:${verifiedReplay.outcome}`)
          return { ok: false, status: 409, error: "Settlement submit proof could not be verified" }
        }
        const verifiedIntent = verifiedReplay.reference
        if (
          verifiedReplay.paymentId !== latestPayment.id ||
          verifiedReplay.merchantUid !== latestPayment.merchantUid ||
          verifiedIntent.a2uPaymentId !== latestPayment.a2uPaymentId ||
          verifiedIntent.fromAddress !== latestPayment.a2uFromAddress ||
          verifiedIntent.toAddress !== latestPayment.a2uToAddress ||
          verifiedIntent.amount !== latestPayment.merchantAmount ||
          verifiedIntent.envelopeXdr !== latestPayment.a2uPreparedEnvelopeXdr ||
          verifiedIntent.preparedHash !== latestPayment.a2uPreparedTxHash ||
          verifiedIntent.preparedSequence !== latestPayment.a2uPreparedSequence ||
          !Number.isFinite(verifiedReplay.horizonFeeCharged) ||
          verifiedReplay.horizonFeeCharged < 0
        ) {
          return { ok: false, status: 409, error: "Settlement submit proof could not be verified" }
        }
        const verifiedFeeStroops = horizonFeePiToExactStroops(verifiedReplay.horizonFeeCharged)
        if (verifiedFeeStroops === null) return { ok: false, status: 409, error: "Settlement Horizon fee proof could not be verified" }
        const durableHorizon = await recordSettlementHorizonCheckpoint({
          paymentId,
          a2uPaymentId: verifiedIntent.a2uPaymentId,
          preparedTxHash: verifiedIntent.preparedHash,
          preparedSequence: verifiedIntent.preparedSequence,
          a2uTxid: verifiedIntent.preparedHash,
          horizonFeeStroops: verifiedFeeStroops,
        })
        if (durableHorizon.outcome !== "RECORDED" && durableHorizon.outcome !== "REPLAYED") return { ok: false, status: 409, error: "Settlement Horizon durable checkpoint unavailable" }
        try {
          await persistCheckpointMerged(paymentId, {
            a2uTxid: verifiedIntent.preparedHash,
            horizonSuccessFlag: true,
            horizonSuccessAt: new Date().toISOString(),
            status: "settlement_pending",
            horizonFeeCharged: verifiedReplay.horizonFeeCharged,
            piCompletionPending: true,
          })
        } catch {
          return { ok: false, status: 500, error: "Settlement movement checkpoint persistence failed" }
        }
        if (walletIntent.state === "present" && !await releasePiWalletIntent(latestPayment.a2uFromAddress, { kind: "settlement_prepared", paymentId, preparedHash: latestPayment.a2uPreparedTxHash, preparedSequence: latestPayment.a2uPreparedSequence })) return { ok: false, status: 500, error: "Settlement wallet intent release failed" }
        return { ok: true, status: 202 }
      } finally {
        await walletLock.release()
      }
    }

    // Validate and derive all fields from LATEST checkpoint (not stale caller copies)
    if (!latestPayment.merchantUid || typeof latestPayment.merchantUid !== "string") {
      console.error("[A2U Locked Executor] Invalid merchantUid in latest checkpoint")
      return { ok: false, status: 400, error: "Invalid payment record" }
    }

    if (typeof latestPayment.amount !== "number" || latestPayment.amount <= 0) {
      console.error("[A2U Locked Executor] Invalid amount in latest checkpoint:", latestPayment.amount)
      return { ok: false, status: 400, error: "Invalid payment amount" }
    }

    if (!latestPayment.piPaymentId || typeof latestPayment.piPaymentId !== "string") {
      console.error("[A2U Locked Executor] Invalid piPaymentId in latest checkpoint")
      return { ok: false, status: 400, error: "Invalid payment record" }
    }

    const safetyState = latestPayment.settlementFailureState
    if (
      latestPayment.refundPaymentId || latestPayment.refundTxid ||
      latestPayment.refundStatus === "pending" || latestPayment.refundStatus === "submitted" ||
      latestPayment.refundStatus === "completed" || latestPayment.refundStatus === "manual_review_required" ||
      latestPayment.status === "refund_pending" || latestPayment.status === "refunded" ||
      safetyState === "held" || safetyState === "manual_review_required" ||
      safetyState === "refund_pending" || safetyState === "refunded"
    ) {
      return { ok: false, status: 409, error: "Refund operation owns this payment" }
    }

    if (
      latestPayment.status === "paid_to_app" &&
      safetyState === "retryable" &&
      latestPayment.nextRetryAt &&
      Date.parse(latestPayment.nextRetryAt) > Date.now()
    ) {
      return { ok: false, status: 409, error: "Settlement retry backoff is active" }
    }

    // Inside lock: any valid a2uTxid or horizonSuccessFlag must permanently skip Stage 2
    if (latestPayment.a2uTxid || latestPayment.horizonSuccessFlag) {
      console.log("[A2U Locked Executor] Valid a2uTxid or horizonSuccessFlag exists - will skip Stage 2")
    }

    // Execute A2U with derived fields from latest authoritative checkpoint
    // CRITICAL: executeA2U will throw on checkpoint persistence failure - catch and return error
    try {
      const result = await executeA2U({
        paymentId,
        payment: latestPayment,
        merchantUid: latestPayment.merchantUid,
        merchantAuthority,
        customerAmount: typeof latestPayment.customerAmount === "number" && Number.isFinite(latestPayment.customerAmount)
          ? latestPayment.customerAmount
          : latestPayment.amount,
        piPaymentId: latestPayment.piPaymentId,
        isRecovery: params.isRecovery,
        ...(params.recoveryOperation ? { recoveryOperation: params.recoveryOperation } : {}),
        ...(params.schedulerWalletPaymentId !== undefined ? { schedulerWalletPaymentId: params.schedulerWalletPaymentId } : {}),
      })

      // Map executor result string status to numeric HTTP status code
      if (result.ok) {
        return { ok: true, status: 200 }
      } else {
        // Error case - map string status values to numeric HTTP codes
        let httpStatus: number = 400
        if (result.status === "404") {
          httpStatus = 404
        } else if (result.status === "500") {
          httpStatus = 500
        } else if (result.status === "400") {
          httpStatus = 400
        } else {
          httpStatus = 400 // Default for unknown statuses
        }
        return { ok: false, status: httpStatus, error: result.error }
      }
    } catch (executeError) {
      console.error("[A2U Locked Executor] Executor threw error (checkpoint persistence failed):", executeError)
      // Return error state - never proceed after checkpoint failure
      return { ok: false, status: 500, error: executeError instanceof Error ? executeError.message : String(executeError) }
    }
  } finally {
    await releaseLockAtomic()
  }
}
