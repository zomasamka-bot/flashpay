import { claimPreparedWalletAuthority, type WalletAuthorityClaim } from './financial-wallet-authority'
import { randomUUID } from 'node:crypto'
import { redis, isRedisConfigured } from './redis'
import { ensureRefundCheckpointTables, query, readSettlementRefundAuthority, withPaymentAuthorityTransaction, withR36RestrictedPaymentTransaction } from './db'
import type { Payment, RefundAuditEvent, RefundCheckpoint } from './types'

const redisKey = (refundId: string) => `flashpay:refund:checkpoint:${refundId}`
const redisLockKey = (idempotencyKey: string) => `flashpay:refund:idempotency:${idempotencyKey}`
const paymentOperationLockKey = (paymentId: string) => `flashpay:payment:operation:${paymentId}`

export async function acquirePaymentOperationLock(paymentId: string, owner: string): Promise<boolean> {
  if (!isRedisConfigured) return false
  // X2: a new Refund may never acquire ownership while a non-final durable
  // Settlement authority exists. Existing Refund replay is handled separately.
  const authority=await readSettlementRefundAuthority(paymentId)
  if(authority.outcome!=="CLEAR"||authority.settlementActive)return false
  const result = await redis.set(paymentOperationLockKey(paymentId), owner, { nx: true, ex: 60 * 60 * 24 * 30 })
  return result === 'OK'
}

export async function ensurePaymentOperationLock(paymentId: string, refundId: string): Promise<boolean> {
  if (!isRedisConfigured) return false
  const result = await redis.eval(
    'local v=redis.call("get",KEYS[1]); if not v then local ok=redis.call("set",KEYS[1],ARGV[1],"NX","EX",ARGV[2]); return (ok and ok.ok=="OK") and 1 or 0 end; if v==ARGV[1] then redis.call("expire",KEYS[1],ARGV[2]); return 1 end; return 0',
    [paymentOperationLockKey(paymentId)], [refundId, String(60 * 60 * 24 * 30)],
  )
  return Number(result) === 1
}

export async function releasePaymentOperationLock(paymentId: string, owner: string): Promise<void> {
  if (!isRedisConfigured) return
  await redis.eval(
    'if redis.call("get", KEYS[1]) == ARGV[1] then return redis.call("del", KEYS[1]) else return 0 end',
    [paymentOperationLockKey(paymentId)],
    [owner],
  )
}

export type RefundSchemaDiagnostics = {
  refund_checkpoints: boolean
  refund_audit_events: boolean
  idx_refund_checkpoints_status_retry: boolean
  idx_refund_checkpoints_payment: boolean
  idx_refund_audit_payment_created: boolean
  idx_refund_audit_refund_created: boolean
}

export type RefundCheckpointReadOnly =
  | { state: 'present'; checkpoint: RefundCheckpoint }
  | { state: 'absent' }
  | { state: 'uncertain' }

const STAGE_ORDER: RefundCheckpoint['stage'][] = ['eligibility_verified', 'intent_created', 'wallet_submission_started', 'wallet_submission_confirmed', 'payment_checkpoint_updated', 'accounting_recorded', 'audit_recorded']

export type AutomaticRefundCheckpointResult =
  | { state: 'ok'; checkpoints: RefundCheckpoint[] }
  | { state: 'uncertain' }

export type AutomaticRefundRetirementState = 'active' | 'retired' | 'uncertain'

export async function readAutomaticRefundRetirementState(paymentId: string, refundId: string): Promise<AutomaticRefundRetirementState> {
  if (!process.env.DATABASE_URL || typeof paymentId !== 'string' || !paymentId.trim() || paymentId !== paymentId.trim() || typeof refundId !== 'string' || !refundId.trim() || refundId !== refundId.trim()) return 'uncertain'
  try {
    if (!(await ensureRefundCheckpointTables())) return 'uncertain'
    const rows = await query(`SELECT 1 FROM refund_automatic_retirements WHERE payment_id=$1 AND refund_id=$2 LIMIT 1`, [paymentId, refundId])
    if (!Array.isArray(rows)) return 'uncertain'
    return rows.length === 1 ? 'retired' : rows.length === 0 ? 'active' : 'uncertain'
  } catch {
    return 'uncertain'
  }
}

export async function cleanupTerminalRefundRetryMetadata(limit: number): Promise<number | null> {
  if (!Number.isInteger(limit) || limit <= 0) return null
  try {
    const rows = await query(`
      WITH eligible AS (
        SELECT c.refund_id
        FROM refund_checkpoints c
        JOIN refund_accounting_records r ON r.refund_id=c.refund_id
        WHERE c.stage='audit_recorded' AND c.status='completed'
          AND (c.last_error_code IS NOT NULL OR c.last_error_message IS NOT NULL OR c.next_retry_at IS NOT NULL)
          AND c.refund_payment_id IS NOT NULL AND c.refund_txid IS NOT NULL
          AND r.payment_id=c.payment_id AND r.refund_payment_id=c.refund_payment_id
          AND r.refund_txid=c.refund_txid AND r.payer_uid=c.payer_uid
          AND r.amount=c.amount AND r.currency='π' AND r.horizon_fee_stroops>=0
          AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_completed')=1
          AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_projection_finalized')=1
          AND (SELECT count(*) FROM refund_audit_events a
               WHERE a.refund_id=c.refund_id
                 AND a.event_id='refund:'||c.refund_id||':projection_finalized'
                 AND a.event_type='refund_projection_finalized'
                 AND a.payment_id=c.payment_id AND a.idempotency_key=c.idempotency_key
                 AND a.actor_type='system'
                 AND (a.details=jsonb_build_object('refundPaymentId',c.refund_payment_id,'refundTxid',c.refund_txid) OR (jsonb_typeof(a.details)='string' AND (a.details #>> '{}')=concat('{"refundPaymentId":',to_json(c.refund_payment_id)::text,',"refundTxid":',to_json(c.refund_txid)::text,'}'))))=1
        ORDER BY c.updated_at ASC, c.refund_id ASC
        LIMIT $1
      )
      UPDATE refund_checkpoints c
      SET last_error_code=NULL, last_error_message=NULL, next_retry_at=NULL, updated_at=NOW()
      FROM eligible e
      WHERE c.refund_id=e.refund_id
      RETURNING c.refund_id`, [Math.min(limit, 20)])
    return Array.isArray(rows) ? rows.length : null
  } catch { return null }
}

export async function listAutomaticRefundCheckpoints(limit: number): Promise<AutomaticRefundCheckpointResult> {
  if (!Number.isInteger(limit) || limit <= 0) return { state: 'uncertain' }
  try {
    if (!(await ensureRefundCheckpointTables())) return { state: 'uncertain' }
    const rows = await query(`
      SELECT * FROM refund_checkpoints
      WHERE NOT EXISTS (
        SELECT 1 FROM refund_automatic_retirements r
        WHERE r.refund_id=refund_checkpoints.refund_id AND r.payment_id=refund_checkpoints.payment_id
      )
        AND (status='pending' OR (stage='audit_recorded' AND status='completed' AND NOT (
        (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=refund_checkpoints.refund_id AND a.event_type='refund_projection_finalized')=1
        AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=refund_checkpoints.refund_id AND a.event_type='refund_projection_finalized' AND refund_checkpoints.refund_payment_id IS NOT NULL AND refund_checkpoints.refund_txid IS NOT NULL AND a.event_id='refund:'||refund_checkpoints.refund_id||':projection_finalized' AND a.payment_id=refund_checkpoints.payment_id AND a.idempotency_key=refund_checkpoints.idempotency_key AND a.actor_type='system' AND (a.details=jsonb_build_object('refundPaymentId',refund_checkpoints.refund_payment_id,'refundTxid',refund_checkpoints.refund_txid) OR (jsonb_typeof(a.details)='string' AND (a.details #>> '{}')=concat('{"refundPaymentId":',to_json(refund_checkpoints.refund_payment_id)::text,',"refundTxid":',to_json(refund_checkpoints.refund_txid)::text,'}'))))=1
      )))
        AND (
          next_retry_at IS NULL
          OR next_retry_at<=NOW()
          OR (
            last_error_code='automatic_refund_blocked'
            AND last_error_message='dr14_interruption'
            AND updated_at<=NOW()-INTERVAL '60 seconds'
          )
        )
      ORDER BY updated_at ASC, refund_id ASC
      LIMIT $1`, [Math.min(limit, 20)])
    if (!Array.isArray(rows)) return { state: 'uncertain' }
    const checkpoints: RefundCheckpoint[] = []
    for (const row of rows) {
      if (typeof row !== 'object' || row === null || Array.isArray(row)) return { state: 'uncertain' }
      const checkpoint = normalizeCheckpoint(row)
      if (!checkpoint) return { state: 'uncertain' }
      const validLifecycle = (checkpoint.status === 'pending' && STAGE_ORDER.includes(checkpoint.stage)) || (checkpoint.stage === 'audit_recorded' && checkpoint.status === 'completed')
      if (!validLifecycle || !Number.isSafeInteger(checkpoint.attemptCount) || checkpoint.attemptCount < 0) return { state: 'uncertain' }
      checkpoints.push(checkpoint)
    }
    return { state: 'ok', checkpoints }
  } catch { return { state: 'uncertain' } }
}

export async function getRefundCheckpointsByPaymentIds(paymentIds: string[]): Promise<{ state: 'ok'; checkpoints: Map<string, RefundCheckpoint> } | { state: 'uncertain' }> {
  if (!Array.isArray(paymentIds)) return { state: 'uncertain' }
  const uniquePaymentIds: string[] = []
  const seen = new Set<string>()
  for (const paymentId of paymentIds) {
    if (typeof paymentId !== 'string' || paymentId.length === 0 || paymentId !== paymentId.trim() || seen.has(paymentId)) return { state: 'uncertain' }
    seen.add(paymentId)
    uniquePaymentIds.push(paymentId)
  }
  try {
    if (uniquePaymentIds.length === 0) return { state: 'ok', checkpoints: new Map() }
    const rows = await query('SELECT * FROM refund_checkpoints WHERE payment_id = ANY($1::text[])', [uniquePaymentIds])
    if (!Array.isArray(rows)) return { state: 'uncertain' }
    const requested = new Set(uniquePaymentIds)
    const checkpoints = new Map<string, RefundCheckpoint>()
    for (const row of rows) {
      const checkpoint = normalizeCheckpoint(row)
      if (!checkpoint || !requested.has(checkpoint.paymentId) || checkpoint.refundId.length === 0 || checkpoint.refundId !== checkpoint.refundId.trim() || checkpoints.has(checkpoint.paymentId)) return { state: 'uncertain' }
      checkpoints.set(checkpoint.paymentId, checkpoint)
    }
    return { state: 'ok', checkpoints }
  } catch { return { state: 'uncertain' } }
}

export async function getRefundCheckpointReadOnly(refundId: string): Promise<RefundCheckpointReadOnly> {
  if (typeof refundId !== 'string' || refundId.trim().length === 0) return { state: 'uncertain' }
  try {
    const rows = await query('SELECT * FROM refund_checkpoints WHERE refund_id=$1 LIMIT 2', [refundId])
    if (!Array.isArray(rows)) return { state: 'uncertain' }
    if (rows.length === 0) return { state: 'absent' }
    if (rows.length !== 1 || typeof rows[0] !== 'object' || rows[0] === null || Array.isArray(rows[0])) return { state: 'uncertain' }
    const checkpoint = normalizeCheckpoint(rows[0])
    return checkpoint ? { state: 'present', checkpoint } : { state: 'uncertain' }
  } catch { return { state: 'uncertain' } }
}

export async function retirePoisonedAutomaticRefundIntent(params: { refundId: string; paymentId: string; reason: string; evidenceCode: string }): Promise<{ outcome: 'RETIRED' | 'ALREADY_RETIRED' | 'BLOCKED' | 'INDETERMINATE' }> {
  const { refundId, paymentId, reason, evidenceCode } = params
  if (![refundId,paymentId,reason,evidenceCode].every((v) => typeof v === 'string' && v.length > 0 && v === v.trim())) return { outcome: 'BLOCKED' }
  try {
    if (!(await ensureRefundCheckpointTables())) return { outcome: 'INDETERMINATE' }
    const rows = await query(`
      WITH candidate AS (
        SELECT c.refund_id,c.payment_id
        FROM refund_checkpoints c
        WHERE c.refund_id=$1 AND c.payment_id=$2
          AND c.status='pending' AND c.stage='wallet_submission_started'
          AND c.refund_payment_id IS NULL AND c.refund_txid IS NULL
          AND c.last_error_code='automatic_refund_blocked'
          AND c.last_error_message='refund_create_uncertain'
          AND NOT EXISTS (SELECT 1 FROM refund_accounting_records a WHERE a.refund_id=c.refund_id OR a.payment_id=c.payment_id)
          AND NOT EXISTS (SELECT 1 FROM settlement_checkpoints s WHERE s.payment_id=c.payment_id AND (s.a2u_txid IS NOT NULL OR s.horizon_confirmed_at IS NOT NULL))
      ), inserted AS (
        INSERT INTO refund_automatic_retirements(refund_id,payment_id,reason,evidence_code)
        SELECT refund_id,payment_id,$3,$4 FROM candidate
        ON CONFLICT (refund_id) DO NOTHING
        RETURNING refund_id
      ) SELECT refund_id FROM inserted`, [refundId,paymentId,reason,evidenceCode])
    if (!Array.isArray(rows)) return { outcome: 'INDETERMINATE' }
    if (rows.length === 1) return { outcome: 'RETIRED' }
    const replay = await query(`SELECT 1 FROM refund_automatic_retirements WHERE refund_id=$1 AND payment_id=$2 AND reason=$3 AND evidence_code=$4 LIMIT 1`, [refundId,paymentId,reason,evidenceCode])
    if (Array.isArray(replay) && replay.length === 1) return { outcome: 'ALREADY_RETIRED' }
    return { outcome: 'BLOCKED' }
  } catch { return { outcome: 'INDETERMINATE' } }
}

export async function deferAutomaticRefund(
  refundId: string,
  expectedStage: RefundCheckpoint['stage'],
  expectedStatus: RefundCheckpoint['status'],
  errorCode: string,
  errorMessage: string,
  nextRetryAt: string,
): Promise<RefundCheckpoint | null> {
  if (typeof refundId !== 'string' || refundId.length === 0 || typeof expectedStage !== 'string' || expectedStage.length === 0 || typeof expectedStatus !== 'string' || expectedStatus.length === 0 || typeof errorCode !== 'string' || errorCode.length === 0 || typeof errorMessage !== 'string' || errorMessage.length === 0 || typeof nextRetryAt !== 'string' || nextRetryAt.length === 0 || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z$/.test(nextRetryAt)) return null
  const retryAt = new Date(nextRetryAt)
  if (Number.isNaN(retryAt.getTime()) || retryAt.getTime() <= Date.now()) return null
  try {
    console.warn('[refunds/auto-deferral] Write:', { refundId, status: expectedStatus, stage: expectedStage, errorCode, reason: errorMessage, executorStep: expectedStage })
    const rows = await query(`
      UPDATE refund_checkpoints
      SET last_error_code=$3, last_error_message=$4, next_retry_at=$5::timestamptz, updated_at=NOW()
      WHERE refund_id=$1 AND stage=$2 AND status=$6
        AND (next_retry_at IS NULL OR next_retry_at<=NOW())
      RETURNING *`, [refundId, expectedStage, errorCode, errorMessage, nextRetryAt, expectedStatus])
    if (!Array.isArray(rows) || rows.length !== 1) return null
    const checkpoint = normalizeCheckpoint(rows[0])
    return checkpoint && checkpoint.refundId === refundId && checkpoint.stage === expectedStage && checkpoint.status === expectedStatus ? checkpoint : null
  } catch { return null }
}

export async function markAutomaticRefundManualReview(refundId: string, expectedStage: RefundCheckpoint['stage']): Promise<RefundCheckpoint | null> {
  if (typeof refundId !== 'string' || refundId.length === 0 || typeof expectedStage !== 'string' || expectedStage.length === 0) return null
  try {
    const eventId = `refund:${refundId}:manual_review`
    const createdAt = new Date().toISOString()
    // Resolve only the durable payment identity; never derive financial authority from Redis.
    const identity = await query(`SELECT payment_id FROM refund_checkpoints WHERE refund_id=$1 LIMIT 2`, [refundId])
    if (!Array.isArray(identity) || identity.length !== 1) return null
    const paymentId = (identity[0] as { payment_id?: unknown } | null)?.payment_id
    if (typeof paymentId !== 'string' || paymentId.length === 0) return null
    const result = await withPaymentAuthorityTransaction(paymentId, async (tx) => tx`
      WITH transitioned AS (
        UPDATE refund_checkpoints
        SET status='manual_review_required', last_error_code='refund_cancelled', last_error_message='refund_cancelled', next_retry_at=NULL, updated_at=NOW()
        WHERE refund_id=${refundId} AND payment_id=${paymentId} AND stage=${expectedStage} AND status='pending'
          -- R36: recheck durable opposite authority at the same PG commit boundary.
          -- Never hide confirmed or prepared movements behind manual review.
          AND refund_txid IS NULL
          AND NOT EXISTS (
            SELECT 1 FROM refund_accounting_records ra
            WHERE ra.payment_id=${paymentId} OR ra.refund_id=${refundId}
          )
          AND NOT EXISTS (
            SELECT 1 FROM settlement_checkpoints sc
            WHERE sc.payment_id=${paymentId}
              AND (
                sc.stage IN ('a2u_created','prepared','horizon_confirmed','pi_completed','db_finalized')
                OR sc.a2u_create_attempted_at IS NOT NULL
                OR sc.a2u_payment_id IS NOT NULL
                OR sc.prepared_envelope_xdr IS NOT NULL
                OR sc.prepared_tx_hash IS NOT NULL
                OR sc.a2u_txid IS NOT NULL
                OR sc.horizon_confirmed_at IS NOT NULL
              )
          )
        RETURNING *
      ), audited AS (
        INSERT INTO refund_audit_events
          (event_id, refund_id, payment_id, event_type, actor_type, idempotency_key, created_at, details)
        SELECT ${eventId}, refund_id, payment_id, 'refund_manual_review', 'system', idempotency_key, ${createdAt}, jsonb_build_object('refundId', refund_id, 'paymentId', payment_id, 'idempotencyKey', idempotency_key)
        FROM transitioned
        RETURNING refund_id
      )
      SELECT transitioned.* FROM transitioned INNER JOIN audited ON audited.refund_id = transitioned.refund_id
    `)
    let checkpoint: RefundCheckpoint | null = null
    if (Array.isArray(result) && result.length === 1) checkpoint = normalizeCheckpoint(result[0])
    if (!checkpoint) {
      const replay = await query(`
        SELECT c.*
        FROM refund_checkpoints c
        WHERE c.refund_id=$1
          AND c.stage=$2
          AND c.status='manual_review_required'
          AND c.last_error_code='refund_cancelled'
          AND c.last_error_message='refund_cancelled'
          AND c.next_retry_at IS NULL
          AND (
            SELECT COUNT(*) FROM refund_audit_events a
            WHERE a.event_id=$3
              AND a.refund_id=c.refund_id
              AND a.payment_id=c.payment_id
              AND a.event_type='refund_manual_review'
              AND a.actor_type='system'
              AND a.idempotency_key=c.idempotency_key
              AND a.details=jsonb_build_object('refundId', c.refund_id, 'paymentId', c.payment_id, 'idempotencyKey', c.idempotency_key)
          ) = 1
        LIMIT 1`, [refundId, expectedStage, eventId])
      if (Array.isArray(replay) && replay.length === 1) checkpoint = normalizeCheckpoint(replay[0])
    }
    if (checkpoint && (checkpoint.stage !== expectedStage || checkpoint.status !== 'manual_review_required' || checkpoint.lastErrorCode !== 'refund_cancelled' || checkpoint.lastErrorMessage !== 'refund_cancelled' || checkpoint.nextRetryAt !== undefined)) checkpoint = null
    if (checkpoint && isRedisConfigured) {
      try { await redis.set(redisKey(checkpoint.refundId), checkpoint) } catch { /* Redis mirror is best effort. */ }
    }
    return checkpoint
  } catch { return null }
}

export async function clearAutomaticRefundDeferral(refundId: string): Promise<RefundCheckpoint | null> {
  if (typeof refundId !== 'string' || refundId.length === 0) return null
  try {
    const rows = await query(`
      UPDATE refund_checkpoints
      SET last_error_code=NULL, last_error_message=NULL, next_retry_at=NULL, updated_at=NOW()
      WHERE refund_id=$1 AND (next_retry_at IS NULL OR next_retry_at<=NOW())
      RETURNING *`, [refundId])
    if (!Array.isArray(rows) || rows.length !== 1) return null
    const checkpoint = normalizeCheckpoint(rows[0])
    return checkpoint && checkpoint.refundId === refundId ? checkpoint : null
  } catch { return null }
}

export async function getRefundSchemaDiagnostics(): Promise<RefundSchemaDiagnostics> {
  const names = [
    'refund_checkpoints', 'refund_audit_events', 'idx_refund_checkpoints_status_retry',
    'idx_refund_checkpoints_payment', 'idx_refund_audit_payment_created', 'idx_refund_audit_refund_created',
  ] as const
  let rawResult: unknown
  try {
    rawResult = await query(`
      SELECT name, EXISTS (
        SELECT 1 FROM pg_class c
        JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE n.nspname = 'public'
          AND c.relname = name
          AND c.relkind = CASE
            WHEN name IN ('refund_checkpoints', 'refund_audit_events') THEN 'r'
            ELSE 'i'
          END
      ) AS present
      FROM unnest($1::text[]) AS names(name)
    `, [names])
  } catch {
    rawResult = null
  }
  const diagnostics = Object.fromEntries(names.map((name) => [name, false])) as RefundSchemaDiagnostics
  if (Array.isArray(rawResult)) {
    for (const row of rawResult) {
      if (typeof row !== 'object' || row === null || Array.isArray(row)) continue
      const record: Record<string, unknown> = row
      if (typeof record.name !== 'string' || !(record.name in diagnostics)) continue
      diagnostics[record.name as keyof RefundSchemaDiagnostics] = record.present === true
    }
  }
  return diagnostics
}

export async function verifyRefundAccountingSchema(): Promise<boolean> {
  if (!process.env.DATABASE_URL) return false
  try {
    const result = await query(`
      WITH target AS (
        SELECT c.oid FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
        WHERE n.nspname='public' AND c.relname='refund_accounting_records' AND c.relkind='r'
      ), constraints AS (
        SELECT con.*, pg_get_expr(con.conbin, con.conrelid) AS expression
        FROM pg_constraint con JOIN target t ON t.oid=con.conrelid
      ), key_columns AS (
        SELECT con.oid, con.contype, array_agg(att.attname::text ORDER BY k.ordinality) AS names
        FROM constraints con JOIN LATERAL unnest(con.conkey) WITH ORDINALITY k(attnum, ordinality) ON true
        JOIN pg_attribute att ON att.attrelid=con.conrelid AND att.attnum=k.attnum
        GROUP BY con.oid, con.contype
      ), defaults AS (
        SELECT a.attname, pg_get_expr(d.adbin, d.adrelid) AS expression
        FROM pg_attribute a JOIN target t ON t.oid=a.attrelid
        LEFT JOIN pg_attrdef d ON d.adrelid=a.attrelid AND d.adnum=a.attnum
        WHERE a.attnum>0 AND NOT a.attisdropped
      ), checks AS (
        SELECT regexp_replace(regexp_replace(lower(expression), '\\s+', '', 'g'), '[()]|::[a-z0-9_\\." ]+', '', 'g') AS normalized
        FROM constraints WHERE contype='c'
      )
      SELECT
        EXISTS (SELECT 1 FROM target) AS table_exists,
        (SELECT count(*)=1 FROM constraints WHERE contype='p' AND conkey=ARRAY[(SELECT attnum FROM pg_attribute WHERE attrelid=(SELECT oid FROM target) AND attname='refund_id')::smallint]) AS exact_pk,
        (SELECT count(*) FROM constraints con
          WHERE con.contype='f' AND con.conkey=ARRAY[(SELECT attnum FROM pg_attribute WHERE attrelid=con.conrelid AND attname='refund_id')::smallint]
          AND con.confkey=ARRAY[(SELECT attnum FROM pg_attribute WHERE attrelid=con.confrelid AND attname='refund_id')::smallint]
          AND con.confrelid='public.refund_checkpoints'::regclass AND con.confdeltype='r')=1 AS exact_fk,
        (SELECT count(*) FROM key_columns WHERE contype='u' AND names=ARRAY['payment_id'])=1 AND
        (SELECT count(*) FROM key_columns WHERE contype='u' AND names=ARRAY['refund_payment_id'])=1 AND
        (SELECT count(*) FROM key_columns WHERE contype='u' AND names=ARRAY['refund_txid'])=1 AS exact_uniques,
        (SELECT count(*) FROM constraints WHERE contype='p')=1 AND (SELECT count(*) FROM constraints WHERE contype='f')=1 AND
        (SELECT count(*) FROM constraints WHERE contype='u')=3 AND (SELECT count(*) FROM constraints WHERE contype='c')=2 AS constraint_set,
        (SELECT count(*)=5 FROM information_schema.columns WHERE table_schema='public' AND table_name='refund_accounting_records' AND column_name IN ('refund_id','payment_id','refund_payment_id','refund_txid','payer_uid') AND data_type='text' AND is_nullable='NO') AS text_columns,
        EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='refund_accounting_records' AND column_name='amount' AND data_type='numeric' AND is_nullable='NO' AND numeric_precision=18 AND numeric_scale=8) AS amount_column,
        EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='refund_accounting_records' AND column_name='horizon_fee_stroops' AND data_type='bigint' AND is_nullable='NO') AS fee_column,
        EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='refund_accounting_records' AND column_name='currency' AND data_type='text' AND is_nullable='NO') AS currency_column,
        EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='refund_accounting_records' AND column_name='created_at' AND data_type='timestamp without time zone' AND is_nullable='NO') AS created_column,
        (SELECT regexp_replace(expression, '::text$', '') = '''π''' FROM defaults WHERE attname='currency') AS currency_default,
        (SELECT regexp_replace(lower(expression),'\\s+','','g') LIKE 'now()%' FROM defaults WHERE attname='created_at') AS created_default,
        (SELECT count(*) FROM checks WHERE normalized='amount>0')=1 AS amount_check,
        (SELECT count(*) FROM checks WHERE normalized='horizon_fee_stroops>=0')=1 AS fee_check
    `)
    const row = Array.isArray(result) && result.length===1 ? result[0] as Record<string, unknown> : null
    console.warn("[refunds/accounting-schema] Checks:", row)
    return Boolean(row?.table_exists && row.exact_pk && row.exact_fk && row.exact_uniques && row.constraint_set && row.text_columns && row.amount_column && row.fee_column && row.currency_column && row.created_column && row.currency_default && row.created_default && row.amount_check && row.fee_check)
  } catch { return false }
}

export async function verifyRefundTables(): Promise<boolean> {
  if (!process.env.DATABASE_URL) return false
  try {
    const result = await query(`
      SELECT to_regclass('public.refund_checkpoints') AS checkpoints,
             to_regclass('public.refund_audit_events') AS audits,
             to_regclass('public.idx_refund_checkpoints_status_retry') AS status_retry,
             to_regclass('public.idx_refund_checkpoints_payment') AS payment_index,
             to_regclass('public.idx_refund_audit_payment_created') AS audit_payment,
             to_regclass('public.idx_refund_audit_refund_created') AS audit_refund
    `)
    const row = Array.isArray(result) && result.length > 0 ? result[0] as Record<string, unknown> : null
    return Boolean(row?.checkpoints && row?.audits && row?.status_retry && row?.payment_index && row?.audit_payment && row?.audit_refund)
  } catch {
    return false
  }
}

/**
 * Phase 2 persistence boundary. Database is authoritative; Redis is a fast
 * recovery mirror and idempotency claim. No wallet operation belongs here.
 */
export async function createRefundCheckpointWithAudit(checkpoint: RefundCheckpoint, event: RefundAuditEvent): Promise<RefundCheckpoint | null> {
  if (!process.env.DATABASE_URL) return null
  const result = await withPaymentAuthorityTransaction(checkpoint.paymentId, async (tx) => {
    const opposite = await tx`SELECT EXISTS(SELECT 1 FROM settlement_checkpoints WHERE payment_id=${checkpoint.paymentId} AND (stage IN ('a2u_created','prepared','horizon_confirmed','pi_completed','db_finalized') OR a2u_create_attempted_at IS NOT NULL)) AS active`
    if (opposite.length !== 1 || typeof opposite[0]?.active !== 'boolean' || opposite[0].active === true) return []
    return await tx`
      WITH inserted AS (
        INSERT INTO refund_checkpoints
          (refund_id, payment_id, idempotency_key, status, stage, payer_uid,
           payer_uid_verified_at, amount, currency, source_payment_status,
           source_settlement_state, created_at, updated_at, attempt_count, pi_mutation_guard_version)
        VALUES (${checkpoint.refundId},${checkpoint.paymentId},${checkpoint.idempotencyKey},${checkpoint.status},${checkpoint.stage},${checkpoint.payerUid},${checkpoint.payerUidVerifiedAt},${checkpoint.amount},${checkpoint.currency},${checkpoint.sourcePaymentStatus},${checkpoint.sourceSettlementState},${checkpoint.createdAt},${checkpoint.updatedAt},${checkpoint.attemptCount},'fin7_v2')
        ON CONFLICT (payment_id) DO NOTHING
        RETURNING *
      ), audited AS (
        INSERT INTO refund_audit_events
          (event_id, refund_id, payment_id, event_type, actor_type, idempotency_key, created_at, details)
        SELECT ${event.eventId}, refund_id, payment_id, ${event.eventType}, ${event.actorType}, idempotency_key, ${event.createdAt}, ${event.details}::jsonb FROM inserted
        RETURNING refund_id
      ) SELECT inserted.* FROM inserted JOIN audited USING (refund_id)`
  })
  if (!Array.isArray(result) || result.length === 0) return null
  const persisted = normalizeCheckpoint(result[0])
  if (persisted && isRedisConfigured) {
    try {
      await redis.set(redisKey(persisted.refundId), persisted)
    } catch (error) {
      // PostgreSQL refund checkpoint + audit committed atomically above.
      // Redis is a recoverable projection, never the financial commit authority.
      console.warn("[Refund Checkpoint] Redis projection deferred after durable commit", {
        paymentId: persisted.paymentId, refundId: persisted.refundId,
      })
    }
  }
  return persisted
}

export async function createDr11RefundAuthorityFromDurableHold(paymentId:string):Promise<RefundCheckpoint|null>{
  if(!process.env.DATABASE_URL||!paymentId||paymentId!==paymentId.trim())return null
  const idempotencyKey=`dr11-live:${paymentId}`
  const refundId=randomUUID(),now=new Date().toISOString(),eventId=randomUUID(),retryAt=new Date(Date.now()-1000).toISOString()
  const result=await withPaymentAuthorityTransaction(paymentId,async(tx)=>{
    const row=await tx`SELECT stage,customer_amount,merchant_amount,app_commission,payer_uid,u2a_verified_at,u2a_completed_at,
      certification_hold,certification_hold_at,certification_hold_expires_at,a2u_payment_id,prepared_tx_hash,a2u_txid AS settlement_txid
      FROM settlement_checkpoints WHERE payment_id=${paymentId} FOR UPDATE`
    if(row.length!==1)return[]
    const r=row[0] as Record<string,unknown>
    const existing=await tx`SELECT * FROM refund_checkpoints WHERE payment_id=${paymentId} FOR UPDATE`
    if(existing.length===1){
      const e=existing[0] as Record<string,unknown>
      if(e.idempotency_key!==idempotencyKey||Number(e.amount)!==0.1||e.payer_uid!==r.payer_uid||e.source_payment_status!=='settlement_failed'||e.source_settlement_state!=='refund_pending'||
        !['intent_created','wallet_submission_started','wallet_submission_confirmed','payment_checkpoint_updated','accounting_recorded','audit_recorded'].includes(String(e.stage)))return[]
      return existing
    }
    if(existing.length!==0)return[]
    if(r.stage!=='payment_identity'||r.certification_hold!=='dr11_refund'||r.certification_hold_at==null||r.certification_hold_expires_at==null||new Date(r.certification_hold_expires_at as any).getTime()<=Date.now()||r.u2a_completed_at==null||
      r.a2u_payment_id!=null||r.prepared_tx_hash!=null||r.settlement_txid!=null||r.payer_uid==null||r.u2a_verified_at==null)return[]
    const amount=Number(r.customer_amount),merchantAmount=Number(r.merchant_amount),commission=Number(r.app_commission)
    if(amount!==0.1||merchantAmount!==amount||commission!==0)return[]
    const inserted=await tx`INSERT INTO refund_checkpoints
      (refund_id,payment_id,idempotency_key,status,stage,payer_uid,payer_uid_verified_at,amount,currency,source_payment_status,source_settlement_state,created_at,updated_at,attempt_count,last_error_code,last_error_message,next_retry_at,pi_mutation_guard_version)
      VALUES(${refundId},${paymentId},${idempotencyKey},'pending','intent_created',${String(r.payer_uid)},${r.u2a_verified_at},${amount},'π','settlement_failed','refund_pending',${now},${now},0,'dr11_live_hold','awaiting_owner_concurrent_harness',${retryAt},'fin7_v2')
      RETURNING *`
    if(inserted.length!==1)return[]
    const audit=await tx`INSERT INTO refund_audit_events(event_id,refund_id,payment_id,event_type,actor_type,idempotency_key,created_at,details)
      VALUES(${eventId},${refundId},${paymentId},'refund_requested','system',${idempotencyKey},${now},${{stage:'intent_created'}}::jsonb) RETURNING event_id`
    if(audit.length!==1)return[]
    const released=await tx`UPDATE settlement_checkpoints SET certification_hold=NULL,certification_hold_at=NULL,certification_hold_expires_at=NULL,updated_at=NOW()
      WHERE payment_id=${paymentId} AND certification_hold='dr11_refund' AND certification_hold_at IS NOT NULL RETURNING payment_id`
    if(released.length!==1)return[]
    return inserted
  })
  if(!Array.isArray(result)||result.length!==1)return null
  const persisted=normalizeCheckpoint(result[0]);if(!persisted)return null
  if(isRedisConfigured){try{await redis.set(redisKey(persisted.refundId),persisted)}catch(error){console.warn('[DR61] refund Redis projection deferred to durable recovery',{paymentId,refundId:persisted.refundId})}}
  return persisted
}

export async function claimRefundIdempotency(idempotencyKey: string, refundId: string): Promise<boolean> {
  if (!isRedisConfigured) return false
  const existing = await redis.get<string>(redisLockKey(idempotencyKey))
  if (existing === refundId) return true
  const claimed = await redis.set(redisLockKey(idempotencyKey), refundId, { nx: true, ex: 60 * 60 * 24 * 30 })
  return claimed === 'OK'
}

export async function releaseRefundIdempotency(idempotencyKey: string, refundId: string): Promise<void> {
  if (!isRedisConfigured) return
  await redis.eval(
    'if redis.call("get", KEYS[1]) == ARGV[1] then return redis.call("del", KEYS[1]) else return 0 end',
    [redisLockKey(idempotencyKey)],
    [refundId],
  )
}

export async function getRefundCheckpointByIdempotency(idempotencyKey: string): Promise<RefundCheckpoint | null> {
  if (!process.env.DATABASE_URL) return null
  const result = await query('SELECT * FROM refund_checkpoints WHERE idempotency_key = $1', [idempotencyKey])
  if (!Array.isArray(result) || result.length === 0) return null
  return normalizeCheckpoint(result[0])
}

export type RefundPiMutationAttemptResult =
  | { outcome: 'RECORDED'; attemptedAt: string }
  | { outcome: 'REPLAYED' | 'CONFLICT' | 'INDETERMINATE'; error: string }

/** FIN7-S4: one-shot authority for POST /v2/payments Refund creation. */
export async function claimRefundCreateAttempt(params: { refundId: string; paymentId: string; idempotencyKey: string }): Promise<RefundPiMutationAttemptResult> {
  const text=(v:string)=>typeof v==='string'&&v.trim()!==''&&v===v.trim()
  if(!text(params.refundId)||!text(params.paymentId)||!text(params.idempotencyKey))return{outcome:'CONFLICT',error:'Refund create attempt input invalid'}
  try{
    if(!(await ensureRefundCheckpointTables()))return{outcome:'INDETERMINATE',error:'Refund durable schema unavailable'}
    const result=await withPaymentAuthorityTransaction(params.paymentId,async(tx)=>{
      const rows=await tx`SELECT refund_id,payment_id,idempotency_key,status,stage,refund_payment_id,refund_txid,pi_mutation_guard_version
        FROM refund_checkpoints WHERE refund_id=${params.refundId} AND payment_id=${params.paymentId} FOR UPDATE`
      if(rows.length!==1)return[{conflict:true}]
      const r=rows[0] as Record<string,unknown>
      if(r.refund_id!==params.refundId||r.payment_id!==params.paymentId||r.idempotency_key!==params.idempotencyKey||r.pi_mutation_guard_version!=='fin7_v2'||
        r.status!=='pending'||r.stage!=='wallet_submission_started'||r.refund_payment_id!=null||r.refund_txid!=null)return[{conflict:true}]
      const inserted=await tx`INSERT INTO refund_pi_create_attempts(refund_id,payment_id,idempotency_key)
        VALUES(${params.refundId},${params.paymentId},${params.idempotencyKey}) ON CONFLICT DO NOTHING RETURNING attempted_at`
      if(inserted.length===1)return[{recorded:true,attempted_at:inserted[0].attempted_at}]
      return await tx`SELECT refund_id,payment_id,idempotency_key FROM refund_pi_create_attempts WHERE refund_id=${params.refundId}`
    })
    if(!Array.isArray(result)||result.length!==1)return{outcome:'CONFLICT',error:'Refund create authority absent or ambiguous'}
    const r=result[0] as Record<string,unknown>
    if(r.conflict===true)return{outcome:'CONFLICT',error:'Refund create lifecycle is legacy or mismatched'}
    if(r.recorded===true){const at=r.attempted_at;return{outcome:'RECORDED',attemptedAt:at instanceof Date?at.toISOString():String(at)}}
    if(r.refund_id===params.refundId&&r.payment_id===params.paymentId&&r.idempotency_key===params.idempotencyKey)return{outcome:'REPLAYED',error:'Refund create attempt already recorded'}
    return{outcome:'CONFLICT',error:'Refund create attempt conflict'}
  }catch{return{outcome:'INDETERMINATE',error:'Refund create attempt uncertain'}}
}

/** FIN7-S3: one-shot Pi mutation authority for Refund-owned external payments. */
export async function claimRefundPiMutationAttempt(params: {
  kind: 'dr11_a2u_cancel' | 'refund_complete'; refundId: string; paymentId: string; externalPaymentId: string; txid?: string
}): Promise<RefundPiMutationAttemptResult> {
  const text=(v:string)=>typeof v==='string'&&v.trim()!==''&&v===v.trim()
  if(!text(params.refundId)||!text(params.paymentId)||!text(params.externalPaymentId)||(params.txid!==undefined&&!/^[0-9a-f]{64}$/.test(params.txid)))return{outcome:'CONFLICT',error:'Refund Pi mutation attempt input invalid'}
  try{
    if(!(await ensureRefundCheckpointTables()))return{outcome:'INDETERMINATE',error:'Refund durable schema unavailable'}
    const result=await withPaymentAuthorityTransaction(params.paymentId,async(tx)=>{
      const rows=await tx`SELECT refund_id,payment_id,idempotency_key,status,stage,refund_payment_id,refund_txid,pi_mutation_guard_version
        FROM refund_checkpoints WHERE refund_id=${params.refundId} AND payment_id=${params.paymentId} FOR UPDATE`
      if(rows.length!==1)return[{conflict:true}]
      const r=rows[0] as Record<string,unknown>
      if(r.pi_mutation_guard_version!=='fin7_v2')return[{conflict:true}]
      const exact=params.kind==='dr11_a2u_cancel'
        ? r.idempotency_key===`dr11-live:${params.paymentId}`&&r.status==='pending'&&r.stage==='intent_created'&&r.refund_payment_id==null&&r.refund_txid==null
        : r.status==='pending'&&['wallet_submission_confirmed','payment_checkpoint_updated','accounting_recorded','audit_recorded'].includes(String(r.stage))&&r.refund_payment_id===params.externalPaymentId&&r.refund_txid===params.txid
      if(!exact)return[{conflict:true}]
      const inserted=await tx`INSERT INTO financial_pi_mutation_attempts(mutation_kind,payment_id,external_payment_id,txid,refund_id)
        VALUES(${params.kind},${params.paymentId},${params.externalPaymentId},${params.txid??null},${params.refundId}) ON CONFLICT DO NOTHING RETURNING attempted_at`
      if(inserted.length===1)return[{recorded:true,attempted_at:inserted[0].attempted_at}]
      return await tx`SELECT txid,refund_id FROM financial_pi_mutation_attempts WHERE mutation_kind=${params.kind} AND payment_id=${params.paymentId} AND external_payment_id=${params.externalPaymentId}`
    })
    if(!Array.isArray(result)||result.length!==1)return{outcome:'CONFLICT',error:'Refund Pi mutation authority absent or ambiguous'}
    const r=result[0] as Record<string,unknown>
    if(r.conflict===true)return{outcome:'CONFLICT',error:'Refund Pi mutation lifecycle is legacy or mismatched'}
    if(r.recorded===true){const at=r.attempted_at;return{outcome:'RECORDED',attemptedAt:at instanceof Date?at.toISOString():String(at)}}
    if(r.refund_id===params.refundId&&r.txid===(params.txid??null))return{outcome:'REPLAYED',error:'Refund Pi mutation attempt already recorded'}
    return{outcome:'CONFLICT',error:'Refund Pi mutation attempt conflict'}
  }catch{return{outcome:'INDETERMINATE',error:'Refund Pi mutation attempt uncertain'}}
}

export async function beginRefundSubmissionAttempt(refundId: string, event: RefundAuditEvent): Promise<{ checkpoint: RefundCheckpoint; startedNow: boolean } | null> {
  if (!(await verifyRefundTables()) || event.refundId !== refundId) return null
  const existing = await query(`
    SELECT c.*, a.event_id AS submission_audit_id
    FROM refund_checkpoints c
    LEFT JOIN refund_audit_events a
      ON a.refund_id = c.refund_id AND a.payment_id = c.payment_id
     AND a.idempotency_key = c.idempotency_key AND a.event_type = 'refund_submission_started'
    WHERE c.refund_id = $1 AND c.payment_id = $2 AND c.idempotency_key = $3
    ORDER BY a.created_at DESC LIMIT 1`, [refundId, event.paymentId, event.idempotencyKey])
  if (Array.isArray(existing) && existing.length > 0) {
    const row = existing[0]
    if (typeof row !== 'object' || row === null || Array.isArray(row)) return null
    const record = row as Record<string, unknown>
    const current = normalizeCheckpoint(record)
    if (current && current.stage === 'wallet_submission_started' && current.status === 'pending' &&
      typeof record.submission_audit_id === 'string') {
      if (isRedisConfigured) await redis.set(redisKey(refundId), current)
      return { checkpoint: current, startedNow: false }
    }
  }
  const result = await query(`
    WITH transitioned AS (
      UPDATE refund_checkpoints SET stage='wallet_submission_started', status='pending', attempt_count=attempt_count+1, updated_at=NOW()
      WHERE refund_id=$1 AND payment_id=$2 AND idempotency_key=$3 AND stage='intent_created' AND status='pending' RETURNING *
    ), audited AS (
      INSERT INTO refund_audit_events (event_id, refund_id, payment_id, event_type, actor_type, idempotency_key, created_at, details)
      SELECT $4, refund_id, payment_id, 'refund_submission_started', $5, idempotency_key, $6, $7::jsonb FROM transitioned
      RETURNING refund_id
    ) SELECT transitioned.* FROM transitioned JOIN audited USING (refund_id)`,
    [refundId, event.paymentId, event.idempotencyKey, event.eventId, event.actorType, event.createdAt, event.details],
  )
  if (!Array.isArray(result) || result.length === 0) return null
  const checkpoint = normalizeCheckpoint(result[0])
  if (!checkpoint) return null
  if (isRedisConfigured) await redis.set(redisKey(refundId), checkpoint)
  return { checkpoint, startedNow: true }
}

export async function beginRefundBlockchainSubmissionClaim(
  refundId: string,
  paymentId: string,
  idempotencyKey: string,
  refundPaymentId: string,
  actorType: RefundAuditEvent['actorType'] = 'system',
): Promise<{ checkpoint: RefundCheckpoint; startedNow: boolean } | null> {
  if (!(await verifyRefundTables()) || !refundId || !paymentId || !idempotencyKey || !refundPaymentId) return null
  const eventId = `refund:${refundId}:blockchain_submission_started`
  const createdAt = new Date().toISOString()
  const details = { refundPaymentId, phase: 'blockchain_submission' }
  const result = await query(`
    WITH audited AS (
      INSERT INTO refund_audit_events
        (event_id, refund_id, payment_id, event_type, actor_type, idempotency_key, created_at, details)
      SELECT $1, refund_id, payment_id, 'refund_blockchain_submission_started', $2, idempotency_key, $3, $4::jsonb
      FROM refund_checkpoints
      WHERE refund_id=$5 AND payment_id=$6 AND idempotency_key=$7
        AND refund_payment_id=$8 AND stage='wallet_submission_started' AND status='pending'
      ON CONFLICT (event_id) DO NOTHING
      RETURNING refund_id
    ) SELECT * FROM audited`,
    [eventId, actorType, createdAt, details, refundId, paymentId, idempotencyKey, refundPaymentId],
  )
  if (Array.isArray(result) && result.length > 0) {
    const checkpointResult = await query(`SELECT * FROM refund_checkpoints WHERE refund_id=$1 AND payment_id=$2 AND idempotency_key=$3 AND refund_payment_id=$4 AND stage='wallet_submission_started' AND status='pending' LIMIT 1`, [refundId, paymentId, idempotencyKey, refundPaymentId])
    if (!Array.isArray(checkpointResult) || checkpointResult.length !== 1) return null
    const row = checkpointResult[0]
    if (typeof row !== 'object' || row === null || Array.isArray(row)) return null
    const checkpoint = normalizeCheckpoint(row as Record<string, unknown>)
    return checkpoint ? { checkpoint, startedNow: true } : null
  }
  const replay = await query(`
    SELECT c.*, a.event_id AS blockchain_audit_id, a.event_type AS blockchain_audit_event_type,
      a.refund_id AS audit_refund_id, a.payment_id AS audit_payment_id,
      a.idempotency_key AS audit_idempotency_key, a.actor_type AS audit_actor_type,
      a.details AS blockchain_audit_details
    FROM refund_checkpoints c JOIN refund_audit_events a
      ON a.event_id=$1 AND a.event_type='refund_blockchain_submission_started'
    WHERE c.refund_id=$2 AND c.payment_id=$3 AND c.idempotency_key=$4
      AND c.refund_payment_id=$5 AND c.stage='wallet_submission_started' AND c.status='pending'
    LIMIT 1`, [eventId, refundId, paymentId, idempotencyKey, refundPaymentId])
  if (!Array.isArray(replay) || replay.length !== 1) return null
  const replayRow = replay[0]
  if (typeof replayRow !== 'object' || replayRow === null || Array.isArray(replayRow)) return null
  const record = replayRow as Record<string, unknown>
  if (record.blockchain_audit_id !== eventId || record.blockchain_audit_event_type !== 'refund_blockchain_submission_started' ||
    record.audit_refund_id !== refundId || record.audit_payment_id !== paymentId ||
    record.audit_idempotency_key !== idempotencyKey || record.audit_actor_type !== actorType) return null
  if (typeof record.blockchain_audit_details !== 'object' || record.blockchain_audit_details === null || Array.isArray(record.blockchain_audit_details)) return null
  const auditDetails = record.blockchain_audit_details as Record<string, unknown>
  if (Object.keys(auditDetails).length !== 2 || auditDetails.refundPaymentId !== refundPaymentId || auditDetails.phase !== 'blockchain_submission') return null
  const checkpoint = normalizeCheckpoint(record)
  return checkpoint ? { checkpoint, startedNow: false } : null
}

export async function ensureRefundPreparedSubmit(
  refundId: string,
  paymentId: string,
  idempotencyKey: string,
  refundPaymentId: string,
  envelopeXdr: string,
  preparedHash: string,
  preparedSequence: string,
  walletAuthority: WalletAuthorityClaim,
): Promise<{ checkpoint: RefundCheckpoint; preparedNow: boolean; envelopeXdr: string; preparedHash: string; preparedSequence: string } | null> {
  if (!(await verifyRefundTables()) || !refundId || refundId !== refundId.trim() || !paymentId || paymentId !== paymentId.trim() || !idempotencyKey || idempotencyKey !== idempotencyKey.trim() || !refundPaymentId || refundPaymentId !== refundPaymentId.trim() || !envelopeXdr || envelopeXdr !== envelopeXdr.trim() || !/^[0-9a-f]{64}$/.test(preparedHash) || !/^[1-9][0-9]*$/.test(preparedSequence)) return null
  const preparedEventId = `refund:${refundId}:blockchain_submit_prepared`
  const authorizationEventId = `refund:${refundId}:blockchain_submit_authorized`
  const blockchainEventId = `refund:${refundId}:blockchain_submission_started`
  const details = { refundPaymentId, envelopeXdr, preparedHash, preparedSequence, phase: 'horizon_prepared' }
  const result = await withR36RestrictedPaymentTransaction(paymentId, async (tx) => {
    if (walletAuthority.paymentId !== paymentId || walletAuthority.operationId !== refundId ||
        walletAuthority.operationKind !== 'refund' || walletAuthority.preparedHash !== preparedHash ||
        walletAuthority.preparedSequence !== preparedSequence ||
        !(await claimPreparedWalletAuthority(walletAuthority, tx))) throw new Error('wallet_authority_conflict')
    const inserted = await tx.unsafe(`SELECT * FROM public.r36_insert_refund_prepared_audit($1,$2,$3,$4,$5,$6,$7,$8::jsonb)`,
      [refundId,paymentId,idempotencyKey,refundPaymentId,authorizationEventId,preparedEventId,blockchainEventId,details])
    if (!Array.isArray(inserted) || inserted.length !== 1) throw new Error('refund_prepare_not_inserted')
    return inserted
  })
  if (Array.isArray(result) && result.length === 1) {
    const checkpoint = normalizeCheckpoint(result[0])
    return checkpoint ? { checkpoint, preparedNow: true, envelopeXdr, preparedHash, preparedSequence } : null
  }
  if (!result) return null
  const replay = await query(`
    SELECT c.*, a.details AS prepared_details FROM refund_checkpoints c JOIN refund_audit_events a
      ON a.event_id=$5 AND a.refund_id=c.refund_id AND a.payment_id=c.payment_id
     AND a.idempotency_key=c.idempotency_key AND a.event_type='refund_blockchain_submit_prepared'
    WHERE c.refund_id=$1 AND c.payment_id=$2 AND c.idempotency_key=$3 AND c.refund_payment_id=$4::text
      AND c.stage='wallet_submission_started' AND c.status='pending' AND a.actor_type='system'
    LIMIT 1`, [refundId, paymentId, idempotencyKey, refundPaymentId, preparedEventId])
  if (!Array.isArray(replay) || replay.length !== 1) return null
  const record = replay[0]
  if (typeof record !== 'object' || record === null || Array.isArray(record) || !('prepared_details' in record)) return null
  const storedDetails = record.prepared_details
  if (typeof storedDetails !== 'object' || storedDetails === null || Array.isArray(storedDetails) || !('refundPaymentId' in storedDetails) || !('phase' in storedDetails) || !('envelopeXdr' in storedDetails) || !('preparedHash' in storedDetails) || !('preparedSequence' in storedDetails)) return null
  if (Object.keys(storedDetails).length !== 5 || storedDetails.refundPaymentId !== refundPaymentId || storedDetails.phase !== 'horizon_prepared' || typeof storedDetails.envelopeXdr !== 'string' || !storedDetails.envelopeXdr || storedDetails.envelopeXdr !== storedDetails.envelopeXdr.trim() || typeof storedDetails.preparedHash !== 'string' || !/^[0-9a-f]{64}$/.test(storedDetails.preparedHash) || typeof storedDetails.preparedSequence !== 'string' || !/^[1-9][0-9]*$/.test(storedDetails.preparedSequence)) return null
  const checkpoint = normalizeCheckpoint(record)
  return checkpoint ? { checkpoint, preparedNow: false, envelopeXdr: storedDetails.envelopeXdr, preparedHash: storedDetails.preparedHash, preparedSequence: storedDetails.preparedSequence } : null
}

export async function authorizeRefundBlockchainSubmit(
  refundId: string,
  paymentId: string,
  idempotencyKey: string,
  refundPaymentId: string,
  envelopeXdr: string,
  preparedHash: string,
  preparedSequence: string,
  actorType: RefundAuditEvent['actorType'] = 'system',
): Promise<{ checkpoint: RefundCheckpoint; authorizedNow: boolean } | null> {
  if (actorType !== 'system' || !(await verifyRefundTables()) || !refundId || refundId !== refundId.trim() || !paymentId || paymentId !== paymentId.trim() || !idempotencyKey || idempotencyKey !== idempotencyKey.trim() || !refundPaymentId || refundPaymentId !== refundPaymentId.trim() || !envelopeXdr || envelopeXdr !== envelopeXdr.trim() || !/^[0-9a-f]{64}$/.test(preparedHash) || !/^[1-9][0-9]*$/.test(preparedSequence)) return null
  const authorizationEventId = `refund:${refundId}:blockchain_submit_authorized`
  const preparedEventId = `refund:${refundId}:blockchain_submit_prepared`
  const blockchainEventId = `refund:${refundId}:blockchain_submission_started`
  const preparedDetails = { refundPaymentId, envelopeXdr, preparedHash, preparedSequence, phase: 'horizon_prepared' }
  const result = await query(`
    WITH inserted AS (
      SELECT c.*
      FROM refund_checkpoints c
      JOIN refund_audit_events a
        ON a.event_id=$7 AND a.refund_id=c.refund_id AND a.payment_id=c.payment_id
       AND a.idempotency_key=c.idempotency_key AND a.event_type='refund_blockchain_submission_started'
       AND a.actor_type='system' AND a.details=jsonb_build_object('refundPaymentId', $4::text, 'phase', 'blockchain_submission')
      JOIN refund_audit_events p
        ON p.event_id=$6 AND p.refund_id=c.refund_id AND p.payment_id=c.payment_id
       AND p.idempotency_key=c.idempotency_key AND p.event_type='refund_blockchain_submit_prepared'
       AND p.actor_type='system' AND p.details=$8::jsonb
      WHERE c.refund_id=$1 AND c.payment_id=$2 AND c.idempotency_key=$3
        AND c.refund_payment_id=$4::text AND c.stage='wallet_submission_started' AND c.status='pending'
        AND NOT EXISTS (SELECT 1 FROM refund_audit_events z WHERE z.event_id=$5 AND z.refund_id=c.refund_id AND z.payment_id=c.payment_id AND z.idempotency_key=c.idempotency_key AND z.event_type='refund_blockchain_submit_authorized')
    ), audited AS (
      INSERT INTO refund_audit_events (event_id, refund_id, payment_id, event_type, actor_type, idempotency_key, created_at, details)
      SELECT $5, refund_id, payment_id, 'refund_blockchain_submit_authorized', 'system', idempotency_key, NOW(), jsonb_build_object('refundPaymentId', $4::text, 'preparedHash', $8::jsonb->>'preparedHash', 'preparedSequence', $8::jsonb->>'preparedSequence', 'phase', 'horizon_submit') FROM inserted
      ON CONFLICT (event_id) DO NOTHING
      RETURNING refund_id
    ) SELECT inserted.* FROM inserted JOIN audited USING (refund_id)`,
    [refundId, paymentId, idempotencyKey, refundPaymentId, authorizationEventId, preparedEventId, blockchainEventId, preparedDetails])
  if (Array.isArray(result) && result.length === 1) {
    const checkpoint = normalizeCheckpoint(result[0])
    if (checkpoint) return { checkpoint, authorizedNow: true }
    return null
  }
  const replay = await query(`
    SELECT c.*
    FROM refund_checkpoints c
    JOIN refund_audit_events a
      ON a.event_id=$5 AND a.refund_id=c.refund_id AND a.payment_id=c.payment_id
     AND a.idempotency_key=c.idempotency_key AND a.event_type='refund_blockchain_submit_authorized'
    JOIN refund_audit_events p
      ON p.event_id=$6 AND p.refund_id=c.refund_id AND p.payment_id=c.payment_id
     AND p.idempotency_key=c.idempotency_key AND p.event_type='refund_blockchain_submit_prepared'
     AND p.actor_type='system' AND p.details=$8::jsonb
    JOIN refund_audit_events b
      ON b.event_id=$7 AND b.refund_id=c.refund_id AND b.payment_id=c.payment_id
     AND b.idempotency_key=c.idempotency_key AND b.event_type='refund_blockchain_submission_started'
     AND b.actor_type='system' AND b.details=jsonb_build_object('refundPaymentId', $4::text, 'phase', 'blockchain_submission')
    WHERE c.refund_id=$1 AND c.payment_id=$2 AND c.idempotency_key=$3
      AND c.refund_payment_id=$4::text AND c.stage='wallet_submission_started' AND c.status='pending'
      AND a.actor_type='system' AND a.details=jsonb_build_object('refundPaymentId', $4::text, 'preparedHash', $8::jsonb->>'preparedHash', 'preparedSequence', $8::jsonb->>'preparedSequence', 'phase', 'horizon_submit')
    LIMIT 1`, [refundId, paymentId, idempotencyKey, refundPaymentId, authorizationEventId, preparedEventId, blockchainEventId, preparedDetails])
  if (!Array.isArray(replay) || replay.length !== 1) return null
  const checkpoint = normalizeCheckpoint(replay[0])
  return checkpoint ? { checkpoint, authorizedNow: false } : null
}

export async function readRefundPreparedSubmit(
  refundId: string,
  paymentId: string,
  idempotencyKey: string,
  refundPaymentId: string,
): Promise<{ checkpoint: RefundCheckpoint; envelopeXdr: string; preparedHash: string; preparedSequence: string } | null> {
  if (!(await verifyRefundTables()) || !refundId || refundId !== refundId.trim() || !paymentId || paymentId !== paymentId.trim() || !idempotencyKey || idempotencyKey !== idempotencyKey.trim() || !refundPaymentId || refundPaymentId !== refundPaymentId.trim()) return null
  const blockchainEventId = `refund:${refundId}:blockchain_submission_started`
  const preparedEventId = `refund:${refundId}:blockchain_submit_prepared`
  const replay = await query(`
    SELECT c.*, p.details AS prepared_details
    FROM refund_checkpoints c
    JOIN refund_audit_events b
      ON b.event_id=$5 AND b.refund_id=c.refund_id AND b.payment_id=c.payment_id
     AND b.idempotency_key=c.idempotency_key AND b.event_type='refund_blockchain_submission_started'
     AND b.actor_type='system' AND b.details=jsonb_build_object('refundPaymentId',$4::text,'phase','blockchain_submission')
    JOIN refund_audit_events p
      ON p.event_id=$6 AND p.refund_id=c.refund_id AND p.payment_id=c.payment_id
     AND p.idempotency_key=c.idempotency_key AND p.event_type='refund_blockchain_submit_prepared'
     AND p.actor_type='system'
    WHERE c.refund_id=$1 AND c.payment_id=$2 AND c.idempotency_key=$3
      AND c.refund_payment_id=$4::text AND c.stage='wallet_submission_started' AND c.status='pending'
    LIMIT 1`, [refundId, paymentId, idempotencyKey, refundPaymentId, blockchainEventId, preparedEventId])
  if (!Array.isArray(replay) || replay.length !== 1) return null
  const record = replay[0]
  if (typeof record !== 'object' || record === null || Array.isArray(record) || !('prepared_details' in record)) return null
  const storedDetails = record.prepared_details
  if (typeof storedDetails !== 'object' || storedDetails === null || Array.isArray(storedDetails) || !('refundPaymentId' in storedDetails) || !('phase' in storedDetails) || !('envelopeXdr' in storedDetails) || !('preparedHash' in storedDetails) || !('preparedSequence' in storedDetails)) return null
  if (Object.keys(storedDetails).length !== 5 || storedDetails.refundPaymentId !== refundPaymentId || storedDetails.phase !== 'horizon_prepared' || typeof storedDetails.envelopeXdr !== 'string' || !storedDetails.envelopeXdr || storedDetails.envelopeXdr !== storedDetails.envelopeXdr.trim() || typeof storedDetails.preparedHash !== 'string' || !/^[0-9a-f]{64}$/.test(storedDetails.preparedHash) || typeof storedDetails.preparedSequence !== 'string' || !/^[1-9][0-9]*$/.test(storedDetails.preparedSequence)) return null
  const checkpoint = normalizeCheckpoint(record)
  return checkpoint ? { checkpoint, envelopeXdr: storedDetails.envelopeXdr, preparedHash: storedDetails.preparedHash, preparedSequence: storedDetails.preparedSequence } : null
}

export async function readRefundBlockchainSubmissionClaimState(
  refundId: string,
  paymentId: string,
  idempotencyKey: string,
  refundPaymentId: string,
): Promise<{ state: 'present'; checkpoint: RefundCheckpoint } | { state: 'absent' } | { state: 'uncertain' }> {
  const uncertain: { state: 'uncertain' } = { state: 'uncertain' }
  try {
    if (!refundId || refundId !== refundId.trim() || !paymentId || paymentId !== paymentId.trim() || !idempotencyKey || idempotencyKey !== idempotencyKey.trim() || !refundPaymentId || refundPaymentId !== refundPaymentId.trim()) return uncertain
    if (!(await verifyRefundTables())) return uncertain
    const eventId = `refund:${refundId}:blockchain_submission_started`
    const checkpointResult = await query(`
      SELECT c.* FROM refund_checkpoints c
      WHERE c.refund_id=$1 AND c.payment_id=$2 AND c.idempotency_key=$3
        AND c.refund_payment_id=$4 AND c.stage='wallet_submission_started' AND c.status='pending'
      LIMIT 2`, [refundId, paymentId, idempotencyKey, refundPaymentId])
    if (!Array.isArray(checkpointResult) || checkpointResult.length !== 1) return uncertain
    const checkpointRow = checkpointResult[0]
    if (typeof checkpointRow !== 'object' || checkpointRow === null || Array.isArray(checkpointRow)) return uncertain
    const checkpoint = normalizeCheckpoint(checkpointRow)
    if (!checkpoint || checkpoint.refundId !== refundId || checkpoint.paymentId !== paymentId || checkpoint.idempotencyKey !== idempotencyKey || checkpoint.refundPaymentId !== refundPaymentId || checkpoint.stage !== 'wallet_submission_started' || checkpoint.status !== 'pending') return uncertain
    const eventResult = await query(`
      SELECT a.refund_id, a.payment_id, a.idempotency_key, a.event_type, a.actor_type, a.details
      FROM refund_audit_events a WHERE a.event_id=$1 LIMIT 2`, [eventId])
    if (!Array.isArray(eventResult)) return uncertain
    if (eventResult.length === 0) return { state: 'absent' }
    if (eventResult.length !== 1) return uncertain
    const eventRow = eventResult[0]
    if (typeof eventRow !== 'object' || eventRow === null || Array.isArray(eventRow) || !('refund_id' in eventRow) || !('payment_id' in eventRow) || !('idempotency_key' in eventRow) || !('event_type' in eventRow) || !('actor_type' in eventRow) || !('details' in eventRow)) return uncertain
    if (eventRow.refund_id !== refundId || eventRow.payment_id !== paymentId || eventRow.idempotency_key !== idempotencyKey || eventRow.event_type !== 'refund_blockchain_submission_started' || eventRow.actor_type !== 'system') return uncertain
    const details = eventRow.details
    if (typeof details !== 'object' || details === null || Array.isArray(details) || !('refundPaymentId' in details) || !('phase' in details) || Object.keys(details).length !== 2 || details.refundPaymentId !== refundPaymentId || details.phase !== 'blockchain_submission') return uncertain
    return { state: 'present', checkpoint }
  } catch {
    return uncertain
  }
}

export async function readRefundPreparedSubmitState(
  refundId: string,
  paymentId: string,
  idempotencyKey: string,
  refundPaymentId: string,
): Promise<{ state: 'present'; checkpoint: RefundCheckpoint; envelopeXdr: string; preparedHash: string; preparedSequence: string } | { state: 'absent' } | { state: 'uncertain' }> {
  const uncertain: { state: 'uncertain' } = { state: 'uncertain' }
  try {
    if (!refundId || refundId !== refundId.trim() || !paymentId || paymentId !== paymentId.trim() || !idempotencyKey || idempotencyKey !== idempotencyKey.trim() || !refundPaymentId || refundPaymentId !== refundPaymentId.trim()) return uncertain
    if (!(await verifyRefundTables())) return uncertain
    const blockchainEventId = `refund:${refundId}:blockchain_submission_started`
    const preparedEventId = `refund:${refundId}:blockchain_submit_prepared`
    const checkpointResult = await query(`
      SELECT c.*
      FROM refund_checkpoints c
      JOIN refund_audit_events b
        ON b.event_id=$5 AND b.refund_id=c.refund_id AND b.payment_id=c.payment_id
       AND b.idempotency_key=c.idempotency_key AND b.event_type='refund_blockchain_submission_started'
       AND b.actor_type='system' AND b.details=jsonb_build_object('refundPaymentId',$4::text,'phase','blockchain_submission')
      WHERE c.refund_id=$1 AND c.payment_id=$2 AND c.idempotency_key=$3
        AND c.refund_payment_id=$4::text AND c.stage='wallet_submission_started' AND c.status='pending'
      LIMIT 2`, [refundId, paymentId, idempotencyKey, refundPaymentId, blockchainEventId])
    if (!Array.isArray(checkpointResult) || checkpointResult.length !== 1) return uncertain
    const checkpointRow = checkpointResult[0]
    if (typeof checkpointRow !== 'object' || checkpointRow === null || Array.isArray(checkpointRow)) return uncertain
    const checkpoint = normalizeCheckpoint(checkpointRow)
    if (!checkpoint || checkpoint.refundId !== refundId || checkpoint.paymentId !== paymentId || checkpoint.idempotencyKey !== idempotencyKey || checkpoint.refundPaymentId !== refundPaymentId || checkpoint.stage !== 'wallet_submission_started' || checkpoint.status !== 'pending') return uncertain
    const preparedResult = await query(`
      SELECT p.refund_id, p.payment_id, p.idempotency_key, p.event_type, p.actor_type, p.details
      FROM refund_audit_events p
      WHERE p.event_id=$1
      LIMIT 2`, [preparedEventId])
    if (!Array.isArray(preparedResult)) return uncertain
    if (preparedResult.length === 0) return { state: 'absent' }
    if (preparedResult.length !== 1) return uncertain
    const preparedRow = preparedResult[0]
    if (typeof preparedRow !== 'object' || preparedRow === null || Array.isArray(preparedRow)) return uncertain
    if (!('refund_id' in preparedRow) || !('payment_id' in preparedRow) || !('idempotency_key' in preparedRow) || !('event_type' in preparedRow) || !('actor_type' in preparedRow) || !('details' in preparedRow)) return uncertain
    if (preparedRow.refund_id !== refundId || preparedRow.payment_id !== paymentId || preparedRow.idempotency_key !== idempotencyKey || preparedRow.event_type !== 'refund_blockchain_submit_prepared' || preparedRow.actor_type !== 'system') return uncertain
    const storedDetails = preparedRow.details
    if (typeof storedDetails !== 'object' || storedDetails === null || Array.isArray(storedDetails) || !('refundPaymentId' in storedDetails) || !('phase' in storedDetails) || !('envelopeXdr' in storedDetails) || !('preparedHash' in storedDetails) || !('preparedSequence' in storedDetails)) return uncertain
    if (Object.keys(storedDetails).length !== 5 || storedDetails.refundPaymentId !== refundPaymentId || storedDetails.phase !== 'horizon_prepared' || typeof storedDetails.envelopeXdr !== 'string' || !storedDetails.envelopeXdr || storedDetails.envelopeXdr !== storedDetails.envelopeXdr.trim() || typeof storedDetails.preparedHash !== 'string' || !/^[0-9a-f]{64}$/.test(storedDetails.preparedHash) || typeof storedDetails.preparedSequence !== 'string' || !/^[1-9][0-9]*$/.test(storedDetails.preparedSequence)) return uncertain
    return { state: 'present', checkpoint, envelopeXdr: storedDetails.envelopeXdr, preparedHash: storedDetails.preparedHash, preparedSequence: storedDetails.preparedSequence }
  } catch {
    return uncertain
  }
}

export async function readRefundBlockchainSubmitAuthorizationState(
  refundId: string,
  paymentId: string,
  idempotencyKey: string,
  refundPaymentId: string,
  envelopeXdr: string,
  preparedHash: string,
  preparedSequence: string,
): Promise<{ state: 'present'; checkpoint: RefundCheckpoint } | { state: 'absent' } | { state: 'uncertain' }> {
  const uncertain: { state: 'uncertain' } = { state: 'uncertain' }
  try {
    if (!refundId || refundId !== refundId.trim() || !paymentId || paymentId !== paymentId.trim() || !idempotencyKey || idempotencyKey !== idempotencyKey.trim() || !refundPaymentId || refundPaymentId !== refundPaymentId.trim() || !envelopeXdr || envelopeXdr !== envelopeXdr.trim() || !/^[0-9a-f]{64}$/.test(preparedHash) || !/^[1-9][0-9]*$/.test(preparedSequence)) return uncertain
    if (!(await verifyRefundTables())) return uncertain
    const claim = await readRefundBlockchainSubmissionClaimState(refundId, paymentId, idempotencyKey, refundPaymentId)
    const prepared = await readRefundPreparedSubmitState(refundId, paymentId, idempotencyKey, refundPaymentId)
    if (claim.state !== 'present' || prepared.state !== 'present' || prepared.envelopeXdr !== envelopeXdr || prepared.preparedHash !== preparedHash || prepared.preparedSequence !== preparedSequence) return uncertain
    const authorizationEventId = `refund:${refundId}:blockchain_submit_authorized`
    const eventResult = await query(`
      SELECT event_id,refund_id,payment_id,idempotency_key,event_type,actor_type,details FROM refund_audit_events WHERE event_id=$1 OR (refund_id=$2 AND event_type='refund_blockchain_submit_authorized') LIMIT 3`, [authorizationEventId, refundId])
    if (!Array.isArray(eventResult)) return uncertain
    if (eventResult.length === 0) return { state: 'absent' }
    if (eventResult.length !== 1) return uncertain
    const eventRow = eventResult[0]
    if (typeof eventRow !== 'object' || eventRow === null || Array.isArray(eventRow) || !('event_id' in eventRow) || !('refund_id' in eventRow) || !('payment_id' in eventRow) || !('idempotency_key' in eventRow) || !('event_type' in eventRow) || !('actor_type' in eventRow) || !('details' in eventRow)) return uncertain
    if (eventRow.event_id !== authorizationEventId || eventRow.refund_id !== refundId || eventRow.payment_id !== paymentId || eventRow.idempotency_key !== idempotencyKey || eventRow.event_type !== 'refund_blockchain_submit_authorized' || eventRow.actor_type !== 'system') return uncertain
    const details = eventRow.details
    if (typeof details !== 'object' || details === null || Array.isArray(details) || !('refundPaymentId' in details) || !('preparedHash' in details) || !('preparedSequence' in details) || !('phase' in details) || Object.keys(details).length !== 4 || details.refundPaymentId !== refundPaymentId || details.preparedHash !== preparedHash || details.preparedSequence !== preparedSequence || details.phase !== 'horizon_submit') return uncertain
    return { state: 'present', checkpoint: prepared.checkpoint }
  } catch {
    return uncertain
  }
}

export async function persistRefundPaymentIdWithAudit(refundId: string, paymentId: string, idempotencyKey: string, refundPaymentId: string, event: RefundAuditEvent): Promise<RefundCheckpoint | null> {
  if (!(await verifyRefundTables()) || event.refundId !== refundId || event.paymentId !== paymentId || event.idempotencyKey !== idempotencyKey || !refundPaymentId) return null
  const currentResult = await query(`SELECT * FROM refund_checkpoints WHERE refund_id=$1 AND payment_id=$2 AND idempotency_key=$3 AND stage='wallet_submission_started' AND status='pending' LIMIT 1`, [refundId, paymentId, idempotencyKey])
  if (!Array.isArray(currentResult) || currentResult.length === 0) return null
  const currentRow = currentResult[0]
  if (typeof currentRow !== 'object' || currentRow === null || Array.isArray(currentRow)) return null
  const current = normalizeCheckpoint(currentRow as Record<string, unknown>)
  if (!current) return null
  if (current.refundPaymentId === refundPaymentId) return current
  if (current.refundPaymentId) return null
  const result = await query(`
    WITH updated AS (
      UPDATE refund_checkpoints SET refund_payment_id=$4, updated_at=NOW()
      WHERE refund_id=$1 AND payment_id=$2 AND idempotency_key=$3 AND stage='wallet_submission_started' AND status='pending'
        AND refund_payment_id IS NULL RETURNING *
    ), audited AS (
      INSERT INTO refund_audit_events (event_id, refund_id, payment_id, event_type, actor_type, idempotency_key, created_at, details)
      SELECT $5, refund_id, payment_id, $6, $7, idempotency_key, $8, $9::jsonb FROM updated
      RETURNING refund_id
    ) SELECT updated.* FROM updated JOIN audited USING (refund_id)`,
    [refundId, paymentId, idempotencyKey, refundPaymentId, event.eventId, event.eventType, event.actorType, event.createdAt, event.details],
  )
  if (Array.isArray(result) && result.length > 0) {
    const checkpoint = normalizeCheckpoint(result[0])
    if (checkpoint && isRedisConfigured) await redis.set(redisKey(refundId), checkpoint)
    return checkpoint
  }
  const replayResult = await query(`SELECT * FROM refund_checkpoints WHERE refund_id=$1 AND payment_id=$2 AND idempotency_key=$3 AND stage='wallet_submission_started' AND status='pending' LIMIT 1`, [refundId, paymentId, idempotencyKey])
  if (!Array.isArray(replayResult) || replayResult.length === 0) return null
  const replayRow = replayResult[0]
  if (typeof replayRow !== 'object' || replayRow === null || Array.isArray(replayRow)) return null
  const replay = normalizeCheckpoint(replayRow as Record<string, unknown>)
  if (!replay || replay.refundPaymentId !== refundPaymentId) return null
  return replay
}

export async function persistRefundBlockchainTxWithAudit(
  refundId: string,
  paymentId: string,
  idempotencyKey: string,
  refundPaymentId: string,
  refundTxid: string,
  event: RefundAuditEvent,
): Promise<RefundCheckpoint | null> {
  if (!(await verifyRefundTables()) || !event.eventId || event.refundId !== refundId || event.paymentId !== paymentId || event.idempotencyKey !== idempotencyKey || event.eventType !== 'refund_submission_confirmed' || !refundTxid || typeof event.details !== 'object' || event.details === null || Array.isArray(event.details) || (event.details as Record<string, unknown>).refundPaymentId !== refundPaymentId || (event.details as Record<string, unknown>).refundTxid !== refundTxid) return null
  const result = await query(`
    WITH transitioned AS (
      UPDATE refund_checkpoints SET refund_txid=$5, stage='wallet_submission_confirmed', updated_at=NOW()
      WHERE refund_id=$1 AND payment_id=$2 AND idempotency_key=$3 AND refund_payment_id=$4
        AND stage='wallet_submission_started' AND status='pending' AND refund_txid IS NULL RETURNING *
    ), audited AS (
      INSERT INTO refund_audit_events (event_id, refund_id, payment_id, event_type, actor_type, idempotency_key, created_at, details)
      SELECT $6, refund_id, payment_id, $7, $8, idempotency_key, $9, $10::jsonb FROM transitioned RETURNING refund_id
    ) SELECT transitioned.* FROM transitioned JOIN audited USING (refund_id)`,
    [refundId, paymentId, idempotencyKey, refundPaymentId, refundTxid, event.eventId, event.eventType, event.actorType, event.createdAt, event.details],
  )
  if (Array.isArray(result) && result.length > 0) {
    const checkpoint = normalizeCheckpoint(result[0])
    if (checkpoint) console.log('REFUND_BLOCKCHAIN_CONFIRMED', { refundId, paymentId, amount: checkpoint.amount, refundPaymentId, refundTxid, recordedAt: event.createdAt })
    if (checkpoint && isRedisConfigured) await redis.set(redisKey(refundId), checkpoint)
    return checkpoint
  }
  const replayResult = await query(`
    SELECT c.*, a.event_id AS audit_event_id, a.event_type AS audit_event_type,
      a.refund_id AS audit_refund_id, a.payment_id AS audit_payment_id,
      a.idempotency_key AS audit_idempotency_key, a.actor_type AS audit_actor_type,
      a.details AS audit_details
    FROM refund_checkpoints c
    JOIN refund_audit_events a
      ON a.refund_id=c.refund_id AND a.payment_id=c.payment_id
      AND a.idempotency_key=c.idempotency_key
      AND a.event_type='refund_submission_confirmed'
    WHERE c.refund_id=$1 AND c.payment_id=$2 AND c.idempotency_key=$3
      AND c.refund_payment_id=$4 AND c.stage='wallet_submission_confirmed'
      AND c.status='pending' AND c.refund_txid=$5
    LIMIT 2`, [refundId, paymentId, idempotencyKey, refundPaymentId, refundTxid])
  if (!Array.isArray(replayResult) || replayResult.length !== 1) return null
  const row = replayResult[0]
  if (typeof row !== 'object' || row === null || Array.isArray(row)) return null
  const record = row as Record<string, unknown>
  if (typeof record.audit_event_id !== 'string' || record.audit_event_id.length === 0 || record.audit_event_type !== 'refund_submission_confirmed' ||
    record.audit_refund_id !== refundId || record.audit_payment_id !== paymentId ||
    record.audit_idempotency_key !== idempotencyKey || record.audit_actor_type !== event.actorType) return null
  if (typeof record.audit_details !== 'object' || record.audit_details === null || Array.isArray(record.audit_details)) return null
  const details = record.audit_details as Record<string, unknown>
  if (details.refundPaymentId !== refundPaymentId || details.refundTxid !== refundTxid) return null
  const checkpoint = normalizeCheckpoint(record)
  return checkpoint ?? null
}

export async function advanceRefundPaymentCheckpointWithAudit(refundId: string, paymentId: string, idempotencyKey: string, refundPaymentId: string, refundTxid: string, event: RefundAuditEvent): Promise<RefundCheckpoint | null> {
  if (!(await verifyRefundTables()) || !event.eventId || event.eventType !== 'refund_payment_checkpoint_updated' || event.refundId !== refundId || event.paymentId !== paymentId || event.idempotencyKey !== idempotencyKey || !refundPaymentId || !refundTxid || typeof event.details !== 'object' || event.details === null || Array.isArray(event.details)) return null
  const eventDetails = event.details as Record<string, unknown>
  if (Object.keys(eventDetails).length !== 2 || eventDetails.refundPaymentId !== refundPaymentId || eventDetails.refundTxid !== refundTxid) return null
  const result = await query(`
    WITH transitioned AS (
      UPDATE refund_checkpoints SET stage='payment_checkpoint_updated', updated_at=NOW()
      WHERE refund_id=$1 AND payment_id=$2 AND idempotency_key=$3 AND refund_payment_id=$4 AND refund_txid=$5
        AND stage='wallet_submission_confirmed' AND status='pending' RETURNING *
    ), audited AS (
      INSERT INTO refund_audit_events (event_id, refund_id, payment_id, event_type, actor_type, idempotency_key, created_at, details)
      SELECT $6, refund_id, payment_id, $7, $8, idempotency_key, $9, $10::jsonb FROM transitioned RETURNING refund_id
    ) SELECT transitioned.* FROM transitioned JOIN audited USING (refund_id)`,
    [refundId, paymentId, idempotencyKey, refundPaymentId, refundTxid, event.eventId, event.eventType, event.actorType, event.createdAt, event.details],
  )
  if (Array.isArray(result) && result.length > 0) return normalizeCheckpoint(result[0])
  const replay = await query(`
    SELECT c.*, a.event_id AS audit_event_id, a.event_type AS audit_event_type,
      a.refund_id AS audit_refund_id, a.payment_id AS audit_payment_id,
      a.idempotency_key AS audit_idempotency_key, a.actor_type AS audit_actor_type,
      a.details AS audit_details
    FROM refund_checkpoints c
    JOIN refund_audit_events a
      ON a.refund_id=c.refund_id AND a.payment_id=c.payment_id
      AND a.idempotency_key=c.idempotency_key
      AND a.event_type='refund_payment_checkpoint_updated'
    WHERE c.refund_id=$1 AND c.payment_id=$2 AND c.idempotency_key=$3
      AND c.refund_payment_id=$4 AND c.refund_txid=$5
      AND c.stage='payment_checkpoint_updated' AND c.status='pending'
    LIMIT 2`, [refundId, paymentId, idempotencyKey, refundPaymentId, refundTxid])
  if (!Array.isArray(replay) || replay.length !== 1) return null
  const record = replay[0]
  if (typeof record !== 'object' || record === null || Array.isArray(record)) return null
  const replayRecord = record as Record<string, unknown>
  if (typeof replayRecord.audit_event_id !== 'string' || replayRecord.audit_event_id.length === 0 ||
    replayRecord.audit_event_type !== 'refund_payment_checkpoint_updated' ||
    replayRecord.audit_refund_id !== refundId || replayRecord.audit_payment_id !== paymentId ||
    replayRecord.audit_idempotency_key !== idempotencyKey || replayRecord.audit_actor_type !== event.actorType) return null
  if (typeof replayRecord.audit_details !== 'object' || replayRecord.audit_details === null || Array.isArray(replayRecord.audit_details)) return null
  const replayDetails = replayRecord.audit_details as Record<string, unknown>
  if (Object.keys(replayDetails).length !== 2 || replayDetails.refundPaymentId !== refundPaymentId || replayDetails.refundTxid !== refundTxid) return null
  const checkpoint = normalizeCheckpoint(replayRecord)
  return checkpoint ?? null
}

export async function advanceRefundAccountingWithAudit(
  refundId: string,
  paymentId: string,
  idempotencyKey: string,
  refundPaymentId: string,
  refundTxid: string,
  payerUid: string,
  amount: number,
  horizonFeeStroops: number,
  event: RefundAuditEvent,
): Promise<RefundCheckpoint | null> {
  if (!(await verifyRefundTables()) || !(await verifyRefundAccountingSchema()) || !event.eventId || event.eventType !== 'refund_accounting_recorded' || event.actorType !== 'system' || event.refundId !== refundId || event.paymentId !== paymentId || event.idempotencyKey !== idempotencyKey || typeof horizonFeeStroops !== 'number' || !Number.isSafeInteger(horizonFeeStroops) || horizonFeeStroops < 0 || typeof event.details !== 'object' || event.details === null || Array.isArray(event.details)) return null
  const details = event.details as Record<string, unknown>
  if (Object.keys(details).length !== 3 || details.refundPaymentId !== refundPaymentId || details.refundTxid !== refundTxid || details.horizonFeeStroops !== horizonFeeStroops) return null
  const result = await query(`
    WITH matching AS (
      SELECT c.refund_id FROM refund_checkpoints c
      JOIN refund_accounting_records a ON a.refund_id=c.refund_id
      WHERE c.refund_id=$1 AND c.payment_id=$2 AND c.idempotency_key=$13 AND c.refund_payment_id=$3 AND c.refund_txid=$4
        AND c.payer_uid=$5 AND c.amount=$6::numeric AND c.stage='payment_checkpoint_updated' AND c.status='pending'
        AND a.payment_id=c.payment_id AND a.refund_payment_id=c.refund_payment_id AND a.refund_txid=c.refund_txid
        AND a.payer_uid=c.payer_uid AND a.amount=c.amount AND a.horizon_fee_stroops=$7::bigint AND a.currency='π'
    ), transitioned AS (
      UPDATE refund_checkpoints SET stage='accounting_recorded', updated_at=NOW()
      WHERE refund_id IN (SELECT refund_id FROM matching)
        AND stage='payment_checkpoint_updated' AND status='pending' RETURNING *
    ), audited AS (
      INSERT INTO refund_audit_events (event_id, refund_id, payment_id, event_type, actor_type, idempotency_key, created_at, details)
      SELECT $8, refund_id, payment_id, $9, $10, idempotency_key, $11, $12::jsonb FROM transitioned RETURNING refund_id
    ) SELECT transitioned.* FROM transitioned JOIN audited USING (refund_id)`,
    [refundId, paymentId, refundPaymentId, refundTxid, payerUid, amount, horizonFeeStroops, event.eventId, event.eventType, event.actorType, event.createdAt, event.details, idempotencyKey],
  )
  if (Array.isArray(result) && result.length > 1) return null
  if (Array.isArray(result) && result.length === 1) return normalizeCheckpoint(result[0])
  const replay = await query(`
    SELECT c.*, a.event_id AS audit_event_id, a.event_type AS audit_event_type, a.actor_type AS audit_actor_type, a.details AS audit_details
    FROM refund_checkpoints c JOIN refund_accounting_records r ON r.refund_id=c.refund_id
    JOIN refund_audit_events a ON a.refund_id=c.refund_id AND a.payment_id=c.payment_id AND a.idempotency_key=c.idempotency_key AND a.event_type='refund_accounting_recorded'
    WHERE c.refund_id=$1 AND c.payment_id=$2 AND c.idempotency_key=$8 AND c.refund_payment_id=$3 AND c.refund_txid=$4 AND c.payer_uid=$5 AND c.amount=$6::numeric
      AND c.stage='accounting_recorded' AND c.status='pending' AND r.payment_id=c.payment_id AND r.refund_payment_id=c.refund_payment_id AND r.refund_txid=c.refund_txid AND r.payer_uid=c.payer_uid AND r.amount=c.amount AND r.horizon_fee_stroops=$7::bigint AND r.currency='π' LIMIT 2`,
    [refundId, paymentId, refundPaymentId, refundTxid, payerUid, amount, horizonFeeStroops, idempotencyKey],
  )
  if (!Array.isArray(replay) || replay.length !== 1) return null
  const row = replay[0]
  if (typeof row !== 'object' || row === null || Array.isArray(row)) return null
  const record = row as Record<string, unknown>
  if (typeof record.audit_event_id !== 'string' || record.audit_event_id.length === 0 || record.audit_event_type !== 'refund_accounting_recorded' || record.audit_actor_type !== 'system' || typeof record.audit_details !== 'object' || record.audit_details === null || Array.isArray(record.audit_details)) return null
  const auditDetails = record.audit_details as Record<string, unknown>
  if (Object.keys(auditDetails).length !== 3 || auditDetails.refundPaymentId !== refundPaymentId || auditDetails.refundTxid !== refundTxid || auditDetails.horizonFeeStroops !== horizonFeeStroops) return null
  return normalizeCheckpoint(record)
}

export async function advanceRefundAuditWithAudit(
  refundId: string,
  paymentId: string,
  idempotencyKey: string,
  refundPaymentId: string,
  refundTxid: string,
  payerUid: string,
  amount: number,
  horizonFeeStroops: number,
  event: RefundAuditEvent,
): Promise<RefundCheckpoint | null> {
  if (!(await verifyRefundTables()) || !(await verifyRefundAccountingSchema()) || !event.eventId || event.eventType !== 'refund_audit_recorded' || event.actorType !== 'system' || event.refundId !== refundId || event.paymentId !== paymentId || event.idempotencyKey !== idempotencyKey || typeof horizonFeeStroops !== 'number' || !Number.isSafeInteger(horizonFeeStroops) || horizonFeeStroops < 0 || typeof event.details !== 'object' || event.details === null || Array.isArray(event.details)) return null
  const details = event.details as Record<string, unknown>
  if (Object.keys(details).length !== 3 || details.refundPaymentId !== refundPaymentId || details.refundTxid !== refundTxid || details.horizonFeeStroops !== horizonFeeStroops) return null
  const params = [refundId, paymentId, idempotencyKey, refundPaymentId, refundTxid, payerUid, amount, horizonFeeStroops, event.eventId, event.eventType, event.actorType, event.createdAt, event.details]
  const result = await query(`
    WITH eligible AS (
      SELECT c.refund_id FROM refund_checkpoints c JOIN refund_accounting_records r ON r.refund_id=c.refund_id
      WHERE c.refund_id=$1 AND c.payment_id=$2 AND c.idempotency_key=$3 AND c.refund_payment_id=$4 AND c.refund_txid=$5
        AND c.payer_uid=$6 AND c.amount=$7::numeric AND c.stage='accounting_recorded' AND c.status='pending'
        AND r.payment_id=c.payment_id AND r.refund_payment_id=c.refund_payment_id AND r.refund_txid=c.refund_txid AND r.payer_uid=c.payer_uid AND r.amount=c.amount AND r.horizon_fee_stroops=$8::bigint AND r.currency='π'
        AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_submission_confirmed')=1
        AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_submission_confirmed' AND a.payment_id=c.payment_id AND a.idempotency_key=c.idempotency_key AND a.event_id <> '' AND a.actor_type='system' AND a.details->>'refundPaymentId'=$4 AND a.details->>'refundTxid'=$5)=1
        AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_payment_checkpoint_updated')=1
        AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_payment_checkpoint_updated' AND a.payment_id=c.payment_id AND a.idempotency_key=c.idempotency_key AND a.event_id <> '' AND a.actor_type='system' AND a.details->>'refundPaymentId'=$4 AND a.details->>'refundTxid'=$5)=1
        AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_accounting_recorded')=1
        AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_accounting_recorded' AND a.payment_id=c.payment_id AND a.idempotency_key=c.idempotency_key AND a.event_id <> '' AND a.actor_type='system' AND a.details->>'refundPaymentId'=$4 AND a.details->>'refundTxid'=$5 AND a.details->>'horizonFeeStroops'=$8::text)=1
        AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_audit_recorded')=0
    ), transitioned AS (
      UPDATE refund_checkpoints SET stage='audit_recorded', updated_at=NOW() WHERE refund_id IN (SELECT refund_id FROM eligible)
        AND stage='accounting_recorded' AND status='pending' RETURNING *
    ), audited AS (
      INSERT INTO refund_audit_events (event_id, refund_id, payment_id, event_type, actor_type, idempotency_key, created_at, details)
      SELECT $9, refund_id, payment_id, $10, $11, idempotency_key, $12, $13::jsonb FROM transitioned RETURNING refund_id
    ) SELECT transitioned.* FROM transitioned JOIN audited USING (refund_id)`, params)
  if (Array.isArray(result) && result.length > 1) return null
  if (Array.isArray(result) && result.length === 1) return normalizeCheckpoint(result[0])
  const diagnostic = await query(`SELECT EXISTS (SELECT 1 FROM refund_checkpoints c JOIN refund_accounting_records r ON r.refund_id=c.refund_id WHERE c.refund_id=$1 AND c.payment_id=$2 AND c.idempotency_key=$3 AND c.refund_payment_id=$4 AND c.refund_txid=$5 AND c.payer_uid=$6 AND c.amount=$7::numeric AND c.stage='accounting_recorded' AND c.status='pending' AND r.payment_id=c.payment_id AND r.refund_payment_id=c.refund_payment_id AND r.refund_txid=c.refund_txid AND r.payer_uid=c.payer_uid AND r.amount=c.amount AND r.horizon_fee_stroops=$8::bigint AND r.currency='π') AS base_match, (SELECT count(*) FROM refund_audit_events WHERE refund_id=$1 AND event_type='refund_submission_confirmed') AS refund_submission_confirmed_total, (SELECT count(*) FROM refund_audit_events WHERE refund_id=$1 AND event_type='refund_submission_confirmed' AND payment_id=$2 AND idempotency_key=$3 AND event_id <> '' AND actor_type='system' AND details->>'refundPaymentId'=$4 AND details->>'refundTxid'=$5) AS refund_submission_confirmed_exact, (SELECT count(*) FROM refund_audit_events WHERE refund_id=$1 AND event_type='refund_payment_checkpoint_updated') AS refund_payment_checkpoint_updated_total, (SELECT count(*) FROM refund_audit_events WHERE refund_id=$1 AND event_type='refund_payment_checkpoint_updated' AND payment_id=$2 AND idempotency_key=$3 AND event_id <> '' AND actor_type='system' AND details->>'refundPaymentId'=$4 AND details->>'refundTxid'=$5) AS refund_payment_checkpoint_updated_exact, (SELECT count(*) FROM refund_audit_events WHERE refund_id=$1 AND event_type='refund_accounting_recorded') AS refund_accounting_recorded_total, (SELECT count(*) FROM refund_audit_events WHERE refund_id=$1 AND event_type='refund_accounting_recorded' AND payment_id=$2 AND idempotency_key=$3 AND event_id <> '' AND actor_type='system' AND details->>'refundPaymentId'=$4 AND details->>'refundTxid'=$5 AND details->>'horizonFeeStroops'=$8::text) AS refund_accounting_recorded_exact, (SELECT count(*) FROM refund_audit_events WHERE refund_id=$1 AND event_type='refund_audit_recorded') AS refund_audit_recorded_total`, params.slice(0, 8))
  const diagnosticRow = Array.isArray(diagnostic) && diagnostic.length === 1 ? diagnostic[0] as Record<string, unknown> : null
  console.warn('[refunds/audit-advance] Diagnostic:', diagnosticRow && { baseMatch: diagnosticRow.base_match, refundSubmissionConfirmedTotal: diagnosticRow.refund_submission_confirmed_total, refundSubmissionConfirmedExact: diagnosticRow.refund_submission_confirmed_exact, refundPaymentCheckpointUpdatedTotal: diagnosticRow.refund_payment_checkpoint_updated_total, refundPaymentCheckpointUpdatedExact: diagnosticRow.refund_payment_checkpoint_updated_exact, refundAccountingRecordedTotal: diagnosticRow.refund_accounting_recorded_total, refundAccountingRecordedExact: diagnosticRow.refund_accounting_recorded_exact, refundAuditRecordedTotal: diagnosticRow.refund_audit_recorded_total })
  const eventDiagnostics = await query(`SELECT event_type, payment_id=$2 AS "paymentIdMatch", idempotency_key=$3 AS "idempotencyKeyMatch", event_id <> '' AS "eventIdNonEmpty", actor_type='system' AS "actorSystem", details->>'refundPaymentId'=$4 AS "refundPaymentIdMatch", details->>'refundTxid'=$5 AS "refundTxidMatch", CASE WHEN event_type='refund_accounting_recorded' THEN details->>'horizonFeeStroops'=$6::text ELSE NULL END AS "feeMatch" FROM refund_audit_events WHERE refund_id=$1 AND event_type IN ('refund_submission_confirmed','refund_payment_checkpoint_updated','refund_accounting_recorded')`, [refundId, paymentId, idempotencyKey, refundPaymentId, refundTxid, horizonFeeStroops])
  const eventDiagnosticRows = Array.isArray(eventDiagnostics) ? eventDiagnostics.filter((event): event is Record<string, unknown> & { event_type: string } => event !== null && typeof event === 'object' && !Array.isArray(event) && 'event_type' in event && typeof event.event_type === 'string') : []
  console.warn('[refunds/audit-advance] Event diagnostics:', Object.fromEntries(eventDiagnosticRows.map(event => [event.event_type, { paymentIdMatch: event.paymentIdMatch, idempotencyKeyMatch: event.idempotencyKeyMatch, eventIdNonEmpty: event.eventIdNonEmpty, actorSystem: event.actorSystem, refundPaymentIdMatch: event.refundPaymentIdMatch, refundTxidMatch: event.refundTxidMatch, ...(event.event_type === 'refund_accounting_recorded' ? { feeMatch: event.feeMatch } : {}) }])))
  const detailsDiagnostics = await query(`SELECT event_type, jsonb_typeof(details) AS details_type, CASE WHEN jsonb_typeof(details)='object' THEN ARRAY(SELECT key FROM jsonb_object_keys(details) key ORDER BY key) ELSE ARRAY[]::text[] END AS detail_keys FROM refund_audit_events WHERE refund_id=$1 AND event_type IN ('refund_submission_confirmed','refund_payment_checkpoint_updated','refund_accounting_recorded')`, [refundId])
  console.warn('[refunds/audit-advance] Details diagnostics:', Array.isArray(detailsDiagnostics) ? detailsDiagnostics : [])
  let legacyCount = 0
  let submissionConfirmed = false
  let paymentCheckpointUpdated = false
  let accountingRecorded = false
  let legacyMatches = true
  const legacyDetailsRows = await query(`SELECT event_type, details FROM refund_audit_events WHERE refund_id=$1 AND event_type IN ('refund_submission_confirmed','refund_payment_checkpoint_updated','refund_accounting_recorded')`, [refundId])
  if (Array.isArray(legacyDetailsRows)) for (const row of legacyDetailsRows) {
    if (row === null || typeof row !== 'object' || Array.isArray(row) || !('event_type' in row) || !('details' in row) || typeof row.event_type !== 'string' || typeof row.details !== 'string') { legacyMatches = false; continue }
    try {
      const parsed: unknown = JSON.parse(row.details)
      const parsedObject = parsed !== null && typeof parsed === 'object' && !Array.isArray(parsed)
      const paymentIdMatch = parsedObject && 'refundPaymentId' in parsed && parsed.refundPaymentId === refundPaymentId
      const refundTxidMatch = parsedObject && 'refundTxid' in parsed && parsed.refundTxid === refundTxid
      const feeMatch = row.event_type === 'refund_accounting_recorded' && parsedObject && 'horizonFeeStroops' in parsed && String(parsed.horizonFeeStroops) === String(horizonFeeStroops)
      legacyCount += 1
      if (row.event_type === 'refund_submission_confirmed') submissionConfirmed = !submissionConfirmed
      if (row.event_type === 'refund_payment_checkpoint_updated') paymentCheckpointUpdated = !paymentCheckpointUpdated
      if (row.event_type === 'refund_accounting_recorded') accountingRecorded = !accountingRecorded
      if (!parsedObject || !paymentIdMatch || !refundTxidMatch || (row.event_type === 'refund_accounting_recorded' && !feeMatch)) legacyMatches = false
    } catch { legacyMatches = false }
  }
  if (legacyCount === 3 && submissionConfirmed && paymentCheckpointUpdated && accountingRecorded && legacyMatches) {
    const repaired = await query(`WITH candidate AS (SELECT ctid, event_type, details FROM refund_audit_events WHERE refund_id=$1 AND payment_id=$2 AND idempotency_key=$3 AND actor_type='system' AND event_id<>'' AND jsonb_typeof(details)='string' AND event_type IN ('refund_submission_confirmed','refund_payment_checkpoint_updated','refund_accounting_recorded')), eligible AS (SELECT count(*)=3 AND count(*) FILTER (WHERE event_type='refund_submission_confirmed')=1 AND count(*) FILTER (WHERE event_type='refund_payment_checkpoint_updated')=1 AND count(*) FILTER (WHERE event_type='refund_accounting_recorded')=1 AS ok FROM candidate) UPDATE refund_audit_events a SET details=(c.details #>> '{}')::jsonb FROM candidate c CROSS JOIN eligible e WHERE e.ok AND a.ctid=c.ctid RETURNING a.event_type`, [refundId, paymentId, idempotencyKey])
    if (Array.isArray(repaired) && repaired.length === 3) {
      return advanceRefundAuditWithAudit(refundId, paymentId, idempotencyKey, refundPaymentId, refundTxid, payerUid, amount, horizonFeeStroops, event)
    }
  }
  const replay = await query(`
    SELECT c.* FROM refund_checkpoints c JOIN refund_accounting_records r ON r.refund_id=c.refund_id
    WHERE c.refund_id=$1 AND c.payment_id=$2 AND c.idempotency_key=$3 AND c.refund_payment_id=$4 AND c.refund_txid=$5 AND c.payer_uid=$6 AND c.amount=$7::numeric AND c.stage='audit_recorded' AND c.status='pending'
      AND r.payment_id=c.payment_id AND r.refund_payment_id=c.refund_payment_id AND r.refund_txid=c.refund_txid AND r.payer_uid=c.payer_uid AND r.amount=c.amount AND r.horizon_fee_stroops=$8::bigint AND r.currency='π'
      AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_submission_confirmed')=1
      AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_submission_confirmed' AND a.payment_id=c.payment_id AND a.idempotency_key=c.idempotency_key AND a.event_id <> '' AND a.actor_type='system' AND a.details->>'refundPaymentId'=$4 AND a.details->>'refundTxid'=$5)=1
      AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_payment_checkpoint_updated')=1
      AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_payment_checkpoint_updated' AND a.payment_id=c.payment_id AND a.idempotency_key=c.idempotency_key AND a.event_id <> '' AND a.actor_type='system' AND a.details->>'refundPaymentId'=$4 AND a.details->>'refundTxid'=$5)=1
      AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_accounting_recorded')=1
      AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_accounting_recorded' AND a.payment_id=c.payment_id AND a.idempotency_key=c.idempotency_key AND a.event_id <> '' AND a.actor_type='system' AND a.details->>'refundPaymentId'=$4 AND a.details->>'refundTxid'=$5 AND a.details->>'horizonFeeStroops'=$8::text)=1
      AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_audit_recorded')=1
      AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_audit_recorded' AND a.payment_id=c.payment_id AND a.idempotency_key=c.idempotency_key AND a.event_id <> '' AND a.actor_type='system' AND a.details->>'refundPaymentId'=$4 AND a.details->>'refundTxid'=$5 AND a.details->>'horizonFeeStroops'=$8::text)=1 LIMIT 2`, params.slice(0, 8))
  if (!Array.isArray(replay) || replay.length !== 1) return null
  const checkpoint = normalizeCheckpoint(replay[0])
  return checkpoint ?? null
}

export async function completeRefundCheckpointWithAudit(
  refundId: string,
  paymentId: string,
  idempotencyKey: string,
  refundPaymentId: string,
  refundTxid: string,
  payerUid: string,
  amount: number,
  horizonFeeStroops: number,
  event: RefundAuditEvent,
): Promise<RefundCheckpoint | null> {
  if (!(await verifyRefundTables()) || !(await verifyRefundAccountingSchema()) || !event.eventId || event.eventType !== 'refund_completed' || event.actorType !== 'system' || event.refundId !== refundId || event.paymentId !== paymentId || event.idempotencyKey !== idempotencyKey || !Number.isSafeInteger(horizonFeeStroops) || horizonFeeStroops < 0 || typeof event.details !== 'object' || event.details === null || Array.isArray(event.details)) return null
  const details = event.details as Record<string, unknown>
  if (Object.keys(details).length !== 3 || details.refundPaymentId !== refundPaymentId || details.refundTxid !== refundTxid || details.horizonFeeStroops !== horizonFeeStroops) return null
  const params = [refundId, paymentId, idempotencyKey, refundPaymentId, refundTxid, payerUid, amount, horizonFeeStroops, event.eventId, event.eventType, event.actorType, event.createdAt, event.details]
  const auditIdentity = `(a.payment_id=c.payment_id AND a.idempotency_key=c.idempotency_key AND a.actor_type='system' AND a.event_id <> '' AND a.details->>'refundPaymentId'=$4 AND a.details->>'refundTxid'=$5)`
  // PRE-DR118 UX18: completion is allowed only after the four prerequisite
  // audit events are canonical JSONB objects. UX14 historically produced JSONB
  // string scalars; UX17 repaired the first three while advancing audit, but an
  // audit_recorded row can still be legacy-shaped at the completion boundary.
  // Repair is identity-bound, multiplicity-bound and semantic-exact. It never
  // creates financial authority and never calls Pi/Horizon.
  const prerequisiteEvents = await query(`
    SELECT event_type, payment_id, idempotency_key, actor_type, event_id, details
    FROM refund_audit_events
    WHERE refund_id=$1 AND event_type IN ('refund_submission_confirmed','refund_payment_checkpoint_updated','refund_accounting_recorded','refund_audit_recorded')
    ORDER BY event_type`, [refundId])
  if (!Array.isArray(prerequisiteEvents) || prerequisiteEvents.length !== 4) return null
  const requiredTypes = new Set(['refund_submission_confirmed','refund_payment_checkpoint_updated','refund_accounting_recorded','refund_audit_recorded'])
  const legacyTypes: string[] = []
  for (const row of prerequisiteEvents) {
    if (row === null || typeof row !== 'object' || Array.isArray(row)) return null
    const record = row as Record<string, unknown>
    if (typeof record.event_type !== 'string' || !requiredTypes.delete(record.event_type) || record.payment_id !== paymentId || record.idempotency_key !== idempotencyKey || record.actor_type !== 'system' || typeof record.event_id !== 'string' || record.event_id.length === 0) return null
    let parsed: unknown = record.details
    if (typeof parsed === 'string') {
      try { parsed = JSON.parse(parsed) } catch { return null }
      legacyTypes.push(record.event_type)
    }
    if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) return null
    const object = parsed as Record<string, unknown>
    const feeEvent = record.event_type === 'refund_accounting_recorded' || record.event_type === 'refund_audit_recorded'
    const submissionRecovered = record.event_type === 'refund_submission_confirmed' && object.recovered === true
    const expectedKeys = feeEvent ? ['refundPaymentId', 'refundTxid', 'horizonFeeStroops'] : submissionRecovered ? ['refundPaymentId', 'refundTxid', 'recovered'] : ['refundPaymentId', 'refundTxid']
    if (Object.keys(object).length !== expectedKeys.length || !expectedKeys.every((key) => Object.prototype.hasOwnProperty.call(object, key)) || object.refundPaymentId !== refundPaymentId || object.refundTxid !== refundTxid || (feeEvent && String(object.horizonFeeStroops) !== String(horizonFeeStroops))) return null
  }
  if (requiredTypes.size !== 0) return null
  if (legacyTypes.length > 0) {
    const repaired = await query(`
      UPDATE refund_audit_events
      SET details=(details #>> '{}')::jsonb
      WHERE refund_id=$1 AND payment_id=$2 AND idempotency_key=$3 AND actor_type='system' AND event_id<>''
        AND jsonb_typeof(details)='string' AND event_type = ANY($4::text[])
      RETURNING event_type`, [refundId, paymentId, idempotencyKey, legacyTypes])
    if (!Array.isArray(repaired) || repaired.length !== legacyTypes.length) return null
  }
  const canonical = await query(`
    SELECT event_type,
      payment_id=$2 AS payment_match,
      idempotency_key=$3 AS idempotency_match,
      actor_type='system' AS actor_system,
      event_id<>'' AS event_id_non_empty,
      jsonb_typeof(details)='object' AS details_object,
      details->>'refundPaymentId'=$4 AS refund_payment_id_match,
      details->>'refundTxid'=$5 AS refund_txid_match,
      CASE WHEN event_type IN ('refund_accounting_recorded','refund_audit_recorded') THEN details->>'horizonFeeStroops'=$6::text ELSE TRUE END AS fee_match
    FROM refund_audit_events
    WHERE refund_id=$1 AND event_type IN ('refund_submission_confirmed','refund_payment_checkpoint_updated','refund_accounting_recorded','refund_audit_recorded')`,
    [refundId, paymentId, idempotencyKey, refundPaymentId, refundTxid, horizonFeeStroops])
  if (!Array.isArray(canonical) || canonical.length !== 4 || canonical.some((row) => row === null || typeof row !== 'object' || Array.isArray(row) || !(row as Record<string, unknown>).payment_match || !(row as Record<string, unknown>).idempotency_match || !(row as Record<string, unknown>).actor_system || !(row as Record<string, unknown>).event_id_non_empty || !(row as Record<string, unknown>).details_object || !(row as Record<string, unknown>).refund_payment_id_match || !(row as Record<string, unknown>).refund_txid_match || !(row as Record<string, unknown>).fee_match)) return null
  const result = await query(`
    WITH eligible AS (
      SELECT c.refund_id FROM refund_checkpoints c JOIN refund_accounting_records r ON r.refund_id=c.refund_id
      WHERE c.refund_id=$1 AND c.payment_id=$2 AND c.idempotency_key=$3 AND c.refund_payment_id=$4 AND c.refund_txid=$5
        AND c.payer_uid=$6 AND c.amount=$7::numeric AND c.stage='audit_recorded' AND c.status='pending'
        AND r.payment_id=c.payment_id AND r.refund_payment_id=c.refund_payment_id AND r.refund_txid=c.refund_txid AND r.payer_uid=c.payer_uid AND r.amount=c.amount AND r.horizon_fee_stroops=$8::bigint AND r.currency='π'
        AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_submission_confirmed')=1
        AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_submission_confirmed' AND ${auditIdentity})=1
        AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_payment_checkpoint_updated')=1
        AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_payment_checkpoint_updated' AND ${auditIdentity})=1
        AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_accounting_recorded')=1
        AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_accounting_recorded' AND ${auditIdentity} AND a.details->>'horizonFeeStroops'=$8::text)=1
        AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_audit_recorded')=1
        AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_audit_recorded' AND ${auditIdentity} AND a.details->>'horizonFeeStroops'=$8::text)=1
        AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_completed')=0
    ), transitioned AS (
      UPDATE refund_checkpoints SET status='completed', updated_at=NOW() WHERE refund_id IN (SELECT refund_id FROM eligible) AND status='pending' AND stage='audit_recorded' RETURNING *
    ), audited AS (
      INSERT INTO refund_audit_events (event_id, refund_id, payment_id, event_type, actor_type, idempotency_key, created_at, details)
      SELECT $9, refund_id, payment_id, $10, $11, idempotency_key, $12, $13::jsonb FROM transitioned RETURNING refund_id
    ) SELECT transitioned.* FROM transitioned JOIN audited USING (refund_id)`, params)
  if (Array.isArray(result) && result.length > 1) return null
  if (Array.isArray(result) && result.length === 1) return normalizeCheckpoint(result[0])
  const replay = await query(`
    SELECT c.* FROM refund_checkpoints c JOIN refund_accounting_records r ON r.refund_id=c.refund_id
    WHERE c.refund_id=$1 AND c.payment_id=$2 AND c.idempotency_key=$3 AND c.refund_payment_id=$4 AND c.refund_txid=$5 AND c.payer_uid=$6 AND c.amount=$7::numeric AND c.stage='audit_recorded' AND c.status='completed'
      AND r.payment_id=c.payment_id AND r.refund_payment_id=c.refund_payment_id AND r.refund_txid=c.refund_txid AND r.payer_uid=c.payer_uid AND r.amount=c.amount AND r.horizon_fee_stroops=$8::bigint AND r.currency='π'
      AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_submission_confirmed')=1
      AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_submission_confirmed' AND ${auditIdentity})=1
      AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_payment_checkpoint_updated')=1
      AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_payment_checkpoint_updated' AND ${auditIdentity})=1
      AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_accounting_recorded')=1
      AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_accounting_recorded' AND ${auditIdentity} AND a.details->>'horizonFeeStroops'=$8::text)=1
      AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_audit_recorded')=1
      AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_audit_recorded' AND ${auditIdentity} AND a.details->>'horizonFeeStroops'=$8::text)=1
      AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_completed')=1
      AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_completed' AND ${auditIdentity} AND a.details->>'horizonFeeStroops'=$8::text)=1 LIMIT 2`, params.slice(0, 8))
  if (!Array.isArray(replay) || replay.length !== 1) return null
  return normalizeCheckpoint(replay[0]) ?? null
}

  export async function finalizeRefundProjectionWithAudit(refundId: string, paymentId: string, idempotencyKey: string, refundPaymentId: string, refundTxid: string, payerUid: string, amount: number): Promise<{ insertedNow: boolean } | null> {
  if (!(await verifyRefundTables()) || !(await verifyRefundAccountingSchema())) return null
  const eventId = `refund:${refundId}:projection_finalized`
  const details = { refundPaymentId, refundTxid }
  const result = await query(`
    WITH eligible AS (
      SELECT c.refund_id, c.payment_id, c.idempotency_key FROM refund_checkpoints c JOIN refund_accounting_records r ON r.refund_id=c.refund_id
      WHERE c.refund_id=$1 AND c.payment_id=$2 AND c.idempotency_key=$3 AND c.refund_payment_id=$4 AND c.refund_txid=$5 AND c.payer_uid=$6 AND c.amount=$7::numeric AND c.stage='audit_recorded' AND c.status='completed'
        AND r.payment_id=c.payment_id AND r.refund_payment_id=c.refund_payment_id AND r.refund_txid=c.refund_txid AND r.payer_uid=c.payer_uid AND r.amount=c.amount AND r.currency='π' AND r.horizon_fee_stroops>=0
        AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_completed')=1
        AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_completed' AND a.payment_id=c.payment_id AND a.idempotency_key=c.idempotency_key AND a.actor_type='system' AND a.event_id<>'' AND a.details=jsonb_build_object('refundPaymentId',$4,'refundTxid',$5,'horizonFeeStroops',r.horizon_fee_stroops))=1
        AND ((SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_projection_finalized')=0 OR ((SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_type='refund_projection_finalized')=1 AND (SELECT count(*) FROM refund_audit_events a WHERE a.refund_id=c.refund_id AND a.event_id=$8 AND a.event_id<>'' AND a.event_type='refund_projection_finalized' AND a.payment_id=c.payment_id AND a.idempotency_key=c.idempotency_key AND a.actor_type='system' AND (a.details=jsonb_build_object('refundPaymentId',$4,'refundTxid',$5) OR (jsonb_typeof(a.details)='string' AND (a.details #>> '{}')=concat('{"refundPaymentId":',to_json($4::text)::text,',"refundTxid":',to_json($5::text)::text,'}'))))=1))
    ), inserted AS (
      INSERT INTO refund_audit_events (event_id, refund_id, payment_id, event_type, actor_type, idempotency_key, created_at, details)
      SELECT $8, refund_id, payment_id, 'refund_projection_finalized', 'system', idempotency_key, NOW(), $9::jsonb FROM eligible
      ON CONFLICT (event_id) DO NOTHING RETURNING event_id
    ), cleaned AS (
      UPDATE refund_checkpoints c
      SET last_error_code=NULL, last_error_message=NULL, next_retry_at=NULL, updated_at=NOW()
      FROM eligible e
      WHERE c.refund_id=e.refund_id
        AND c.payment_id=e.payment_id
        AND c.idempotency_key=e.idempotency_key
        AND c.stage='audit_recorded' AND c.status='completed'
      RETURNING c.refund_id
    ) SELECT (SELECT count(*) FROM eligible) AS eligible_count,
             (SELECT count(*) FROM inserted) AS inserted_count,
             (SELECT count(*) FROM cleaned) AS cleaned_count`,
    [refundId, paymentId, idempotencyKey, refundPaymentId, refundTxid, payerUid, amount, eventId, details],
  )
  if (!Array.isArray(result) || result.length !== 1 || Number((result[0] as Record<string, unknown>).eligible_count) !== 1 || Number((result[0] as Record<string, unknown>).cleaned_count) !== 1) return null
  const insertedNow = Number((result[0] as Record<string, unknown>).inserted_count) === 1
  if (insertedNow) console.log('REFUND_COMPLETED', refundId)
  if (insertedNow) return { insertedNow }
  const replay = await query(`SELECT event_id FROM refund_audit_events WHERE refund_id=$2 AND event_type='refund_projection_finalized' AND ((SELECT count(*) FROM refund_audit_events WHERE refund_id=$2 AND event_type='refund_projection_finalized')=1) AND event_id=$1 AND event_id<>'' AND payment_id=$3 AND actor_type='system' AND idempotency_key=$4 AND (details=jsonb_build_object('refundPaymentId',$5::text,'refundTxid',$6::text) OR (jsonb_typeof(details)='string' AND (details #>> '{}')=concat('{"refundPaymentId":',to_json($5::text)::text,',"refundTxid":',to_json($6::text)::text,'}'))) LIMIT 2`, [eventId, refundId, paymentId, idempotencyKey, refundPaymentId, refundTxid])
  return Array.isArray(replay) && replay.length === 1 ? { insertedNow: false } : null
}

export async function transitionRefundCheckpointWithAudit(
  refundId: string,
  fromStage: RefundCheckpoint['stage'],
  toStage: RefundCheckpoint['stage'],
  status: RefundCheckpoint['status'],
  event: RefundAuditEvent,
  patch: { refundPaymentId?: string; refundTxid?: string; lastErrorCode?: string; lastErrorMessage?: string; nextRetryAt?: string } = {},
): Promise<RefundCheckpoint | null> {
  if (!(await verifyRefundTables()) || event.refundId !== refundId || event.paymentId === '' || event.idempotencyKey === '') return null
  const fromIndex = STAGE_ORDER.indexOf(fromStage)
  const toIndex = STAGE_ORDER.indexOf(toStage)
  if (fromIndex < 0 || toIndex !== fromIndex + 1) return null
  const result = await query(`
    WITH transitioned AS (
      UPDATE refund_checkpoints SET stage=$2, status=$3, updated_at=NOW(),
        refund_payment_id=COALESCE($4, refund_payment_id), refund_txid=COALESCE($5, refund_txid),
        last_error_code=COALESCE($6, last_error_code), last_error_message=COALESCE($7, last_error_message),
        next_retry_at=COALESCE($8, next_retry_at)
      WHERE refund_id=$1 AND payment_id=$9 AND idempotency_key=$10 AND stage=$11 AND status NOT IN ('failed','completed','manual_review_required')
      RETURNING *
    ), audited AS (
      INSERT INTO refund_audit_events
        (event_id, refund_id, payment_id, event_type, actor_type, idempotency_key, created_at, details)
      SELECT $12, refund_id, payment_id, $13, $14, idempotency_key, $15, $16::jsonb FROM transitioned
      RETURNING refund_id
    ) SELECT transitioned.* FROM transitioned JOIN audited USING (refund_id)`,
    [refundId, toStage, status, patch.refundPaymentId ?? null, patch.refundTxid ?? null,
      patch.lastErrorCode ?? null, patch.lastErrorMessage ?? null, patch.nextRetryAt ?? null,
      event.paymentId, event.idempotencyKey, fromStage, event.eventId, event.eventType,
      event.actorType, event.createdAt, event.details],
  )
  if (!Array.isArray(result) || result.length === 0) return null
  const checkpoint = normalizeCheckpoint(result[0])
  if (checkpoint && isRedisConfigured) await redis.set(redisKey(refundId), checkpoint)
  return checkpoint
}

export async function transitionRefundCheckpoint(
  refundId: string,
  fromStage: RefundCheckpoint['stage'],
  toStage: RefundCheckpoint['stage'],
  status: RefundCheckpoint['status'],
  patch: { refundPaymentId?: string; refundTxid?: string; lastErrorCode?: string; lastErrorMessage?: string; nextRetryAt?: string } = {},
): Promise<RefundCheckpoint | null> {
  if (!(await verifyRefundTables())) return null
  const fromIndex = STAGE_ORDER.indexOf(fromStage)
  const toIndex = STAGE_ORDER.indexOf(toStage)
  if (fromIndex < 0 || toIndex !== fromIndex + 1) return null
  const result = await query(`
    UPDATE refund_checkpoints SET stage = $2, status = $3, updated_at = NOW(),
      refund_payment_id = COALESCE($4, refund_payment_id), refund_txid = COALESCE($5, refund_txid),
      last_error_code = COALESCE($6, last_error_code), last_error_message = COALESCE($7, last_error_message),
      next_retry_at = COALESCE($8, next_retry_at)
    WHERE refund_id = $1 AND stage = $9 AND status NOT IN ('failed', 'completed', 'manual_review_required')
    RETURNING *`, [refundId, toStage, status, patch.refundPaymentId ?? null, patch.refundTxid ?? null,
      patch.lastErrorCode ?? null, patch.lastErrorMessage ?? null, patch.nextRetryAt ?? null, fromStage])
  if (!Array.isArray(result) || result.length === 0) return null
  const transitioned = normalizeCheckpoint(result[0])
  if (transitioned && isRedisConfigured) await redis.set(redisKey(refundId), transitioned)
  return transitioned
}

export function refundPreflight(
  checkpoint: RefundCheckpoint,
  payment: Payment,
  input: { paymentId: string; payerUid: string; amount: number },
): boolean {
  return checkpoint.status === 'pending' && checkpoint.stage === 'intent_created' &&
    checkpoint.sourcePaymentStatus === 'settlement_failed' && checkpoint.sourceSettlementState === 'refund_pending' &&
    checkpoint.paymentId === input.paymentId && checkpoint.payerUid === input.payerUid && checkpoint.amount === input.amount &&
    payment.id === input.paymentId && payment.status === 'settlement_failed' && payment.settlementFailureState === 'refund_pending' &&
    payment.refundStatus === 'pending' && typeof payment.payerUidCapturedAt === 'string' && payment.payerUidCapturedAt.trim().length > 0 &&
    payment.payerUidSource === 'verified_u2a' && payment.payerRefundEligible === true && payment.payerUid === input.payerUid &&
    payment.customerAmount === input.amount && !payment.a2uPaymentId && !payment.a2uTxid &&
    payment.horizonSuccessFlag !== true && !payment.refundPaymentId && !payment.refundTxid
}

export type PaymentRefundCheckpointLookup =
  | { state: 'absent' }
  | { state: 'present'; checkpoint: RefundCheckpoint }
  | { state: 'uncertain' }

export async function findRefundCheckpointByPaymentId(paymentId: string): Promise<PaymentRefundCheckpointLookup> {
  if (!process.env.DATABASE_URL || typeof paymentId !== 'string' || paymentId.trim() === '') return { state: 'uncertain' }
  try {
    const result = await query('SELECT * FROM refund_checkpoints WHERE payment_id = $1 LIMIT 1', [paymentId])
    if (!Array.isArray(result)) return { state: 'uncertain' }
    if (result.length === 0) return { state: 'absent' }
    const row = result[0]
    if (typeof row !== 'object' || row === null || Array.isArray(row)) return { state: 'uncertain' }
    const checkpoint = normalizeCheckpoint(row as Record<string, unknown>)
    return checkpoint ? { state: 'present', checkpoint } : { state: 'uncertain' }
  } catch {
    return { state: 'uncertain' }
  }
}

export async function getRefundCheckpointAuthoritative(refundId: string): Promise<RefundCheckpoint | null> {
  if (!process.env.DATABASE_URL) return null
  const result = await query('SELECT * FROM refund_checkpoints WHERE refund_id = $1', [refundId])
  if (!Array.isArray(result) || result.length === 0) return null
  const checkpoint = normalizeCheckpoint(result[0])
  if (checkpoint && isRedisConfigured) await redis.set(redisKey(refundId), checkpoint)
  return checkpoint
}

export async function getRefundCheckpoint(refundId: string): Promise<RefundCheckpoint | null> {
  if (isRedisConfigured) {
    const cached = await redis.get<RefundCheckpoint>(redisKey(refundId))
    if (cached) return normalizeCheckpoint(cached)
  }
  if (!process.env.DATABASE_URL) return null
  const result = await query('SELECT * FROM refund_checkpoints WHERE refund_id = $1', [refundId])
  if (!Array.isArray(result) || result.length === 0) return null
  const checkpoint = normalizeCheckpoint(result[0])
  if (checkpoint && isRedisConfigured) await redis.set(redisKey(refundId), checkpoint)
  return checkpoint
}

export async function appendRefundAuditEvent(event: RefundAuditEvent): Promise<boolean> {
  if (!process.env.DATABASE_URL) return false
  const result = await query(
    `INSERT INTO refund_audit_events
      (event_id, refund_id, payment_id, event_type, actor_type, idempotency_key, created_at, details)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8::jsonb)
     ON CONFLICT (event_id) DO NOTHING
     RETURNING event_id`,
    [event.eventId, event.refundId, event.paymentId, event.eventType, event.actorType, event.idempotencyKey, event.createdAt, event.details],
  )
  return Array.isArray(result) && result.length > 0
}

function normalizeOptionalTimestamp(value: unknown): string | undefined {
  if (typeof value === 'string') {
    const ms = Date.parse(value)
    return Number.isFinite(ms) ? value : undefined
  }
  if (value instanceof Date && Number.isFinite(value.getTime())) return value.toISOString()
  return undefined
}

function normalizeCheckpoint(value: unknown): RefundCheckpoint | null {
  if (!value || typeof value !== 'object') return null
  const row = value as Record<string, unknown>
  const refundId = String(row.refundId ?? row.refund_id ?? '')
  const paymentId = String(row.paymentId ?? row.payment_id ?? '')
  const idempotencyKey = String(row.idempotencyKey ?? row.idempotency_key ?? '')
  const payerUid = String(row.payerUid ?? row.payer_uid ?? '')
  const amount = Number(row.amount)
  if (!refundId || !paymentId || !idempotencyKey || !payerUid || !Number.isFinite(amount) || amount <= 0) return null
  return {
    refundId,
    paymentId,
    idempotencyKey,
    status: String(row.status) as RefundCheckpoint['status'],
    stage: String(row.stage) as RefundCheckpoint['stage'],
    payerUid,
    payerUidVerifiedAt: String(row.payerUidVerifiedAt ?? row.payer_uid_verified_at),
    amount,
    currency: 'π',
    sourcePaymentStatus: String(row.sourcePaymentStatus ?? row.source_payment_status) as RefundCheckpoint['sourcePaymentStatus'],
    sourceSettlementState: String(row.sourceSettlementState ?? row.source_settlement_state) as RefundCheckpoint['sourceSettlementState'],
    createdAt: String(row.createdAt ?? row.created_at),
    updatedAt: String(row.updatedAt ?? row.updated_at),
    refundPaymentId: typeof (row.refundPaymentId ?? row.refund_payment_id) === 'string' ? (row.refundPaymentId ?? row.refund_payment_id) as string : undefined,
    refundTxid: typeof (row.refundTxid ?? row.refund_txid) === 'string' ? (row.refundTxid ?? row.refund_txid) as string : undefined,
    attemptCount: Number(row.attemptCount ?? row.attempt_count ?? 0),
    lastErrorCode: typeof (row.lastErrorCode ?? row.last_error_code) === 'string' ? (row.lastErrorCode ?? row.last_error_code) as string : undefined,
    lastErrorMessage: typeof (row.lastErrorMessage ?? row.last_error_message) === 'string' ? (row.lastErrorMessage ?? row.last_error_message) as string : undefined,
    nextRetryAt: normalizeOptionalTimestamp(row.nextRetryAt ?? row.next_retry_at),
  }
}
