import {currentRecoveryRight} from './r36-recovery-scope'
import { readPiA2UQueueAdmission } from './pi-a2u-queue-admission'
import { claimRejectedRefundCreateRecovery } from './refund-rejected-create-recovery'
import { verifyRefundOriginalCustomerBinding } from './refund-original-customer-binding'
import { redis, isRedisConfigured } from './redis'
import {
  ensurePaymentOperationLock,
  getRefundCheckpointAuthoritative,
  getRefundCheckpointReadOnly,
  readRefundBlockchainSubmissionClaimState,
  readRefundPreparedSubmitState,
  readRefundBlockchainSubmitAuthorizationState,
  authorizeRefundBlockchainSubmit,
  persistRefundPaymentIdWithAudit,
  refundPreflight,
  beginRefundSubmissionAttempt,
  beginRefundBlockchainSubmissionClaim,
  persistRefundBlockchainTxWithAudit,
  advanceRefundPaymentCheckpointWithAudit,
  advanceRefundAccountingWithAudit,
  advanceRefundAuditWithAudit,
  completeRefundCheckpointWithAudit,
  finalizeRefundProjectionWithAudit,
  claimRefundPiMutationAttempt,
  claimRefundCreateAttempt,
} from './refund-checkpoint-store'
import { isRefundEligible, type Payment, type RefundAuditEvent, type RefundCheckpoint } from './types'
import { reconcileRefundWithPi } from './refund-pi-reconciliation'
import { reconcileIncompleteA2UPayment } from './pi-reconciliation'
import { verifyRefundBlockchainEvidence } from './refund-blockchain-evidence'
import { serverConfig } from './server-config'
import { getDurableU2AIngressAuthoritative, query, readSettlementRefundAuthority } from './db'
import { recordRefundAccounting } from './refund-accounting'
import { acquirePiWalletSubmitLock, acquirePiWalletIntentSubmitLock, claimPiWalletIntent, readPiWalletIntent, releasePiWalletIntent } from './pi-wallet-submit-lock'
import { adoptUnparseableLegacyPaymentProjection, compareAndSwapPaymentProjection } from './payment-projection-cas'
import { classifyDr11OrphanA2UPaymentDto, isDr11OrphanA2UProjectionCandidate } from './refund-dr11-orphan-a2u-recovery-rules'

export type RefundExecutionResult =
  | { outcome: 'ready_for_submission' | 'found'; refundId: string; paymentId: string; amount: number; refundPaymentId?: string }
  | { outcome: 'blocked'; reason: string }

function isRecord(value: unknown): value is Record<string, unknown> { return typeof value === 'object' && value !== null && !Array.isArray(value) }
function paymentFromRedis(value: unknown): Payment | null {
  if (!isRecord(value)) return null
  const id = typeof value.id === 'string' ? value.id : ''
  const payerUid = typeof value.payerUid === 'string' ? value.payerUid : typeof value.payer_uid === 'string' ? value.payer_uid : ''
  const customerAmount = typeof value.customerAmount === 'number' ? value.customerAmount : Number(value.customerAmount ?? value.customer_amount)
  if (!id || !payerUid || !Number.isFinite(customerAmount) || customerAmount <= 0) return null
  return { ...value, id, payerUid, customerAmount, payerUidSource: value.payerUidSource ?? value.payer_uid_source, payerUidCapturedAt: value.payerUidCapturedAt ?? value.payer_uid_captured_at, settlementFailureState: value.settlementFailureState ?? value.settlement_failure_state, refundStatus: value.refundStatus ?? value.refund_status } as Payment
}
function guarded(checkpoint: RefundCheckpoint, payment: Payment): boolean {
  const merchant = payment.a2uTxid || payment.horizonSuccessFlag === true || payment.status === 'settled_to_merchant'
  const refund = payment.refundPaymentId || payment.refundTxid || payment.refundStatus === 'completed'
  return !merchant && !refund && isRefundEligible(payment) && refundPreflight(checkpoint, payment, { paymentId: checkpoint.paymentId, payerUid: checkpoint.payerUid, amount: checkpoint.amount })
}


type RefundPaymentProjectionLoad =
  | { outcome: 'FOUND'; payment: Payment; rebuilt: boolean }
  | { outcome: 'BLOCKED'; reason: string }

function refundProjectionMatchesCheckpoint(payment: Payment, checkpoint: RefundCheckpoint): boolean {
  if (payment.id !== checkpoint.paymentId || payment.payerUid !== checkpoint.payerUid || payment.customerAmount !== checkpoint.amount) return false
  if (payment.a2uPaymentId || payment.a2uTxid || payment.horizonSuccessFlag === true || payment.status === 'settled_to_merchant') return false
  return true
}

async function verifyOriginalU2AForRefundRecovery(checkpoint: RefundCheckpoint): Promise<{
  paymentId: string; merchantId: string; merchantUid: string; customerAmount: number; u2aIdentifier: string; u2aTxid: string;
  payerUid: string; createdAt: string; verifiedAt: string; completedAt: string
} | null> {
  if (!serverConfig.isPiApiKeyConfigured || !serverConfig.piApiKey) return null
  if (checkpoint.sourcePaymentStatus !== 'settlement_failed' || checkpoint.sourceSettlementState !== 'refund_pending') return null
  const authority = await readSettlementRefundAuthority(checkpoint.paymentId)
  if (authority.outcome !== 'CLEAR' || authority.settlementActive || !authority.refundActive) return null
  const durable = await getDurableU2AIngressAuthoritative(checkpoint.paymentId)
  if (durable.outcome !== 'FOUND') return null
  const completedAt = durable.checkpoint.completedAt
  if (completedAt === null) return null
  const d = durable.checkpoint
  if (d.paymentId !== checkpoint.paymentId || d.payerUid !== checkpoint.payerUid || d.customerAmount !== checkpoint.amount) return null
  let response: Response
  try {
    response = await fetch(`https://api.minepi.com/v2/payments/${encodeURIComponent(d.u2aIdentifier)}`, {
      method: 'GET',
      headers: { Authorization: `Key ${serverConfig.piApiKey}`, Accept: 'application/json' },
      cache: 'no-store',
      redirect: 'error',
    })
  } catch { return null }
  if (!response.ok) return null
  const raw: unknown = await response.json().catch(() => null)
  if (!isRecord(raw)) return null
  const dto = raw
  const metadata = isRecord(dto.metadata) ? dto.metadata : null
  const transaction = isRecord(dto.transaction) ? dto.transaction : null
  const status = isRecord(dto.status) ? dto.status : null
  if (
    dto.identifier !== d.u2aIdentifier || dto.direction !== 'user_to_app' || dto.amount !== d.customerAmount || dto.user_uid !== d.payerUid ||
    metadata?.paymentId !== checkpoint.paymentId || transaction?.txid !== d.u2aTxid || transaction?.verified !== true ||
    status?.developer_approved !== true || status?.transaction_verified !== true || status?.developer_completed !== true ||
    status?.cancelled === true || status?.user_cancelled === true
  ) return null
  return { ...d, completedAt }
}

async function neutralizeDr11OrphanA2UIdentifier(checkpoint: RefundCheckpoint, payment: Payment): Promise<boolean> {
  if (!serverConfig.isPiApiKeyConfigured || !serverConfig.piApiKey || !isDr11OrphanA2UProjectionCandidate(checkpoint, payment) || typeof payment.a2uPaymentId !== 'string' || typeof payment.merchantUid !== 'string') return false
  const expected = { paymentId: checkpoint.paymentId, a2uPaymentId: payment.a2uPaymentId, merchantUid: payment.merchantUid, amount: checkpoint.amount }
  const readExact = async (): Promise<unknown | null> => {
    try {
      const response = await fetch(`https://api.minepi.com/v2/payments/${encodeURIComponent(expected.a2uPaymentId)}`, {
        method: 'GET', headers: { Authorization: `Key ${serverConfig.piApiKey}`, Accept: 'application/json' }, cache: 'no-store', redirect: 'error',
      })
      if (!response.ok) return null
      return await response.json().catch(() => null)
    } catch { return null }
  }
  const before = await readExact()
  const beforeState = classifyDr11OrphanA2UPaymentDto(before, expected)
  if (beforeState === 'BLOCKED') return false
  if (beforeState === 'CANCELLED_UNMOVED') return true
  const cancelAttempt = await claimRefundPiMutationAttempt({ kind: 'dr11_a2u_cancel', refundId: checkpoint.refundId, paymentId: checkpoint.paymentId, externalPaymentId: expected.a2uPaymentId })
  if (cancelAttempt.outcome !== 'RECORDED') return false
  let cancelResponse: Response | null = null
  try {
    cancelResponse = await fetch(`https://api.minepi.com/v2/payments/${encodeURIComponent(expected.a2uPaymentId)}/cancel`, {
      method: 'POST', headers: { Authorization: `Key ${serverConfig.piApiKey}`, 'Content-Type': 'application/json' }, redirect: 'error',
    })
  } catch { return false }
  if (!cancelResponse.ok) return false
  const after = await readExact()
  return classifyDr11OrphanA2UPaymentDto(after, expected) === 'CANCELLED_UNMOVED'
}

async function loadRefundPaymentProjection(checkpoint: RefundCheckpoint): Promise<RefundPaymentProjectionLoad> {
  const rawExisting = await redis.get(`payment:${checkpoint.paymentId}`)
  const existing = paymentFromRedis(rawExisting)
  if (existing && refundProjectionMatchesCheckpoint(existing, checkpoint) && !(checkpoint.stage === 'intent_created' && checkpoint.status === 'pending' && !guarded(checkpoint, existing))) {
    const binding = await verifyRefundOriginalCustomerBinding({ paymentId: checkpoint.paymentId, payerUid: checkpoint.payerUid, amount: checkpoint.amount, merchantId: existing.merchantId, merchantUid: existing.merchantUid })
    if (binding.outcome !== 'VERIFIED') return { outcome: 'BLOCKED', reason: 'original_customer_binding_unverified' }
    return { outcome: 'FOUND', payment: existing, rebuilt: false }
  }

  // DR67: Redis is projection-only. Repair a stale pre-refund projection only
  // when it is still the same payment key, contains no merchant/refund/Horizon
  // movement evidence, and the durable U2A + canonical Pi + PostgreSQL refund
  // authority are independently re-proven below. Identity/amount are rebuilt from
  // that durable authority; any financial evidence or terminal state fails closed.
  // DR69: legacy Redis JSON may preserve absent optional pre-submit fields as
  // explicit null. Null is absence, not prepared-A2U evidence. Non-null values
  // remain fail-closed because a prepared hash/sequence/XDR can represent a
  // merchant-settlement intent even before Horizon movement exists.
  const noPreparedA2UEvidence = existing !== null &&
    existing.a2uPreparedTxHash == null &&
    existing.a2uPreparedSequence == null &&
    existing.a2uPreparedEnvelopeXdr == null
  const stalePreRefundProjection = existing !== null &&
    existing.id === checkpoint.paymentId &&
    (existing.status === 'settlement_failed' || existing.status === 'refund_pending') &&
    existing.settlementFailureState === 'refund_pending' && existing.refundStatus === 'pending' &&
    !existing.a2uPaymentId && !existing.a2uTxid && noPreparedA2UEvidence &&
    existing.horizonSuccessFlag !== true && !existing.refundPaymentId && !existing.refundTxid &&
    checkpoint.status === 'pending' && checkpoint.stage === 'intent_created' && !checkpoint.refundPaymentId && !checkpoint.refundTxid
  const dr11OrphanA2UProjection = existing !== null && isDr11OrphanA2UProjectionCandidate(checkpoint, existing)
  if (existing && !stalePreRefundProjection && !dr11OrphanA2UProjection) {
    console.warn('[DR69 REFUND SOURCE PROJECTION CONFLICT]', {
      paymentId: checkpoint.paymentId,
      refundId: checkpoint.refundId,
      status: existing.status,
      settlementFailureState: existing.settlementFailureState ?? null,
      refundStatus: existing.refundStatus ?? null,
      hasA2UPaymentId: !!existing.a2uPaymentId,
      hasA2UTxid: !!existing.a2uTxid,
      hasPreparedTxHash: existing.a2uPreparedTxHash != null,
      hasPreparedSequence: existing.a2uPreparedSequence != null,
      hasPreparedEnvelopeXdr: existing.a2uPreparedEnvelopeXdr != null,
      horizonSuccess: existing.horizonSuccessFlag === true,
      hasRefundPaymentId: !!existing.refundPaymentId,
      hasRefundTxid: !!existing.refundTxid,
    })
    return { outcome: 'BLOCKED', reason: 'projection_conflict' }
  }

  const durable = await verifyOriginalU2AForRefundRecovery(checkpoint)
  if (!durable) return { outcome: 'BLOCKED', reason: 'durable_projection_unproven' }
  if (dr11OrphanA2UProjection && existing) {
    const neutralized = await neutralizeDr11OrphanA2UIdentifier(checkpoint, existing)
    if (!neutralized) return { outcome: 'BLOCKED', reason: 'dr11_orphan_a2u_unproven' }
    console.warn('[DR71 DR11 ORPHAN A2U CANCELLED]', { paymentId: checkpoint.paymentId, refundId: checkpoint.refundId, financialMovementAccepted: false })
  }

  let refundPaymentVerified = false
  if (checkpoint.refundTxid !== undefined) {
    if (typeof checkpoint.refundPaymentId !== 'string' || checkpoint.refundPaymentId.length === 0 || !/^[0-9a-f]{64}$/.test(checkpoint.refundTxid)) return { outcome: 'BLOCKED', reason: 'refund_evidence_invalid' }
    const refund = await reconcileRefundWithPi({ paymentId: checkpoint.paymentId, refundId: checkpoint.refundId, idempotencyKey: checkpoint.idempotencyKey, payerUid: checkpoint.payerUid, amount: checkpoint.amount, refundPaymentId: checkpoint.refundPaymentId })
    if (refund.outcome !== 'FOUND' || !refund.payment || refund.payment.identifier !== checkpoint.refundPaymentId || refund.payment.status.cancelled || refund.payment.status.user_cancelled) return { outcome: 'BLOCKED', reason: 'refund_evidence_unproven' }
    const evidence = await verifyRefundBlockchainEvidence({ checkpoint, payment: refund.payment })
    if (evidence.outcome !== 'VERIFIED_TX' || evidence.txid !== checkpoint.refundTxid) return { outcome: 'BLOCKED', reason: 'refund_evidence_unproven' }
    refundPaymentVerified = true
  }

  const refundProjected = refundPaymentVerified && ['payment_checkpoint_updated', 'accounting_recorded', 'audit_recorded'].includes(checkpoint.stage)
  const projection: Payment = {
    id: durable.paymentId,
    merchantId: durable.merchantId,
    merchantUid: durable.merchantUid,
    accessToken: '',
    redisProjectionVersion: 1,
    amount: durable.customerAmount,
    customerAmount: durable.customerAmount,
    note: '',
    status: refundProjected ? 'refund_pending' : 'settlement_failed',
    createdAt: durable.createdAt,
    piPaymentId: durable.u2aIdentifier,
    u2aTxid: durable.u2aTxid,
    payerUid: durable.payerUid,
    payerUidSource: 'verified_u2a',
    payerUidCapturedAt: checkpoint.payerUidVerifiedAt,
    paidAt: durable.completedAt,
    settlementFailureState: 'refund_pending',
    payerRefundEligible: true,
    refundStatus: refundProjected ? 'submitted' : 'pending',
    ...(refundProjected ? { refundPaymentId: checkpoint.refundPaymentId, refundTxid: checkpoint.refundTxid } : {}),
  }
  if (!existing && rawExisting !== null && rawExisting !== undefined) {
    const adopted = await adoptUnparseableLegacyPaymentProjection(checkpoint.paymentId, projection)
    if (adopted.outcome !== 'UPDATED') {
      console.warn('[DR70 UNPARSEABLE LEGACY PROJECTION BLOCKED]', { paymentId: checkpoint.paymentId, refundId: checkpoint.refundId, adoptionOutcome: adopted.outcome })
      return { outcome: 'BLOCKED', reason: adopted.outcome === 'UNAVAILABLE' ? 'projection_uncertain' : 'projection_conflict' }
    }
    const adoptedReadBack = paymentFromRedis(await redis.get(`payment:${checkpoint.paymentId}`))
    if (!adoptedReadBack || !refundProjectionMatchesCheckpoint(adoptedReadBack, checkpoint) || !guarded(checkpoint, adoptedReadBack)) return { outcome: 'BLOCKED', reason: 'projection_conflict' }
    console.warn('[DR70 UNPARSEABLE LEGACY PROJECTION ADOPTED]', { paymentId: checkpoint.paymentId, refundId: checkpoint.refundId, financialEvidenceAccepted: false })
    return { outcome: 'FOUND', payment: adoptedReadBack, rebuilt: true }
  }

  if ((stalePreRefundProjection || dr11OrphanA2UProjection) && existing) {
    const repaired = await compareAndSwapPaymentProjection(checkpoint.paymentId, existing, projection)
    if (repaired.outcome !== 'UPDATED') return { outcome: 'BLOCKED', reason: repaired.outcome === 'CONFLICT' ? 'projection_conflict' : 'projection_uncertain' }
    const repairedReadBack = paymentFromRedis(await redis.get(`payment:${checkpoint.paymentId}`))
    if (!repairedReadBack || !refundProjectionMatchesCheckpoint(repairedReadBack, checkpoint) || !guarded(checkpoint, repairedReadBack)) return { outcome: 'BLOCKED', reason: 'projection_conflict' }
    console.warn('[DR67 REFUND SOURCE PROJECTION REPAIR]', { paymentId: checkpoint.paymentId, refundId: checkpoint.refundId, fromStatus: existing.status, toStatus: 'settlement_failed' })
    return { outcome: 'FOUND', payment: repairedReadBack, rebuilt: true }
  }

  const created = await redis.set(`payment:${checkpoint.paymentId}`, projection, { nx: true })
  const readBack = paymentFromRedis(await redis.get(`payment:${checkpoint.paymentId}`))
  if (!readBack || !refundProjectionMatchesCheckpoint(readBack, checkpoint)) return { outcome: 'BLOCKED', reason: 'projection_conflict' }
  if (created !== 'OK') {
    const expectedRefundProjection = refundProjected
      ? readBack.status === 'refund_pending' && readBack.refundStatus === 'submitted' && readBack.refundPaymentId === checkpoint.refundPaymentId && readBack.refundTxid === checkpoint.refundTxid
      : readBack.status === 'settlement_failed' && readBack.refundStatus === 'pending' && readBack.settlementFailureState === 'refund_pending'
    if (!expectedRefundProjection) return { outcome: 'BLOCKED', reason: 'projection_conflict' }
    return { outcome: 'FOUND', payment: readBack, rebuilt: false }
  }
  console.log('[F2-5 REFUND PROJECTION REBUILD]', { paymentId: checkpoint.paymentId, refundId: checkpoint.refundId, stage: checkpoint.stage, refundPaymentVerified, settlementAuthority: false })
  return { outcome: 'FOUND', payment: readBack, rebuilt: true }
}

export async function executeRefundNextStep(refundId: string, refundAuthority?: { paymentId: string; refundId: string } | null): Promise<RefundExecutionResult> {
  const checkpoint = await getRefundCheckpointAuthoritative(refundId)
  if (!checkpoint || checkpoint.status !== 'pending' && !(checkpoint.stage === 'audit_recorded' && checkpoint.status === 'completed')) return { outcome: 'blocked', reason: 'invalid_stage' }
  const ids = ['wallet_submission_confirmed', 'payment_checkpoint_updated', 'accounting_recorded', 'audit_recorded'].includes(checkpoint.stage)
    ? typeof checkpoint.refundPaymentId === 'string' && checkpoint.refundPaymentId.length > 0 && typeof checkpoint.refundTxid === 'string' && checkpoint.refundTxid.length > 0
    : true
  if (!ids) return { outcome: 'blocked', reason: 'invalid_stage' }
  if (checkpoint.stage === 'intent_created' && checkpoint.status === 'pending' && !checkpoint.refundPaymentId && !checkpoint.refundTxid) return executeRefundCreation(refundId)
  if (checkpoint.stage === 'wallet_submission_started' && checkpoint.status === 'pending' && !checkpoint.refundTxid) return checkpoint.refundPaymentId ? executeRefundBlockchain(refundId, refundAuthority) : executeRefundCreation(refundId, refundAuthority)
  if (checkpoint.stage === 'wallet_submission_confirmed' && checkpoint.status === 'pending') return executeRefundCompletion(refundId)
  if (checkpoint.stage === 'payment_checkpoint_updated' && checkpoint.status === 'pending') return executeRefundAccounting(refundId)
  if (checkpoint.stage === 'accounting_recorded' && checkpoint.status === 'pending') return executeRefundAudit(refundId)
  if (checkpoint.stage === 'audit_recorded' && checkpoint.status === 'pending') return executeRefundCheckpointCompletion(refundId)
  if (checkpoint.stage === 'audit_recorded' && checkpoint.status === 'completed') return executeRefundFinalProjection(refundId)
  return { outcome: 'blocked', reason: 'invalid_stage' }
}

export async function executeRefundCreation(refundId: string, refundAuthority?: { paymentId: string; refundId: string } | null): Promise<RefundExecutionResult> {
  if (!isRedisConfigured || !serverConfig.piApiKey) return { outcome: 'blocked', reason: 'unavailable' }
  let checkpoint = await getRefundCheckpointAuthoritative(refundId)
  if (!checkpoint) return { outcome: 'blocked', reason: 'not_found' }
  const firstProjection = await loadRefundPaymentProjection(checkpoint)
  if (firstProjection.outcome !== 'FOUND' || (checkpoint.stage === 'intent_created' && !guarded(checkpoint, firstProjection.payment))) return { outcome: 'blocked', reason: firstProjection.outcome === 'BLOCKED' ? firstProjection.reason : 'preflight_failed' }
  if (checkpoint.stage !== 'intent_created' && checkpoint.stage !== 'wallet_submission_started') return { outcome: 'blocked', reason: 'invalid_stage' }
  if (!await ensurePaymentOperationLock(checkpoint.paymentId, checkpoint.refundId)) return { outcome: 'blocked', reason: 'lock_conflict' }
  checkpoint = await getRefundCheckpointAuthoritative(refundId) as typeof checkpoint
  if (!checkpoint) return { outcome: 'blocked', reason: 'preflight_failed' }
  const loadedPayment = await loadRefundPaymentProjection(checkpoint)
  if (loadedPayment.outcome !== 'FOUND') return { outcome: 'blocked', reason: loadedPayment.reason }
  const payment = loadedPayment.payment
  const merchantEvidence = payment.a2uTxid || payment.horizonSuccessFlag === true || payment.status === 'settled_to_merchant'
  const refundEvidence = payment.refundTxid || payment.refundStatus === 'completed'
  if (checkpoint.stage === 'intent_created' && (!guarded(checkpoint, payment) || merchantEvidence || refundEvidence)) return { outcome: 'blocked', reason: 'preflight_failed' }
  if (checkpoint.stage === 'wallet_submission_started' && (checkpoint.status !== 'pending' || checkpoint.paymentId !== payment.id || checkpoint.payerUid !== payment.payerUid || checkpoint.amount !== payment.customerAmount || merchantEvidence || refundEvidence)) return { outcome: 'blocked', reason: 'preflight_failed' }
  const reconciliation = await reconcileRefundWithPi({ paymentId: checkpoint.paymentId, refundId, idempotencyKey: checkpoint.idempotencyKey, payerUid: checkpoint.payerUid, amount: checkpoint.amount, refundPaymentId: checkpoint.refundPaymentId })
  if (reconciliation.outcome === 'INDETERMINATE') return { outcome: 'blocked', reason: 'reconciliation_uncertain' }
  if ((await verifyRefundOriginalCustomerBinding({ paymentId: checkpoint.paymentId, payerUid: checkpoint.payerUid, amount: checkpoint.amount })).outcome !== 'VERIFIED') return { outcome: 'blocked', reason: 'original_customer_binding_unverified' }
  if (reconciliation.outcome === 'FOUND' && reconciliation.payment) {
    if (reconciliation.payment.status.cancelled || reconciliation.payment.status.user_cancelled) return { outcome: 'blocked', reason: 'refund_cancelled' }
    if (checkpoint.refundPaymentId && checkpoint.refundPaymentId !== reconciliation.payment.identifier) return { outcome: 'blocked', reason: 'refund_id_conflict' }
    if (checkpoint.stage === 'intent_created') {
      const event: RefundAuditEvent = { eventId: crypto.randomUUID(), refundId, paymentId: checkpoint.paymentId, eventType: 'refund_submission_started', actorType: 'system', idempotencyKey: checkpoint.idempotencyKey, createdAt: new Date().toISOString(), details: { phase: 'recovered_before_create' } }
      const attempt = await beginRefundSubmissionAttempt(refundId, event)
      if (!attempt) return { outcome: 'blocked', reason: 'attempt_conflict' }
      if (!attempt.startedNow) {
        const latest = await getRefundCheckpointAuthoritative(refundId)
        if (!latest || latest.stage !== 'wallet_submission_started' || latest.status !== 'pending') return { outcome: 'blocked', reason: 'attempt_conflict' }
        const recoveryProjection = await loadRefundPaymentProjection(latest)
        if (recoveryProjection.outcome !== 'FOUND') return { outcome: 'blocked', reason: recoveryProjection.reason }
        const recoveryPayment = recoveryProjection.payment
        const recoveryMerchantEvidence = recoveryPayment.a2uPaymentId || recoveryPayment.a2uTxid || recoveryPayment.horizonSuccessFlag === true || recoveryPayment.status === 'settled_to_merchant'
        const recoveryRefundEvidence = recoveryPayment.refundPaymentId || recoveryPayment.refundTxid || recoveryPayment.refundStatus === 'completed'
        if (latest.paymentId !== recoveryPayment.id || latest.payerUid !== recoveryPayment.payerUid || latest.amount !== recoveryPayment.customerAmount || recoveryMerchantEvidence || recoveryRefundEvidence) return { outcome: 'blocked', reason: 'attempt_conflict' }
        const recovery = await reconcileRefundWithPi({ paymentId: latest.paymentId, refundId, idempotencyKey: latest.idempotencyKey, payerUid: latest.payerUid, amount: latest.amount, refundPaymentId: latest.refundPaymentId })
        if (recovery.outcome !== 'FOUND' || !recovery.payment || recovery.payment.status.cancelled || recovery.payment.status.user_cancelled) return { outcome: 'blocked', reason: recovery.payment?.status.cancelled || recovery.payment?.status.user_cancelled ? 'refund_cancelled' : 'attempt_conflict' }
        checkpoint = latest
        if (checkpoint.refundPaymentId && checkpoint.refundPaymentId !== recovery.payment.identifier) return { outcome: 'blocked', reason: 'refund_id_conflict' }
        const persisted = await persistRefundPaymentIdWithAudit(refundId, checkpoint.paymentId, checkpoint.idempotencyKey, recovery.payment.identifier, { eventId: crypto.randomUUID(), refundId, paymentId: checkpoint.paymentId, eventType: 'refund_payment_identified', actorType: 'system', idempotencyKey: checkpoint.idempotencyKey, createdAt: new Date().toISOString(), details: { refundPaymentId: recovery.payment.identifier, recovered: true } })
        return persisted ? { outcome: 'found', refundId, paymentId: checkpoint.paymentId, amount: checkpoint.amount, refundPaymentId: recovery.payment.identifier } : { outcome: 'blocked', reason: 'refund_id_persistence_conflict' }
      }
      checkpoint = attempt.checkpoint
    }
    if (!checkpoint.refundPaymentId) {
      const persisted = await persistRefundPaymentIdWithAudit(refundId, checkpoint.paymentId, checkpoint.idempotencyKey, reconciliation.payment.identifier, { eventId: crypto.randomUUID(), refundId, paymentId: checkpoint.paymentId, eventType: 'refund_payment_identified', actorType: 'system', idempotencyKey: checkpoint.idempotencyKey, createdAt: new Date().toISOString(), details: { refundPaymentId: reconciliation.payment.identifier, recovered: true } })
      if (!persisted) return { outcome: 'blocked', reason: 'refund_id_persistence_conflict' }
    }
    return { outcome: 'found', refundId, paymentId: checkpoint.paymentId, amount: checkpoint.amount, refundPaymentId: reconciliation.payment.identifier }
  }
  if (checkpoint.stage === 'wallet_submission_started' && (checkpoint.refundPaymentId || checkpoint.refundTxid)) return { outcome: 'blocked', reason: 'submission_outcome_uncertain' }
  // Check app-wide provider readiness before consuming create authority. An
  // empty list alone never re-arms an already consumed attempt.
  if (await readPiA2UQueueAdmission() !== 'EMPTY') return { outcome: 'blocked', reason: 'refund_provider_queue_held' }
  if (checkpoint.stage !== 'wallet_submission_started' && checkpoint.stage !== 'intent_created') return { outcome: 'blocked', reason: 'invalid_stage' }
  if (checkpoint.stage === 'intent_created') {
    const event: RefundAuditEvent = { eventId: crypto.randomUUID(), refundId, paymentId: checkpoint.paymentId, eventType: 'refund_submission_started', actorType: 'system', idempotencyKey: checkpoint.idempotencyKey, createdAt: new Date().toISOString(), details: { phase: 'refund_create' } }
    const attempt = await beginRefundSubmissionAttempt(refundId, event)
    if (!attempt || !attempt.startedNow) return { outcome: 'blocked', reason: 'attempt_conflict' }
    checkpoint = attempt.checkpoint
  }
  const createAttempt = await claimRefundCreateAttempt({ refundId, paymentId: checkpoint.paymentId, idempotencyKey: checkpoint.idempotencyKey })
  if (createAttempt.outcome !== 'RECORDED') {
    if (createAttempt.outcome !== 'REPLAYED' || !await claimRejectedRefundCreateRecovery({refundId,paymentId:checkpoint.paymentId,idempotencyKey:checkpoint.idempotencyKey}))
      return { outcome: 'blocked', reason: createAttempt.outcome === 'INDETERMINATE' ? 'refund_create_attempt_uncertain' : 'refund_create_reconcile_only' }
  }
  const response = await fetch('https://api.minepi.com/v2/payments', { method: 'POST', headers: { Authorization: `Key ${serverConfig.piApiKey}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ payment: { amount: checkpoint.amount, memo: `FlashPay refund for ${checkpoint.paymentId}`, metadata: { type: 'refund', paymentId: checkpoint.paymentId, refundId: checkpoint.refundId, idempotencyKey: checkpoint.idempotencyKey }, uid: checkpoint.payerUid } }) }).catch(() => null)
  console.warn('[refunds/executor] POST /v2/payments:', { refundId, stage: checkpoint.stage, responsePresent: response !== null, status: response?.status ?? null, ok: response?.ok ?? false, body: await response?.clone().json().catch(() => null) })
  const reconcileAfterUncertainty = async (): Promise<RefundExecutionResult> => {
    const recovered = await reconcileRefundWithPi({ paymentId: checkpoint.paymentId, refundId, idempotencyKey: checkpoint.idempotencyKey, payerUid: checkpoint.payerUid, amount: checkpoint.amount, refundPaymentId: checkpoint.refundPaymentId })
    console.warn('[refunds/executor] reconcileAfterUncertainty:', { outcome: recovered.outcome, payment: recovered.payment })
    if (recovered.outcome !== 'FOUND' || !recovered.payment || recovered.payment.status.cancelled || recovered.payment.status.user_cancelled) return { outcome: 'blocked', reason: recovered.payment?.status.cancelled || recovered.payment?.status.user_cancelled ? 'refund_cancelled' : 'refund_create_uncertain' }
    if (checkpoint.refundPaymentId && checkpoint.refundPaymentId !== recovered.payment.identifier) return { outcome: 'blocked', reason: 'refund_id_conflict' }
    const persisted = await persistRefundPaymentIdWithAudit(refundId, checkpoint.paymentId, checkpoint.idempotencyKey, recovered.payment.identifier, { eventId: crypto.randomUUID(), refundId, paymentId: checkpoint.paymentId, eventType: 'refund_payment_identified', actorType: 'system', idempotencyKey: checkpoint.idempotencyKey, createdAt: new Date().toISOString(), details: { refundPaymentId: recovered.payment.identifier, recovered: true } })
    return persisted ? { outcome: 'found', refundId, paymentId: checkpoint.paymentId, amount: checkpoint.amount, refundPaymentId: recovered.payment.identifier } : { outcome: 'blocked', reason: 'refund_id_persistence_conflict' }
  }
  if (!response || !response.ok) return reconcileAfterUncertainty()
  const body: unknown = await response.json().catch(() => null)
  if (!isRecord(body) || typeof body.identifier !== 'string') return reconcileAfterUncertainty()
  const verified = await reconcileRefundWithPi({ paymentId: checkpoint.paymentId, refundId, idempotencyKey: checkpoint.idempotencyKey, payerUid: checkpoint.payerUid, amount: checkpoint.amount, refundPaymentId: body.identifier })
  console.warn('[refunds/executor] verified reconciliation:', { outcome: verified.outcome, payment: verified.payment })
  if (verified.outcome !== 'FOUND' || !verified.payment || verified.payment.identifier !== body.identifier) return { outcome: 'blocked', reason: 'refund_create_uncertain' }
  if (verified.payment.status.cancelled || verified.payment.status.user_cancelled) return { outcome: 'blocked', reason: 'refund_cancelled' }
  const persisted = await persistRefundPaymentIdWithAudit(refundId, checkpoint.paymentId, checkpoint.idempotencyKey, body.identifier, { eventId: crypto.randomUUID(), refundId, paymentId: checkpoint.paymentId, eventType: 'refund_payment_identified', actorType: 'system', idempotencyKey: checkpoint.idempotencyKey, createdAt: new Date().toISOString(), details: { refundPaymentId: body.identifier } })
  if (!persisted) return { outcome: 'blocked', reason: 'refund_id_persistence_conflict' }
  return { outcome: 'found', refundId, paymentId: checkpoint.paymentId, amount: checkpoint.amount, refundPaymentId: body.identifier }
}

export async function readRefundPreparedReplayUnderExistingOwner(refundId: string, refundAuthority?: { paymentId: string; refundId: string } | null) {
  const blocked: Awaited<ReturnType<typeof import('./refund-blockchain-submit').evaluateRefundPreparedReplayPreGate>> = { outcome: 'BLOCKED', prepared: null, observedSourceSequence: null, reference: null, moneyMovementProven: false, authorizesFinancialAction: false }
  try {
    const initial = await getRefundCheckpointReadOnly(refundId)
    if (initial.state !== 'present' || initial.checkpoint.stage !== 'wallet_submission_started' || initial.checkpoint.status !== 'pending' || typeof initial.checkpoint.refundPaymentId !== 'string' || !initial.checkpoint.refundPaymentId) return blocked
    const refund = await reconcileRefundWithPi({ paymentId: initial.checkpoint.paymentId, refundId, idempotencyKey: initial.checkpoint.idempotencyKey, payerUid: initial.checkpoint.payerUid, amount: initial.checkpoint.amount, refundPaymentId: initial.checkpoint.refundPaymentId })
    if (refund.outcome !== 'FOUND' || !refund.payment || refund.payment.identifier !== initial.checkpoint.refundPaymentId || refund.payment.status.cancelled || refund.payment.status.user_cancelled) return blocked
    const walletLock = await acquirePiWalletSubmitLock(refund.payment.from_address)
    if (!walletLock) return blocked
    try {
      const lockedCheckpoint = await getRefundCheckpointReadOnly(refundId)
      const lockedRefund = await reconcileRefundWithPi({ paymentId: initial.checkpoint.paymentId, refundId, idempotencyKey: initial.checkpoint.idempotencyKey, payerUid: initial.checkpoint.payerUid, amount: initial.checkpoint.amount, refundPaymentId: initial.checkpoint.refundPaymentId })
      const claim = await readRefundBlockchainSubmissionClaimState(refundId, initial.checkpoint.paymentId, initial.checkpoint.idempotencyKey, initial.checkpoint.refundPaymentId)
      const prepared = await readRefundPreparedSubmitState(refundId, initial.checkpoint.paymentId, initial.checkpoint.idempotencyKey, initial.checkpoint.refundPaymentId)
      if (lockedCheckpoint.state !== 'present' || lockedCheckpoint.checkpoint.stage !== 'wallet_submission_started' || lockedCheckpoint.checkpoint.status !== 'pending' || claim.state !== 'present' || prepared.state !== 'present' || lockedRefund.outcome !== 'FOUND' || !lockedRefund.payment || lockedRefund.payment.identifier !== initial.checkpoint.refundPaymentId || lockedRefund.payment.from_address !== refund.payment.from_address || lockedRefund.payment.to_address !== refund.payment.to_address || lockedRefund.payment.amount !== refund.payment.amount || lockedRefund.payment.status.cancelled || lockedRefund.payment.status.user_cancelled) return blocked
      const submit = await import('./refund-blockchain-submit')
      const evidence = await submit.readRefundPreparedRecoveryEvidence({ checkpoint: prepared.checkpoint, payment: lockedRefund.payment })
      if (evidence.outcome === 'VERIFIED') return evidence
      if (evidence.outcome !== 'PREPARED_IS_NEXT') return blocked
      const lockedRawSource = await redis.get(`flashpay:payment:operation:${initial.checkpoint.paymentId}`)
      if (lockedRawSource !== refundId) return blocked
      const rawPayment = await redis.get(`payment:${initial.checkpoint.paymentId}`)
      if (!isRecord(rawPayment) || rawPayment.payerUid !== undefined && rawPayment.payerUid !== initial.checkpoint.payerUid || rawPayment.payer_uid !== undefined && rawPayment.payer_uid !== initial.checkpoint.payerUid || rawPayment.customerAmount !== undefined && rawPayment.customerAmount !== initial.checkpoint.amount || rawPayment.customer_amount !== undefined && rawPayment.customer_amount !== initial.checkpoint.amount || rawPayment.payerUidSource !== undefined && rawPayment.payer_uid_source !== undefined && rawPayment.payerUidSource !== rawPayment.payer_uid_source || rawPayment.payerUidCapturedAt !== undefined && rawPayment.payer_uid_captured_at !== undefined && rawPayment.payerUidCapturedAt !== rawPayment.payer_uid_captured_at || rawPayment.settlementFailureState !== undefined && rawPayment.settlement_failure_state !== undefined && rawPayment.settlementFailureState !== rawPayment.settlement_failure_state || rawPayment.refundStatus !== undefined && rawPayment.refund_status !== undefined && rawPayment.refundStatus !== rawPayment.refund_status || rawPayment.a2uPaymentId !== undefined && rawPayment.a2u_payment_id !== undefined && rawPayment.a2uPaymentId !== rawPayment.a2u_payment_id || rawPayment.a2uTxid !== undefined && rawPayment.a2u_txid !== undefined && rawPayment.a2uTxid !== rawPayment.a2u_txid || rawPayment.a2uPreparedTxHash !== undefined && rawPayment.a2u_prepared_tx_hash !== undefined && rawPayment.a2uPreparedTxHash !== rawPayment.a2u_prepared_tx_hash || rawPayment.a2uPreparedSequence !== undefined && rawPayment.a2u_prepared_sequence !== undefined && rawPayment.a2uPreparedSequence !== rawPayment.a2u_prepared_sequence || rawPayment.a2uPreparedEnvelopeXdr !== undefined && rawPayment.a2u_prepared_envelope_xdr !== undefined && rawPayment.a2uPreparedEnvelopeXdr !== rawPayment.a2u_prepared_envelope_xdr || rawPayment.refundPaymentId !== undefined && rawPayment.refund_payment_id !== undefined && rawPayment.refundPaymentId !== rawPayment.refund_payment_id || rawPayment.refundTxid !== undefined && rawPayment.refund_txid !== undefined && rawPayment.refundTxid !== rawPayment.refund_txid || rawPayment.merchantUid !== undefined && rawPayment.merchant_uid !== undefined && rawPayment.merchantUid !== rawPayment.merchant_uid || rawPayment.payerRefundEligible !== undefined && rawPayment.payer_refund_eligible !== undefined && rawPayment.payerRefundEligible !== rawPayment.payer_refund_eligible || rawPayment.a2uPaymentId !== undefined || rawPayment.a2u_payment_id !== undefined || rawPayment.a2uTxid !== undefined || rawPayment.a2u_txid !== undefined || rawPayment.a2uPreparedTxHash !== undefined || rawPayment.a2u_prepared_tx_hash !== undefined || rawPayment.a2uPreparedSequence !== undefined || rawPayment.a2u_prepared_sequence !== undefined || rawPayment.a2uPreparedEnvelopeXdr !== undefined || rawPayment.a2u_prepared_envelope_xdr !== undefined || rawPayment.refundPaymentId !== undefined || rawPayment.refund_payment_id !== undefined || rawPayment.refundTxid !== undefined || rawPayment.refund_txid !== undefined || (rawPayment.horizonSuccessFlag !== undefined && rawPayment.horizonSuccessFlag !== false) || (rawPayment.horizon_success_flag !== undefined && rawPayment.horizon_success_flag !== false)) return blocked
      const lockedSourcePayment = paymentFromRedis(rawPayment)
      if (lockedSourcePayment === null || typeof lockedSourcePayment.merchantUid !== "string" || lockedSourcePayment.merchantUid.length === 0 || lockedSourcePayment.merchantUid !== lockedSourcePayment.merchantUid.trim() || typeof lockedSourcePayment.customerAmount !== 'number' || !Number.isFinite(lockedSourcePayment.customerAmount) || lockedSourcePayment.customerAmount <= 0 || lockedSourcePayment.id !== initial.checkpoint.paymentId || lockedSourcePayment.payerUid !== initial.checkpoint.payerUid || lockedSourcePayment.customerAmount !== initial.checkpoint.amount || lockedSourcePayment.status !== 'settlement_failed' || lockedSourcePayment.settlementFailureState !== 'refund_pending' || lockedSourcePayment.a2uPaymentId || lockedSourcePayment.a2uTxid || lockedSourcePayment.a2uPreparedTxHash || lockedSourcePayment.a2uPreparedSequence || lockedSourcePayment.a2uPreparedEnvelopeXdr || lockedSourcePayment.refundPaymentId || lockedSourcePayment.refundTxid || lockedSourcePayment.horizonSuccessFlag === true || lockedSourcePayment.refundStatus === 'completed' || !isRefundEligible(lockedSourcePayment)) return blocked
      const lockedA2u = await reconcileIncompleteA2UPayment(lockedSourcePayment.id, lockedSourcePayment.customerAmount, lockedSourcePayment.merchantUid, lockedRefund.payment)
      if (lockedA2u.outcome !== 'CONFIRMED_NONE') return blocked
      const gate = submit.evaluateRefundPreparedReplayPreGate({ sourcePayment: lockedSourcePayment, payment: lockedRefund.payment, prepared, evidence })
      if (gate.outcome !== 'ELIGIBLE_EXACT_REPLAY') return gate
      if (refundAuthority !== undefined && (refundAuthority === null || refundAuthority.paymentId !== initial.checkpoint.paymentId || refundAuthority.refundId !== refundId)) return blocked
      // DR54: total Redis loss may erase the refund wallet-owner projection while the
      // PostgreSQL claim/prepared evidence survives. Reconstruct only under the source-wallet
      // submit lock and only after the exact durable/Pi/Horizon/A2U-absence gate above passes.
      const currentWalletIntent = await readPiWalletIntent(lockedRefund.payment.from_address)
      if (currentWalletIntent.state === 'unavailable') return blocked
      if (currentWalletIntent.state === 'absent') {
        const reconstructed = await claimPiWalletIntent(lockedRefund.payment.from_address, { kind: 'refund_claim', paymentId: initial.checkpoint.paymentId, refundId })
        if (!reconstructed) return blocked
      } else if (currentWalletIntent.owner.kind !== 'refund_claim' || currentWalletIntent.owner.paymentId !== initial.checkpoint.paymentId || currentWalletIntent.owner.refundId !== refundId) return blocked
      const reconstructedWalletIntent = await readPiWalletIntent(lockedRefund.payment.from_address)
      if (reconstructedWalletIntent.state !== 'present' || reconstructedWalletIntent.owner.kind !== 'refund_claim' || reconstructedWalletIntent.owner.paymentId !== initial.checkpoint.paymentId || reconstructedWalletIntent.owner.refundId !== refundId) return blocked
      const authorization = await readRefundBlockchainSubmitAuthorizationState(refundId, initial.checkpoint.paymentId, initial.checkpoint.idempotencyKey, lockedRefund.payment.identifier, gate.prepared.envelopeXdr, gate.prepared.preparedHash, gate.prepared.preparedSequence)
      if (authorization.state === 'uncertain') return blocked
      if (authorization.state === 'absent') {
        await authorizeRefundBlockchainSubmit(refundId, initial.checkpoint.paymentId, initial.checkpoint.idempotencyKey, lockedRefund.payment.identifier, gate.prepared.envelopeXdr, gate.prepared.preparedHash, gate.prepared.preparedSequence, 'system')
        const rereadAuthorization = await readRefundBlockchainSubmitAuthorizationState(refundId, initial.checkpoint.paymentId, initial.checkpoint.idempotencyKey, lockedRefund.payment.identifier, gate.prepared.envelopeXdr, gate.prepared.preparedHash, gate.prepared.preparedSequence)
        if (rereadAuthorization.state !== 'present') return blocked
        if (process.env.VERCEL_ENV !== "production" && process.env.FLASHPAY_REFUND_CRASH_TEST === "1" && lockedRefund.payment.network === "Pi Testnet" && lockedRefund.payment.amount === 0.1) {
          console.log("[P7 TEST] Refund auth-before-submit 0.10")
          return blocked
        }
      }
      const replay = await submit.submitRefundPreparedStoredXdrOnce({ payment: lockedRefund.payment, gate, verifyOwned: walletLock.verifyOwned })
      return replay
    } finally {
      await walletLock.release()
    }
  } catch {
    return blocked
  }
}

export async function executeRefundBlockchain(refundId: string, refundAuthority?: { paymentId: string; refundId: string } | null, mode: 'execute' | 'evidence_only' = 'execute'): Promise<RefundExecutionResult> {
  if(mode!=='execute'&&mode!=='evidence_only')return {outcome:'blocked',reason:'invalid_stage'}
  if(mode==='evidence_only'&&currentRecoveryRight())return {outcome:'blocked',reason:'preflight_failed'}
  if (!isRedisConfigured || !serverConfig.piApiKey) return { outcome: 'blocked', reason: 'unavailable' }
  let checkpoint = await getRefundCheckpointAuthoritative(refundId)
  if (!checkpoint || checkpoint.stage !== 'wallet_submission_started' || checkpoint.status !== 'pending' || !checkpoint.refundPaymentId) return { outcome: 'blocked', reason: 'invalid_stage' }
  const scopedRight=currentRecoveryRight()
  if(scopedRight && (scopedRight.kind!=='refund' || scopedRight.id!==checkpoint.paymentId ||
    scopedRight.op!==refundId || refundAuthority?.paymentId!==scopedRight.id || refundAuthority.refundId!==refundId))
    return {outcome:'blocked',reason:'preflight_failed'}
  if (!await ensurePaymentOperationLock(checkpoint.paymentId, checkpoint.refundId)) return { outcome: 'blocked', reason: 'lock_conflict' }
  checkpoint = await getRefundCheckpointAuthoritative(refundId)
  if (!checkpoint) return { outcome: 'blocked', reason: 'preflight_failed' }
  const loadedPayment = await loadRefundPaymentProjection(checkpoint)
  if (loadedPayment.outcome !== 'FOUND') return { outcome: 'blocked', reason: loadedPayment.reason }
  const payment = loadedPayment.payment
  const merchant = payment.a2uPaymentId || payment.a2uTxid || payment.horizonSuccessFlag === true || payment.status === 'settled_to_merchant'
  const refund = payment.refundPaymentId || payment.refundTxid || payment.refundStatus === 'completed'
  if (checkpoint.stage !== 'wallet_submission_started' || checkpoint.status !== 'pending' || checkpoint.refundPaymentId === undefined || checkpoint.paymentId !== payment.id || checkpoint.payerUid !== payment.payerUid || checkpoint.amount !== payment.customerAmount || merchant || refund) return { outcome: 'blocked', reason: 'preflight_failed' }
  const refundPaymentId = checkpoint.refundPaymentId
  const reconciliation = await reconcileRefundWithPi({ paymentId: checkpoint.paymentId, refundId, idempotencyKey: checkpoint.idempotencyKey, payerUid: checkpoint.payerUid, amount: checkpoint.amount, refundPaymentId: checkpoint.refundPaymentId })
  if (reconciliation.outcome === 'INDETERMINATE' || !reconciliation.payment) return { outcome: 'blocked', reason: 'reconciliation_uncertain' }
  const refundPayment = reconciliation.payment
  if (refundPayment.status.cancelled || refundPayment.status.user_cancelled) return { outcome: 'blocked', reason: 'refund_cancelled' }
  const persistRecoveredConfirmation = async (txid: string): Promise<RefundExecutionResult> => {
    const persisted = await persistRefundBlockchainTxWithAudit(refundId, checkpoint.paymentId, checkpoint.idempotencyKey, refundPaymentId, txid, { eventId: crypto.randomUUID(), refundId, paymentId: checkpoint.paymentId, eventType: 'refund_submission_confirmed', actorType: 'system', idempotencyKey: checkpoint.idempotencyKey, createdAt: new Date().toISOString(), details: { refundPaymentId, refundTxid: txid, recovered: true } })
    if (!persisted) return { outcome: 'blocked', reason: 'tx_persistence_conflict' }
    const walletIntent = await readPiWalletIntent(refundPayment.from_address)
    if (walletIntent.state === 'unavailable') return { outcome: 'blocked', reason: 'lock_conflict' }
    if (walletIntent.state === 'present' && walletIntent.owner.paymentId === checkpoint.paymentId && (walletIntent.owner.kind !== 'refund_claim' || walletIntent.owner.refundId !== refundId)) return { outcome: 'blocked', reason: 'lock_conflict' }
    if (walletIntent.state === 'present' && walletIntent.owner.paymentId === checkpoint.paymentId) {
      const cleanupLock = await acquirePiWalletSubmitLock(refundPayment.from_address)
      if (!cleanupLock) return { outcome: 'blocked', reason: 'lock_conflict' }
      try {
        const lockedIntent = await readPiWalletIntent(refundPayment.from_address)
        if (lockedIntent.state === 'unavailable') return { outcome: 'blocked', reason: 'lock_conflict' }
        if (lockedIntent.state === 'present' && lockedIntent.owner.paymentId === checkpoint.paymentId && (lockedIntent.owner.kind !== 'refund_claim' || lockedIntent.owner.refundId !== refundId)) return { outcome: 'blocked', reason: 'lock_conflict' }
        if (lockedIntent.state === 'present' && lockedIntent.owner.paymentId === checkpoint.paymentId && !await releasePiWalletIntent(refundPayment.from_address, lockedIntent.owner)) return { outcome: 'blocked', reason: 'lock_conflict' }
      } finally {
        await cleanupLock.release()
      }
    }
    return { outcome: 'found', refundId, paymentId: checkpoint.paymentId, amount: checkpoint.amount, refundPaymentId }
  }
  const evidence = await import('./refund-blockchain-evidence').then(({ verifyRefundBlockchainEvidence }) => verifyRefundBlockchainEvidence({ checkpoint, payment: refundPayment }))
  if (evidence.outcome === 'VERIFIED_TX') return mode==='evidence_only'?{outcome:'blocked',reason:'already_confirmed'}:persistRecoveredConfirmation(evidence.txid)
  const claim = await readRefundBlockchainSubmissionClaimState(refundId, checkpoint.paymentId, checkpoint.idempotencyKey, refundPaymentId)
  if (claim.state === 'uncertain') return { outcome: 'blocked', reason: 'blockchain_uncertain' }
  const prepared = claim.state === 'present' ? await readRefundPreparedSubmitState(refundId, checkpoint.paymentId, checkpoint.idempotencyKey, refundPaymentId) : null
  if (prepared?.state === 'uncertain') return { outcome: 'blocked', reason: 'blockchain_uncertain' }
  if (prepared?.state === 'present') {
    if(mode==='evidence_only')return {outcome:'blocked',reason:'already_prepared'}
    const preparedEvidence = await import('./refund-blockchain-submit').then(({ readRefundPreparedRecoveryEvidence }) => readRefundPreparedRecoveryEvidence({ checkpoint: prepared.checkpoint, payment: refundPayment }))
    if (preparedEvidence.outcome === 'VERIFIED') return persistRecoveredConfirmation(prepared.preparedHash)
    if (preparedEvidence.outcome !== 'PREPARED_IS_NEXT') return { outcome: 'blocked', reason: 'blockchain_uncertain' }
    const preparedAuthorityMismatch = refundAuthority !== undefined && (refundAuthority === null || refundAuthority.paymentId !== checkpoint.paymentId || refundAuthority.refundId !== refundId)
    if (preparedAuthorityMismatch) return { outcome: 'blocked', reason: 'wallet_drain_not_selected' }
    const replay = await readRefundPreparedReplayUnderExistingOwner(refundId, refundAuthority)
    if (replay.outcome === 'VERIFIED' && replay.moneyMovementProven === true && replay.authorizesFinancialAction === false && replay.reference?.preparedHash === prepared.preparedHash && replay.reference?.preparedSequence === prepared.preparedSequence && replay.reference?.refundPaymentId === refundPaymentId && replay.reference?.fromAddress === refundPayment.from_address && replay.reference?.toAddress === refundPayment.to_address && replay.reference?.amount === refundPayment.amount) return persistRecoveredConfirmation(prepared.preparedHash)
    if (replay.outcome === 'CONFIRMED_TX') {
      if (replay.txid !== prepared.preparedHash) return { outcome: 'blocked', reason: 'blockchain_uncertain' }
      const replayEvidence = await import('./refund-blockchain-submit').then(({ readRefundPreparedRecoveryEvidence }) => readRefundPreparedRecoveryEvidence({ checkpoint: prepared.checkpoint, payment: refundPayment }))
      if (replayEvidence.outcome !== 'VERIFIED' || replayEvidence.moneyMovementProven !== true || replayEvidence.authorizesFinancialAction !== false || replayEvidence.reference?.preparedHash !== prepared.preparedHash || replayEvidence.reference?.preparedSequence !== prepared.preparedSequence || replayEvidence.reference?.refundPaymentId !== refundPayment.identifier || replayEvidence.reference?.fromAddress !== refundPayment.from_address || replayEvidence.reference?.toAddress !== refundPayment.to_address || replayEvidence.reference?.amount !== refundPayment.amount) return { outcome: 'blocked', reason: 'blockchain_uncertain' }
      return persistRecoveredConfirmation(replay.txid)
    }
    return { outcome: 'blocked', reason: 'blockchain_uncertain' }
  }
  if (evidence.outcome === 'INDETERMINATE') return { outcome: 'blocked', reason: 'blockchain_uncertain' }
  const freshAuthorityMismatch = refundAuthority !== undefined && (refundAuthority === null || refundAuthority.paymentId !== checkpoint.paymentId || refundAuthority.refundId !== refundId)
  if (freshAuthorityMismatch) return { outcome: 'blocked', reason: 'wallet_drain_not_selected' }
  const walletLock = await acquirePiWalletIntentSubmitLock(refundPayment.from_address, { kind: 'refund_claim', paymentId: checkpoint.paymentId, refundId })
  if (!walletLock) return { outcome: 'blocked', reason: 'lock_conflict' }
  try {
    const claim = await beginRefundBlockchainSubmissionClaim(refundId, checkpoint.paymentId, checkpoint.idempotencyKey, checkpoint.refundPaymentId)
    if (!claim) return { outcome: 'blocked', reason: 'blockchain_claim_conflict' }
    const submission = await import('./refund-blockchain-submit').then(({ submitRefundBlockchainOnce }) => submitRefundBlockchainOnce({ checkpoint: claim.checkpoint, payment: refundPayment, verifyOwned: walletLock.verifyOwned },mode))
    if(submission.outcome==='EVIDENCE_PREPARED')return {outcome:'blocked',reason:'prepared_evidence_only'}
    if (submission.outcome !== 'CONFIRMED_TX') {
      if (submission.code === 'submit_failed') return { outcome: 'blocked', reason: submission.code }
      const failureIntent = await readPiWalletIntent(refundPayment.from_address)
      if (failureIntent.state === 'unavailable') return { outcome: 'blocked', reason: 'lock_conflict' }
      if (failureIntent.state === 'present' && failureIntent.owner.paymentId === checkpoint.paymentId && (failureIntent.owner.kind !== 'refund_claim' || failureIntent.owner.refundId !== refundId)) return { outcome: 'blocked', reason: 'lock_conflict' }
      if (failureIntent.state === 'present' && failureIntent.owner.paymentId === checkpoint.paymentId && !await releasePiWalletIntent(refundPayment.from_address, failureIntent.owner)) return { outcome: 'blocked', reason: 'lock_conflict' }
      return { outcome: 'blocked', reason: submission.code }
    }
    const persisted = await persistRefundBlockchainTxWithAudit(refundId, checkpoint.paymentId, checkpoint.idempotencyKey, checkpoint.refundPaymentId, submission.txid, { eventId: crypto.randomUUID(), refundId, paymentId: checkpoint.paymentId, eventType: 'refund_submission_confirmed', actorType: 'system', idempotencyKey: checkpoint.idempotencyKey, createdAt: new Date().toISOString(), details: { refundPaymentId: checkpoint.refundPaymentId, refundTxid: submission.txid } })
    if (!persisted) return { outcome: 'blocked', reason: 'tx_persistence_conflict' }
    const postSubmitIntent = await readPiWalletIntent(refundPayment.from_address)
    if (postSubmitIntent.state === 'unavailable') return { outcome: 'blocked', reason: 'lock_conflict' }
    if (postSubmitIntent.state === 'present' && postSubmitIntent.owner.paymentId === checkpoint.paymentId && (postSubmitIntent.owner.kind !== 'refund_claim' || postSubmitIntent.owner.refundId !== refundId)) return { outcome: 'blocked', reason: 'lock_conflict' }
    if (postSubmitIntent.state === 'present' && postSubmitIntent.owner.paymentId === checkpoint.paymentId && !await releasePiWalletIntent(refundPayment.from_address, postSubmitIntent.owner)) return { outcome: 'blocked', reason: 'lock_conflict' }
    return { outcome: 'found', refundId, paymentId: checkpoint.paymentId, amount: checkpoint.amount, refundPaymentId: checkpoint.refundPaymentId }
  } finally {
    await walletLock.release()
  }
}

export async function executeRefundAccounting(refundId: string): Promise<RefundExecutionResult> {
  let initial = await getRefundCheckpointAuthoritative(refundId)
  if (!initial || (initial.stage !== 'payment_checkpoint_updated' && initial.stage !== 'accounting_recorded') || initial.status !== 'pending' || typeof initial.refundPaymentId !== 'string' || initial.refundPaymentId.length === 0 || typeof initial.refundTxid !== 'string' || initial.refundTxid.length === 0) return { outcome: 'blocked', reason: 'invalid_stage' }
  if (!await ensurePaymentOperationLock(initial.paymentId, initial.refundId)) return { outcome: 'blocked', reason: 'lock_conflict' }
  const checkpoint = await getRefundCheckpointAuthoritative(refundId)
  if (!checkpoint || checkpoint.paymentId !== initial.paymentId || checkpoint.idempotencyKey !== initial.idempotencyKey || checkpoint.payerUid !== initial.payerUid || checkpoint.amount !== initial.amount || checkpoint.refundPaymentId !== initial.refundPaymentId || checkpoint.refundTxid !== initial.refundTxid || (checkpoint.stage !== 'payment_checkpoint_updated' && checkpoint.stage !== 'accounting_recorded') || checkpoint.status !== 'pending' || typeof checkpoint.refundPaymentId !== 'string' || checkpoint.refundPaymentId.length === 0 || typeof checkpoint.refundTxid !== 'string' || checkpoint.refundTxid.length === 0) return { outcome: 'blocked', reason: 'invalid_stage' }
  const refundPaymentId = checkpoint.refundPaymentId
  const refundTxid = checkpoint.refundTxid

  const loadedPayment = await loadRefundPaymentProjection(checkpoint)
  if (loadedPayment.outcome !== 'FOUND') return { outcome: 'blocked', reason: loadedPayment.reason }
  const payment = loadedPayment.payment
  if (payment.id !== checkpoint.paymentId || payment.payerUid !== checkpoint.payerUid || payment.customerAmount !== checkpoint.amount || payment.refundPaymentId !== refundPaymentId || payment.refundTxid !== refundTxid || payment.status !== 'refund_pending' || payment.refundStatus !== 'submitted' || payment.settlementFailureState !== 'refund_pending') return { outcome: 'blocked', reason: 'payment_conflict' }
  if (checkpoint.stage === 'payment_checkpoint_updated') {
    const accounting = await recordRefundAccounting(refundId)
    if (accounting.outcome === 'CONFLICT') return { outcome: 'blocked', reason: 'accounting_conflict' }
    if (accounting.outcome === 'INDETERMINATE') return { outcome: 'blocked', reason: 'accounting_uncertain' }
  }
  let rows: unknown
  try {
    rows = await query(`
      SELECT refund_id, payment_id, refund_payment_id, refund_txid, payer_uid, currency,
        amount = $5::numeric AS exact_amount, horizon_fee_stroops::text AS fee_text
      FROM refund_accounting_records
      WHERE refund_id=$1 OR payment_id=$2 OR refund_payment_id=$3 OR refund_txid=$4`,
      [refundId, checkpoint.paymentId, refundPaymentId, refundTxid, checkpoint.amount])
  } catch { return { outcome: 'blocked', reason: 'accounting_uncertain' } }
  if (!Array.isArray(rows) || rows.length !== 1) return { outcome: 'blocked', reason: 'accounting_uncertain' }
  const row = isRecord(rows[0]) ? rows[0] : null
  if (!row || row.refund_id !== refundId || row.payment_id !== checkpoint.paymentId || row.refund_payment_id !== refundPaymentId || row.refund_txid !== refundTxid || row.payer_uid !== checkpoint.payerUid || row.currency !== 'π' || row.exact_amount !== true || typeof row.fee_text !== 'string' || !/^\d+$/.test(row.fee_text)) return { outcome: 'blocked', reason: 'accounting_uncertain' }
  const fee = Number(row.fee_text)
  if (!Number.isSafeInteger(fee) || fee < 0) return { outcome: 'blocked', reason: 'accounting_uncertain' }
  const advanced = await advanceRefundAccountingWithAudit(refundId, checkpoint.paymentId, checkpoint.idempotencyKey, refundPaymentId, refundTxid, checkpoint.payerUid, checkpoint.amount, fee, { eventId: crypto.randomUUID(), refundId, paymentId: checkpoint.paymentId, eventType: 'refund_accounting_recorded', actorType: 'system', idempotencyKey: checkpoint.idempotencyKey, createdAt: new Date().toISOString(), details: { refundPaymentId, refundTxid, horizonFeeStroops: fee } })
  return advanced ? { outcome: 'found', refundId, paymentId: checkpoint.paymentId, amount: checkpoint.amount, refundPaymentId } : { outcome: 'blocked', reason: 'accounting_checkpoint_conflict' }
}

export async function executeRefundAudit(refundId: string): Promise<RefundExecutionResult> {
  const initial = await getRefundCheckpointAuthoritative(refundId)
  if (!initial || (initial.stage !== 'accounting_recorded' && initial.stage !== 'audit_recorded') || initial.status !== 'pending' || typeof initial.refundPaymentId !== 'string' || initial.refundPaymentId.length === 0 || typeof initial.refundTxid !== 'string' || initial.refundTxid.length === 0) return { outcome: 'blocked', reason: 'invalid_stage' }
  if (!await ensurePaymentOperationLock(initial.paymentId, initial.refundId)) return { outcome: 'blocked', reason: 'lock_conflict' }
  const checkpoint = await getRefundCheckpointAuthoritative(refundId)
  if (!checkpoint || checkpoint.paymentId !== initial.paymentId || checkpoint.idempotencyKey !== initial.idempotencyKey || checkpoint.payerUid !== initial.payerUid || checkpoint.amount !== initial.amount || checkpoint.refundPaymentId !== initial.refundPaymentId || checkpoint.refundTxid !== initial.refundTxid || (checkpoint.stage !== 'accounting_recorded' && checkpoint.stage !== 'audit_recorded') || checkpoint.status !== 'pending') return { outcome: 'blocked', reason: 'invalid_stage' }
  const rows = await query(`SELECT refund_id,payment_id,refund_payment_id,refund_txid,payer_uid,currency,amount=$5::numeric AS exact_amount,horizon_fee_stroops::text AS fee_text FROM refund_accounting_records WHERE refund_id=$1 OR payment_id=$2 OR refund_payment_id=$3 OR refund_txid=$4`, [refundId, checkpoint.paymentId, checkpoint.refundPaymentId, checkpoint.refundTxid, checkpoint.amount])
  if (!Array.isArray(rows) || rows.length !== 1) return { outcome: 'blocked', reason: 'audit_uncertain' }
  const row = isRecord(rows[0]) ? rows[0] : null
  if (!row || row.refund_id !== refundId || row.payment_id !== checkpoint.paymentId || row.refund_payment_id !== checkpoint.refundPaymentId || row.refund_txid !== checkpoint.refundTxid || row.payer_uid !== checkpoint.payerUid || row.currency !== 'π' || row.exact_amount !== true || typeof row.fee_text !== 'string' || !/^\d+$/.test(row.fee_text)) return { outcome: 'blocked', reason: 'audit_uncertain' }
  const fee = Number(row.fee_text)
  if (!Number.isSafeInteger(fee) || fee < 0) return { outcome: 'blocked', reason: 'audit_uncertain' }
  const sealed = await advanceRefundAuditWithAudit(refundId, checkpoint.paymentId, checkpoint.idempotencyKey, checkpoint.refundPaymentId, checkpoint.refundTxid, checkpoint.payerUid, checkpoint.amount, fee, { eventId: crypto.randomUUID(), refundId, paymentId: checkpoint.paymentId, eventType: 'refund_audit_recorded', actorType: 'system', idempotencyKey: checkpoint.idempotencyKey, createdAt: new Date().toISOString(), details: { refundPaymentId: checkpoint.refundPaymentId, refundTxid: checkpoint.refundTxid, horizonFeeStroops: fee } })
  if (!sealed) return { outcome: 'blocked', reason: 'audit_checkpoint_conflict' }
  return { outcome: 'found', refundId, paymentId: checkpoint.paymentId, amount: checkpoint.amount, refundPaymentId: checkpoint.refundPaymentId }
}

export async function executeRefundCheckpointCompletion(refundId: string): Promise<RefundExecutionResult> {
  const initial = await getRefundCheckpointAuthoritative(refundId)
  if (!initial || initial.stage !== 'audit_recorded' || (initial.status !== 'pending' && initial.status !== 'completed') || typeof initial.refundPaymentId !== 'string' || initial.refundPaymentId.length === 0 || typeof initial.refundTxid !== 'string' || initial.refundTxid.length === 0) return { outcome: 'blocked', reason: 'invalid_stage' }
  if (!await ensurePaymentOperationLock(initial.paymentId, initial.refundId)) return { outcome: 'blocked', reason: 'lock_conflict' }
  const checkpoint = await getRefundCheckpointAuthoritative(refundId)
  if (!checkpoint || checkpoint.paymentId !== initial.paymentId || checkpoint.idempotencyKey !== initial.idempotencyKey || checkpoint.payerUid !== initial.payerUid || checkpoint.amount !== initial.amount || checkpoint.refundPaymentId !== initial.refundPaymentId || checkpoint.refundTxid !== initial.refundTxid || checkpoint.stage !== 'audit_recorded' || (checkpoint.status !== 'pending' && checkpoint.status !== 'completed')) return { outcome: 'blocked', reason: 'invalid_stage' }
  const rows = await query(`SELECT refund_id,payment_id,refund_payment_id,refund_txid,payer_uid,currency,amount=$5::numeric AS exact_amount,horizon_fee_stroops::text AS fee_text FROM refund_accounting_records WHERE refund_id=$1 OR payment_id=$2 OR refund_payment_id=$3 OR refund_txid=$4`, [refundId, checkpoint.paymentId, checkpoint.refundPaymentId, checkpoint.refundTxid, checkpoint.amount])
  if (!Array.isArray(rows) || rows.length !== 1) return { outcome: 'blocked', reason: 'completion_uncertain' }
  const row = isRecord(rows[0]) ? rows[0] : null
  if (!row || row.refund_id !== refundId || row.payment_id !== checkpoint.paymentId || row.refund_payment_id !== checkpoint.refundPaymentId || row.refund_txid !== checkpoint.refundTxid || row.payer_uid !== checkpoint.payerUid || row.currency !== 'π' || row.exact_amount !== true || typeof row.fee_text !== 'string' || !/^\d+$/.test(row.fee_text)) return { outcome: 'blocked', reason: 'completion_uncertain' }
  const fee = Number(row.fee_text)
  if (!Number.isSafeInteger(fee) || fee < 0) return { outcome: 'blocked', reason: 'completion_uncertain' }
  const completed = await completeRefundCheckpointWithAudit(refundId, checkpoint.paymentId, checkpoint.idempotencyKey, checkpoint.refundPaymentId, checkpoint.refundTxid, checkpoint.payerUid, checkpoint.amount, fee, { eventId: crypto.randomUUID(), refundId, paymentId: checkpoint.paymentId, eventType: 'refund_completed', actorType: 'system', idempotencyKey: checkpoint.idempotencyKey, createdAt: new Date().toISOString(), details: { refundPaymentId: checkpoint.refundPaymentId, refundTxid: checkpoint.refundTxid, horizonFeeStroops: fee } })
  if (!completed) return { outcome: 'blocked', reason: 'completion_checkpoint_conflict' }
  return { outcome: 'found', refundId, paymentId: checkpoint.paymentId, amount: checkpoint.amount, refundPaymentId: checkpoint.refundPaymentId }
}

export async function executeRefundFinalProjection(refundId: string): Promise<RefundExecutionResult> {
  const initial = await getRefundCheckpointAuthoritative(refundId)
  if (!initial || initial.stage !== 'audit_recorded' || initial.status !== 'completed' || typeof initial.refundPaymentId !== 'string' || initial.refundPaymentId.length === 0 || typeof initial.refundTxid !== 'string' || initial.refundTxid.length === 0) return { outcome: 'blocked', reason: 'invalid_stage' }
  if (!await ensurePaymentOperationLock(initial.paymentId, initial.refundId)) return { outcome: 'blocked', reason: 'lock_conflict' }
  const checkpoint = await getRefundCheckpointAuthoritative(refundId)
  if (!checkpoint || checkpoint.paymentId !== initial.paymentId || checkpoint.idempotencyKey !== initial.idempotencyKey || checkpoint.payerUid !== initial.payerUid || checkpoint.amount !== initial.amount || checkpoint.refundPaymentId !== initial.refundPaymentId || checkpoint.refundTxid !== initial.refundTxid || checkpoint.stage !== 'audit_recorded' || checkpoint.status !== 'completed') return { outcome: 'blocked', reason: 'invalid_stage' }
  const rows = await query(`SELECT refund_id,payment_id,refund_payment_id,refund_txid,payer_uid,currency,amount=$5::numeric AS exact_amount,horizon_fee_stroops::text AS fee_text FROM refund_accounting_records WHERE refund_id=$1 OR payment_id=$2 OR refund_payment_id=$3 OR refund_txid=$4`, [refundId, checkpoint.paymentId, checkpoint.refundPaymentId, checkpoint.refundTxid, checkpoint.amount])
  if (!Array.isArray(rows) || rows.length !== 1) return { outcome: 'blocked', reason: 'projection_uncertain' }
  const row = isRecord(rows[0]) ? rows[0] : null
  if (!row || row.refund_id !== refundId || row.payment_id !== checkpoint.paymentId || row.refund_payment_id !== checkpoint.refundPaymentId || row.refund_txid !== checkpoint.refundTxid || row.payer_uid !== checkpoint.payerUid || row.currency !== 'π' || row.exact_amount !== true || typeof row.fee_text !== 'string' || !/^\d+$/.test(row.fee_text)) return { outcome: 'blocked', reason: 'projection_uncertain' }
  const fee = Number(row.fee_text)
  if (!Number.isSafeInteger(fee) || fee < 0) return { outcome: 'blocked', reason: 'projection_uncertain' }
  const verified = await completeRefundCheckpointWithAudit(refundId, checkpoint.paymentId, checkpoint.idempotencyKey, checkpoint.refundPaymentId, checkpoint.refundTxid, checkpoint.payerUid, checkpoint.amount, fee, { eventId: crypto.randomUUID(), refundId, paymentId: checkpoint.paymentId, eventType: 'refund_completed', actorType: 'system', idempotencyKey: checkpoint.idempotencyKey, createdAt: new Date().toISOString(), details: { refundPaymentId: checkpoint.refundPaymentId, refundTxid: checkpoint.refundTxid, horizonFeeStroops: fee } })
  if (!verified) return { outcome: 'blocked', reason: 'completion_checkpoint_conflict' }
  const loadedPayment = await loadRefundPaymentProjection(checkpoint)
  if (loadedPayment.outcome !== 'FOUND') return { outcome: 'blocked', reason: loadedPayment.reason }
  const payment = loadedPayment.payment
  if (payment.id !== checkpoint.paymentId || payment.payerUid !== checkpoint.payerUid || payment.customerAmount !== checkpoint.amount || payment.status === 'settled_to_merchant' || payment.a2uPaymentId || payment.a2uTxid || payment.horizonSuccessFlag === true) return { outcome: 'blocked', reason: 'projection_conflict' }
  const alreadyFinal = payment.status === 'refunded' && payment.refundStatus === 'completed' && payment.settlementFailureState === 'refunded' && payment.refundPaymentId === checkpoint.refundPaymentId && payment.refundTxid === checkpoint.refundTxid
  if (alreadyFinal) {
    const finalized = await finalizeRefundProjectionWithAudit(refundId, checkpoint.paymentId, checkpoint.idempotencyKey, checkpoint.refundPaymentId, checkpoint.refundTxid, checkpoint.payerUid, checkpoint.amount)
    if (finalized) {
      try {
        await redis.eval<[string], number>("redis.call('SREM',KEYS[1],ARGV[1]); redis.call('ZREM',KEYS[2],ARGV[1]); return 1", ['flashpay:recovery:active-payments:v1', 'flashpay:settlement:ready:v1'], [checkpoint.paymentId])
      } catch (error) {
        console.warn('[refunds/executor] Active recovery index cleanup failed', error)
      }
    }
    return finalized ? { outcome: 'found', refundId, paymentId: checkpoint.paymentId, amount: checkpoint.amount, refundPaymentId: checkpoint.refundPaymentId } : { outcome: 'blocked', reason: 'projection_finality_uncertain' }
  }
  if (payment.status !== 'refund_pending' || payment.refundStatus !== 'submitted' || payment.settlementFailureState !== 'refund_pending' || payment.refundPaymentId !== checkpoint.refundPaymentId || payment.refundTxid !== checkpoint.refundTxid) return { outcome: 'blocked', reason: 'projection_conflict' }
  const projected: Payment = { ...payment, status: 'refunded', refundStatus: 'completed', settlementFailureState: 'refunded' }
  const projectionCas = await compareAndSwapPaymentProjection(checkpoint.paymentId, payment, projected)
  const readBack = projectionCas.outcome === 'UPDATED' ? projectionCas.payment : projectionCas.outcome === 'CONFLICT' ? projectionCas.current : null
  if (!readBack || readBack.status !== 'refunded' || readBack.refundStatus !== 'completed' || readBack.settlementFailureState !== 'refunded' || readBack.refundPaymentId !== checkpoint.refundPaymentId || readBack.refundTxid !== checkpoint.refundTxid) return { outcome: 'blocked', reason: projectionCas.outcome === 'CONFLICT' ? 'projection_conflict' : 'projection_uncertain' }
  const finalized = await finalizeRefundProjectionWithAudit(refundId, checkpoint.paymentId, checkpoint.idempotencyKey, checkpoint.refundPaymentId, checkpoint.refundTxid, checkpoint.payerUid, checkpoint.amount)
  if (finalized) {
    try {
      await redis.eval<[string], number>("redis.call('SREM',KEYS[1],ARGV[1]); redis.call('ZREM',KEYS[2],ARGV[1]); return 1", ['flashpay:recovery:active-payments:v1', 'flashpay:settlement:ready:v1'], [checkpoint.paymentId])
    } catch (error) {
      console.warn('[refunds/executor] Active recovery index cleanup failed', error)
    }
  }
  return finalized ? { outcome: 'found', refundId, paymentId: checkpoint.paymentId, amount: checkpoint.amount, refundPaymentId: checkpoint.refundPaymentId } : { outcome: 'blocked', reason: 'projection_finality_uncertain' }
}

export async function executeRefundCompletion(refundId: string): Promise<RefundExecutionResult> {
  if (!isRedisConfigured || !serverConfig.piApiKey) return { outcome: 'blocked', reason: 'unavailable' }
  let checkpoint = await getRefundCheckpointAuthoritative(refundId)
  if (!checkpoint || (checkpoint.stage !== 'wallet_submission_confirmed' && checkpoint.stage !== 'payment_checkpoint_updated') || checkpoint.status !== 'pending' || typeof checkpoint.refundPaymentId !== 'string' || checkpoint.refundPaymentId.length === 0 || typeof checkpoint.refundTxid !== 'string' || checkpoint.refundTxid.length === 0) return { outcome: 'blocked', reason: 'invalid_stage' }
  if (!await ensurePaymentOperationLock(checkpoint.paymentId, checkpoint.refundId)) return { outcome: 'blocked', reason: 'lock_conflict' }
  checkpoint = await getRefundCheckpointAuthoritative(refundId)
  if (!checkpoint || (checkpoint.stage !== 'wallet_submission_confirmed' && checkpoint.stage !== 'payment_checkpoint_updated') || checkpoint.status !== 'pending' || typeof checkpoint.refundPaymentId !== 'string' || checkpoint.refundPaymentId.length === 0 || typeof checkpoint.refundTxid !== 'string' || checkpoint.refundTxid.length === 0) return { outcome: 'blocked', reason: 'invalid_stage' }
  const refundPaymentId = checkpoint.refundPaymentId
  const refundTxid = checkpoint.refundTxid
  const loadedPayment = await loadRefundPaymentProjection(checkpoint)
  if (loadedPayment.outcome !== 'FOUND') return { outcome: 'blocked', reason: loadedPayment.reason }
  const payment = loadedPayment.payment
  if (checkpoint.stage === 'payment_checkpoint_updated') {
    if (!payment || checkpoint.paymentId !== payment.id || payment.status !== 'refund_pending' || payment.refundStatus !== 'submitted' || payment.settlementFailureState !== 'refund_pending' || payment.refundPaymentId !== refundPaymentId || payment.refundTxid !== refundTxid) return { outcome: 'blocked', reason: 'checkpoint_conflict' }
    return { outcome: 'found', refundId, paymentId: checkpoint.paymentId, amount: checkpoint.amount, refundPaymentId }
  }
  if (!payment || checkpoint.paymentId !== payment.id || checkpoint.payerUid !== payment.payerUid || checkpoint.amount !== payment.customerAmount || (payment.refundPaymentId !== undefined && payment.refundPaymentId !== refundPaymentId) || (payment.refundTxid !== undefined && payment.refundTxid !== refundTxid) || payment.a2uPaymentId || payment.a2uTxid || payment.horizonSuccessFlag === true || payment.status === 'settled_to_merchant' || payment.refundStatus === 'completed') return { outcome: 'blocked', reason: 'preflight_failed' }
  const reconciliation = await reconcileRefundWithPi({ paymentId: checkpoint.paymentId, refundId, idempotencyKey: checkpoint.idempotencyKey, payerUid: checkpoint.payerUid, amount: checkpoint.amount, refundPaymentId })
  if (reconciliation.outcome !== 'FOUND' || !reconciliation.payment || reconciliation.payment.identifier !== refundPaymentId || reconciliation.payment.status.cancelled || reconciliation.payment.status.user_cancelled) return { outcome: 'blocked', reason: 'pi_evidence_uncertain' }
  const blockchainEvidence = await verifyRefundBlockchainEvidence({ checkpoint, payment: reconciliation.payment })
  if (blockchainEvidence.outcome !== 'VERIFIED_TX' || blockchainEvidence.txid !== refundTxid) return { outcome: 'blocked', reason: 'blockchain_evidence_uncertain' }
  const completionIntent = await readPiWalletIntent(reconciliation.payment.from_address)
  if (completionIntent.state === 'unavailable') return { outcome: 'blocked', reason: 'lock_conflict' }
  if (completionIntent.state === 'present' && completionIntent.owner.paymentId === checkpoint.paymentId && (completionIntent.owner.kind !== 'refund_claim' || completionIntent.owner.refundId !== refundId)) return { outcome: 'blocked', reason: 'lock_conflict' }
  if (completionIntent.state === 'present' && completionIntent.owner.paymentId === checkpoint.paymentId) {
    const completionLock = await acquirePiWalletSubmitLock(reconciliation.payment.from_address)
    if (!completionLock) return { outcome: 'blocked', reason: 'lock_conflict' }
    try {
      const lockedCompletionIntent = await readPiWalletIntent(reconciliation.payment.from_address)
      if (lockedCompletionIntent.state === 'unavailable') return { outcome: 'blocked', reason: 'lock_conflict' }
      if (lockedCompletionIntent.state === 'present' && lockedCompletionIntent.owner.paymentId === checkpoint.paymentId && (lockedCompletionIntent.owner.kind !== 'refund_claim' || lockedCompletionIntent.owner.refundId !== refundId)) return { outcome: 'blocked', reason: 'lock_conflict' }
      if (lockedCompletionIntent.state === 'present' && lockedCompletionIntent.owner.paymentId === checkpoint.paymentId && !await releasePiWalletIntent(reconciliation.payment.from_address, lockedCompletionIntent.owner)) return { outcome: 'blocked', reason: 'lock_conflict' }
    } finally {
      await completionLock.release()
    }
  }
  const needsCompletion = reconciliation.payment.status.developer_completed !== true
  if (needsCompletion) {
    const completionAttempt = await claimRefundPiMutationAttempt({ kind: 'refund_complete', refundId, paymentId: checkpoint.paymentId, externalPaymentId: refundPaymentId, txid: refundTxid })
    if (completionAttempt.outcome !== 'RECORDED') return { outcome: 'blocked', reason: completionAttempt.outcome === 'INDETERMINATE' ? 'completion_attempt_uncertain' : 'completion_reconcile_only' }
    const response = await fetch(`https://api.minepi.com/v2/payments/${encodeURIComponent(refundPaymentId)}/complete`, { method: 'POST', headers: { Authorization: `Key ${serverConfig.piApiKey}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ txid: refundTxid }) }).catch(() => null)
    if (response === null || !response.ok) {
      const recovered = await reconcileRefundWithPi({ paymentId: checkpoint.paymentId, refundId, idempotencyKey: checkpoint.idempotencyKey, payerUid: checkpoint.payerUid, amount: checkpoint.amount, refundPaymentId })
      if (recovered.outcome !== 'FOUND' || !recovered.payment || recovered.payment.identifier !== refundPaymentId || recovered.payment.status.cancelled || recovered.payment.status.user_cancelled || recovered.payment.transaction === null || recovered.payment.transaction.txid !== refundTxid || !recovered.payment.transaction.verified || !recovered.payment.status.transaction_verified || recovered.payment.status.developer_completed !== true) return { outcome: 'blocked', reason: 'completion_uncertain' }
    }
  }
  const confirmed = await reconcileRefundWithPi({ paymentId: checkpoint.paymentId, refundId, idempotencyKey: checkpoint.idempotencyKey, payerUid: checkpoint.payerUid, amount: checkpoint.amount, refundPaymentId })
  if (confirmed.outcome !== 'FOUND' || !confirmed.payment || confirmed.payment.identifier !== refundPaymentId || confirmed.payment.status.cancelled || confirmed.payment.status.user_cancelled || confirmed.payment.transaction === null || confirmed.payment.transaction.txid !== refundTxid || !confirmed.payment.transaction.verified || !confirmed.payment.status.transaction_verified || confirmed.payment.status.developer_completed !== true) return { outcome: 'blocked', reason: 'completion_unverified' }
  const updatedPayment: Payment = { ...payment, status: 'refund_pending', refundStatus: 'submitted', refundPaymentId, refundTxid, settlementFailureState: 'refund_pending' }
  const projectionCas = await compareAndSwapPaymentProjection(payment.id, payment, updatedPayment)
  const persistedPayment = projectionCas.outcome === 'UPDATED' ? projectionCas.payment : projectionCas.outcome === 'CONFLICT' ? projectionCas.current : null
  if (!persistedPayment || persistedPayment.id !== payment.id || persistedPayment.status !== 'refund_pending' || persistedPayment.refundStatus !== 'submitted' || persistedPayment.settlementFailureState !== 'refund_pending' || persistedPayment.refundPaymentId !== refundPaymentId || persistedPayment.refundTxid !== refundTxid) return { outcome: 'blocked', reason: projectionCas.outcome === 'CONFLICT' ? 'projection_conflict' : 'projection_uncertain' }
  const advanced = await advanceRefundPaymentCheckpointWithAudit(refundId, checkpoint.paymentId, checkpoint.idempotencyKey, refundPaymentId, refundTxid, { eventId: crypto.randomUUID(), refundId, paymentId: checkpoint.paymentId, eventType: 'refund_payment_checkpoint_updated', actorType: 'system', idempotencyKey: checkpoint.idempotencyKey, createdAt: new Date().toISOString(), details: { refundPaymentId, refundTxid } })
  if (!advanced) return { outcome: 'blocked', reason: 'checkpoint_conflict' }
  return { outcome: 'found', refundId, paymentId: checkpoint.paymentId, amount: checkpoint.amount, refundPaymentId }
}

export async function prepareRefundExecution(refundId: string): Promise<RefundExecutionResult> {
  if (!isRedisConfigured || !refundId) return { outcome: 'blocked', reason: 'unavailable' }
  const checkpoint = await getRefundCheckpointAuthoritative(refundId)
  if (!checkpoint) return { outcome: 'blocked', reason: 'not_found' }
  const loadedPayment = await loadRefundPaymentProjection(checkpoint)
  if (loadedPayment.outcome !== 'FOUND' || !guarded(checkpoint, loadedPayment.payment)) return { outcome: 'blocked', reason: loadedPayment.outcome === 'BLOCKED' ? loadedPayment.reason : 'preflight_failed' }
  const payment = loadedPayment.payment
  if (!await ensurePaymentOperationLock(checkpoint.paymentId, checkpoint.refundId)) return { outcome: 'blocked', reason: 'lock_conflict' }
  const reloaded = await getRefundCheckpointAuthoritative(refundId)
  if (!reloaded || reloaded.stage !== 'intent_created' || reloaded.status !== 'pending') return { outcome: 'blocked', reason: 'preflight_failed' }
  const finalProjection = await loadRefundPaymentProjection(reloaded)
  if (finalProjection.outcome !== 'FOUND' || !guarded(reloaded, finalProjection.payment)) return { outcome: 'blocked', reason: finalProjection.outcome === 'BLOCKED' ? finalProjection.reason : 'preflight_failed' }
  return { outcome: 'ready_for_submission', refundId: reloaded.refundId, paymentId: reloaded.paymentId, amount: reloaded.amount }
}
