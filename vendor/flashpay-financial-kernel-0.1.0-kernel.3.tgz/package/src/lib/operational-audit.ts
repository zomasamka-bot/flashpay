import "server-only"

import { randomUUID } from "crypto"
import { redis, isRedisConfigured } from "./redis"

export const OPERATIONAL_AUDIT_KEY = "flashpay:operations:audit:v1"
export const OPERATIONAL_AUDIT_MAX_EVENTS = 500

export type OperationalAuditAction = "control.enable" | "control.disable" | "control.reset" | "domain.enable" | "domain.disable" | "domain.master_unlock" | "domain.master_lock"

export interface OperationalAuditEvent {
  eventId: string
  action: OperationalAuditAction
  actorUid: string
  requestId: string
  createdAt: number
  previousRevision: number
  resultingRevision: number
  previousEnabled: boolean
  resultingEnabled: boolean
  reason: string
}

function safeReason(value: unknown): string {
  if (typeof value !== "string") return ""
  return value.trim().slice(0, 240)
}


export function createOperationalAuditEvent(input: Omit<OperationalAuditEvent, "eventId" | "createdAt" | "reason"> & { reason?: unknown }): OperationalAuditEvent {
  return {
    ...input,
    eventId: randomUUID(),
    createdAt: Date.now(),
    reason: safeReason(input.reason),
  }
}

export async function appendOperationalAuditEvent(input: Omit<OperationalAuditEvent, "eventId" | "createdAt" | "reason"> & { reason?: unknown }): Promise<void> {
  if (!isRedisConfigured) throw new Error("Operational audit Redis is not configured")

  const event = createOperationalAuditEvent(input)

  // Append-only bounded operational history. No financial identifiers, tokens, XDR or secrets.
  await redis.lpush(OPERATIONAL_AUDIT_KEY, JSON.stringify(event))
  await redis.ltrim(OPERATIONAL_AUDIT_KEY, 0, OPERATIONAL_AUDIT_MAX_EVENTS - 1)
}


export async function appendOperationalQueueAuditEvent(input: { actorUid: string; requestId: string; paymentId: string; action: "queue.prune_terminal" | "queue.dismiss_reviewed"; reason: string }): Promise<void> {
  if (!isRedisConfigured) throw new Error("Operational audit Redis is not configured")
  const event = {
    eventId: randomUUID(),
    action: input.action,
    actorUid: input.actorUid,
    requestId: input.requestId,
    paymentId: input.paymentId,
    createdAt: Date.now(),
    reason: safeReason(input.reason),
  }
  await redis.lpush(OPERATIONAL_AUDIT_KEY, JSON.stringify(event))
  await redis.ltrim(OPERATIONAL_AUDIT_KEY, 0, OPERATIONAL_AUDIT_MAX_EVENTS - 1)
}
