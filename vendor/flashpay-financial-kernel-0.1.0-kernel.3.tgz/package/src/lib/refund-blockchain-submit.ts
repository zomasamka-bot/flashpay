import { prepareR36EvidenceCandidate } from "./r36-prepared-evidence"
import { getPiSigningSeed } from "./pi-wallet-signing-config"
import { r36PreparedEvidenceStore } from "./r36-prepared-evidence-store"
import { verifyRefundOriginalCustomerBinding } from './refund-original-customer-binding'
import { verifyPreparedWalletAuthority, claimFirstWalletSubmission } from "./financial-wallet-authority"
import "server-only"

import {
  Asset,
  Horizon,
  Memo,
  Keypair,
  Operation,
  Transaction,
  TransactionBuilder,
  TimeoutInfinite,
} from "@stellar/stellar-sdk"
import type { RefundCheckpoint } from "./types"
import { isRefundEligible, type Payment } from "./types"
import type { RefundPiPayment } from "./refund-pi-reconciliation"
import type { SettlementSubmitHorizonReadResult } from "./financial-recovery-settlement-submit-horizon-reader"
import { readSettlementSubmitHorizonEvidence } from "./financial-recovery-settlement-submit-horizon-reader"
import { authorizeRefundBlockchainSubmit, ensureRefundPreparedSubmit, readRefundPreparedSubmit, readRefundPreparedSubmitState, readRefundBlockchainSubmitAuthorizationState } from "./refund-checkpoint-store"
import { readPiWalletIntent } from "./pi-wallet-submit-lock"
import { classifyRefundPreparedSequence, evaluateRefundPreparedHorizonBinding } from "./refund-blockchain-evidence"
import { exactPositiveStroopsToStellarAmount, exactStroopAmountMatch, numberToExactPositiveStroops } from "./financial-amount-stroops"

export type RefundBlockchainSubmitResult =
  | { outcome: "CONFIRMED_TX"; txid: string }
  | { outcome: "FAILED"; code: "invalid_input" | "configuration" | "source_load_failed" | "build_failed" | "submit_failed"; message: string }

type Input = {
  checkpoint: RefundCheckpoint
  payment: RefundPiPayment
  verifyOwned: () => Promise<boolean>
}

const HORIZON_URL = "https://api.testnet.minepi.com"

type RefundPreparedSubmitXdrInput = {
  envelopeXdr: string
  preparedHash: string
  preparedSequence: string
  refundPaymentId: string
  fromAddress: string
  toAddress: string
  amount: number
}

export function verifyRefundPreparedSubmitXdr(input: RefundPreparedSubmitXdrInput): { outcome: "VERIFIED_INTENT" | "BLOCKED"; reference: RefundPreparedSubmitXdrInput | null; moneyMovementProven: false; authorizesFinancialAction: false } {
  const blocked: { outcome: "BLOCKED"; reference: null; moneyMovementProven: false; authorizesFinancialAction: false } = { outcome: "BLOCKED", reference: null, moneyMovementProven: false, authorizesFinancialAction: false }
  if (!input.envelopeXdr || input.envelopeXdr !== input.envelopeXdr.trim() || !input.preparedHash || !/^[0-9a-f]{64}$/.test(input.preparedHash) || !input.preparedSequence || !/^[1-9][0-9]*$/.test(input.preparedSequence) || !input.refundPaymentId || input.refundPaymentId !== input.refundPaymentId.trim() || !input.fromAddress || input.fromAddress !== input.fromAddress.trim() || !input.toAddress || input.toAddress !== input.toAddress.trim() || !isValidPositiveAmount(input.amount)) return blocked
  try {
    const transaction = TransactionBuilder.fromXDR(input.envelopeXdr, "Pi Testnet")
    if (!(transaction instanceof Transaction) || transaction.toXDR() !== input.envelopeXdr || Buffer.from(transaction.hash()).toString("hex") !== input.preparedHash || transaction.sequence !== input.preparedSequence || transaction.source !== input.fromAddress || transaction.timeBounds?.minTime !== "0" || transaction.timeBounds?.maxTime !== "0" || transaction.signatures.length !== 1 || transaction.operations.length !== 1) return blocked
    const operation = transaction.operations[0]
    if (operation.type !== "payment" || operation.source !== undefined || !operation.asset.isNative() || operation.destination !== input.toAddress || !exactStroopAmountMatch(operation.amount, input.amount)) return blocked
    const memo = transaction.memo
    if (memo.type !== "text") return blocked
    const memoValue: unknown = memo.value
    const expectedMemoBytes = Buffer.from(input.refundPaymentId, "utf8")
    if (typeof memoValue === "string") {
      if (memoValue !== input.refundPaymentId) return blocked
    } else if (memoValue instanceof Uint8Array) {
      if (!Buffer.from(memoValue).equals(expectedMemoBytes)) return blocked
    } else {
      return blocked
    }
    const keypair = Keypair.fromPublicKey(input.fromAddress)
    const signature = transaction.signatures[0]
    if (!Buffer.from(signature.hint.toBytes()).equals(Buffer.from(keypair.signatureHint())) || !keypair.verify(transaction.hash(), signature.signature.toBytes())) return blocked
    return { outcome: "VERIFIED_INTENT", reference: input, moneyMovementProven: false, authorizesFinancialAction: false }
  } catch {
    return blocked
  }
}

function isValidPositiveAmount(value: number): boolean {
  return numberToExactPositiveStroops(value) !== null
}

function isExactInput({ checkpoint, payment }: Pick<Input, "checkpoint" | "payment">): boolean {
  return checkpoint.stage === "wallet_submission_started" && checkpoint.status === "pending" &&
    typeof checkpoint.refundPaymentId === "string" && checkpoint.refundPaymentId === payment.identifier &&
    checkpoint.paymentId === payment.metadata.paymentId && checkpoint.refundId === payment.metadata.refundId &&
    checkpoint.idempotencyKey === payment.metadata.idempotencyKey && checkpoint.payerUid === payment.user_uid &&
    isValidPositiveAmount(checkpoint.amount) && isValidPositiveAmount(payment.amount) && checkpoint.amount === payment.amount &&
    payment.direction === "app_to_user" && payment.network === "Pi Testnet" &&
    payment.metadata.type === "refund" && payment.transaction === null &&
    payment.status.cancelled === false && payment.status.user_cancelled === false &&
    typeof payment.from_address === "string" && payment.from_address.length > 0 &&
    typeof payment.to_address === "string" && payment.to_address.length > 0
}

export function evaluateRefundPreparedRecoveryEvidence(input: { checkpoint: RefundCheckpoint; payment: RefundPiPayment; envelopeXdr: string; preparedHash: string; preparedSequence: string; horizonRead: SettlementSubmitHorizonReadResult }): ReturnType<typeof classifyRefundPreparedSequence> | ReturnType<typeof evaluateRefundPreparedHorizonBinding> {
  if (!isExactInput({ checkpoint: input.checkpoint, payment: input.payment })) return { outcome: "BLOCKED", reference: null, moneyMovementProven: false, authorizesFinancialAction: false }
  const expected = { preparedHash: input.preparedHash, preparedSequence: input.preparedSequence, refundPaymentId: input.payment.identifier, fromAddress: input.payment.from_address, toAddress: input.payment.to_address, amount: input.payment.amount }
  const horizon = evaluateRefundPreparedHorizonBinding(input.horizonRead, expected)
  if (horizon.outcome !== "UNRESOLVED") return horizon
  const xdr = verifyRefundPreparedSubmitXdr({ envelopeXdr: input.envelopeXdr, preparedHash: input.preparedHash, preparedSequence: input.preparedSequence, refundPaymentId: input.payment.identifier, fromAddress: input.payment.from_address, toAddress: input.payment.to_address, amount: input.payment.amount })
  if (xdr.outcome !== "VERIFIED_INTENT") return { outcome: "BLOCKED", reference: null, moneyMovementProven: false, authorizesFinancialAction: false }
  return classifyRefundPreparedSequence(horizon)
}

export async function readRefundPreparedRecoveryEvidence(input: Pick<Input, "checkpoint" | "payment">): Promise<ReturnType<typeof evaluateRefundPreparedRecoveryEvidence>> {
  const blocked: { outcome: "BLOCKED"; reference: null; moneyMovementProven: false; authorizesFinancialAction: false } = { outcome: "BLOCKED", reference: null, moneyMovementProven: false, authorizesFinancialAction: false }
  if (!isExactInput(input)) return blocked
  try {
    const prepared = await readRefundPreparedSubmit(input.checkpoint.refundId, input.checkpoint.paymentId, input.checkpoint.idempotencyKey, input.payment.identifier)
    if (!prepared || !isExactInput({ checkpoint: prepared.checkpoint, payment: input.payment })) return blocked
    const horizonRead = await readSettlementSubmitHorizonEvidence(prepared.preparedHash, prepared.preparedSequence, input.payment.from_address)
    return evaluateRefundPreparedRecoveryEvidence({ checkpoint: prepared.checkpoint, payment: input.payment, envelopeXdr: prepared.envelopeXdr, preparedHash: prepared.preparedHash, preparedSequence: prepared.preparedSequence, horizonRead })
  } catch {
    return blocked
  }
}

export function evaluateRefundPreparedReplayPreGate(input: { sourcePayment: Payment; payment: RefundPiPayment; prepared: Awaited<ReturnType<typeof readRefundPreparedSubmitState>>; evidence: ReturnType<typeof evaluateRefundPreparedRecoveryEvidence> }): { outcome: "ELIGIBLE_EXACT_REPLAY"; prepared: Extract<Awaited<ReturnType<typeof readRefundPreparedSubmitState>>, { state: "present" }>; observedSourceSequence: string; reference: Extract<ReturnType<typeof evaluateRefundPreparedRecoveryEvidence>, { outcome: "PREPARED_IS_NEXT" }>["reference"]; moneyMovementProven: false; authorizesFinancialAction: false } | { outcome: "BLOCKED"; prepared: null; observedSourceSequence: null; reference: null; moneyMovementProven: false; authorizesFinancialAction: false } {
  const blocked: { outcome: "BLOCKED"; prepared: null; observedSourceSequence: null; reference: null; moneyMovementProven: false; authorizesFinancialAction: false } = { outcome: "BLOCKED", prepared: null, observedSourceSequence: null, reference: null, moneyMovementProven: false, authorizesFinancialAction: false }
  if (input.prepared.state !== "present" || !isExactInput({ checkpoint: input.prepared.checkpoint, payment: input.payment }) || input.payment.status.transaction_verified !== false || input.payment.status.developer_completed !== false || input.prepared.checkpoint.sourcePaymentStatus !== "settlement_failed" || input.prepared.checkpoint.sourceSettlementState !== "refund_pending" || input.sourcePayment.id !== input.prepared.checkpoint.paymentId || input.sourcePayment.payerUid !== input.prepared.checkpoint.payerUid || input.sourcePayment.customerAmount !== input.prepared.checkpoint.amount || input.sourcePayment.refundStatus !== "pending" || !isRefundEligible(input.sourcePayment) || input.evidence.outcome !== "PREPARED_IS_NEXT" || input.evidence.reference.preparedHash !== input.prepared.preparedHash || input.evidence.reference.preparedSequence !== input.prepared.preparedSequence || input.evidence.reference.refundPaymentId !== input.payment.identifier || input.evidence.reference.fromAddress !== input.payment.from_address || input.evidence.reference.toAddress !== input.payment.to_address || input.evidence.reference.amount !== input.payment.amount) return blocked
  return { outcome: "ELIGIBLE_EXACT_REPLAY", prepared: input.prepared, observedSourceSequence: input.evidence.observedSourceSequence, reference: input.evidence.reference, moneyMovementProven: false, authorizesFinancialAction: false }
}

export async function submitRefundPreparedStoredXdrOnce(input: { payment: RefundPiPayment; gate: ReturnType<typeof evaluateRefundPreparedReplayPreGate>; verifyOwned: () => Promise<boolean> }): Promise<RefundBlockchainSubmitResult> {
  const blocked: RefundBlockchainSubmitResult = { outcome: "FAILED", code: "invalid_input", message: "Refund transaction is not an eligible exact replay" }
  if (input.gate.outcome !== "ELIGIBLE_EXACT_REPLAY" || input.payment.status.transaction_verified !== false || input.payment.status.developer_completed !== false || input.gate.prepared.state !== "present" || input.gate.reference.preparedHash !== input.gate.prepared.preparedHash || input.gate.reference.preparedSequence !== input.gate.prepared.preparedSequence || input.gate.reference.refundPaymentId !== input.payment.identifier || input.gate.reference.fromAddress !== input.payment.from_address || input.gate.reference.toAddress !== input.payment.to_address || input.gate.reference.amount !== input.payment.amount) return blocked
  try {
    const recovery = await readRefundPreparedRecoveryEvidence({ checkpoint: input.gate.prepared.checkpoint, payment: input.payment })
    if (recovery.outcome === "VERIFIED" && recovery.reference.preparedHash === input.gate.prepared.preparedHash && recovery.reference.preparedSequence === input.gate.prepared.preparedSequence && recovery.reference.refundPaymentId === input.payment.identifier && recovery.reference.fromAddress === input.payment.from_address && recovery.reference.toAddress === input.payment.to_address && recovery.reference.amount === input.payment.amount) return { outcome: "CONFIRMED_TX", txid: input.gate.prepared.preparedHash }
    if (recovery.outcome !== "PREPARED_IS_NEXT" || recovery.observedSourceSequence !== input.gate.observedSourceSequence || recovery.reference.preparedHash !== input.gate.prepared.preparedHash || recovery.reference.preparedSequence !== input.gate.prepared.preparedSequence || recovery.reference.refundPaymentId !== input.payment.identifier || recovery.reference.fromAddress !== input.payment.from_address || recovery.reference.toAddress !== input.payment.to_address || recovery.reference.amount !== input.payment.amount) return { outcome: "FAILED", code: "submit_failed", message: "Refund transaction evidence is not ready" }
    const intent = await readPiWalletIntent(input.payment.from_address)
    if (intent.state !== "present" || intent.owner.kind !== "refund_claim" || intent.owner.refundId !== input.gate.prepared.checkpoint.refundId || intent.owner.paymentId !== input.gate.prepared.checkpoint.paymentId) return blocked
    const authorization = await readRefundBlockchainSubmitAuthorizationState(input.gate.prepared.checkpoint.refundId, input.gate.prepared.checkpoint.paymentId, input.gate.prepared.checkpoint.idempotencyKey, input.payment.identifier, input.gate.prepared.envelopeXdr, input.gate.prepared.preparedHash, input.gate.prepared.preparedSequence)
    if (authorization.state !== "present") return { outcome: "FAILED", code: "submit_failed", message: "Refund transaction authorization is not confirmed" }
    const xdr = verifyRefundPreparedSubmitXdr({ envelopeXdr: input.gate.prepared.envelopeXdr, preparedHash: input.gate.prepared.preparedHash, preparedSequence: input.gate.prepared.preparedSequence, refundPaymentId: input.payment.identifier, fromAddress: input.payment.from_address, toAddress: input.payment.to_address, amount: input.payment.amount })
    if (xdr.outcome !== "VERIFIED_INTENT") return blocked
    const transaction = TransactionBuilder.fromXDR(input.gate.prepared.envelopeXdr, "Pi Testnet")
    if (!(transaction instanceof Transaction) || transaction.toXDR() !== input.gate.prepared.envelopeXdr || Buffer.from(transaction.hash()).toString("hex") !== input.gate.prepared.preparedHash || transaction.sequence !== input.gate.prepared.preparedSequence || transaction.source !== input.payment.from_address) return blocked
    const server = new Horizon.Server(HORIZON_URL)
    if (!await input.verifyOwned()) return { outcome: "FAILED", code: "submit_failed", message: "Refund wallet submit ownership lost" }
    if (!await verifyPreparedWalletAuthority({
      network: 'Pi Testnet', sourceWallet: input.payment.from_address,
      paymentId: input.gate.prepared.checkpoint.paymentId, operationKind: 'refund',
      operationId: input.gate.prepared.checkpoint.refundId,
      preparedHash: input.gate.prepared.preparedHash,
      preparedSequence: input.gate.prepared.preparedSequence,
    })) return { outcome: "FAILED", code: "submit_failed", message: "Durable refund replay authority not proven" }
    if ((await verifyRefundOriginalCustomerBinding({ paymentId: input.gate.prepared.checkpoint.paymentId, payerUid: input.gate.prepared.checkpoint.payerUid, amount: input.gate.prepared.checkpoint.amount })).outcome !== 'VERIFIED') return { outcome: 'FAILED', code: 'submit_failed', message: 'Original customer binding unverified before prepared replay' }
    if (!await claimFirstWalletSubmission({
      network: 'Pi Testnet', sourceWallet: input.payment.from_address,
      paymentId: input.gate.prepared.checkpoint.paymentId, operationKind: 'refund',
      operationId: input.gate.prepared.checkpoint.refundId,
      preparedHash: input.gate.prepared.preparedHash,
      preparedSequence: input.gate.prepared.preparedSequence,
    })) return { outcome: "FAILED", code: "submit_failed", message: "Refund one-shot submission already used or unavailable" }
    await server.submitTransaction(transaction)
    if (process.env.VERCEL_ENV !== "production" && process.env.FLASHPAY_REFUND_CRASH_TEST === "1" && input.payment.network === "Pi Testnet" && input.payment.amount === 0.1) {
      console.log("[P7 TEST] Refund post-replay-submit 0.10")
      return { outcome: "FAILED", code: "submit_failed", message: "P7 refund post-replay-submit test" }
    }
    const after = await readRefundPreparedRecoveryEvidence({ checkpoint: input.gate.prepared.checkpoint, payment: input.payment })
    return after.outcome === "VERIFIED" && after.reference.preparedHash === input.gate.prepared.preparedHash && after.reference.preparedSequence === input.gate.prepared.preparedSequence && after.reference.refundPaymentId === input.payment.identifier && after.reference.fromAddress === input.payment.from_address && after.reference.toAddress === input.payment.to_address && after.reference.amount === input.payment.amount ? { outcome: "CONFIRMED_TX", txid: input.gate.prepared.preparedHash } : { outcome: "FAILED", code: "submit_failed", message: "Refund transaction was not confirmed" }
  } catch (error) {
    try {
      const after = await readRefundPreparedRecoveryEvidence({ checkpoint: input.gate.prepared.checkpoint, payment: input.payment })
      if (after.outcome === "VERIFIED" && after.reference.preparedHash === input.gate.prepared.preparedHash && after.reference.preparedSequence === input.gate.prepared.preparedSequence && after.reference.refundPaymentId === input.payment.identifier && after.reference.fromAddress === input.payment.from_address && after.reference.toAddress === input.payment.to_address && after.reference.amount === input.payment.amount) return { outcome: "CONFIRMED_TX", txid: input.gate.prepared.preparedHash }
    } catch {
      return { outcome: "FAILED", code: "submit_failed", message: error instanceof Error ? error.message : "Refund transaction submission failed" }
    }
    return { outcome: "FAILED", code: "submit_failed", message: error instanceof Error ? error.message : "Refund transaction submission failed" }
  }
}

export async function submitRefundBlockchainOnce(input: Input, mode: "execute" | "evidence_only" = "execute"): Promise<RefundBlockchainSubmitResult | { outcome: "EVIDENCE_PREPARED" }> {
  if (mode !== "execute" && mode !== "evidence_only") return { outcome: "FAILED", code: "invalid_input", message: "Invalid refund preparation mode" }
  if (mode === "evidence_only" && !await input.verifyOwned()) return { outcome: "FAILED", code: "submit_failed", message: "Refund preparation ownership lost" }
  if (!isExactInput(input) || input.payment.status.transaction_verified !== false || input.payment.status.developer_completed !== false) return { outcome: "FAILED", code: "invalid_input", message: "Refund input is not an eligible unsent Testnet refund" }
  const seed = getPiSigningSeed()
  if (!seed) return { outcome: "FAILED", code: "configuration", message: "Refund signing configuration is unavailable" }

  let keypair: Keypair
  try {
    keypair = Keypair.fromSecret(seed)
    if (keypair.publicKey() !== input.payment.from_address) return { outcome: "FAILED", code: "invalid_input", message: "Refund source does not match the configured signer" }
  } catch {
    return { outcome: "FAILED", code: "configuration", message: "Refund signing configuration is invalid" }
  }

  let server: Horizon.Server
  let source: Awaited<ReturnType<Horizon.Server["loadAccount"]>>
  let baseFee: Awaited<ReturnType<Horizon.Server["fetchBaseFee"]>>
  try {
    server = new Horizon.Server(HORIZON_URL)
    source = await server.loadAccount(input.payment.from_address)
    baseFee = await server.fetchBaseFee()
  } catch (error) {
    return { outcome: "FAILED", code: "source_load_failed", message: error instanceof Error ? error.message : "Refund source loading failed" }
  }

  const refundAmountStroops = numberToExactPositiveStroops(input.payment.amount)
  const refundStellarAmount = refundAmountStroops === null ? null : exactPositiveStroopsToStellarAmount(refundAmountStroops)
  if (refundAmountStroops === null || refundStellarAmount === null) return { outcome: "FAILED", code: "invalid_input", message: "Refund amount is not an exact positive stroop amount" }

  const candidate = await prepareR36EvidenceCandidate({network:'Pi Testnet',sourceWallet:input.payment.from_address,
    destinationWallet:input.payment.to_address,paymentId:input.checkpoint.paymentId,operationKind:'refund',
    operationId:input.checkpoint.refundId,piPaymentId:input.payment.identifier,amountStroops:String(refundAmountStroops)},
    source.sequence,baseFee.toString(),async()=>{
      const t = new TransactionBuilder(source,{fee:baseFee.toString(),networkPassphrase:input.payment.network})
        .addOperation(Operation.payment({destination:input.payment.to_address,asset:Asset.native(),amount:refundStellarAmount}))
        .addMemo(Memo.text(input.payment.identifier)).setTimeout(TimeoutInfinite).build()
      t.sign(keypair);return t
    },r36PreparedEvidenceStore,{recipientPublicKeyPem:process.env.FLASHPAY_R36_EVIDENCE_RECIPIENT_PUBLIC_KEY??'',sign:t=>{t.sign(keypair)}})
  if(candidate.outcome!=='READY_FOR_ORIGINAL_GUARDS')return {outcome:'FAILED',code:'submit_failed',message:'Prepared evidence unavailable or changed; hold without resigning'}
  // Evidence is encrypted staging only: no prepared authority, send attempt,
  // accounting or Horizon POST is allowed through the preparation-only path.
  if(mode==='evidence_only')return {outcome:'EVIDENCE_PREPARED'}
  const transaction=candidate.transaction

  const envelopeXdr = transaction.toXDR()
  const preparedHash = Buffer.from(transaction.hash()).toString("hex")
  const preparedSequence = transaction.sequence
  // R36: the wallet claim and refund prepared audit insert share one PG transaction.
  const prepared = await ensureRefundPreparedSubmit(input.checkpoint.refundId, input.checkpoint.paymentId, input.checkpoint.idempotencyKey, input.payment.identifier, envelopeXdr, preparedHash, preparedSequence, {
    network: input.payment.network, sourceWallet: input.payment.from_address,
    paymentId: input.checkpoint.paymentId, operationKind: 'refund',
    operationId: input.checkpoint.refundId, preparedHash, preparedSequence,
  })
  if (!prepared || prepared.preparedNow !== true || prepared.envelopeXdr !== envelopeXdr || prepared.preparedHash !== preparedHash || prepared.preparedSequence !== preparedSequence) return { outcome: "FAILED", code: "submit_failed", message: "Refund transaction was not confirmed" }


  if (process.env.VERCEL_ENV !== "production" && process.env.FLASHPAY_REFUND_CRASH_TEST === "1" && input.payment.network === "Pi Testnet" && input.payment.amount === 0.1) {
    console.log("[P7 TEST] Refund prepared-before-auth 0.10")
    return { outcome: "FAILED", code: "submit_failed", message: "P7 refund prepared-before-auth test" }
  }

  const authorization = await authorizeRefundBlockchainSubmit(input.checkpoint.refundId, input.checkpoint.paymentId, input.checkpoint.idempotencyKey, input.payment.identifier, envelopeXdr, preparedHash, preparedSequence, "system")
  if (!authorization || authorization.authorizedNow !== true) return { outcome: "FAILED", code: "submit_failed", message: "Refund transaction was not confirmed" }

  try {
    if (!await input.verifyOwned()) return { outcome: "FAILED", code: "submit_failed", message: "Refund wallet submit ownership lost" }
    if (!await verifyPreparedWalletAuthority({
      network: 'Pi Testnet', sourceWallet: input.payment.from_address,
      paymentId: input.checkpoint.paymentId, operationKind: 'refund',
      operationId: input.checkpoint.refundId, preparedHash, preparedSequence,
    })) return { outcome: "FAILED", code: "submit_failed", message: "Durable refund authority not proven" }
    if ((await verifyRefundOriginalCustomerBinding({ paymentId: input.checkpoint.paymentId, payerUid: input.checkpoint.payerUid, amount: input.checkpoint.amount })).outcome !== 'VERIFIED') return { outcome: 'FAILED', code: 'submit_failed', message: 'Original customer binding unverified before Horizon submission' }
    if (!await claimFirstWalletSubmission({
      network: 'Pi Testnet', sourceWallet: input.payment.from_address,
      paymentId: input.checkpoint.paymentId, operationKind: 'refund',
      operationId: input.checkpoint.refundId, preparedHash, preparedSequence,
    })) return { outcome: "FAILED", code: "submit_failed", message: "Refund one-shot submission already used or unavailable" }
    const result = await server.submitTransaction(transaction)
    if (result.successful !== true || result.hash !== preparedHash) return { outcome: "FAILED", code: "submit_failed", message: "Refund transaction was not confirmed" }
    return { outcome: "CONFIRMED_TX", txid: result.hash }
  } catch (error) {
    try {
      const after = await readRefundPreparedRecoveryEvidence({ checkpoint: prepared.checkpoint, payment: input.payment })
      if (after.outcome === "VERIFIED" && after.reference.preparedHash === preparedHash && after.reference.preparedSequence === preparedSequence && after.reference.refundPaymentId === input.payment.identifier && after.reference.fromAddress === input.payment.from_address && after.reference.toAddress === input.payment.to_address && after.reference.amount === input.payment.amount) return { outcome: "CONFIRMED_TX", txid: preparedHash }
    } catch {
      return { outcome: "FAILED", code: "submit_failed", message: error instanceof Error ? error.message : "Refund transaction submission failed" }
    }
    return { outcome: "FAILED", code: "submit_failed", message: error instanceof Error ? error.message : "Refund transaction submission failed" }
  }
}
