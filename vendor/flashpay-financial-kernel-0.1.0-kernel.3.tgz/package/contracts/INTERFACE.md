# Server interface v1

The named API exports accept original NextRequest/Request and route context, and return original Response/NextResponse. Consumers must inspect HTTP status and explicit outcome; a timeout, 404, pending state or successful HTTP delivery is not financial finality. See `http.json` for all compatibility routes. The host may submit intent or request observation/recovery; it cannot submit an authoritative `settled` result through this interface.

- **createPayment**: POST `/api/payments`, JSON `amount`, `note`, `accessToken`, `createIntentId`; original handler derives merchant identity from Pi, validates amount/policy/wallet readiness and persists idempotent intent. Retries keep the same intent and identity. A changed amount under that intent is a conflict.
- **readCreateIntent / readPayment**: GET `/api/payments/create-intent` and `/api/payments/:id`, original authentication/query contracts. Reopen the existing request after uncertainty; do not replace it.
- **startPayment / approvePayment / completePayment**: original Pi routes and their original authenticated bodies/callback identities. Client declarations never replace canonical Pi reads, durable U2A evidence, prepared XDR or R36 authority. Approval/completion callbacks may repeat; financial effects must not.
- **requestRefund / readRefund**: original `/api/refunds/intent` and `/api/refunds/customer-status`. Refund requires the verified original payer, entitlement, durable state and no settlement conflict. A merchant cannot redirect the refund destination.
- **readReceipt**: GET `/api/receipts/:id` with original account authentication. A receipt requires durable finality/accounting. Redis alone or another application's receipt ID is insufficient.
- **recover**: authenticated `/api/recovery/new-intents`, original configured scope and selection. A wake is a notification, not payment authority. Ambiguous attempts stay held. Scheduling, host lifetime and durable continuation must all be supplied by the deployment adapter.

`lib/*` and `runtime/*` exports are trusted-host compatibility/worker internals, NOT a public browser API. Their callers must retain the original authenticated routes and role boundaries. Never expose a raw SQL, signing or accounting primitive to a client.

Legacy administrative emergency/operations routes retain their original authorization. Integrators should mount only the routes their product needs. FLASHpay keeps its existing owner-only Profile control and ordinary Home wallet connection; this extraction does not redesign either.
