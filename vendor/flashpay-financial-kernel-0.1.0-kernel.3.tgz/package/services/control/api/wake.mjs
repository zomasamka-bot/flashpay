import {authenticate,validateWake} from '../lib/auth.mjs';
import {warmTrustHost} from '../lib/host-manager.mjs';
export default async function handler(req,res){
 res.setHeader('Cache-Control','no-store');
 if(req.method!=='POST')return res.status(405).json({error:'METHOD_NOT_ALLOWED'});
 let raw='';try{if(req.body!==undefined){raw=Buffer.isBuffer(req.body)?req.body.toString('utf8'):typeof req.body==='string'?req.body:JSON.stringify(req.body)}else{for await(const chunk of req){raw+=chunk;if(Buffer.byteLength(raw)>1024)return res.status(413).json({error:'REQUEST_SIZE'})}}if(Buffer.byteLength(raw)>1024)return res.status(413).json({error:'REQUEST_SIZE'})}catch{return res.status(400).json({error:'REQUEST_INVALID'})}
 if(!authenticate(req.headers,raw,process.env.R36_WAKE_SECRET))return res.status(401).json({error:'UNAUTHORIZED'});
 let body;try{body=JSON.parse(raw)}catch{return res.status(400).json({error:'REQUEST_INVALID'})}
 if(!validateWake(body))return res.status(400).json({error:'REQUEST_SCOPE'});
 try{const result=await warmTrustHost();console.info('[R36 host wake]',{status:'ready',financialAuthority:false});return res.status(200).json(result)}catch(e){const code=/^[A-Z_]{1,96}$/.test(e?.message)?e.message:'PRIVATE_HOST_UNAVAILABLE';console.warn('[R36 host wake]',{status:'held',code,financialAuthority:false});return res.status(503).json({error:code,ready:false,financialAuthority:false})}
}
