import {authenticate} from '../lib/auth.mjs';
import {observeIntakeRegistry} from '../lib/intake-observation.mjs';
export default async function handler(req,res){
 res.setHeader('Cache-Control','no-store');
 if(req.method!=='POST')return res.status(405).json({error:'METHOD_NOT_ALLOWED'});
 let raw='';try{if(req.body!==undefined)raw=Buffer.isBuffer(req.body)?req.body.toString('utf8'):typeof req.body==='string'?req.body:JSON.stringify(req.body);else for await(const b of req){raw+=b;if(Buffer.byteLength(raw)>1024)return res.status(413).json({error:'REQUEST_SIZE'})}}catch{return res.status(400).json({error:'REQUEST_INVALID'})}
 if(!authenticate(req.headers,raw,process.env.R36_WAKE_SECRET))return res.status(401).json({error:'UNAUTHORIZED'});
 let body;try{body=JSON.parse(raw)}catch{return res.status(400).json({error:'REQUEST_INVALID'})}
 if(!body||Object.keys(body).join(',')!=='schema'||body.schema!=='R36_PRIVATE_INTAKE_V1')return res.status(400).json({error:'REQUEST_SCOPE'});
 try{return res.status(200).json(await observeIntakeRegistry())}catch{return res.status(503).json({ready:false,error:'REGISTRY_UNAVAILABLE',financialAuthority:false})}
}
