# KERNEL-1 · @flashpay/financial-kernel 0.1.0-kernel.1

DEVELOPMENT QUALIFICATION CANDIDATE — NOT_FOR_DEPLOY.

This is the original FLASHpay server implementation extracted from Git e672a2f8fd10f0613bcd5bb1df4f1ce36b94539d. It is a Next.js 15.5.28 / Node 24 package, not a framework-neutral rewrite. Financial decisions remain in the original handlers, R36 verifiers and PostgreSQL functions. An imported library cannot defend against a malicious host that owns its database credentials; the host and deployment administrator remain inside the trust boundary.

## One release, separate installations

Install the exact same `.tgz` and SHA-256 in each application. Configure `transpilePackages: ['@flashpay/financial-kernel']`. Use the HTTP exports in `contracts/http.json` or the named entry points. Keep the original Next route runtime/dynamic/maxDuration values. `after()` must run within a real Next request lifetime. Do not create a second copy of financial implementation files.

Each application needs its own process/deployment, PostgreSQL project/role namespace and credentials, Redis database/token, source wallet, registered Pi application/API credentials, R36 policy and evidence/signing/TLS keys, private state Drive and control project. This version deliberately does not implement shared-database multi-tenancy. Do not switch application identity in a running process. Do not share a wallet/sequence across applications.

## Immutable deployment binding

Provide `KERNEL_DEPLOYMENT_PROFILE` as exact JSON bytes and `KERNEL_DEPLOYMENT_SHA256` as their SHA-256. The type/validation is in `src/deployment.ts`. Required fields: schema, applicationId, piApplicationId, network, databaseHost, databaseName, databaseBranch, publicOrigin, trustOrigin, redisOrigin, sourceWallet, recoveryCutover, historicalHolds. Only Pi Testnet is supported. The Pi app ID is a configuration declaration, not proof of registration; provider identity must be separately qualified with its own credentials.

Bind the same digest and identity into `public.kernel_deployment_identity`. Runtime and evidence-reader may read this metadata; registrar/issuer/signer receive no extra direct table privileges. This binding grants no financial authority. Existing policy enrollment, certificate signature/freshness/revocation, wallet ownership, prepared XDR, one-shot and accounting checks still apply. A missing/mismatched binding stops execution.

Do not put secrets in the profile or repository. Use the deployment's protected secret store for database passwords, Redis tokens, Pi API key, wallet seed, recovery authentication and R36 keys. Preserve separate runtime, registrar, issuer, signer, evidence reader and migration credentials. The technical issuer is not the app owner's personal Pi session.

## Fresh empty installation

Provision a dedicated PostgreSQL 17-compatible instance with an existing `neondb_owner` schema owner, a verified TLS endpoint, and a trustworthy `neon.branch_id` identity. Do not set that identity on an existing database merely to pass verification. `tools/install-fresh.cjs` requires an empty database and unused R36 role namespace. It runs schema creation and identity binding in one transaction, creates NOLOGIN roles, and refuses a second run. Invoke with protected `KERNEL_MIGRATION_DATABASE_URL` plus the profile variables. No wallet/policy activation or credential creation occurs.

`sql/fresh-schema.sql` is the qualified empty schema, with three recovery selectors referring to deployment metadata instead of FLASHpay history constants. `sql/original-upgrades` preserves historical SQL provenance; NEVER run the whole directory. `sql/bind-existing-empty.sql` is a reviewed component, not a complete production migration.

For existing FLASHpay, use the separately delivered migration/rollback guide. Do not use the fresh installer on it. Keep the current source, SQL function definitions, role ACLs and encrypted backups until rollback is retired.

## APIs and service contracts

`contracts/INTERFACE.md` specifies input authority and result rules. `services` contains parameterized original private-host code. `services/control` is a deployment template, not a pre-authorized live service. It additionally requires a hashed KERNEL_HOST_PROFILE identifying applicationId/projectId/region/driveName. A private service image must contain this exact package at `/kernel`, plus locked dependencies; it must not contain keys, credentials or financial data. The existing supervisor keeps keys in RAM-backed storage, separate service containers, restricted database roles and provider GET-only egress. An event wake goes only to this application's authenticated original Recovery route.

The control template must be assembled with this package in `vendor` and a regenerated frozen lockfile; its old lockfile is retained only as `BASE_DEPENDENCIES.lock.json` for dependency provenance. Real Vercel Drive/image relocation and a live Pi cycle are not asserted by the local tests. No new paid resource is required or automatically provisioned by this package.

## Evidence limits

The qualification uses real isolated PostgreSQL, TLS, Redis/Lua, original cryptography/SQL/handlers, two different application profiles, independent processes and real SIGKILL. Pi identity/network/finality are synthetic boundary inputs, and all external financial traffic is blocked. These results do not issue independent financial certification, authorize Mainnet, measure production latency, or prove 10,000 concurrent payments.

Do not switch the live FLASHpay domain, workers, credentials or schedules to this candidate until the application-plus-private-host migration has been rehearsed together and its live acceptance approved. Never roll back durable financial rows to replay an ambiguous submission. Keep SAFE_HOLD_NO_RESEND.
