import { prepareR36EvidenceCandidate } from "./r36-prepared-evidence"
import { getPiSigningSeed } from "./pi-wallet-signing-config"
import { r36PreparedEvidenceStore } from "./r36-prepared-evidence-store"
import { claimPreparedWalletAuthority, claimFirstWalletSubmission, type WalletAuthorityClaim } from './financial-wallet-authority'
import { currentRecoveryRight } from './r36-recovery-scope'
import { redis, isRedisConfigured } from "./redis"
import { serverConfig } from "./server-config"
import { withAtomicSettlementPreparedAuthority, recordA2UTransactionAtomic, recordSettlementA2UCreatedCheckpoint, recordSettlementPreparedCheckpoint, recordSettlementHorizonCheckpoint, recordSettlementPiCompletedCheckpoint, recordSettlementDbFinalizedCheckpoint, getSettlementCheckpointAuthoritative, recordSettlementA2UOngoingObservation, retireCancelledSettlementA2UStage1, claimSettlementA2UCreateAttempt, claimSettlementPiMutationAttempt } from "./db"
import { buildA2USuccessResponse } from "./a2u-response"
import { validateFinancialData } from "./financial-validation"
import { acquirePiWalletIntentSubmitLock, acquirePiWalletSubmitLock, readPiWalletIntent, releasePiWalletIntent, replacePiWalletIntent } from "./pi-wallet-submit-lock"
import * as StellarSDK from "@stellar/stellar-sdk"
import { numberToExactPositiveStroops } from "./financial-amount-stroops"
import { executeFinancialRecoverySettlementSubmitReplay } from "./financial-recovery-settlement-submit-replay-orchestration"
import { proveA2UStage1HorizonAbsence } from "./a2u-stage1-retirement"
import { readR36IndependentHorizonProof } from "./r36-independent-horizon-proof"

/**
 * UNIFIED A2U EXECUTOR - Single source of truth for ALL A2U execution paths
 * 
 * REPLACES:
 * - /api/pi/a2u new-payment + ongoing-payment + already_completed flows
 * - /api/pi/complete settlement_pending retry flow
 * - /lib/a2u-recovery-service.ts completePiA2UAndReconcile
 * - /api/recovery/[id] server-side Pi /complete
 * 
 * SINGLE FLOW:
 * 1. Check if already settled → return success
 * 2. Load/reuse/create A2U (if needed)
 * 3. Sign once (if needed)
 * 4. Submit Horizon once (if needed)
 * 5. Persist checkpoint
 * 6. Complete Pi once (if needed)
 * 7. Reconcile DB once
 * 
 * Recovery skips completed stages and handles already_completed.
 * No Horizon re-signing when txid exists.
 */

import type { Payment } from "./types"
import { reconcileIncompleteA2UPayment, isPiA2UPayment as isReconciledPiA2UPayment } from "./pi-reconciliation"
import { markRefundPendingAfterFailedSettlement } from "./types"
import { isPaymentFinal } from "./payment-status"
import { compareAndSwapPaymentProjection } from "./payment-projection-cas"

/**
 * Pi A2U Payment API Response - Strict type definition
 * Based on Pi API response structure for payments endpoint
 */
interface PiA2UPayment {
  identifier: string
  from_address: string
  to_address: string
  amount: number
  direction?: "app_to_user" | "user_to_app"
  metadata?: Record<string, unknown>
  user_uid?: string
  created_at?: string
  status?: {
    developer_approved?: boolean
    transaction_verified?: boolean
    developer_completed?: boolean
    cancelled?: boolean
    user_cancelled?: boolean
  }
  transaction?: {
    txid?: string
    verified?: boolean
    _link?: string
  }
}

/**
 * ============================================================================
 * UNIFIED INTERNAL RESULT CONTRACT - TYPED DISCRIMINATED UNIONS
 * ============================================================================
 * 
 * Each stage returns its specific data type on success.
 * All errors: { ok: false; error: string; userFacingStatus: string }
 */
type Stage1Result =
  | { ok: true; data: { a2uPaymentId: string; a2uPayment: PiA2UPayment } }
  | { ok: false; error: string; userFacingStatus: string; retryable?: boolean; retryAfterMs?: number; errorCode?: string; errorBody?: string }

type Stage2Result = 
  | { ok: true; data: { txidFromHorizon: string; horizonFeeCharged: number } }
  | { ok: false; error: string; userFacingStatus: string; waitCode?: 'R36_SCOPED_CONTINUATION_REQUIRED' }

type Stage3Result = 
  | { ok: true }
  | { ok: false; error: string; userFacingStatus: string }

type Stage4Result =
  | { ok: true; transactionId: string; transaction: { u2aIdentifier: string; u2aTxid: string; a2uIdentifier: string; a2uTxid: string; merchantId: string; merchantUid: string } }
  | { ok: false; error: string; userFacingStatus: string }

/**
 * Reusable type guard: Check if unknown is a Record<string, unknown>
 */
function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null
}

/**
 * Type guard: Validate unknown object as PiA2UPayment
 */
function isPiA2UPayment(value: unknown): value is PiA2UPayment {
  if (!isRecord(value)) return false
  const obj = value
  
  // Required fields
  if (typeof obj.identifier !== 'string') return false
  if (typeof obj.from_address !== 'string') return false
  if (typeof obj.to_address !== 'string') return false
  if (typeof obj.amount !== 'number' || !Number.isFinite(obj.amount)) return false
  
  // Optional status field with boolean flags
  if (obj.status !== undefined && obj.status !== null) {
    if (!isRecord(obj.status)) return false
    const statusObj = obj.status
    if (statusObj.developer_approved !== undefined && typeof statusObj.developer_approved !== 'boolean') return false
    if (statusObj.transaction_verified !== undefined && typeof statusObj.transaction_verified !== 'boolean') return false
    if (statusObj.developer_completed !== undefined && typeof statusObj.developer_completed !== 'boolean') return false
    if (statusObj.cancelled !== undefined && typeof statusObj.cancelled !== 'boolean') return false
    if (statusObj.user_cancelled !== undefined && typeof statusObj.user_cancelled !== 'boolean') return false
  }
  
  // Optional transaction field: txid and verified are optional strings/booleans
  if (obj.transaction !== undefined && obj.transaction !== null) {
    if (!isRecord(obj.transaction)) return false
    const txObj = obj.transaction
    if (txObj.txid !== undefined && typeof txObj.txid !== 'string') return false
    if (txObj.verified !== undefined && typeof txObj.verified !== 'boolean') return false
    if (txObj._link !== undefined && typeof txObj._link !== 'string') return false
  }
  
  return true
}

export interface ExecutorContext {
  paymentId: string
  payment: Payment // Use canonical Payment type - REQUIRED
  merchantUid: string
  merchantAuthority: "durable_u2a"
  customerAmount: number // REQUIRED - validated amount
  piPaymentId?: string // Optional - provided for recovery flows, undefined for new payments
  isRecovery: boolean
  recoveryOperation?: "SETTLEMENT_CREATE" | "SETTLEMENT_SUBMIT" | "SETTLEMENT_RECONCILE" | "SETTLEMENT_DISPATCH"
  schedulerWalletPaymentId?: string | null
}

/**
 * CRITICAL: Executor NEVER returns success: true
 * ALL paths (new, ongoing, complete, recovery) return { success: false, status: "settlement_pending" }
 * or error states. ONLY buildA2USuccessResponse() can return success: true after reading Redis predicate.
 * STRICT DISCRIMINATED UNION: success: false MUST include status and error (no optional)
 */
type ExecutorResult = 
  | { ok: true; status: "settlement_pending" }
  | { ok: false; status: string; error: string }

/**
 * UNIFIED EXECUTOR: Resume from stored stage or execute complete flow
 * Validates all context inputs and returns discriminated union (success must include txidFromHorizon)
 */
export async function executeA2U(ctx: ExecutorContext): Promise<ExecutorResult> {
  const executeA2UTimingStartedAt = Date.now()
  // Validate required context fields - no optional coercion
  if (!ctx.paymentId || typeof ctx.paymentId !== 'string') {
    return { ok: false, status: "invalid_context", error: "paymentId required and must be string" }
  }
  if (!ctx.payment || typeof ctx.payment !== 'object') {
    return { ok: false, status: "invalid_context", error: "payment object required" }
  }
  if (!ctx.merchantUid || typeof ctx.merchantUid !== 'string') {
    return { ok: false, status: "invalid_context", error: "merchantUid required and must be string" }
  }
  const durableMerchantAuthority = ctx.merchantAuthority === "durable_u2a"
  if (!ctx.payment.a2uPaymentId && !durableMerchantAuthority) {
    return { ok: false, status: "invalid_context", error: "durable merchant authority required before A2U creation" }
  }
  if (typeof ctx.customerAmount !== 'number' || !Number.isFinite(ctx.customerAmount)) {
    return { ok: false, status: "invalid_context", error: "customerAmount required and must be finite number" }
  }
  if (typeof ctx.isRecovery !== 'boolean') {
    return { ok: false, status: "invalid_context", error: "isRecovery required and must be boolean" }
  }
  // piPaymentId is optional for new payments, but MUST be present for recovery or stage 4 DB recording
  // Validation below will enforce when needed

  console.log("[A2U Executor] ===== UNIFIED A2U EXECUTOR START =====")
  console.log("[A2U Executor] Payment ID:", ctx.paymentId)
  console.log("[A2U Executor] Is Recovery:", ctx.isRecovery)
  console.log("[A2U Executor] Current Status:", ctx.payment.status)

  // STAGE 0: Check if already settled (terminal state)
  // Executor returns ok:true; caller invokes buildA2USuccessResponse() to return final response
  if (ctx.payment.status === "settled_to_merchant") {
    console.log("[A2U Executor] ℹ️ Already settled - skipping execution")
    if (ctx.payment.id === ctx.paymentId && isPaymentFinal(ctx.payment) === true && isRedisConfigured) {
      try {
        await redis.eval<[string], number>("redis.call('SREM',KEYS[1],ARGV[1]); redis.call('ZREM',KEYS[2],ARGV[1]); return 1", ["flashpay:recovery:active-payments:v1", "flashpay:settlement:ready:v1"], [ctx.paymentId])
      } catch (error) {
        console.warn("[A2U Executor] Active recovery index cleanup failed", error)
      }
    }
    return { ok: true, status: "settlement_pending" }
  }

  // STAGE 1: Get/Create A2U payment (skip if already have a2uPaymentId)
  if (ctx.isRecovery && ctx.recoveryOperation === "SETTLEMENT_CREATE" && ctx.payment.a2uPaymentId) {
    return { ok: false, status: "settlement_pending", error: "Create target exists" }
  }
  if (ctx.isRecovery && ctx.recoveryOperation === "SETTLEMENT_SUBMIT" && !ctx.payment.a2uPaymentId) {
    return { ok: false, status: "settlement_pending", error: "Submit requires a2uPaymentId" }
  }
  let a2uPaymentId = ctx.payment.a2uPaymentId

  if (!a2uPaymentId) {
    console.log("[A2U Executor] STAGE 1: Creating new A2U payment")
    const attemptAt = new Date().toISOString()
    ctx.payment = await persistCheckpointMerged(ctx.paymentId, {
      lastAttemptAt: attemptAt,
      retryCount: (ctx.payment.retryCount || 0) + 1,
      settlementFailureState: "reconciling",
    })
    const stage1TimingStartedAt = Date.now()
    const stageResult = await stage1CreateA2U(ctx)
    console.log("[P7B TIMING] executeA2U Stage1", { paymentId: ctx.paymentId, durationMs: Date.now() - stage1TimingStartedAt })
    if (!stageResult.ok) {
      const retryable = stageResult.retryable === true
      const failClosedStage1=["a2u_foreign_ongoing_payment","a2u_precreate_found_requires_reconciliation","a2u_precreate_reconciliation_indeterminate","a2u_ambiguous_reconciliation_indeterminate","a2u_network_reconciliation_indeterminate","a2u_rate_limited_post_ambiguous","a2u_failed_post_reconciliation_confirmed_none","a2u_network_reconciliation_confirmed_none"].includes(stageResult.errorCode??"")||stageResult.errorCode?.startsWith("unparseable_")===true||stageResult.errorCode?.startsWith("invalid_dto_")===true
      let failedPayment = ctx.payment
      let refundPendingFromConfirmedNone = false
      if (!failClosedStage1 && !retryable && typeof ctx.customerAmount === "number" && Number.isFinite(ctx.customerAmount) && ctx.customerAmount > 0 &&
        typeof ctx.merchantUid === "string" && ctx.merchantUid.trim().length > 0) {
        const reconciliation = await reconcileIncompleteA2UPayment(ctx.paymentId, ctx.customerAmount, ctx.merchantUid)
        if (reconciliation.outcome === "FOUND" && reconciliation.dto) {
          if (!isPiA2UPayment(reconciliation.dto)) {
            failedPayment = { ...failedPayment, settlementFailureState: "held", refundStatus: "manual_review_required", status: "paid_to_app" }
          } else {
          const transaction = isRecord(reconciliation.dto.transaction) ? reconciliation.dto.transaction : null
          failedPayment = { ...failedPayment, a2uPaymentId: reconciliation.dto.identifier, ...(typeof transaction?.txid === "string" ? { a2uTxid: transaction.txid } : {}) }
          }
        } else if (reconciliation.outcome === "CONFIRMED_NONE") {
          failedPayment = markRefundPendingAfterFailedSettlement(
            { ...failedPayment, status: "settlement_failed" },
            { code: stageResult.errorCode || "a2u_non_retryable_no_transfer", message: stageResult.error, occurredAt: new Date().toISOString() },
          )
          refundPendingFromConfirmedNone = failedPayment.refundStatus === "pending" && failedPayment.settlementFailureState === "refund_pending"
        }
      }
      const retryCount = ctx.payment.retryCount || 1
      const exponentialBackoffMs = Math.min(30 * 60_000, 5_000 * 2 ** Math.max(0, retryCount - 1))
      const nextRetryAt = retryable
        ? new Date(Date.now() + Math.max(exponentialBackoffMs, stageResult.retryAfterMs ?? 0)).toISOString()
        : undefined
      ctx.payment = await persistCheckpointMerged(ctx.paymentId, {
        ...failedPayment,
        a2uErrorCode: stageResult.errorCode,
        a2uErrorMessage: stageResult.error,
        a2uErrorBody: stageResult.errorBody,
        settlementFailureState: retryable ? "retryable" : refundPendingFromConfirmedNone ? "refund_pending" : "held",
        refundStatus: retryable ? "not_started" : refundPendingFromConfirmedNone ? "pending" : "manual_review_required",
        nextRetryAt,
        status: retryable ? "paid_to_app" : refundPendingFromConfirmedNone ? "settlement_failed" : "paid_to_app",
      })
      return {
        ok: false,
        status: retryable ? "settlement_pending" : stageResult.userFacingStatus,
        error: stageResult.error,
      }
    }
    // Discriminated union: ok: true includes a2uPaymentId
    a2uPaymentId = stageResult.data.a2uPaymentId
    ctx.payment.a2uPaymentId = a2uPaymentId

    // Persist Stage 1: a2uPaymentId immediately after creation (crash-safe merge)
    if (stageResult.data.a2uPayment) {
      const stage1Updates: Partial<Payment> = {
        a2uPaymentId: a2uPaymentId,
        a2uFromAddress: stageResult.data.a2uPayment.from_address,
        a2uToAddress: stageResult.data.a2uPayment.to_address,
        customerAmount: ctx.customerAmount,
        merchantAmount: Number(stageResult.data.a2uPayment.amount),
        settlementFailureState: "none",
      }
      // Preserve the existing Redis checkpoint first. Then require the exact same
      // Stage1 identity to become durable in PostgreSQL before Stage2 can execute.
      ctx.payment = await persistCheckpointMerged(ctx.paymentId, stage1Updates)
      const durableStage1 = await recordSettlementA2UCreatedCheckpoint({
        paymentId: ctx.paymentId,
        merchantId: ctx.payment.merchantId,
        merchantUid: ctx.merchantUid,
        customerAmount: ctx.customerAmount,
        merchantAmount: Number(stageResult.data.a2uPayment.amount),
        u2aIdentifier: ctx.payment.piPaymentId!,
        u2aTxid: ctx.payment.u2aTxid!,
        a2uPaymentId,
        a2uFromAddress: stageResult.data.a2uPayment.from_address,
        a2uToAddress: stageResult.data.a2uPayment.to_address,
      })
      if (durableStage1.outcome !== "RECORDED" && durableStage1.outcome !== "REPLAYED") {
        console.error("[A2U Stage1] Durable checkpoint not proven:", durableStage1.outcome)
        return { ok: false, status: "settlement_pending", error: "A2U Stage1 durable checkpoint not proven" }
      }
    }
  } else {
    console.log("[A2U Executor] STAGE 1: Reusing existing A2U payment:", a2uPaymentId)

    // For reused a2uPaymentId, fetch from Pi API to validate state
    console.log("[A2U Executor] STAGE 1: Fetching and validating reused A2U from Pi API")
    const fetchedPayment = await fetchA2UPayment(a2uPaymentId)
    if (!fetchedPayment) {
      return { ok: false, status: "error", error: "Failed to fetch existing A2U payment from Pi" }
    }
    if (!isReconciledPiA2UPayment(fetchedPayment)) { return { ok:false,status:"settlement_pending",error:"A2U identity mismatch" } }
    if (fetchedPayment.identifier !== a2uPaymentId) {
      return { ok: false, status: "error", error: "A2U identifier mismatch from Pi API" }
    }
    // Normalize and check amount match exactly
    const fetchedAmount = Number(fetchedPayment.amount)
    if (!Number.isFinite(fetchedAmount) || fetchedAmount !== ctx.customerAmount) {
      return { ok: false, status: "error", error: "A2U amount mismatch" }
    }
    if (!fetchedPayment.from_address || !fetchedPayment.to_address) {
      return { ok: false, status: "error", error: "A2U missing addresses" }
    }
    if (ctx.isRecovery && ctx.recoveryOperation === "SETTLEMENT_DISPATCH" && (fetchedPayment.from_address !== ctx.payment.a2uFromAddress || fetchedPayment.to_address !== ctx.payment.a2uToAddress)) {
      return { ok: false, status: "settlement_pending", error: "A2U identity mismatch" }
    }
    
    // Check if payment is cancelled
    if (fetchedPayment.status?.cancelled === true || fetchedPayment.status?.user_cancelled === true || fetchedPayment.cancelled === true || fetchedPayment.rejected === true) {
      const metadata = isRecord(fetchedPayment.metadata) ? fetchedPayment.metadata : null
      const exactCancelledIdentity = fetchedPayment.identifier === a2uPaymentId && fetchedPayment.network === "Pi Testnet" && fetchedPayment.direction === "app_to_user" && fetchedPayment.amount === ctx.customerAmount && fetchedPayment.user_uid === ctx.merchantUid && metadata?.type === "a2u_settlement" && metadata?.paymentId === ctx.paymentId && typeof fetchedPayment.txid !== "string" && typeof fetchedPayment.transaction_id !== "string" && typeof fetchedPayment.transaction?.txid !== "string" && fetchedPayment.transaction?.verified !== true && fetchedPayment.status?.transaction_verified !== true && fetchedPayment.status?.developer_completed !== true
      if (!exactCancelledIdentity) return { ok:false,status:"settlement_pending",error:"Cancelled A2U identity/progression is not safe to retire" }
      const horizon = await proveA2UStage1HorizonAbsence(fetchedPayment as unknown as Record<string,unknown>, a2uPaymentId)
      if (horizon.outcome !== "ABSENT") return { ok:false,status:"settlement_pending",error:"Cancelled A2U Horizon absence not proven" }
      const now = new Date().toISOString()
      const retired = await retireCancelledSettlementA2UStage1({paymentId:ctx.paymentId,a2uPaymentId,piCancelledAt:now,horizonAbsenceProvenAt:now})
      if (retired.outcome !== "RETIRED" && retired.outcome !== "REPLAYED") return { ok:false,status:"settlement_pending",error:"Cancelled A2U durable retirement not proven" }
      const latest = ctx.payment
      const cleaned: Payment = { ...latest }
      delete cleaned.a2uPaymentId; delete cleaned.a2uFromAddress; delete cleaned.a2uToAddress; delete cleaned.a2uPreparedEnvelopeXdr; delete cleaned.a2uPreparedTxHash; delete cleaned.a2uPreparedSequence; delete cleaned.a2uTxid; delete cleaned.horizonFeeCharged; delete cleaned.horizonSuccessAt; delete cleaned.settledAt
      cleaned.status = "paid_to_app"; cleaned.settlementFailureState = "retryable"; cleaned.refundStatus = "not_started"; cleaned.a2uErrorCode = "a2u_stage1_retired_cancelled"; cleaned.a2uErrorMessage = "Cancelled A2U retired after exact Pi and Horizon absence proof"
      const projection = await compareAndSwapPaymentProjection(ctx.paymentId, latest, cleaned)
      if (projection.outcome === "UPDATED") ctx.payment = projection.payment
      console.warn("[R4P] Cancelled A2U Stage1 retired", { paymentId:ctx.paymentId, a2uPaymentId, durableOutcome:retired.outcome, redisProjectionOutcome:projection.outcome })
      return { ok:false,status:"settlement_pending",error:"Cancelled A2U Stage1 retired; fresh Stage1 required" }
    }

    const metadata = isRecord(fetchedPayment.metadata) ? fetchedPayment.metadata : null
    if (
      metadata === null ||
      metadata.type !== "a2u_settlement" ||
      metadata.paymentId !== ctx.paymentId ||
      fetchedPayment.direction !== "app_to_user" ||
      fetchedPayment.user_uid !== ctx.merchantUid
    ) {
      return { ok: false, status: "settlement_pending", error: "A2U identity mismatch" }
    }
    
    // Extract state from PaymentDTO
    const isDevCompleted = fetchedPayment.status?.developer_completed === true
    const existingTxid = fetchedPayment.transaction?.txid

    if (
      ctx.isRecovery &&
      (ctx.recoveryOperation === "SETTLEMENT_SUBMIT" || ctx.recoveryOperation === "SETTLEMENT_DISPATCH") &&
      (typeof ctx.payment.a2uTxid === "string" ||
        ctx.payment.horizonSuccessFlag === true ||
        ctx.payment.piCompletionPending === true ||
        ctx.payment.piCompleted === true ||
        ctx.payment.requiresDbReconciliation === true ||
        typeof existingTxid === "string" ||
        typeof fetchedPayment.txid === "string" ||
        typeof fetchedPayment.transaction_id === "string" ||
        fetchedPayment.completed === true ||
        fetchedPayment.transaction?.verified === true ||
        fetchedPayment.status?.transaction_verified === true ||
        fetchedPayment.status?.developer_completed === true)
    ) {
      return { ok: false, status: "settlement_pending", error: "Existing A2U transfer evidence requires reconciliation" }
    }
    
    // If any txid exists, preserve it and permanently skip Stage2
    if (typeof existingTxid === "string") {
      console.log("[A2U Executor] A2U has existing txid - preserving and skipping Stage 2")
      const preserveUpdates: Partial<Payment> = {
        a2uTxid: existingTxid,
        a2uFromAddress: fetchedPayment.from_address,
        a2uToAddress: fetchedPayment.to_address,
        customerAmount: ctx.customerAmount,
        merchantAmount: fetchedAmount,
        status: "settlement_pending" as const,
        horizonSuccessFlag: true,
        horizonSuccessAt: new Date().toISOString(),
        piCompleted: isDevCompleted,
        piCompletionPending: !isDevCompleted,
        ...(isDevCompleted && { paidAt: new Date().toISOString() }),
        requiresDbReconciliation: isDevCompleted,
      }
      // Replace ctx.payment with fully merged record
      ctx.payment = await persistCheckpointMerged(ctx.paymentId, preserveUpdates)
      console.log("[A2U Executor] ✓ Txid preserved - will skip Stage 2")
      // txidFromHorizon is set, Stage 2 will be skipped
    } else {
      // No txid: continue through normal flow (Stage 2 signing)
      console.log("[A2U Executor] A2U has no txid - will continue through Stage 2 for signing")
      const continueUpdates = {
        a2uFromAddress: fetchedPayment.from_address,
        a2uToAddress: fetchedPayment.to_address,
        customerAmount: ctx.customerAmount,
        merchantAmount: fetchedAmount,
      }
      // Replace ctx.payment with fully merged record
      ctx.payment = await persistCheckpointMerged(ctx.paymentId, continueUpdates)
    }
  }

  if (ctx.isRecovery && ctx.recoveryOperation === "SETTLEMENT_CREATE") {
    return { ok: true, status: "settlement_pending" }
  }

  // STAGE 2: Sign (skip if already have a2uTxid)
  let txidFromHorizon = ctx.payment.a2uTxid

  if (!txidFromHorizon) {
    if (ctx.schedulerWalletPaymentId !== undefined && ctx.schedulerWalletPaymentId !== ctx.paymentId) return { ok: false, status: "settlement_pending", error: "wallet_drain_not_selected" }
    console.log("[A2U Executor] STAGE 2: Signing transaction")
    const stage2TimingStartedAt = Date.now()
    const signResult = await stage2SignAndSubmit(ctx)
    console.log("[P7B TIMING] executeA2U Stage2/Horizon", { paymentId: ctx.paymentId, durationMs: Date.now() - stage2TimingStartedAt })
    if (!signResult.ok) {
      if (signResult.waitCode === 'R36_SCOPED_CONTINUATION_REQUIRED') {
        console.info('[R36 settlement handoff] prepared_waiting_for_scoped_selector', { paymentId: ctx.paymentId, code: signResult.waitCode })
      } else {
        console.error("[DR41 STAGE2 DIAGNOSTIC] stage2_result_failed", { paymentId: ctx.paymentId, userFacingStatus: signResult.userFacingStatus, error: signResult.error })
      }
      return {
        ok: false,
        status: signResult.userFacingStatus,
        error: signResult.error,
      }
    }
    // Discriminated union: ok: true includes txidFromHorizon and horizonFeeCharged
    txidFromHorizon = signResult.data.txidFromHorizon

    // Persist Stage 2 and release the exact prepared wallet intent after confirmed Horizon success.
    const finalized = await finalizeStage2AfterMove(ctx, txidFromHorizon, signResult.data.horizonFeeCharged)
    if (!finalized.ok) return finalized
    console.log("[A2U Executor] ✓ Checkpoint persisted after Horizon success with fee:", signResult.data.horizonFeeCharged)
  } else {
    console.log("[A2U Executor] STAGE 2: Skipping signing - txid already exists:", txidFromHorizon)
    if (ctx.isRecovery) {
      if (!a2uPaymentId || typeof a2uPaymentId !== "string") {
        return { ok: false, status: "settlement_pending", error: "Recovered Horizon durable checkpoint identity missing" }
      }
      const durableHorizonResume = await ensureRecoveredHorizonDurability(ctx, a2uPaymentId, txidFromHorizon)
      if (!durableHorizonResume.ok) {
        return { ok: false, status: "settlement_pending", error: durableHorizonResume.error }
      }
    }
  }

  // STAGE 3: Complete Pi (skip if already piCompleted)
  if (!ctx.payment.piCompleted) {
    console.log("[A2U Executor] STAGE 3: Calling Pi /complete")
    // Validate a2uPaymentId is present before calling Pi
    if (!a2uPaymentId || typeof a2uPaymentId !== 'string') {
      return { ok: false, status: "error", error: "a2uPaymentId missing before stage 3" }
    }
    if (!txidFromHorizon || typeof txidFromHorizon !== 'string') {
      return { ok: false, status: "error", error: "txidFromHorizon missing before stage 3 - Horizon must have succeeded" }
    }
    const stage3TimingStartedAt = Date.now()
    const piResult = await stage3CompletePi(ctx, a2uPaymentId, txidFromHorizon)
    console.log("[P7B TIMING] executeA2U Stage3 Pi complete", { paymentId: ctx.paymentId, durationMs: Date.now() - stage3TimingStartedAt })
    if (!piResult.ok) {
      return {
        ok: false,
        status: piResult.userFacingStatus,
        error: piResult.error,
      }
    }
    // Persist Stage 3: piCompleted and timestamp after confirmed or already-completed Pi state (crash-safe merge)
    const stage3Updates = {
      piCompleted: true,
      piCompletionPending: false,
      paidAt: new Date().toISOString(),
    }
    const durablePi = await recordSettlementPiCompletedCheckpoint({paymentId:ctx.paymentId,a2uPaymentId,a2uTxid:txidFromHorizon})
    if(durablePi.outcome!=="RECORDED"&&durablePi.outcome!=="REPLAYED")
      return {ok:false,status:"settlement_pending",error:"Pi-completed durable checkpoint not proven"}
    // Replace ctx.payment with fully merged record only after durable Pi finality is proven.
    ctx.payment = await persistCheckpointMerged(ctx.paymentId, stage3Updates)
    console.log("[A2U Executor] ✓ Pi /complete and durable finality succeeded")
  } else {
    console.log("[A2U Executor] STAGE 3: Skipping Pi /complete - already piCompleted")
    if (!a2uPaymentId || typeof a2uPaymentId !== "string" || !txidFromHorizon || typeof txidFromHorizon !== "string") {
      return { ok: false, status: "settlement_pending", error: "Pi-completed durable checkpoint identity missing" }
    }
    // Never advance durable Pi finality from a Redis-only completion flag.
    // An uncertain crash window requires independent Pi reconciliation, not
    // a PostgreSQL stage promotion based on cached state.
    if (ctx.isRecovery) {
      const piAuthority = await getSettlementCheckpointAuthoritative(ctx.paymentId)
      if (piAuthority.outcome !== "FOUND" ||
          (piAuthority.checkpoint.stage !== "pi_completed" && piAuthority.checkpoint.stage !== "db_finalized") ||
          piAuthority.checkpoint.a2uPaymentId !== a2uPaymentId ||
          piAuthority.checkpoint.a2uTxid !== txidFromHorizon) {
        return { ok: false, status: "settlement_pending", error: "Recovered Pi completion lacks durable finality proof" }
      }
    }
    const durablePiReplay = await recordSettlementPiCompletedCheckpoint({
      paymentId: ctx.paymentId,
      a2uPaymentId,
      a2uTxid: txidFromHorizon,
    })
    if (durablePiReplay.outcome !== "RECORDED" && durablePiReplay.outcome !== "REPLAYED") {
      return { ok: false, status: "settlement_pending", error: "Pi-completed durable checkpoint not proven" }
    }
    console.log("[F2-7 DURABLE PI RESUME]", { paymentId: ctx.paymentId, a2uPaymentId, a2uTxid: txidFromHorizon, durableOutcome: durablePiReplay.outcome })
  }

  // SHARED ACCOUNTING CHECKPOINT: Ensure appNetImpact and appCommission are persisted before Stage 4
  // This runs for both new (post-Stage 2) and recovered (post-reload) payments
  if (
    typeof ctx.payment.appNetImpact !== "number" ||
    !Number.isFinite(ctx.payment.appNetImpact) ||
    typeof ctx.payment.appCommission !== "number" ||
    !Number.isFinite(ctx.payment.appCommission)
  ) {
    console.log("[A2U Executor] Shared Accounting Checkpoint: Missing or invalid accounting fields, attempting to populate from verified data")
    
    // Verify all required values exist and are valid
    if (
      typeof ctx.payment.customerAmount !== "number" ||
      !Number.isFinite(ctx.payment.customerAmount) ||
      typeof ctx.payment.merchantAmount !== "number" ||
      !Number.isFinite(ctx.payment.merchantAmount) ||
      typeof ctx.payment.horizonFeeCharged !== "number" ||
      !Number.isFinite(ctx.payment.horizonFeeCharged)
    ) {
      return { 
        ok: false, 
        status: "error", 
        error: "Cannot populate accounting fields: customerAmount, merchantAmount, or horizonFeeCharged missing or invalid" 
      }
    }

    // Calculate appNetImpact from verified persisted values
    const calculatedAppNetImpact = ctx.payment.customerAmount - ctx.payment.merchantAmount - ctx.payment.horizonFeeCharged
    
    // Set appCommission per FlashPay business rule: no commission charged at this stage (authoritative = 0)
    const appCommissionValue = 0

    // Persist accounting checkpoint
    const accountingUpdates = {
      appNetImpact: calculatedAppNetImpact,
      appCommission: appCommissionValue,
    }
    const accountingTimingStartedAt = Date.now()
    ctx.payment = await persistCheckpointMerged(ctx.paymentId, accountingUpdates)
    console.log("[P7B TIMING] executeA2U accounting checkpoint", { paymentId: ctx.paymentId, durationMs: Date.now() - accountingTimingStartedAt })
    console.log("[A2U Executor] ✓ Accounting checkpoint persisted: appNetImpact:", calculatedAppNetImpact, "appCommission:", appCommissionValue)
  } else {
    console.log("[A2U Executor] Accounting checkpoint: Fields already present, skipping")
  }

  // J12-G: Once the scheduler-selected A2U is Pi-complete, release the Pi A2U slot
  // before DB reconciliation. The durable checkpoint keeps DB work recoverable via State 2.
  if (
    ctx.schedulerWalletPaymentId === ctx.paymentId &&
    ctx.payment.requiresDbReconciliation !== true &&
    ctx.payment.dbRecorded !== true &&
    ctx.payment.piCompleted === true &&
    ctx.payment.piCompletionPending === false
  ) {
    const canonicalA2UTxid = typeof ctx.payment.a2uTxid === "string" && /^[0-9a-f]{64}$/.test(ctx.payment.a2uTxid)
    const canonicalA2UPaymentId = typeof ctx.payment.a2uPaymentId === "string" && ctx.payment.a2uPaymentId.trim() !== "" && ctx.payment.a2uPaymentId === ctx.payment.a2uPaymentId.trim()
    const accountingComplete =
      typeof ctx.payment.customerAmount === "number" && Number.isFinite(ctx.payment.customerAmount) && ctx.payment.customerAmount > 0 &&
      typeof ctx.payment.merchantAmount === "number" && Number.isFinite(ctx.payment.merchantAmount) && ctx.payment.merchantAmount === ctx.payment.customerAmount &&
      typeof ctx.payment.horizonFeeCharged === "number" && Number.isFinite(ctx.payment.horizonFeeCharged) && ctx.payment.horizonFeeCharged >= 0 &&
      ctx.payment.appCommission === 0 &&
      typeof ctx.payment.appNetImpact === "number" && Number.isFinite(ctx.payment.appNetImpact) &&
      ctx.payment.appNetImpact === ctx.payment.customerAmount - ctx.payment.merchantAmount - ctx.payment.horizonFeeCharged
    if (!canonicalA2UTxid || !canonicalA2UPaymentId || ctx.payment.horizonSuccessFlag !== true || !accountingComplete) {
      return { ok: false, status: "settlement_pending", error: "Pi-complete DB deferral checkpoint could not be verified" }
    }
    ctx.payment = await persistCheckpointMerged(ctx.paymentId, {
      status: "settlement_pending",
      requiresDbReconciliation: true,
      dbRecorded: false,
    })
    console.log("[P7J12G] Pi A2U slot released; DB reconciliation deferred", { paymentId: ctx.paymentId })
    return { ok: true, status: "settlement_pending" }
  }

  // STAGE 4: DB Reconciliation (skip if already dbRecorded)
  if (!ctx.payment.dbRecorded) {
    console.log("[A2U Executor] STAGE 4: Reconciling in database")
    // Validate txidFromHorizon exists for DB record
    if (!txidFromHorizon || typeof txidFromHorizon !== 'string') {
      return { ok: false, status: "error", error: "txidFromHorizon missing before stage 4 - cannot record in DB" }
    }
    const stage4TimingStartedAt = Date.now()
    const dbResult = await stage4ReconcileDB(ctx, txidFromHorizon)
    console.log("[P7B TIMING] executeA2U Stage4 DB", { paymentId: ctx.paymentId, durationMs: Date.now() - stage4TimingStartedAt })
    if (!dbResult.ok) {
      return {
        ok: false,
        status: dbResult.userFacingStatus,
        error: dbResult.error,
      }
    }
    // CRITICAL: Verify returned transaction record matches validated payment identifiers before persisting final markers
    if (!dbResult.transaction) {
      console.error("[A2U Executor] CRITICAL: DB returned no transaction identifiers - cannot verify reconciliation boundary")
      try {
        await persistCheckpointMerged(ctx.paymentId, {
          status: "settlement_pending",
          dbRecorded: false,
          requiresDbReconciliation: true,
        })
        console.log("[A2U Executor] Preserved recovery checkpoint without final markers due to verification failure")
      } catch (persistErr) {
        const persistError = persistErr instanceof Error ? persistErr.message : String(persistErr)
        console.error("[A2U Executor] CRITICAL: Failed to preserve recovery checkpoint:", persistError)
        return { ok: false, status: "error", error: "DB verification failed and recovery checkpoint persistence failed" }
      }
      return { ok: false, status: "settlement_pending", error: "DB reconciliation verification failed - no transaction identifiers returned" }
    }

    // Verify EVERY canonical identifier matches validated payment data (ownership verification)
    const identifierMismatches: string[] = []
    if (dbResult.transaction.u2aIdentifier !== ctx.payment.piPaymentId) {
      identifierMismatches.push(`u2aIdentifier: "${dbResult.transaction.u2aIdentifier}" !== "${ctx.payment.piPaymentId}"`)
    }
    if (dbResult.transaction.u2aTxid !== ctx.payment.u2aTxid) {
      identifierMismatches.push(`u2aTxid: "${dbResult.transaction.u2aTxid}" !== "${ctx.payment.u2aTxid}"`)
    }
    if (dbResult.transaction.a2uIdentifier !== ctx.payment.a2uPaymentId) {
      identifierMismatches.push(`a2uIdentifier: "${dbResult.transaction.a2uIdentifier}" !== "${ctx.payment.a2uPaymentId}"`)
    }
    if (dbResult.transaction.a2uTxid !== ctx.payment.a2uTxid) {
      identifierMismatches.push(`a2uTxid: "${dbResult.transaction.a2uTxid}" !== "${ctx.payment.a2uTxid}"`)
    }
    if (dbResult.transaction.merchantId !== ctx.payment.merchantId) {
      identifierMismatches.push(`merchantId: "${dbResult.transaction.merchantId}" !== "${ctx.payment.merchantId}"`)
    }
    if (dbResult.transaction.merchantUid !== ctx.payment.merchantUid) {
      identifierMismatches.push(`merchantUid: "${dbResult.transaction.merchantUid}" !== "${ctx.payment.merchantUid}"`)
    }

    if (identifierMismatches.length > 0) {
      console.error("[A2U Executor] CRITICAL: DB returned transaction with mismatched identifiers:", identifierMismatches.join("; "))
      try {
        await persistCheckpointMerged(ctx.paymentId, {
          status: "settlement_pending",
          dbRecorded: false,
          requiresDbReconciliation: true,
        })
        console.log("[A2U Executor] Preserved recovery checkpoint (DB-only) due to identifier mismatch")
      } catch (persistErr) {
        const persistError = persistErr instanceof Error ? persistErr.message : String(persistErr)
        console.error("[A2U Executor] CRITICAL: Failed to preserve recovery checkpoint on mismatch:", persistError)
        return { ok: false, status: "error", error: "DB reconciliation failed and recovery checkpoint persistence failed" }
      }
      return { ok: false, status: "settlement_pending", error: "DB reconciliation verification failed - identifier mismatch" }
    }

    console.log("[A2U Executor] ✓ DB reconciliation verified - all canonical identifiers match, transactionId:", dbResult.transactionId)
    
    const durableDbFinality = await recordSettlementDbFinalizedCheckpoint({
      paymentId:ctx.paymentId,u2aIdentifier:ctx.payment.piPaymentId!,u2aTxid:ctx.payment.u2aTxid!,
      a2uPaymentId:ctx.payment.a2uPaymentId!,a2uTxid:ctx.payment.a2uTxid!,
      merchantId:ctx.payment.merchantId,merchantUid:ctx.merchantUid,
      customerAmount:ctx.payment.customerAmount!,merchantAmount:ctx.payment.merchantAmount!,
      horizonFeeCharged:ctx.payment.horizonFeeCharged!,appCommission:ctx.payment.appCommission!
    })
    if(durableDbFinality.outcome!=="RECORDED"&&durableDbFinality.outcome!=="REPLAYED")
      return {ok:false,status:"settlement_pending",error:"DB-finalized durable checkpoint not proven"}

    // Only NOW persist final markers after successful DB and durable-authority verification

    const stage4Updates = {
      dbRecorded: true,
      status: "settled_to_merchant" as const,
      requiresDbReconciliation: false,
      settledAt: new Date().toISOString(),
    }
    
    // Final Redis checkpoint after confirmed DB success - preserve all identifiers on failure
    try {
      ctx.payment = await persistCheckpointMerged(ctx.paymentId, stage4Updates)
      console.log("[A2U Executor] ✓ Final DB markers persisted (dbRecorded=true, settled_to_merchant)")
    } catch (finalPersistErr) {
      const persistError = finalPersistErr instanceof Error ? finalPersistErr.message : String(finalPersistErr)
      console.error("[A2U Executor] CRITICAL: Final Redis checkpoint failed after DB success - returning error without retry:", persistError)
      // DO NOT attempt recovery checkpoint write - DB is already committed with verified transactionId
      // On next invocation, isRecovery=true will use DB-only reconciliation to verify identifiers and write only final markers
      return { ok: false, status: "settlement_pending", error: "Final Redis checkpoint failed - DB committed successfully, retry only checkpoint" }
    }
  } else {
    console.log("[A2U Executor] STAGE 4: Skipping DB reconciliation - already recorded")
  }

  // Executor completes all stages successfully
  // Caller branches on result.ok, then invokes buildA2USuccessResponse() for final response
  console.log("[A2U Executor] ===== ALL STAGES COMPLETE - SETTLEMENT PENDING =====")
  console.log("[P7B TIMING] executeA2U total", { paymentId: ctx.paymentId, durationMs: Date.now() - executeA2UTimingStartedAt })
  return { ok: true, status: "settlement_pending" }
}

/**
 * STAGE 1: Create or fetch A2U payment - TYPED DISCRIMINATED UNION
 * Parses response as unknown and validates with isPiA2UPayment guard - NO CASTS
 */
function responseStatusRetryable(status: number): boolean {
  return status === 408 || status === 425 || status === 429 || status >= 500
}

function codeIsTooManyPayments(errorData: unknown, errorText: string): boolean {
  const code = isRecord(errorData) && typeof errorData.code === "string" ? errorData.code : ""
  return code === "too_many_payments" || /too_many_payments/i.test(errorText)
}

function parseRetryAfterMs(value: string | null, now: number): number | undefined {
  if (value === null) return undefined
  const trimmed = value.trim()
  if (/^[0-9]+$/.test(trimmed)) {
    const seconds = Number(trimmed)
    if (Number.isSafeInteger(seconds) && seconds >= 0 && seconds <= 86_400) return seconds * 1000
    return undefined
  }
  const retryAt = Date.parse(trimmed)
  const delay = retryAt - now
  return Number.isFinite(retryAt) && delay >= 0 && delay <= 86_400_000 ? delay : undefined
}

async function stage1CreateA2U(ctx: ExecutorContext): Promise<Stage1Result> {
  try {
    // R101-6: the shared locked executor has already re-proved the immutable
    // merchant/U2A binding from PostgreSQL plus canonical Pi server evidence.
    // No merchant bearer is needed or consulted after U2A completion.
    if (ctx.merchantAuthority !== "durable_u2a") {
      return { ok: false, error: "Durable merchant authority required", userFacingStatus: "error" }
    }
    console.log("[R101-6 A2U Stage1] ✓ Durable merchant/U2A authority verified upstream")

    // FIN-5: PostgreSQL must prove this payment was born under the guarded
    // create generation and atomically claim its one allowed Pi create attempt.
    // Legacy/replayed/uncertain claims fail closed before any network POST.
    const createAttempt = await claimSettlementA2UCreateAttempt({
      paymentId: ctx.paymentId,
      merchantUid: ctx.merchantUid,
      customerAmount: ctx.customerAmount,
      u2aIdentifier: ctx.payment.piPaymentId ?? "",
      u2aTxid: ctx.payment.u2aTxid ?? "",
      payerUid: ctx.payment.payerUid ?? "",
    })
    if (createAttempt.outcome !== "RECORDED") {
      return { ok:false, error:"Durable A2U create attempt authority unavailable", userFacingStatus:"manual_review_required", retryable:false, errorCode:"a2u_create_attempt_authority_unavailable" }
    }
    console.log("[FIN-5 A2U CREATE ATTEMPT] durable one-shot claim recorded", { paymentId: ctx.paymentId, attemptedAt: createAttempt.attemptedAt })

    // Create A2U payment
    const requestBody = {
      payment: {
        amount: ctx.customerAmount,
        memo: `FlashPay settlement for ${ctx.paymentId}`,
        metadata: {
          paymentId: ctx.paymentId,
          type: "a2u_settlement",
          timestamp: new Date().toISOString(),
        },
        uid: ctx.merchantUid,
      },
    }

    const createResponse = await fetch("https://api.minepi.com/v2/payments", {
      method: "POST",
      headers: {
        Authorization: `Key ${serverConfig.piApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(requestBody),
    })

    if (!createResponse.ok) {
      const errorText = await createResponse.text()
      let errorData
      try {
        errorData = JSON.parse(errorText)
      } catch {
        errorData = { raw: errorText }
      }

      // Handle ongoing_payment_found
      if (errorData.code === "ongoing_payment_found" || errorText.includes("ongoing_payment")) {
        const ongoingPaymentId = errorData.payment?.identifier || errorData.identifier || errorData.payment_id
        if (typeof ongoingPaymentId === "string" && ongoingPaymentId.trim() !== "" && ongoingPaymentId === ongoingPaymentId.trim()) {
          // R4R: Pi's ongoing identifier is global to the app/user and can belong to a
          // different FlashPay payment. Never attribute it to ctx.paymentId before exact
          // server-side identity binding has been proved.
          const fetchResult = await fetchA2UPayment(ongoingPaymentId)
          const metadata = fetchResult && isRecord(fetchResult.metadata) ? fetchResult.metadata : null
          const exactOngoingIdentity = Boolean(fetchResult && isPiA2UPayment(fetchResult) && isReconciledPiA2UPayment(fetchResult) && metadata?.paymentId === ctx.paymentId && metadata.type === "a2u_settlement" && fetchResult.amount === ctx.customerAmount && fetchResult.direction === "app_to_user" && fetchResult.user_uid === ctx.merchantUid && fetchResult.identifier === ongoingPaymentId && typeof fetchResult.txid !== "string" && typeof fetchResult.transaction_id !== "string" && fetchResult.completed !== true && fetchResult.cancelled !== true && fetchResult.rejected !== true && typeof fetchResult.transaction?.txid !== "string" && fetchResult.transaction?.verified !== true && fetchResult.status?.transaction_verified !== true && fetchResult.status?.developer_completed !== true && fetchResult.status?.cancelled !== true && fetchResult.status?.user_cancelled !== true)
          if (exactOngoingIdentity) {
            const observation = await recordSettlementA2UOngoingObservation(ctx.paymentId, ongoingPaymentId)
            if (observation !== "RECORDED" && observation !== "REPLAYED") return {ok:false,error:"Pi ongoing A2U identifier could not be durably captured",userFacingStatus:"manual_review_required",retryable:false,errorCode:"a2u_ongoing_identifier_capture_unproven"}
            return { ok: true, data: { a2uPaymentId: fetchResult!.identifier, a2uPayment: fetchResult! } }
          }
          if (fetchResult && isPiA2UPayment(fetchResult) && isReconciledPiA2UPayment(fetchResult)) {
            console.warn("[R4R] FOREIGN_ONGOING_PAYMENT", { paymentId: ctx.paymentId, ongoingPaymentId, exactIdentity: false })
            return {ok:false,error:"Pi ongoing A2U belongs to a different FlashPay payment",userFacingStatus:"manual_review_required",retryable:false,errorCode:"a2u_foreign_ongoing_payment"}
          }
        }
        return {ok:false,error:"Pi ongoing A2U requires reconciliation",userFacingStatus:"manual_review_required",retryable:false,errorCode:"a2u_precreate_found_requires_reconciliation"}
      }

      // A failed POST is ambiguous: Pi may have created the A2U before the response was lost.
      // Reconcile before exposing the failure or allowing a later retry. This is the only safe
      // point to decide whether a new A2U may be created.
      const errorCode = typeof errorData.error === "string"
        ? errorData.error
        : typeof errorData.code === "string"
          ? errorData.code
          : undefined
      const errorMessage = typeof errorData.error_message === "string"
        ? errorData.error_message
        : typeof errorData.message === "string"
          ? errorData.message
          : "A2U creation failed"
      const ambiguous = responseStatusRetryable(createResponse.status) || codeIsTooManyPayments(errorData, errorText)
      if (ambiguous) {
        const reconciled = await reconcileIncompleteA2UPayment(ctx.paymentId, ctx.customerAmount, ctx.merchantUid)
        if (reconciled.outcome === "FOUND") {
          const dto = reconciled.dto
          if (dto === undefined || !isReconciledPiA2UPayment(dto) || !isPiA2UPayment(dto)) {
            return { ok:false,error:"Pi found an existing A2U transfer requiring reconciliation",userFacingStatus:"manual_review_required",retryable:false,errorCode:"a2u_precreate_found_requires_reconciliation" }
          }
          const tx = isRecord(dto.transaction) ? dto.transaction : null
          const st = isRecord(dto.status) ? dto.status : null
          if (typeof dto.identifier !== "string" || dto.identifier.trim() === "" || dto.identifier !== dto.identifier.trim() || typeof dto.txid === "string" || typeof dto.transaction_id === "string" || typeof tx?.txid === "string" || dto.completed === true || dto.cancelled === true || dto.rejected === true || tx?.verified === true || st?.transaction_verified === true || st?.developer_completed === true || st?.cancelled === true || st?.user_cancelled === true) {
            return { ok:false,error:"Pi found an existing A2U transfer requiring reconciliation",userFacingStatus:"manual_review_required",retryable:false,errorCode:"a2u_precreate_found_requires_reconciliation" }
          }
          return { ok: true, data: { a2uPaymentId: dto.identifier, a2uPayment: dto } }
        }
        if (reconciled.outcome === "INDETERMINATE") {
          return { ok: false, error: reconciled.reason, userFacingStatus: "manual_review_required", retryable: false, errorCode: "a2u_ambiguous_reconciliation_indeterminate" }
        }
        // DR-20: Pi documents what incomplete_server_payments contains, but does not
        // document an immediate strong-consistency guarantee after an ambiguous failed
        // POST. Therefore CONFIRMED_NONE is not authority to create a second A2U.
        // Hold this payment fail-closed; a 429 still raises global fresh-create
        // backpressure so other payments do not form a retry storm.
        const rateLimitedAmbiguous = createResponse.status === 429 || codeIsTooManyPayments(errorData, errorText)
        return {
          ok: false,
          error: rateLimitedAmbiguous ? "Pi rate-limited an ambiguous A2U create; exact identity is not proven" : "Pi failed an ambiguous A2U create; exact identity is not proven",
          userFacingStatus: "manual_review_required",
          retryable: false,
          errorCode: rateLimitedAmbiguous ? "a2u_rate_limited_post_ambiguous" : "a2u_failed_post_reconciliation_confirmed_none",
          errorBody: errorText.slice(0, 2000),
        }
      }

      console.error("[DR-22 FINANCIAL EVENT]", { event: "a2u_create_failed", paymentId: ctx.paymentId, stage: "pi_create", httpStatus: createResponse.status, errorCode, rateLimited: createResponse.status === 429 || codeIsTooManyPayments(errorData, errorText), failClosed: true })
      const rateLimited = createResponse.status === 429 || codeIsTooManyPayments(errorData, errorText)
      const retryable = responseStatusRetryable(createResponse.status) || rateLimited
      const retryAfterMs = retryable ? parseRetryAfterMs(createResponse.headers.get("retry-after"), Date.now()) : undefined
      return {
        ok: false,
        error: errorMessage,
        userFacingStatus: "error",
        retryable,
        ...(retryAfterMs !== undefined ? { retryAfterMs } : {}),
        errorCode: rateLimited ? "too_many_payments" : errorCode,
        errorBody: errorText.slice(0, 2000),
      }
    }

    let responseData: unknown
    try {
      responseData = await createResponse.json()
    } catch {
      const reconciliation = await reconcileIncompleteA2UPayment(ctx.paymentId, ctx.customerAmount, ctx.merchantUid)
      if (reconciliation.outcome === "FOUND") {
        const dto = reconciliation.dto
        const tx = isRecord(dto?.transaction) ? dto.transaction : null
        const st = isRecord(dto?.status) ? dto.status : null
        if (dto && isReconciledPiA2UPayment(dto) && isPiA2UPayment(dto) && typeof dto.identifier === "string" && dto.identifier.trim() !== "" && dto.identifier === dto.identifier.trim() && typeof dto.txid !== "string" && typeof dto.transaction_id !== "string" && typeof tx?.txid !== "string" && dto.completed !== true && dto.cancelled !== true && dto.rejected !== true && tx?.verified !== true && st?.transaction_verified !== true && st?.developer_completed !== true && st?.cancelled !== true && st?.user_cancelled !== true) {
          return { ok: true, data: { a2uPaymentId: dto.identifier, a2uPayment: dto } }
        }
      }
      return { ok: false, error: 'A2U response could not be parsed; reconciliation did not produce a usable DTO', userFacingStatus: 'error', retryable: false, errorCode: reconciliation.outcome === 'CONFIRMED_NONE' ? 'unparseable_confirmed_none' : reconciliation.outcome === 'FOUND' ? 'unparseable_found_invalid' : 'unparseable_indeterminate' }
    }
    
    // Validate response with type guard - NO CASTS
    if (!isPiA2UPayment(responseData)) {
      console.error("[DR-22 FINANCIAL EVENT]", { event: "a2u_create_invalid_dto", paymentId: ctx.paymentId, stage: "pi_create_response", responseType: responseData === null ? "null" : Array.isArray(responseData) ? "array" : typeof responseData, failClosed: true })
      const reconciliation = await reconcileIncompleteA2UPayment(ctx.paymentId, ctx.customerAmount, ctx.merchantUid)
      if (reconciliation.outcome === "FOUND") {
        const dto = reconciliation.dto
        const tx = isRecord(dto?.transaction) ? dto.transaction : null
        const st = isRecord(dto?.status) ? dto.status : null
        if (dto && isReconciledPiA2UPayment(dto) && isPiA2UPayment(dto) && typeof dto.identifier === "string" && dto.identifier.trim() !== "" && dto.identifier === dto.identifier.trim() && typeof dto.txid !== "string" && typeof dto.transaction_id !== "string" && typeof tx?.txid !== "string" && dto.completed !== true && dto.cancelled !== true && dto.rejected !== true && tx?.verified !== true && st?.transaction_verified !== true && st?.developer_completed !== true && st?.cancelled !== true && st?.user_cancelled !== true) {
          return { ok: true, data: { a2uPaymentId: dto.identifier, a2uPayment: dto } }
        }
      }
      if (reconciliation.outcome === "FOUND") {
        return { ok: false, error: "A2U response invalid; Pi found an existing transfer with an invalid DTO", userFacingStatus: "error", retryable: false, errorCode: "invalid_dto_transfer_invalid" }
      }
      if (reconciliation.outcome === "INDETERMINATE") {
        return { ok: false, error: "A2U response invalid and Pi reconciliation is indeterminate", userFacingStatus: "error", retryable: false, errorCode: "invalid_dto_reconciliation_indeterminate" }
      }
      return { ok: false, error: "A2U response invalid; Pi confirmed no incomplete transfer", userFacingStatus: "error", retryable: false, errorCode: "invalid_dto_confirmed_none" }
    }
    if (!isReconciledPiA2UPayment(responseData)) {
      return {ok:false,error:"A2U binding failed",userFacingStatus:"manual_review_required",retryable:false,errorCode:"invalid_dto_create_response_binding"}
    }
    const md = isRecord(responseData.metadata) ? responseData.metadata : null
    const tx = isRecord(responseData.transaction) ? responseData.transaction : null
    const st = isRecord(responseData.status) ? responseData.status : null
    if (typeof responseData.identifier !== "string" || responseData.identifier.trim() === "" || responseData.identifier !== responseData.identifier.trim() || responseData.amount !== ctx.customerAmount || responseData.direction !== "app_to_user" || responseData.user_uid !== ctx.merchantUid || md?.paymentId !== ctx.paymentId || md?.type !== "a2u_settlement" || typeof responseData.txid === "string" || typeof responseData.transaction_id === "string" || typeof tx?.txid === "string" || responseData.completed === true || responseData.cancelled === true || responseData.rejected === true || tx?.verified === true || st?.transaction_verified === true || st?.developer_completed === true || st?.cancelled === true || st?.user_cancelled === true) {
      return {ok:false,error:"A2U binding failed",userFacingStatus:"manual_review_required",retryable:false,errorCode:"invalid_dto_create_response_binding"}
    }
    
    console.log("[A2U Stage1] ✓ A2U payment created:", responseData.identifier)

    return {
      ok: true,
      data: {
        a2uPaymentId: responseData.identifier,
        a2uPayment: responseData,
      },
    }
  } catch (error) {
    console.error("[A2U Stage1] Exception:", error)
    const reconciled = await reconcileIncompleteA2UPayment(ctx.paymentId, ctx.customerAmount, ctx.merchantUid)
    if (reconciled.outcome === "FOUND") {
      const dto = reconciled.dto
      const tx = isRecord(dto?.transaction) ? dto.transaction : null
      const st = isRecord(dto?.status) ? dto.status : null
      if (dto && isReconciledPiA2UPayment(dto) && isPiA2UPayment(dto) && typeof dto.identifier === "string" && dto.identifier.trim() !== "" && dto.identifier === dto.identifier.trim() && typeof dto.txid !== "string" && typeof dto.transaction_id !== "string" && typeof tx?.txid !== "string" && dto.completed !== true && dto.cancelled !== true && dto.rejected !== true && tx?.verified !== true && st?.transaction_verified !== true && st?.developer_completed !== true && st?.cancelled !== true && st?.user_cancelled !== true) {
        return { ok: true, data: { a2uPaymentId: dto.identifier, a2uPayment: dto } }
      }
      return { ok: false, error: "Pi found an existing A2U transfer requiring reconciliation", userFacingStatus: "manual_review_required", retryable: false, errorCode: "a2u_precreate_found_requires_reconciliation" }
    }
    if (reconciled.outcome === "INDETERMINATE") {
      return { ok: false, error: reconciled.reason, userFacingStatus: "manual_review_required", retryable: false, errorCode: "a2u_network_reconciliation_indeterminate", errorBody: String(error).slice(0, 2000) }
    }
    // DR-20: transport failure means the POST outcome is ambiguous. Pi's public
    // incomplete-server-payments contract does not establish that an immediate
    // absence is a strongly consistent proof that creation did not happen. Never
    // authorize a fresh create from that absence alone.
    return { ok: false, error: "A2U creation network outcome is ambiguous", userFacingStatus: "manual_review_required", retryable: false, errorCode: "a2u_network_reconciliation_confirmed_none", errorBody: String(error).slice(0, 2000) }
  }
}

type Stage2PreparedResult =
  | { ok: true; transaction: StellarSDK.Transaction; preparedHash: string; preparedSequence: string }
  | { ok: false; error: string; userFacingStatus: string }

async function prepareStage2UnderHeldWalletLock(ctx: ExecutorContext, appKeypair: StellarSDK.Keypair, appPublicKey: string, horizonServer: StellarSDK.Horizon.Server, toAddress: string, amount: number, a2uPaymentId: string): Promise<Stage2PreparedResult> {
  console.log("[DR41 STAGE2 DIAGNOSTIC] prepare_enter", { paymentId: ctx.paymentId, amount, exactStroops: numberToExactPositiveStroops(amount), hasToAddress: typeof toAddress === "string" && toAddress.length > 0, hasA2UPaymentId: typeof a2uPaymentId === "string" && a2uPaymentId.length > 0 })
  const sourceAccount = await horizonServer.loadAccount(appPublicKey)
  console.log("[DR41 STAGE2 DIAGNOSTIC] source_account_loaded", { paymentId: ctx.paymentId, sourceSequence: sourceAccount.sequence })
  let feeCharged: number
  try {
    const baseFeeFromHorizon = await horizonServer.fetchBaseFee()
    const baseFeeNumber = Number(baseFeeFromHorizon)
    if (!Number.isFinite(baseFeeNumber) || baseFeeNumber <= 0) return { ok: false, error: "Horizon baseFee is not a valid positive number", userFacingStatus: "error" }
    feeCharged = baseFeeNumber * 2
    console.log("[DR41 STAGE2 DIAGNOSTIC] base_fee_loaded", { paymentId: ctx.paymentId, baseFeeStroops: baseFeeNumber, transactionFeeStroops: feeCharged })
  } catch (feeError) {
    console.error("[A2U Stage2] Failed to fetch Horizon baseFee:", feeError)
    return { ok: false, error: "Failed to fetch Horizon baseFee", userFacingStatus: "error" }
  }
  const feeAsString = String(Math.floor(feeCharged))
  console.log("[A2U Stage2] Building transaction")
  const exactAmountStroops = numberToExactPositiveStroops(amount)
  console.log("[DR41 STAGE2 DIAGNOSTIC] amount_canonicalized", { paymentId: ctx.paymentId, amount, stellarAmount: amount.toFixed(7), exactAmountStroops })
  if (exactAmountStroops === null) {
    console.error("[DR41 STAGE2 DIAGNOSTIC] amount_rejected", { paymentId: ctx.paymentId, amount, stellarAmount: amount.toFixed(7) })
    return { ok: false, error: "Settlement amount is not an exact positive stroop value", userFacingStatus: "error" }
  }
  // Persist the immutable signed intent for independent review BEFORE asking
  // the original certificate-dependent claim. This grants no submission right.
  const candidate = await prepareR36EvidenceCandidate({network:'Pi Testnet',sourceWallet:appPublicKey,
    destinationWallet:toAddress,paymentId:ctx.paymentId,operationKind:'settlement',
    operationId:a2uPaymentId,piPaymentId:a2uPaymentId,amountStroops:String(exactAmountStroops)},
    sourceAccount.sequence,feeAsString,async()=>{
      const t = new StellarSDK.TransactionBuilder(sourceAccount,{fee:feeAsString,networkPassphrase:'Pi Testnet'})
        .addOperation(StellarSDK.Operation.payment({destination:toAddress,asset:StellarSDK.Asset.native(),amount:amount.toFixed(7)}))
        .addMemo(StellarSDK.Memo.text(a2uPaymentId.substring(0,28))).setTimeout(StellarSDK.TimeoutInfinite).build()
      t.sign(appKeypair);return t
    },r36PreparedEvidenceStore,{recipientPublicKeyPem:process.env.FLASHPAY_R36_EVIDENCE_RECIPIENT_PUBLIC_KEY??'',sign:t=>{t.sign(appKeypair)}})
  if(candidate.outcome!=='READY_FOR_ORIGINAL_GUARDS')return {ok:false,error:'Prepared evidence unavailable or changed; hold without resigning',userFacingStatus:'settlement_pending'}
  const transaction=candidate.transaction
  const preparedEnvelopeXdr = transaction.toXDR()
  if (typeof preparedEnvelopeXdr !== "string" || !preparedEnvelopeXdr.trim() || preparedEnvelopeXdr !== preparedEnvelopeXdr.trim()) return { ok: false, error: "Prepared A2U envelope is invalid", userFacingStatus: "error" }
  const preparedHash = Buffer.from(transaction.hash()).toString("hex")
  const preparedSequence = transaction.sequence
  console.log("[DR41 STAGE2 DIAGNOSTIC] prepared_identity", { paymentId: ctx.paymentId, preparedHash, preparedSequence, envelopePresent: preparedEnvelopeXdr.length > 0 })
  if (!/^[0-9a-f]{64}$/.test(preparedHash) || !/^[1-9][0-9]*$/.test(preparedSequence)) return { ok: false, error: "Prepared A2U transaction intent is invalid", userFacingStatus: "error" }
  // R36: claim and prepared evidence must share ONE PostgreSQL transaction.
  // Redis is updated only AFTER this transaction commits successfully.
  const durablePrepared = await withAtomicSettlementPreparedAuthority(ctx.paymentId, async (tx) => {
    const owned = await claimPreparedWalletAuthority({network:'Pi Testnet', sourceWallet:appPublicKey,
      paymentId:ctx.paymentId, operationKind:'settlement', operationId:a2uPaymentId,
      preparedHash, preparedSequence}, tx)
    if (!owned) throw Object.assign(new Error('R36 wallet authority unavailable or occupied'), {code:'R36_PREPARED_AUTHORITY_NOT_ADMITTED'})
    const checkpoint = await recordSettlementPreparedCheckpoint({

    paymentId:ctx.paymentId,merchantId:ctx.payment.merchantId,merchantUid:ctx.merchantUid,
    customerAmount:ctx.customerAmount,merchantAmount:amount,a2uPaymentId,a2uFromAddress:appPublicKey,a2uToAddress:toAddress,
    preparedEnvelopeXdr,preparedTxHash:preparedHash,preparedSequence
    }, tx)
    if (checkpoint.outcome !== 'RECORDED' && checkpoint.outcome !== 'REPLAYED')
      throw Object.assign(new Error('R36 prepared checkpoint rejected; rolling back wallet authority'), {code:'R36_PREPARED_CHECKPOINT_REJECTED'})
    return checkpoint
  })
  console.log("[DR41 STAGE2 DIAGNOSTIC] durable_prepared_outcome", { paymentId: ctx.paymentId, outcome: durablePrepared?.outcome, preparedHash, preparedSequence })
  // A re-entered fresh path must NOT turn an earlier PREPARED identity into
  // another POST. The reconciliation path must inspect the stored XDR via GET.
  if (durablePrepared?.outcome !== "RECORDED")
    return {ok:false,error:durablePrepared?.outcome === 'REPLAYED'
      ? 'Prepared settlement already exists; reconcile without fresh submit'
      : 'Prepared settlement authority or checkpoint not committed; hold without submit',userFacingStatus:"settlement_pending"}
  ctx.payment = await persistCheckpointMerged(ctx.paymentId, { a2uPreparedEnvelopeXdr: preparedEnvelopeXdr, a2uPreparedTxHash: preparedHash, a2uPreparedSequence: preparedSequence, status: "settlement_pending" as const })
  const preparedOwnerReplaced = await replacePiWalletIntent(appPublicKey, { kind: "settlement_claim", paymentId: ctx.paymentId }, { kind: "settlement_prepared", paymentId: ctx.paymentId, preparedHash, preparedSequence })
  console.log("[DR41 STAGE2 DIAGNOSTIC] wallet_intent_replace", { paymentId: ctx.paymentId, preparedOwnerReplaced })
  if (!preparedOwnerReplaced) return { ok: false, error: "Pi wallet prepared intent unavailable", userFacingStatus: "settlement_pending" }
  const preparedOwner = await readPiWalletIntent(appPublicKey)
  console.log("[DR41 STAGE2 DIAGNOSTIC] wallet_intent_read", { paymentId: ctx.paymentId, state: preparedOwner.state, kind: preparedOwner.state === "present" ? preparedOwner.owner.kind : null, ownerMatchesPayment: preparedOwner.state === "present" ? preparedOwner.owner.paymentId === ctx.paymentId : false })
  if (preparedOwner.state !== "present" || preparedOwner.owner.kind !== "settlement_prepared" || preparedOwner.owner.paymentId !== ctx.paymentId || preparedOwner.owner.preparedHash !== preparedHash || preparedOwner.owner.preparedSequence !== preparedSequence) return { ok: false, error: "Pi wallet prepared intent unavailable", userFacingStatus: "settlement_pending" }
  return { ok: true, transaction, preparedHash, preparedSequence }
}

type Stage2MoveResult =
  | { ok: true; txidFromHorizon: string }
  | { ok: false; error: string; userFacingStatus: string }

async function moveStage2UnderHeldWalletLock(horizonServer: StellarSDK.Horizon.Server, transaction: StellarSDK.Transaction, preparedHash: string, verifyOwned: () => Promise<boolean>, authority: WalletAuthorityClaim): Promise<Stage2MoveResult> {
  if (!await verifyOwned()) return { ok: false, error: "Settlement wallet submit ownership lost", userFacingStatus: "settlement_pending" }
  if (transaction.source !== authority.sourceWallet || transaction.sequence !== authority.preparedSequence ||
      Buffer.from(transaction.hash()).toString('hex') !== preparedHash || preparedHash !== authority.preparedHash ||
      !(await claimFirstWalletSubmission(authority)))
    return { ok: false, error: "Settlement durable one-shot submission authority denied", userFacingStatus: "settlement_pending" }
  const submitResult = await horizonServer.submitTransaction(transaction)
  const txidFromHorizon = submitResult.hash
  if (txidFromHorizon !== preparedHash) return { ok: false, error: "Horizon returned a different transaction hash", userFacingStatus: "error" }
  return { ok: true, txidFromHorizon }
}

type Stage2FinalizeResult =
  | { ok: true }
  | { ok: false; status: "settlement_pending"; error: string }

async function finalizeStage2AfterMove(ctx: ExecutorContext, txidFromHorizon: string, horizonFeeCharged: number): Promise<Stage2FinalizeResult> {
  const stage2Updates = {
    status: "settlement_pending" as const,
    a2uTxid: txidFromHorizon,
    customerAmount: ctx.customerAmount,
    horizonFeeCharged,
    horizonSuccessFlag: true,
    horizonSuccessAt: new Date().toISOString(),
    piCompletionPending: true,
    piCompleted: false,
  }
  ctx.payment = await persistCheckpointMerged(ctx.paymentId, stage2Updates)
  const walletIntent = await readPiWalletIntent(ctx.payment.a2uFromAddress)
  if (walletIntent.state === "unavailable") return { ok: false, status: "settlement_pending", error: "Wallet intent cleanup pending" }
  if (walletIntent.state === "present" && walletIntent.owner.paymentId === ctx.paymentId && (walletIntent.owner.kind !== "settlement_prepared" || walletIntent.owner.preparedHash !== ctx.payment.a2uPreparedTxHash || walletIntent.owner.preparedSequence !== ctx.payment.a2uPreparedSequence)) return { ok: false, status: "settlement_pending", error: "Wallet intent cleanup pending" }
  if (walletIntent.state === "present" && walletIntent.owner.paymentId === ctx.paymentId) {
    const cleanupLock = await acquirePiWalletSubmitLock(ctx.payment.a2uFromAddress)
    if (!cleanupLock) return { ok: false, status: "settlement_pending", error: "Wallet intent cleanup pending" }
    try {
      const lockedIntent = await readPiWalletIntent(ctx.payment.a2uFromAddress)
      if (lockedIntent.state === "unavailable") return { ok: false, status: "settlement_pending", error: "Wallet intent cleanup pending" }
      if (lockedIntent.state === "present" && lockedIntent.owner.paymentId === ctx.paymentId && (lockedIntent.owner.kind !== "settlement_prepared" || lockedIntent.owner.preparedHash !== ctx.payment.a2uPreparedTxHash || lockedIntent.owner.preparedSequence !== ctx.payment.a2uPreparedSequence)) return { ok: false, status: "settlement_pending", error: "Wallet intent cleanup pending" }
      if (lockedIntent.state === "present" && lockedIntent.owner.paymentId === ctx.paymentId && !await releasePiWalletIntent(ctx.payment.a2uFromAddress, lockedIntent.owner)) return { ok: false, status: "settlement_pending", error: "Wallet intent cleanup pending" }
    } finally {
      await cleanupLock.release()
    }
  }
  return { ok: true }
}

/**
 * STAGE 2: Sign and submit to Horizon - TYPED DISCRIMINATED UNION
 * Returns { txidFromHorizon, horizonFeeCharged } on success or error with userFacingStatus
 */
async function stage2SignAndSubmit(ctx: ExecutorContext): Promise<Stage2Result> {
  let walletLock: { release: () => Promise<void>; verifyOwned: () => Promise<boolean> } | null = null
  try {
    // CRITICAL: Use ONLY Payment fields (never undefined a2uPayment object parameter)
    const toAddress = ctx.payment.a2uToAddress
    const amount = ctx.payment.merchantAmount
    const a2uPaymentId = ctx.payment.a2uPaymentId
    
    if (!toAddress || typeof toAddress !== 'string') {
      return { ok: false, error: "Payment missing required a2uToAddress", userFacingStatus: "error" }
    }
    if (typeof amount !== 'number' || !Number.isFinite(amount)) {
      return { ok: false, error: "Payment missing required merchantAmount", userFacingStatus: "error" }
    }
    if (!a2uPaymentId || typeof a2uPaymentId !== 'string') {
      return { ok: false, error: "Payment missing required a2uPaymentId", userFacingStatus: "error" }
    }
    
    if (ctx.payment.a2uPreparedTxHash !== undefined || ctx.payment.a2uPreparedSequence !== undefined || ctx.payment.a2uPreparedEnvelopeXdr !== undefined) {
      return { ok: false, error: "Payment has a prepared A2U transaction requiring reconciliation", userFacingStatus: "settlement_pending" }
    }

    const piPrivateSeed = getPiSigningSeed()
    if (!piPrivateSeed) {
      console.error("[A2U Stage2] Pi wallet signing configuration unavailable or invalid")
      // DO NOT set horizonSuccessFlag=true or persist a2uTxid on failure
      return { ok: false, error: "Pi wallet signing configuration unavailable or invalid", userFacingStatus: "settlement_pending" }
    }

    console.log("[A2U Stage2] Creating Stellar keypair")
    const appKeypair = StellarSDK.Keypair.fromSecret(piPrivateSeed)
    const appPublicKey = appKeypair.publicKey()

    if (appPublicKey !== ctx.payment.a2uFromAddress) {
      console.error("[A2U Stage2] Address mismatch")
      return { ok: false, error: "Private seed does not match app wallet address", userFacingStatus: "error" }
    }

    console.log("[DR41 STAGE2 DIAGNOSTIC] wallet_lock_request", { paymentId: ctx.paymentId, status: ctx.payment.status, isRecovery: ctx.isRecovery, recoveryOperation: ctx.recoveryOperation ?? null, hasPreparedEvidence: ctx.payment.a2uPreparedTxHash !== undefined || ctx.payment.a2uPreparedSequence !== undefined || ctx.payment.a2uPreparedEnvelopeXdr !== undefined })
    walletLock = await acquirePiWalletIntentSubmitLock(appPublicKey, { kind: "settlement_claim", paymentId: ctx.paymentId })
    console.log("[DR41 STAGE2 DIAGNOSTIC] wallet_lock_result", { paymentId: ctx.paymentId, acquired: walletLock !== null })
    if (!walletLock) return { ok: false, error: "Pi wallet submit lock unavailable", userFacingStatus: "settlement_pending" }

    console.log("[A2U Stage2] Connecting to Horizon")
    const horizonServer = new StellarSDK.Horizon.Server("https://api.testnet.minepi.com", { allowHttp: false })
    const prepared = await prepareStage2UnderHeldWalletLock(ctx, appKeypair, appPublicKey, horizonServer, toAddress, amount, a2uPaymentId)
    if (!prepared.ok) {
      console.error("[DR41 STAGE2 DIAGNOSTIC] prepare_failed", { paymentId: ctx.paymentId, error: prepared.error, userFacingStatus: prepared.userFacingStatus })
      return prepared
    }
    console.log("[DR41 STAGE2 DIAGNOSTIC] prepare_succeeded", { paymentId: ctx.paymentId, preparedHash: prepared.preparedHash, preparedSequence: prepared.preparedSequence })
    const { transaction, preparedHash } = prepared

    // Preparation deliberately runs without a scoped submission right. Return
    // to resumeAdmittedRecovery, which immediately reselects THIS committed
    // payment through the original SQL guard. Never manufacture a right here
    // or attempt a send that claimFirstWalletSubmission must reject.
    if (process.env.FLASHPAY_RECOVERY_SCOPE === 'admitted_new' && !currentRecoveryRight()) {
      return {ok:false,userFacingStatus:'settlement_pending',
        error:'Settlement preparation recorded; scoped recovery selection required',
        waitCode:'R36_SCOPED_CONTINUATION_REQUIRED'}
    }

    console.log("[DR41 STAGE2 DIAGNOSTIC] horizon_submit_about_to_start", { paymentId: ctx.paymentId, preparedHash, preparedSequence: transaction.sequence })
    console.log("[A2U Stage2] Submitting to Horizon")
    let moved: Stage2MoveResult
    let reconciledSubmitFeeStroops: number | null = null
    try {
      moved = await moveStage2UnderHeldWalletLock(horizonServer, transaction, preparedHash, () => walletLock!.verifyOwned(), {
        network: 'Pi Testnet', sourceWallet: appPublicKey,
        paymentId: ctx.paymentId, operationKind: 'settlement', operationId: a2uPaymentId,
        preparedHash, preparedSequence: transaction.sequence,
      })
    } catch (submitError) {
      // R100-7: a transport exception after submit is ambiguous. Reconcile the exact
      // prepared hash immediately via the existing GET-only Horizon proof path; never
      // submit again from this branch. Anything short of exact movement proof stays pending.
      console.warn("[R100-7 SETTLEMENT HORIZON IMMEDIATE RECONCILIATION] submit exception", {
        paymentId: ctx.paymentId,
        preparedHash,
        preparedSequence: transaction.sequence,
        error: submitError instanceof Error ? submitError.message : "unknown",
      })
      const reconciled = await executeFinancialRecoverySettlementSubmitReplay({ payment: ctx.payment, paymentId: ctx.paymentId })
      const feeStroops = reconciled.outcome === "MOVEMENT_VERIFIED"
        ? Math.round(reconciled.horizonFeeCharged * 10_000_000)
        : Number.NaN
      if (
        reconciled.outcome !== "MOVEMENT_VERIFIED" ||
        reconciled.moneyMovementProven !== true ||
        reconciled.authorizesFinancialAction !== false ||
        reconciled.paymentId !== ctx.paymentId ||
        reconciled.merchantUid !== ctx.merchantUid ||
        reconciled.reference.preparedHash !== preparedHash ||
        reconciled.reference.preparedSequence !== transaction.sequence ||
        reconciled.reference.a2uPaymentId !== a2uPaymentId ||
        reconciled.reference.fromAddress !== appPublicKey ||
        reconciled.reference.toAddress !== toAddress ||
        reconciled.reference.amount !== amount ||
        reconciled.reference.envelopeXdr !== transaction.toXDR() ||
        !Number.isFinite(reconciled.horizonFeeCharged) ||
        reconciled.horizonFeeCharged < 0 ||
        !Number.isSafeInteger(feeStroops) ||
        feeStroops < 0 ||
        feeStroops / 10_000_000 !== reconciled.horizonFeeCharged
      ) {
        return { ok: false, error: "Horizon submit outcome remains unverified", userFacingStatus: "settlement_pending" }
      }
      reconciledSubmitFeeStroops = feeStroops
      moved = { ok: true, txidFromHorizon: preparedHash }
      console.log("[R100-7 SETTLEMENT HORIZON IMMEDIATE RECONCILIATION] exact movement verified", {
        paymentId: ctx.paymentId, preparedHash, preparedSequence: transaction.sequence, feeStroops,
      })
    }
    if (!moved.ok) {
      console.error("[DR41 STAGE2 DIAGNOSTIC] horizon_move_failed", { paymentId: ctx.paymentId, error: moved.error, userFacingStatus: moved.userFacingStatus, preparedHash, preparedSequence: transaction.sequence })
      return moved
    }
    const txidFromHorizon = moved.txidFromHorizon
    console.log("[A2U Stage2] ✓ Horizon submission succeeded:", txidFromHorizon)
    
    // Fetch the typed transaction record from Horizon to read actual fee_charged
    console.log("[A2U Stage2] Fetching transaction record for fee verification")
    const transactionRecord = reconciledSubmitFeeStroops === null
      ? await horizonServer.transactions().transaction(txidFromHorizon).call()
      : null
    
    // Validate fee_charged is number or string (stroops). On the R100-7 ambiguity
    // branch this fee already came from the exact GET-only Horizon proof above.
    const feeChargedStroops = reconciledSubmitFeeStroops ?? transactionRecord?.fee_charged
    if (typeof feeChargedStroops !== 'number' && typeof feeChargedStroops !== 'string') {
      return { ok: false, error: "Horizon transaction has invalid fee_charged type", userFacingStatus: "error" }
    }
    
    const feeChargedAsNumber = Number(feeChargedStroops)
    if (!Number.isFinite(feeChargedAsNumber) || feeChargedAsNumber < 0) {
      return { ok: false, error: "Horizon transaction fee_charged is not a finite nonnegative number", userFacingStatus: "error" }
    }
    
    // Convert stroops to Pi (1 Pi = 10,000,000 stroops)
    if (!Number.isSafeInteger(feeChargedAsNumber)) {
      return { ok: false, error: "Horizon transaction fee_charged is not an exact integer stroop value", userFacingStatus: "error" }
    }
    const horizonFeeCharged = feeChargedAsNumber / 10_000_000
    const durableHorizon = await recordSettlementHorizonCheckpoint({
      paymentId:ctx.paymentId,a2uPaymentId,preparedTxHash:preparedHash,preparedSequence:transaction.sequence,
      a2uTxid:txidFromHorizon,horizonFeeStroops:feeChargedAsNumber
    })
    if(durableHorizon.outcome!=="RECORDED"&&durableHorizon.outcome!=="REPLAYED")
      return {ok:false,error:"Horizon durable checkpoint not proven",userFacingStatus:"settlement_pending"}
    
    console.log("[A2U Stage2] ✓ Fee verified from Horizon:", horizonFeeCharged)
    // Return txid and fee for persisting in executeA2U
    return { 
      ok: true,
      data: {
        txidFromHorizon,
        horizonFeeCharged,
      },
    }
  } catch (error) {
    const e = error as { name?: unknown; message?: unknown; code?: unknown; response?: { status?: unknown; data?: { extras?: { result_codes?: unknown } } } }
    console.error("[DR41 STAGE2 DIAGNOSTIC] exception", {
      paymentId: ctx.paymentId,
      name: typeof e?.name === "string" ? e.name : null,
      message: typeof e?.message === "string" ? e.message.slice(0, 500) : String(error).slice(0, 500),
      code: typeof e?.code === "string" || typeof e?.code === "number" ? e.code : null,
      httpStatus: typeof e?.response?.status === "number" ? e.response.status : null,
      horizonResultCodes: e?.response?.data?.extras?.result_codes ?? null,
      stage: ctx.payment.a2uPreparedTxHash ? "post_prepared" : "pre_prepared",
    })
    console.error("[A2U Stage2] Exception:", error)
    return { ok: false, error: String(error), userFacingStatus: "error" }
  } finally {
    if (walletLock) {
      try {
        const currentIntent = await readPiWalletIntent(ctx.payment.a2uFromAddress)
        if (currentIntent.state === "present" && currentIntent.owner.kind === "settlement_claim" && currentIntent.owner.paymentId === ctx.paymentId) {
          const rawPayment = await redis.get(`payment:${ctx.paymentId}`)
          const parsed = typeof rawPayment === "string" ? JSON.parse(rawPayment) : rawPayment
          if (isRecord(parsed) && !Array.isArray(parsed) && parsed.id === ctx.paymentId && parsed.a2uFromAddress === ctx.payment.a2uFromAddress && parsed.a2uPreparedEnvelopeXdr === undefined && parsed.a2uPreparedTxHash === undefined && parsed.a2uPreparedSequence === undefined) {
            await releasePiWalletIntent(ctx.payment.a2uFromAddress, { kind: "settlement_claim", paymentId: ctx.paymentId })
          }
        }
      } catch {
        // Keep the durable claim when cleanup reads, parsing, or release are uncertain.
      } finally {
        await walletLock.release()
      }
    }
  }
}

type RecoveredHorizonDurabilityResult =
  | { ok: true; durableOutcome: "RECORDED" | "REPLAYED"; horizonFeeCharged: number }
  | { ok: false; error: string }

async function ensureRecoveredHorizonDurability(
  ctx: ExecutorContext,
  a2uPaymentId: string,
  a2uTxid: string,
): Promise<RecoveredHorizonDurabilityResult> {
  if (!ctx.isRecovery || !/^[0-9a-f]{64}$/.test(a2uTxid)) {
    return { ok: false, error: "Recovered Horizon durable checkpoint identity invalid" }
  }
  const durable = await getSettlementCheckpointAuthoritative(ctx.paymentId)
  if (durable.outcome !== "FOUND") {
    return { ok: false, error: "Recovered Horizon durable authority unavailable" }
  }
  let d = durable.checkpoint
  if (
    d.paymentId !== ctx.paymentId ||
    d.merchantId !== ctx.payment.merchantId ||
    d.merchantUid !== ctx.merchantUid ||
    d.customerAmount !== ctx.customerAmount ||
    d.merchantAmount !== ctx.customerAmount ||
    d.a2uPaymentId !== a2uPaymentId ||
    d.a2uFromAddress !== ctx.payment.a2uFromAddress ||
    d.a2uToAddress !== ctx.payment.a2uToAddress
  ) {
    return { ok: false, error: "Recovered Horizon durable identity mismatch" }
  }

  if (d.stage === "prepared") {
    if (
      d.preparedTxHash !== a2uTxid ||
      typeof d.preparedSequence !== "string" || !/^[1-9][0-9]*$/.test(d.preparedSequence) ||
      typeof d.preparedEnvelopeXdr !== "string" || d.preparedEnvelopeXdr.trim() === "" || d.preparedEnvelopeXdr !== d.preparedEnvelopeXdr.trim()
    ) {
      return { ok: false, error: "Recovered Horizon prepared authority mismatch" }
    }
    try {
      const horizonServer = new StellarSDK.Horizon.Server("https://api.testnet.minepi.com", { allowHttp: false })
      const transactionRecord = await horizonServer.transactions().transaction(a2uTxid).call()
      const record = transactionRecord as unknown as Record<string, unknown>
      if (record.hash !== a2uTxid || record.successful !== true) {
        return { ok: false, error: "Recovered Horizon transaction proof mismatch" }
      }
      const feeRaw = record.fee_charged
      if (typeof feeRaw !== "number" && typeof feeRaw !== "string") {
        return { ok: false, error: "Recovered Horizon fee proof invalid" }
      }
      const feeStroops = Number(feeRaw)
      if (!Number.isSafeInteger(feeStroops) || feeStroops < 0) {
        return { ok: false, error: "Recovered Horizon fee proof invalid" }
      }
      const durableHorizon = await recordSettlementHorizonCheckpoint({
        paymentId: ctx.paymentId,
        a2uPaymentId,
        preparedTxHash: d.preparedTxHash,
        preparedSequence: d.preparedSequence,
        a2uTxid,
        horizonFeeStroops: feeStroops,
      })
      if (durableHorizon.outcome !== "RECORDED" && durableHorizon.outcome !== "REPLAYED") {
        return { ok: false, error: "Recovered Horizon durable checkpoint not proven" }
      }
      const horizonFeeCharged = feeStroops / 10_000_000
      ctx.payment = await persistCheckpointMerged(ctx.paymentId, {
        status: "settlement_pending",
        a2uTxid,
        horizonSuccessFlag: true,
        horizonFeeCharged,
        piCompletionPending: ctx.payment.piCompleted === true ? false : true,
      })
      console.log("[F2-7 DURABLE HORIZON RESUME]", {
        paymentId: ctx.paymentId,
        a2uPaymentId,
        a2uTxid,
        durableOutcome: durableHorizon.outcome,
        horizonFeeCharged,
      })
      return { ok: true, durableOutcome: durableHorizon.outcome, horizonFeeCharged }
    } catch (error) {
      console.error("[F2-7 DURABLE HORIZON RESUME] Horizon proof uncertain", error)
      return { ok: false, error: "Recovered Horizon transaction proof uncertain" }
    }
  }

  if (d.stage === "horizon_confirmed" || d.stage === "pi_completed" || d.stage === "db_finalized") {
    if (
      d.preparedTxHash !== a2uTxid ||
      d.a2uTxid !== a2uTxid ||
      typeof d.preparedSequence !== "string" || !/^[1-9][0-9]*$/.test(d.preparedSequence) ||
      typeof d.horizonFeeStroops !== "number" || !Number.isSafeInteger(d.horizonFeeStroops) || d.horizonFeeStroops < 0
    ) {
      return { ok: false, error: "Recovered Horizon durable evidence mismatch" }
    }
    const durableHorizon = await recordSettlementHorizonCheckpoint({
      paymentId: ctx.paymentId,
      a2uPaymentId,
      preparedTxHash: d.preparedTxHash,
      preparedSequence: d.preparedSequence,
      a2uTxid,
      horizonFeeStroops: d.horizonFeeStroops,
    })
    if (durableHorizon.outcome !== "RECORDED" && durableHorizon.outcome !== "REPLAYED") {
      return { ok: false, error: "Recovered Horizon durable checkpoint not proven" }
    }
    // Recover the remote-complete/local-checkpoint gap using a fresh read, never Redis authority.
    if (d.stage === "horizon_confirmed") {
      const matchesCompletionProof = (value: unknown, completed: boolean): boolean => {
        if (!isReconciledPiA2UPayment(value) || !isPiA2UPayment(value)) return false
        return value.identifier === d.a2uPaymentId && value.network === "Pi Testnet" &&
          value.direction === "app_to_user" && value.user_uid === d.merchantUid &&
          value.amount === d.merchantAmount && value.from_address === d.a2uFromAddress &&
          value.to_address === d.a2uToAddress && value.metadata?.paymentId === d.paymentId &&
          value.metadata?.type === "a2u_settlement" && value.transaction?.txid === d.a2uTxid &&
          value.transaction?.verified === true && value.status?.transaction_verified === true &&
          value.status?.developer_approved === true && value.status?.developer_completed === completed &&
          value.status?.cancelled === false && value.status?.user_cancelled === false
      }
      let proof = await fetchA2UPayment(a2uPaymentId)
      // Pi can leave transaction=null until /complete binds the accepted Horizon txid.
      // This DTO proves identity only; the exact durable XDR must be proven on Horizon.
      const unlinkedIncomplete = isReconciledPiA2UPayment(proof) && isPiA2UPayment(proof) &&
        proof.identifier === d.a2uPaymentId && proof.network === "Pi Testnet" &&
        proof.direction === "app_to_user" && proof.user_uid === d.merchantUid &&
        proof.amount === d.merchantAmount && proof.from_address === d.a2uFromAddress &&
        proof.to_address === d.a2uToAddress && proof.metadata?.paymentId === d.paymentId &&
        proof.metadata?.type === "a2u_settlement" && proof.transaction === null &&
        proof.status?.transaction_verified === false && proof.status?.developer_approved === true &&
        proof.status?.developer_completed === false && proof.status?.cancelled === false &&
        proof.status?.user_cancelled === false
      if (matchesCompletionProof(proof, false) || unlinkedIncomplete) {
        // An unproven monotonic Redis completion flag cannot authorize a new mutation.
        if (ctx.payment.piCompleted === true) {
          return { ok: false, error: "Recovered Pi completion conflicts with independent incomplete evidence" }
        }
        if (unlinkedIncomplete) {
          if (typeof d.preparedEnvelopeXdr !== "string" || numberToExactPositiveStroops(d.merchantAmount) === null) {
            return { ok: false, error: "Recovered Pi completion prepared evidence invalid" }
          }
          const horizon = await readR36IndependentHorizonProof({
            network: "Pi Testnet", preparedHash: d.preparedTxHash, preparedSequence: d.preparedSequence,
            sourceWallet: d.a2uFromAddress, destinationWallet: d.a2uToAddress,
            amount: d.merchantAmount.toFixed(7), envelopeXdr: d.preparedEnvelopeXdr,
            expectedFeeStroops: String(d.horizonFeeStroops),
          })
          if (horizon.outcome !== "PROVEN") {
            return { ok: false, error: "Recovered Pi completion independent Horizon proof unavailable or mismatched" }
          }
        }
        // Existing durable one-shot claim authorizes only a previously unattempted completion.
        // A prior/ambiguous attempt is GET-only and fails closed until completion is proven.
        const resumed = await stage3CompletePi(ctx, a2uPaymentId, a2uTxid)
        if (!resumed.ok) return { ok: false, error: resumed.error }
        proof = await fetchA2UPayment(a2uPaymentId)
      }
      if (!matchesCompletionProof(proof, true)) {
        return { ok: false, error: "Recovered Pi completion independent proof unavailable or mismatched" }
      }
      const completion = await recordSettlementPiCompletedCheckpoint({ paymentId: d.paymentId, a2uPaymentId, a2uTxid })
      if (completion.outcome !== "RECORDED" && completion.outcome !== "REPLAYED") {
        return { ok: false, error: "Recovered Pi completion durable transition unproven" }
      }
      const refreshed = await getSettlementCheckpointAuthoritative(ctx.paymentId)
      if (refreshed.outcome !== "FOUND" ||
          !["pi_completed", "db_finalized"].includes(refreshed.checkpoint.stage) ||
          refreshed.checkpoint.a2uPaymentId !== a2uPaymentId || refreshed.checkpoint.a2uTxid !== a2uTxid ||
          refreshed.checkpoint.preparedTxHash !== d.preparedTxHash ||
          refreshed.checkpoint.merchantId !== d.merchantId || refreshed.checkpoint.merchantUid !== d.merchantUid ||
          refreshed.checkpoint.customerAmount !== d.customerAmount || refreshed.checkpoint.merchantAmount !== d.merchantAmount ||
          refreshed.checkpoint.a2uFromAddress !== d.a2uFromAddress || refreshed.checkpoint.a2uToAddress !== d.a2uToAddress ||
          refreshed.checkpoint.preparedSequence !== d.preparedSequence ||
          typeof refreshed.checkpoint.horizonFeeStroops !== "number" || !Number.isSafeInteger(refreshed.checkpoint.horizonFeeStroops) ||
          refreshed.checkpoint.horizonFeeStroops < 0 || refreshed.checkpoint.horizonFeeStroops !== d.horizonFeeStroops) {
        return { ok: false, error: "Recovered Pi completion durable readback mismatch" }
      }
      d = refreshed.checkpoint
    }
    // Redis is only a projection. A stale piCompleted=true must never promote
    // horizon_confirmed to pi_completed through the Stage 3 replay branch.
    // Fail closed rather than attempting to downgrade monotonic Redis evidence.
    if (d.stage === "horizon_confirmed" && ctx.payment.piCompleted === true) {
      return { ok: false, error: "Recovered Pi completion conflicts with durable PostgreSQL stage" }
    }
    if (typeof d.horizonFeeStroops !== "number" || !Number.isSafeInteger(d.horizonFeeStroops) || d.horizonFeeStroops < 0) {
      return { ok: false, error: "Recovered Horizon durable fee unavailable" }
    }
    const horizonFeeCharged = d.horizonFeeStroops / 10_000_000
    ctx.payment = await persistCheckpointMerged(ctx.paymentId, {
      status: d.stage === "db_finalized" ? "settled_to_merchant" : "settlement_pending",
      a2uTxid,
      horizonSuccessFlag: true,
      horizonFeeCharged,
      piCompletionPending: d.stage === "horizon_confirmed",
      piCompleted: d.stage === "pi_completed" || d.stage === "db_finalized",
      requiresDbReconciliation: d.stage === "pi_completed",
      dbRecorded: d.stage === "db_finalized",
    })
    return { ok: true, durableOutcome: durableHorizon.outcome, horizonFeeCharged }
  }

  return { ok: false, error: "Recovered Horizon durable stage invalid" }
}


/**
 * STAGE 3: Call Pi /complete - TYPED DISCRIMINATED UNION
 * Returns no-data success or error with userFacingStatus
 */
async function stage3CompletePi(ctx: ExecutorContext, a2uPaymentId: string, txidFromHorizon: string): Promise<Stage3Result> {
  const verifyCompletedDto = (value: unknown): boolean => {
    if (!isReconciledPiA2UPayment(value) || !isPiA2UPayment(value)) return false
    const md = isRecord(value.metadata) ? value.metadata : null
    const tx = isRecord(value.transaction) ? value.transaction : null
    const st = isRecord(value.status) ? value.status : null
    return value.identifier === a2uPaymentId && value.amount === ctx.customerAmount && value.direction === "app_to_user" && value.user_uid === ctx.merchantUid && md?.paymentId === ctx.paymentId && md?.type === "a2u_settlement" && tx?.txid === txidFromHorizon && tx?.verified === true && st?.transaction_verified === true && st?.developer_completed === true && st?.cancelled !== true && st?.user_cancelled !== true
  }

  const refetchCompleted = async (): Promise<boolean> => verifyCompletedDto(await fetchA2UPayment(a2uPaymentId))

  try {
    if (await refetchCompleted()) return { ok: true }
    const completionAttempt = await claimSettlementPiMutationAttempt({ kind: "a2u_complete", paymentId: ctx.paymentId, externalPaymentId: a2uPaymentId, txid: txidFromHorizon })
    if (completionAttempt.outcome !== "RECORDED") {
      if (await refetchCompleted()) return { ok: true }
      return { ok: false, error: "Pi /complete attempt is reconcile-only", userFacingStatus: "settlement_pending" }
    }
    console.log("[A2U Stage3] Calling Pi /v2/payments/complete")

    const response = await fetch(`https://api.minepi.com/v2/payments/${a2uPaymentId}/complete`, {
      method: "POST",
      headers: {
        Authorization: `Key ${serverConfig.piApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ txid: txidFromHorizon }),
    })

    if (!response.ok) {
      const errorText = await response.text()
      // Any failed /complete response can be ambiguous: Pi may have completed the payment
      // before the error response was observed. Reconcile the exact payment/txid first;
      // never retry /complete blindly.
      if (await refetchCompleted()) {
        console.log("[A2U Stage3] Pi /complete non-OK response reconciled as completed")
        return { ok: true }
      }
      if (response.status === 400 && errorText.includes("already_completed")) {
        return { ok: false, error: "Pi already_completed state unverified", userFacingStatus: "settlement_pending" }
      }
      console.error("[A2U Stage3] Pi /complete failed and completion was not verified:", errorText)
      return {
        ok: false,
        error: "Pi /complete failed and completion was not verified",
        userFacingStatus: responseStatusRetryable(response.status) ? "settlement_pending" : "error",
      }
    }

    const responseBody: unknown = await response.clone().json().catch(() => null)
    if (!verifyCompletedDto(responseBody) && !await refetchCompleted()) {
      return { ok: false, error: "Pi /complete success state unverified", userFacingStatus: "settlement_pending" }
    }

    console.log("[A2U Stage3] ✓ Pi /complete succeeded and verified")
    return { ok: true }
  } catch (error) {
    console.error("[A2U Stage3] /complete transport exception; reconciling exact completion state:", error)
    if (await refetchCompleted()) {
      console.log("[A2U Stage3] Pi /complete transport exception reconciled as completed")
      return { ok: true }
    }
    return { ok: false, error: "Pi /complete transport outcome unverified", userFacingStatus: "settlement_pending" }
  }
}

/**
 * STAGE 4: Reconcile in database
 * STRICT: Validate ALL fields before transaction entry, NO fallbacks
 * TYPED DISCRIMINATED UNION
 */
async function stage4ReconcileDB(ctx: ExecutorContext, txidFromHorizon: string): Promise<Stage4Result> {
  try {
    console.log("[A2U Stage4] Reconciling database")

    // CRITICAL: Reload latest payment record from Redis before validation
    // Ensures every field is from the authoritative checkpoint where it was persisted
    const latestPaymentData = await redis.get(`payment:${ctx.paymentId}`)
    if (!latestPaymentData) {
      console.error("[A2U Stage4] Cannot reload payment record from Redis - checkpoint may be corrupted")
      return { ok: false, error: "Payment record not found in Redis - cannot proceed to DB", userFacingStatus: "error" }
    }

    let latestPayment: Payment
    try {
      latestPayment = typeof latestPaymentData === "string" ? JSON.parse(latestPaymentData) : latestPaymentData
    } catch (parseErr) {
      console.error("[A2U Stage4] Failed to parse payment record from Redis:", parseErr)
      return { ok: false, error: "Payment record corrupted in Redis - cannot proceed to DB", userFacingStatus: "error" }
    }

    console.log("[A2U Stage4] Reloaded latest payment record from Redis checkpoint")

    // STRICT: Validate financial data first - will reject on missing values
    const validation = validateFinancialData(latestPayment)
    if (!validation.success) {
      console.error("[A2U Stage4] Financial validation failed:", validation.error)
      // Preserve checkpoint for DB-only recovery by not updating stale ctx.payment
      return { ok: false, error: validation.error, userFacingStatus: "error" }
    }

    const financialData = validation.data

    console.log("[A2U Stage4] All financial fields validated from Redis checkpoint - proceeding to DB:")
    console.log("[A2U Stage4]   - piPaymentId:", financialData.piPaymentId)
    console.log("[A2U Stage4]   - u2aTxid:", financialData.u2aTxid)
    console.log("[A2U Stage4]   - a2uPaymentId:", financialData.a2uPaymentId)
    console.log("[A2U Stage4]   - a2uTxid:", financialData.a2uTxid)
    console.log("[A2U Stage4]   - customerAmount:", financialData.customerAmount)
    console.log("[A2U Stage4]   - merchantAmount:", financialData.merchantAmount)
    console.log("[A2U Stage4]   - horizonFeeCharged:", financialData.horizonFeeCharged)
    console.log("[A2U Stage4]   - appCommission:", financialData.appCommission)

    // Call DB with VALIDATED financial data only
    // CRITICAL: Pass ONLY validated identifiers from financialData
    const dbResult = await recordA2UTransactionAtomic({
      paymentId: ctx.paymentId,
      u2aIdentifier: financialData.piPaymentId,
      u2aTxid: financialData.u2aTxid,
      a2uIdentifier: financialData.a2uPaymentId,
      a2uTxid: financialData.a2uTxid,
      merchantId: financialData.merchantId,
      merchantUid: financialData.merchantUid,
      customerAmount: financialData.customerAmount,
      merchantAmount: financialData.merchantAmount,
      horizonFeeCharged: financialData.horizonFeeCharged,
      appCommission: financialData.appCommission,
    })

    if (!dbResult || !dbResult.success) {
      console.error("[A2U Stage4] DB reconciliation failed:", dbResult?.error)
      // Preserve failure state for recovery using monotonic merge
      try {
        await persistCheckpointMerged(ctx.paymentId, {
          status: "settlement_pending",
          dbRecorded: false,
          requiresDbReconciliation: true,
        })
        console.log("[A2U Stage4] Persisted settlement_pending with dbRecorded=false and requiresDbReconciliation=true via persistCheckpointMerged")
        // Only return settlement_pending if recovery checkpoint was successfully stored
        return { ok: false, error: dbResult?.error || "Unknown DB error", userFacingStatus: "settlement_pending" }
      } catch (persistErr) {
        // Persistence failed - propagate error, do NOT return settlement_pending
        const persistError = persistErr instanceof Error ? persistErr.message : String(persistErr)
        console.error("[A2U Stage4] CRITICAL: Failed to persist recovery checkpoint on DB failure:", persistError)
        return { ok: false, error: `DB failure AND recovery checkpoint persistence failed: ${persistError}`, userFacingStatus: "error" }
      }
    }

    console.log("[A2U Stage4] ✓ DB reconciliation succeeded with transaction ID:", dbResult.transactionId)
    // Return ok: true with transaction identifiers for boundary verification
    return { 
      ok: true, 
      transactionId: dbResult.transactionId,
      transaction: dbResult.transaction
    }
  } catch (error) {
    console.error("[A2U Stage4] Exception:", error)
    return { ok: false, error: String(error), userFacingStatus: "error" }
  }
}

/**
 * Crash-safe, strictly monotonic checkpoint merge and persist
 * Returns the fully merged record on success; throws on failure to stop workflow immediately.
 * CRITICAL: If persistence fails, caller must stop all further execution and return error.
 * Reloads latest record and merges to ensure:
 * - Terminal markers (a2uPaymentId, a2uTxid, horizonSuccessFlag, piCompleted, dbRecorded) never unset
 * - Original timestamps preserved (horizonSuccessAt, paidAt, settledAt never downgraded)
 * - Conflicting identifiers fail safely
 * - settled_to_merchant never regresses
 * - Merge is strictly monotonic and irreversible
 */
export async function persistCheckpointMerged(
  paymentId: string,
  updates: Partial<Payment>,
  casAttempt = 0,
): Promise<Payment> {
  if (!isRedisConfigured) {
    const msg = "[A2U Checkpoint] Redis not configured - cannot persist checkpoint"
    console.error(msg)
    throw new Error(msg)
  }

  try {
    // Reload latest record to merge with new evidence
    const latestData = await redis.get(`payment:${paymentId}`)
    if (!latestData) {
      const msg = "[A2U Checkpoint] Cannot reload payment after modification - data may be corrupted"
      console.error(msg)
      throw new Error(msg)
    }

    const latest: Payment = typeof latestData === "string" ? JSON.parse(latestData) : latestData
    if (latest.id !== paymentId) throw new Error("[A2U Checkpoint] Payment identity mismatch")
    if (updates.id !== undefined && updates.id !== paymentId) throw new Error("[A2U Checkpoint] Payment identity mismatch")

    // STRICT MONOTONICITY: Build merged record preserving all terminal evidence
    const merged: Payment = { ...latest }

    // Enforce immutable terminal markers (never unset once true)
    // Conflicting a2uPaymentId must fail immediately - stop workflow
    if (latest.a2uPaymentId && updates.a2uPaymentId && latest.a2uPaymentId !== updates.a2uPaymentId) {
      const msg = `[A2U Checkpoint] FATAL: Conflicting a2uPaymentId - existing="${latest.a2uPaymentId}" vs new="${updates.a2uPaymentId}" - workflow stopped`
      console.error(msg)
      throw new Error(msg)
    }
    if (updates.a2uPaymentId) {
      merged.a2uPaymentId = updates.a2uPaymentId
    }

    // Conflicting a2uTxid must fail immediately - stop workflow
    if (latest.a2uPreparedEnvelopeXdr !== undefined && updates.a2uPreparedEnvelopeXdr !== undefined && latest.a2uPreparedEnvelopeXdr !== updates.a2uPreparedEnvelopeXdr) {
      throw new Error(`[A2U Checkpoint] FATAL: Conflicting a2uPreparedEnvelopeXdr`)
    }
    if (latest.a2uPreparedEnvelopeXdr !== undefined) merged.a2uPreparedEnvelopeXdr = latest.a2uPreparedEnvelopeXdr
    if (updates.a2uPreparedEnvelopeXdr !== undefined) merged.a2uPreparedEnvelopeXdr = updates.a2uPreparedEnvelopeXdr

    if (latest.a2uPreparedTxHash !== undefined && updates.a2uPreparedTxHash !== undefined && latest.a2uPreparedTxHash !== updates.a2uPreparedTxHash) {
      throw new Error(`[A2U Checkpoint] FATAL: Conflicting a2uPreparedTxHash`)
    }
    if (latest.a2uPreparedSequence !== undefined && updates.a2uPreparedSequence !== undefined && latest.a2uPreparedSequence !== updates.a2uPreparedSequence) {
      throw new Error(`[A2U Checkpoint] FATAL: Conflicting a2uPreparedSequence`)
    }
    if (latest.a2uPreparedTxHash !== undefined) merged.a2uPreparedTxHash = latest.a2uPreparedTxHash
    if (latest.a2uPreparedSequence !== undefined) merged.a2uPreparedSequence = latest.a2uPreparedSequence
    if (updates.a2uPreparedTxHash !== undefined) merged.a2uPreparedTxHash = updates.a2uPreparedTxHash
    if (updates.a2uPreparedSequence !== undefined) merged.a2uPreparedSequence = updates.a2uPreparedSequence

    if (latest.a2uTxid && updates.a2uTxid && latest.a2uTxid !== updates.a2uTxid) {
      const msg = `[A2U Checkpoint] FATAL: Conflicting a2uTxid - existing="${latest.a2uTxid}" vs new="${updates.a2uTxid}" - workflow stopped`
      console.error(msg)
      throw new Error(msg)
    }
    if (updates.a2uTxid) {
      merged.a2uTxid = updates.a2uTxid
    }

    // Never unset proven success evidence once true - always preserve
    if (latest.horizonSuccessFlag === true) {
      merged.horizonSuccessFlag = true
    } else if (updates.horizonSuccessFlag) {
      merged.horizonSuccessFlag = true
    }

    // Never unset piCompleted once true - always preserve
    if (latest.piCompleted === true) {
      merged.piCompleted = true
    } else if (updates.piCompleted) {
      merged.piCompleted = true
    }

    // Never unset dbRecorded once true - always preserve
    if (latest.dbRecorded === true) {
      merged.dbRecorded = true
    } else if (updates.dbRecorded) {
      merged.dbRecorded = true
    }

    // Preserve original success timestamps - never downgrade
    if (latest.horizonSuccessAt && !updates.horizonSuccessAt) {
      merged.horizonSuccessAt = latest.horizonSuccessAt
    } else if (updates.horizonSuccessAt) {
      merged.horizonSuccessAt = latest.horizonSuccessAt || updates.horizonSuccessAt
    }

    if (latest.paidAt && !updates.paidAt) {
      merged.paidAt = latest.paidAt
    } else if (updates.paidAt) {
      merged.paidAt = latest.paidAt || updates.paidAt
    }

    if (latest.settledAt && !updates.settledAt) {
      merged.settledAt = latest.settledAt
    } else if (updates.settledAt) {
      merged.settledAt = latest.settledAt || updates.settledAt
    }

    // Never regress from settled_to_merchant - terminal state must not downgrade
    if (latest.status === "settled_to_merchant" && updates.status && updates.status !== "settled_to_merchant") {
      const msg = `[A2U Checkpoint] FATAL: Cannot regress from settled_to_merchant to ${updates.status} - workflow stopped`
      console.error(msg)
      throw new Error(msg)
    }
    if (updates.status) {
      merged.status = updates.status
    }

    // Merge all other allowed fields from updates while preserving protected checkpoint evidence
    // Only assign fields that are explicitly allowed (not protected terminals or timestamps)
    // Use explicit typed assignment to avoid unsafe casts
    if (updates.id !== undefined) merged.id = updates.id
    if (updates.merchantId !== undefined) merged.merchantId = updates.merchantId
    if (updates.merchantAddress !== undefined) merged.merchantAddress = updates.merchantAddress
    if (updates.merchantUid !== undefined) merged.merchantUid = updates.merchantUid
    // DR-5: bearer material is legacy projection compatibility only, never durable or recovery authority.
    // Every server checkpoint write scrubs any historical bearer instead of propagating or accepting one.
    merged.accessToken = ""
    if (updates.amount !== undefined) merged.amount = updates.amount
    if (updates.customerAmount !== undefined) merged.customerAmount = updates.customerAmount
    if (updates.merchantAmount !== undefined) merged.merchantAmount = updates.merchantAmount
    if (updates.horizonFeeCharged !== undefined) merged.horizonFeeCharged = updates.horizonFeeCharged
    if (updates.appCommission !== undefined) merged.appCommission = updates.appCommission
    if (updates.appNetImpact !== undefined) merged.appNetImpact = updates.appNetImpact
    if (updates.note !== undefined) merged.note = updates.note
    if (updates.settlementStage !== undefined) merged.settlementStage = updates.settlementStage
    if (updates.createdAt !== undefined) merged.createdAt = updates.createdAt
    if (updates.piPaymentId !== undefined) merged.piPaymentId = updates.piPaymentId
    if (updates.u2aTxid !== undefined) merged.u2aTxid = updates.u2aTxid
    if (updates.a2uFromAddress !== undefined) merged.a2uFromAddress = updates.a2uFromAddress
    if (updates.a2uToAddress !== undefined) merged.a2uToAddress = updates.a2uToAddress
    if (updates.requiresDbReconciliation !== undefined) merged.requiresDbReconciliation = updates.requiresDbReconciliation
    if (updates.piCompletionPending !== undefined) merged.piCompletionPending = updates.piCompletionPending
    if (updates.a2uErrorCode !== undefined) merged.a2uErrorCode = updates.a2uErrorCode
    if (updates.a2uErrorMessage !== undefined) merged.a2uErrorMessage = updates.a2uErrorMessage
    if (updates.a2uErrorBody !== undefined) merged.a2uErrorBody = updates.a2uErrorBody
    if (updates.retryCount !== undefined) merged.retryCount = updates.retryCount
    if (updates.lastAttemptAt !== undefined) merged.lastAttemptAt = updates.lastAttemptAt
    if (updates.nextRetryAt !== undefined) merged.nextRetryAt = updates.nextRetryAt
    if (updates.settlementFailureState !== undefined) merged.settlementFailureState = updates.settlementFailureState
    if (updates.payerUid !== undefined) merged.payerUid = updates.payerUid
    if (updates.payerUidSource !== undefined) merged.payerUidSource = updates.payerUidSource
    if (updates.payerUidCapturedAt !== undefined) merged.payerUidCapturedAt = updates.payerUidCapturedAt
    if (updates.payerRefundEligible !== undefined) merged.payerRefundEligible = updates.payerRefundEligible
    if (updates.refundPaymentId !== undefined) merged.refundPaymentId = updates.refundPaymentId
    if (updates.refundTxid !== undefined) merged.refundTxid = updates.refundTxid
    if (updates.refundStatus !== undefined) merged.refundStatus = updates.refundStatus
    if (updates.refundFailureCode !== undefined) merged.refundFailureCode = updates.refundFailureCode
    if (updates.refundProof !== undefined) merged.refundProof = updates.refundProof

    // F2-6: fence the projection. A stale GET->merge writer may never overwrite
    // a newer Payment projection. On a benign race, re-read and re-merge a
    // bounded number of times; any uncertainty remains fail-closed.
    console.log("[A2U Checkpoint] Persisting fenced monotonic checkpoint to Redis")
    const cas = await compareAndSwapPaymentProjection(paymentId, latest, merged)
    if (cas.outcome === "CONFLICT" && casAttempt < 4) {
      console.warn("[F2-6 REDIS CAS] projection advanced concurrently; retrying merge", { paymentId, casAttempt: casAttempt + 1 })
      return persistCheckpointMerged(paymentId, updates, casAttempt + 1)
    }
    if (cas.outcome !== "UPDATED") {
      throw new Error(`[F2-6 REDIS CAS] Payment projection write blocked: ${cas.outcome}`)
    }
    const persisted = cas.payment
    console.log("[A2U Checkpoint] ✓ Fenced monotonic checkpoint persisted", { paymentId, redisProjectionVersion: persisted.redisProjectionVersion })

    try {
      if (isPaymentFinal(persisted) || (persisted.status === "paid_to_app" && persisted.settlementFailureState === "held" && persisted.refundStatus === "manual_review_required")) {
        await redis.eval<[string], number>("redis.call('SREM',KEYS[1],ARGV[1]); redis.call('ZREM',KEYS[2],ARGV[1]); return 1", ["flashpay:recovery:active-payments:v1", "flashpay:settlement:ready:v1"], [paymentId])
      }
    } catch (error) {
      console.warn("[A2U Checkpoint] Active recovery index cleanup failed", error)
    }

    return persisted
  } catch (error) {
    const msg = `[A2U Checkpoint] CRITICAL FAILURE: Checkpoint persistence failed - workflow stopped immediately: ${error instanceof Error ? error.message : String(error)}`
    console.error(msg)
    // Throw immediately - caller must not proceed to Pi /complete or DB
    throw new Error(msg)
  }
}

/**
 * Fetch existing A2U payment
 * Parses response as unknown and validates with isPiA2UPayment guard - NO CASTS
 */
async function fetchA2UPayment(a2uPaymentId: string): Promise<PiA2UPayment | null> {
  try {
    const response = await fetch(`https://api.minepi.com/v2/payments/${a2uPaymentId}`, {
      method: "GET",
      headers: {
        Authorization: `Key ${serverConfig.piApiKey}`,
        "Content-Type": "application/json",
      },
    })

    if (!response.ok) {
      console.error("[A2U Fetch] Failed to fetch A2U payment")
      return null
    }

    const responseData: unknown = await response.json()
    
    // Validate response with type guard - NO CASTS
    if (!isPiA2UPayment(responseData)) {
      console.error("[DR-22 FINANCIAL EVENT]", { event: "a2u_fetch_invalid_dto", stage: "pi_fetch", a2uPaymentId, responseType: responseData === null ? "null" : Array.isArray(responseData) ? "array" : typeof responseData, failClosed: true })
      return null
    }
    
    return responseData
  } catch (error) {
    console.error("[A2U Fetch] Exception:", error)
    return null
  }
}
