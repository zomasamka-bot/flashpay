'use server'
import {verifyDatabaseUrl,verifyDatabaseBinding} from '../deployment'


import { randomUUID } from 'crypto'
import { financialPresentationIntegrityCTE } from './financial-presentation-integrity'
import { numberToExactPositiveStroops } from './financial-amount-stroops'
import type {
  SettlementRequest,
  TransactionRow,
  ReceiptRow,
  MerchantBalanceRow,
  RefundCheckpoint,
  RefundAuditEvent,
} from './types'

// Database layer - handles PostgreSQL/Neon integration via postgres client
// Note: Functions that use database client are server-only

/**
 * Normalize PostgreSQL NUMERIC value to validated number.
 * PostgreSQL NUMERIC is returned as string or finite number; must be validated.
 * @throws Error if value is not a finite number or fully valid numeric string
 */
function normalizePostgresNumeric(value: unknown, fieldName: string): number {
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) {
      throw new Error(`${fieldName} is not finite: ${value}`)
    }
    return value
  }
  
  if (typeof value === 'string') {
    const trimmed = value.trim()
    if (trimmed.length === 0) {
      throw new Error(`${fieldName} is empty string`)
    }
    const converted = Number(trimmed)
    if (!Number.isFinite(converted)) {
      throw new Error(`${fieldName} is not a valid finite number: "${value}"`)
    }
    return converted
  }
  
  throw new Error(`${fieldName} has unsupported type: ${typeof value}`)
}

// Singleton connection instance
let sqlClient: any = null
let initializationAttempted = false

// Get or create the postgres client connection
async function getPostgresClient() {
  // Return cached client if already initialized
  if (sqlClient !== null) {
    return sqlClient
  }

  // Return null if already tried and failed
  if (initializationAttempted) {
    return null
  }

  if (!process.env.DATABASE_URL) {
    console.warn('[DB] DATABASE_URL not configured, cannot initialize postgres client')
    initializationAttempted = true
    return null
  }

  try {
    console.log('[DB] Initializing postgres client...')
    // Import the postgres client
    const postgres = await import('postgres')
    const sql = postgres.default

    if (!sql) {
      console.error('[DB] Postgres client is not available from the module')
      initializationAttempted = true
      return null
    }

    // Create client instance with connection URL
    verifyDatabaseUrl(process.env.DATABASE_URL)
    const candidate = sql(process.env.DATABASE_URL, {ssl:{rejectUnauthorized:true}})
    try { await verifyDatabaseBinding(candidate as any) } catch (e) { await candidate.end({timeout:1});throw e }
    sqlClient = candidate
    initializationAttempted = true
    console.log('[DB] Postgres client initialized successfully')
    return sqlClient
  } catch (error) {
    console.error('[DB] Failed to load postgres client:', error)
    initializationAttempted = true
    sqlClient = null
    return null
  }
}

// R36 restricted DB identity. This connection must never use DATABASE_URL.
// Fail closed until a separately provisioned runtime credential is present.
let r36RestrictedClient: any = null
export async function getR36RestrictedClient(): Promise<any | null> {
  if (r36RestrictedClient) return r36RestrictedClient
  const url = process.env.R36_RUNTIME_DATABASE_URL
  if (!url || url === process.env.DATABASE_URL) return null
  try {
    // All package deployments use the same strict connection/ACL path.
    const { openProductionR36Runtime } = await import('./r36-production-runtime')
    r36RestrictedClient = await openProductionR36Runtime(url,process.env.DATABASE_URL)
    return r36RestrictedClient
  } catch { return null }
}

// For R36 atomic operations: advisory lock, checkpoint and protected claim
// share the SAME restricted SQL transaction. Caller must use the provided tx.
export async function withR36RestrictedPaymentTransaction<T>(
  paymentId: string, work: (tx: any) => Promise<T>
): Promise<T | null> {
  if (!paymentId || paymentId !== paymentId.trim()) return null
  const client = await getR36RestrictedClient()
  if (!client) return null
  try {
    return await client.begin(async (tx: any) => {
      await tx`SELECT pg_advisory_xact_lock(hashtextextended(${paymentId}, 0))`
      return await work(tx)
    })
  } catch (error) {
    const reportedCode = (error as {code?: unknown})?.code
    const code = typeof reportedCode === 'string' && (/^[0-9A-Z]{5}$/.test(reportedCode) ||
      ['R36_PREPARED_AUTHORITY_NOT_ADMITTED','R36_PREPARED_CHECKPOINT_REJECTED'].includes(reportedCode))
      ? reportedCode : 'R36_TRANSACTION_UNCLASSIFIED'
    console.error('[R36] Restricted financial transaction failed closed',
      { paymentId, code })
    return null
  }
}

export async function withPaymentAuthorityTransaction<T>(paymentId: string, work: (tx: any) => Promise<T>): Promise<T | null> {
  if (typeof paymentId !== 'string' || paymentId.trim() === '' || paymentId !== paymentId.trim()) return null
  const client = await getPostgresClient()
  if (!client) return null
  try {
    return await client.begin(async (tx: any) => {
      // DR-6/DR-7: PostgreSQL is the durable Settlement/Refund XOR serialization
      // authority. Redis remains a fast coordination lock only. Both durable
      // claim paths take this transaction-scoped lock before inspecting or
      // creating the opposite authority.
      await tx`SELECT pg_advisory_xact_lock(hashtextextended(${paymentId}, 0))`
      return await work(tx)
    })
  } catch (error) {
    console.error('[DB] Payment authority transaction uncertain:', error)
    return null
  }
}

export async function query(text: string, values?: unknown[]) {
  // Check if PostgreSQL is configured
  if (!process.env.DATABASE_URL) {
    console.warn('[DB] PostgreSQL not configured, query blocked')
    return null
  }

  try {
    const client = await getPostgresClient()
    if (!client) {
      console.error('[DB] Postgres client failed to initialize')
      return null
    }

    console.log('[DB] Executing query:', text.substring(0, 60) + '...')

    // Use parameterized query with postgres client
    let result: any

    if (values && values.length > 0) {
      // Postgres client handles parameterization automatically
      result = await client.unsafe(text, values)
    } else {
      result = await client.unsafe(text)
    }

    console.log('[DB] Query succeeded, rows:', result?.length || 0)
    return result as unknown[]
  } catch (error) {
    console.error('[DB] Query execution failed:', error)
    return null
  }
}

/**
 * Initialize database schema on first run
 */
/**
 * N-FIN-10A durable settlement authority schema.
 *
 * IMPORTANT: this stage is schema-only. No financial execution or recovery path
 * reads from or writes to this table yet. Later N-FIN-10 stages will add a single
 * monotonic CAS writer before any recovery cutover.
 */
let settlementCheckpointSchemaReady = false
let settlementCheckpointSchemaInitPromise: Promise<boolean> | null = null

export async function ensureSettlementCheckpointTable(): Promise<boolean> {
  if (!process.env.DATABASE_URL) return false
  if (settlementCheckpointSchemaReady) return true
  if (settlementCheckpointSchemaInitPromise) return settlementCheckpointSchemaInitPromise

  settlementCheckpointSchemaInitPromise = ensureSettlementCheckpointTableUncached()
  try {
    const ready = await settlementCheckpointSchemaInitPromise
    if (ready) settlementCheckpointSchemaReady = true
    return ready
  } finally {
    settlementCheckpointSchemaInitPromise = null
  }
}

/** R36 ACL: runtime schema probes are read-only and fail closed. Migration is separate. */
async function r36VerifyColumns(table: string, columns: readonly string[]): Promise<boolean> {
  if (!process.env.DATABASE_URL) return false
  try {
    const result = await query(`SELECT column_name FROM information_schema.columns WHERE table_schema = 'public' AND table_name = $1`, [table])
    if (!Array.isArray(result)) return false
    const actual = new Set(result.map((r: any) => String(r.column_name)))
    return columns.every((name) => actual.has(name))
  } catch (error) {
    console.error('[DB] R36 read-only schema verification failed:', error)
    return false
  }
}
async function r36VerifyTables(spec: ReadonlyArray<readonly [string, readonly string[]]>): Promise<boolean> {
  for (const [table, columns] of spec) if (!(await r36VerifyColumns(table, columns))) return false
  return true
}

async function ensureSettlementCheckpointTableUncached(): Promise<boolean> {
  return r36VerifyTables([['settlement_checkpoints', ['payment_id','version','stage','merchant_id','merchant_uid','customer_amount','merchant_amount','app_commission','prepared_envelope_xdr','prepared_tx_hash','prepared_sequence','a2u_txid','horizon_fee_stroops','db_finalized_at']]])
}

export type SettlementPaymentIdentityCheckpointResult =
  | { outcome: 'RECORDED' | 'REPLAYED'; version: number }
  | { outcome: 'CONFLICT' | 'INDETERMINATE'; error: string }

export async function recordSettlementPaymentIdentityCheckpoint(params: {
  paymentId: string
  merchantId: string
  merchantUid: string
  customerAmount: number
}): Promise<SettlementPaymentIdentityCheckpointResult> {
  const canonicalText = (value: string) => typeof value === 'string' && value.length > 0 && value === value.trim()
  if (
    !canonicalText(params.paymentId) ||
    !canonicalText(params.merchantId) ||
    !canonicalText(params.merchantUid) ||
    typeof params.customerAmount !== 'number' ||
    !Number.isFinite(params.customerAmount) ||
    params.customerAmount <= 0
  ) {
    return { outcome: 'CONFLICT', error: 'Settlement payment identity input is invalid' }
  }

  try {
    const client = await getPostgresClient()
    if (!client) return { outcome: 'INDETERMINATE', error: 'PostgreSQL unavailable' }

    const rows = await client.begin(async (tx: any) => {
      const inserted = await tx`
        INSERT INTO settlement_checkpoints (
          payment_id, version, stage, merchant_id, merchant_uid,
          customer_amount, merchant_amount, app_commission, a2u_create_guard_version, pi_mutation_guard_version
        )
        VALUES (
          ${params.paymentId}, 1, 'payment_identity', ${params.merchantId}, ${params.merchantUid},
          ${params.customerAmount}, ${params.customerAmount}, 0, 'fin5_v1', 'fin7_v2'
        )
        ON CONFLICT DO NOTHING
        RETURNING version
      `
      if (inserted.length === 1) return [{ ...inserted[0], inserted: true }]

      return await tx`
        SELECT version, stage, merchant_id, merchant_uid,
               customer_amount, merchant_amount, app_commission
        FROM settlement_checkpoints
        WHERE payment_id = ${params.paymentId}
        FOR UPDATE
      `
    })

    if (!Array.isArray(rows) || rows.length !== 1 || typeof rows[0] !== 'object' || rows[0] === null) {
      return { outcome: 'CONFLICT', error: 'Settlement payment identity is ambiguous or conflicting' }
    }
    const row = rows[0] as Record<string, unknown>
    const version = Number(row.version)
    if (!Number.isSafeInteger(version) || version < 1) {
      return { outcome: 'CONFLICT', error: 'Settlement payment identity durable version is invalid' }
    }
    if (row.inserted === true) return { outcome: 'RECORDED', version }

    let storedCustomerAmount: number
    let storedMerchantAmount: number
    let storedAppCommission: number
    try {
      storedCustomerAmount = normalizePostgresNumeric(row.customer_amount, 'settlement.customer_amount')
      storedMerchantAmount = normalizePostgresNumeric(row.merchant_amount, 'settlement.merchant_amount')
      storedAppCommission = normalizePostgresNumeric(row.app_commission, 'settlement.app_commission')
    } catch {
      return { outcome: 'CONFLICT', error: 'Settlement payment identity durable accounting is invalid' }
    }

    const validStage = typeof row.stage === 'string' && [
      'payment_identity', 'a2u_created', 'prepared', 'horizon_confirmed', 'pi_completed', 'db_finalized'
    ].includes(row.stage)
    if (
      !validStage ||
      row.merchant_id !== params.merchantId ||
      row.merchant_uid !== params.merchantUid ||
      storedCustomerAmount !== params.customerAmount ||
      storedMerchantAmount !== params.customerAmount ||
      storedAppCommission !== 0
    ) {
      return { outcome: 'CONFLICT', error: 'Settlement payment identity durable identity/accounting mismatch' }
    }
    return { outcome: 'REPLAYED', version }
  } catch (error) {
    console.error('[DB] Settlement payment identity checkpoint outcome is uncertain:', error)
    return { outcome: 'INDETERMINATE', error: 'Settlement payment identity checkpoint outcome is uncertain' }
  }
}

export type Dr11CertificationHoldResult =
  | { outcome: 'RECORDED' | 'REPLAYED' }
  | { outcome: 'CONFLICT' | 'INDETERMINATE'; error: string }

/** DR60: durable, non-financial hold for the exact owner-armed DR11 payment. */
export async function recordDr11RefundCertificationHold(params:{paymentId:string;merchantId:string;merchantUid:string;customerAmount:number}):Promise<Dr11CertificationHoldResult>{
  if(!params.paymentId||params.paymentId!==params.paymentId.trim()||!params.merchantId||!params.merchantUid||params.customerAmount!==0.1)
    return{outcome:'CONFLICT',error:'DR11 certification hold input invalid'}
  try{
    const client=await getPostgresClient(); if(!client)return{outcome:'INDETERMINATE',error:'PostgreSQL unavailable'}
    const rows=await client.begin(async(tx:any)=>{
      await tx`SELECT pg_advisory_xact_lock(hashtextextended(${params.paymentId},0))`
      const updated=await tx`UPDATE settlement_checkpoints SET certification_hold='dr11_refund',certification_hold_at=NOW(),certification_hold_expires_at=NOW()+INTERVAL '15 minutes',updated_at=NOW()
        WHERE payment_id=${params.paymentId} AND stage='payment_identity' AND merchant_id=${params.merchantId} AND merchant_uid=${params.merchantUid}
          AND customer_amount=${params.customerAmount} AND merchant_amount=${params.customerAmount} AND app_commission=0
          AND certification_hold IS NULL AND a2u_payment_id IS NULL AND prepared_tx_hash IS NULL AND a2u_txid IS NULL
          AND NOT EXISTS(SELECT 1 FROM refund_checkpoints WHERE payment_id=${params.paymentId})
        RETURNING certification_hold,certification_hold_expires_at`
      if(updated.length===1)return[{recorded:true,certification_hold:updated[0].certification_hold}]
      return await tx`SELECT stage,merchant_id,merchant_uid,customer_amount,merchant_amount,app_commission,certification_hold,certification_hold_at,certification_hold_expires_at,
        a2u_payment_id,prepared_tx_hash,a2u_txid FROM settlement_checkpoints WHERE payment_id=${params.paymentId} FOR UPDATE`
    })
    if(!Array.isArray(rows)||rows.length!==1||!rows[0])return{outcome:'CONFLICT',error:'DR11 certification identity absent or ambiguous'}
    const r=rows[0] as Record<string,unknown>; if(r.recorded===true)return{outcome:'RECORDED'}
    let ca,ma,ac; try{ca=normalizePostgresNumeric(r.customer_amount,'dr11.customer_amount');ma=normalizePostgresNumeric(r.merchant_amount,'dr11.merchant_amount');ac=normalizePostgresNumeric(r.app_commission,'dr11.app_commission')}catch{return{outcome:'CONFLICT',error:'DR11 durable accounting invalid'}}
    if(r.stage!=='payment_identity'||r.merchant_id!==params.merchantId||r.merchant_uid!==params.merchantUid||ca!==0.1||ma!==0.1||ac!==0||r.certification_hold!=='dr11_refund'||r.certification_hold_at==null||r.certification_hold_expires_at==null||new Date(r.certification_hold_expires_at as any).getTime()<=Date.now()||r.a2u_payment_id!=null||r.prepared_tx_hash!=null||r.a2u_txid!=null)
      return{outcome:'CONFLICT',error:'DR11 certification hold conflicts with durable authority'}
    return{outcome:'REPLAYED'}
  }catch(e){console.error('[DR60] certification hold write uncertain',e);return{outcome:'INDETERMINATE',error:'DR11 certification hold write uncertain'}}
}

export type Dr11CertificationHoldRead = {outcome:'HELD'|'ABSENT'}|{outcome:'INDETERMINATE';error:string}
export async function readDr11RefundCertificationHold(paymentId:string):Promise<Dr11CertificationHoldRead>{
  if(!paymentId||paymentId!==paymentId.trim())return{outcome:'INDETERMINATE',error:'Invalid payment identity'}
  try{
    const client=await getPostgresClient();if(!client)return{outcome:'INDETERMINATE',error:'PostgreSQL unavailable'}
    const rows=await client`SELECT certification_hold,certification_hold_at,certification_hold_expires_at FROM settlement_checkpoints WHERE payment_id=${paymentId}`
    if(rows.length!==1)return rows.length===0?{outcome:'ABSENT'}:{outcome:'INDETERMINATE',error:'DR11 hold identity ambiguous'}
    const r=rows[0] as Record<string,unknown>
    if(r.certification_hold==null&&r.certification_hold_at==null&&r.certification_hold_expires_at==null)return{outcome:'ABSENT'}
    if(r.certification_hold==='dr11_refund'&&r.certification_hold_at!=null&&r.certification_hold_expires_at!=null){const expires=new Date(r.certification_hold_expires_at as any).getTime();if(Number.isFinite(expires)&&expires>Date.now())return{outcome:'HELD'};if(Number.isFinite(expires)&&expires<=Date.now())return{outcome:'ABSENT'}}
    return{outcome:'INDETERMINATE',error:'DR11 hold state contradictory'}
  }catch(e){return{outcome:'INDETERMINATE',error:'DR11 hold read uncertain'}}
}

export type SettlementU2APretransactionRecoveryCandidate =
  | { outcome: 'CANDIDATE'; customerAmount: number; approvalIdentifier: string }
  | { outcome: 'NOT_CANDIDATE' | 'INDETERMINATE'; error: string }

/** R4J: read-only proof that the exact Pi identifier is still only the durable
 * approval owner. No U2A blockchain identity or settlement execution may exist. */
export async function readSettlementU2APretransactionRecoveryCandidate(paymentId: string, piPaymentId: string): Promise<SettlementU2APretransactionRecoveryCandidate> {
  if (!paymentId || paymentId !== paymentId.trim() || !piPaymentId || piPaymentId !== piPaymentId.trim())
    return { outcome: 'NOT_CANDIDATE', error: 'Invalid recovery identity' }
  try {
    const client = await getPostgresClient(); if (!client) return { outcome: 'INDETERMINATE', error: 'PostgreSQL unavailable' }
    const rows = await client`
      SELECT stage,customer_amount,u2a_approval_identifier,u2a_approval_claimed_at,u2a_identifier,u2a_txid,
             payer_uid,u2a_verified_at,u2a_completed_at,a2u_payment_id,prepared_tx_hash,a2u_txid,horizon_confirmed_at
      FROM settlement_checkpoints WHERE payment_id=${paymentId}`
    if (rows.length !== 1) return { outcome: 'NOT_CANDIDATE', error: 'Payment authority absent or ambiguous' }
    const r = rows[0] as Record<string,unknown>
    if (r.stage !== 'payment_identity' || r.u2a_approval_identifier !== piPaymentId || r.u2a_approval_claimed_at == null || r.u2a_identifier != null || r.u2a_txid != null ||
        r.payer_uid != null || r.u2a_verified_at != null || r.u2a_completed_at != null || r.a2u_payment_id != null ||
        r.prepared_tx_hash != null || r.a2u_txid != null || r.horizon_confirmed_at != null)
      return { outcome: 'NOT_CANDIDATE', error: 'Payment has progressed beyond pre-transaction approval ownership' }
    const customerAmount = normalizePostgresNumeric(r.customer_amount, 'settlement.customer_amount')
    return { outcome: 'CANDIDATE', customerAmount, approvalIdentifier: piPaymentId }
  } catch (error) {
    console.error('[R4J U2A PRETRANSACTION READ] uncertain:', error)
    return { outcome: 'INDETERMINATE', error: 'Pre-transaction recovery read uncertain' }
  }
}

export type SettlementU2AApprovalRetirementResult =
  | { outcome: 'RETIRED' | 'REPLAYED'; version: number }
  | { outcome: 'CONFLICT' | 'INDETERMINATE'; error: string }

/** R4J: retire the exact approval owner only after the caller has proven by
 * canonical Pi GET that Pi cancelled it with no transaction. The advisory lock
 * serializes this transition with all other payment authority changes. */
export async function retireSettlementU2AApprovalAfterCanonicalCancellation(params: {
  paymentId: string; piPaymentId: string; piCancelledAt: string
}): Promise<SettlementU2AApprovalRetirementResult> {
  if (!params.paymentId || params.paymentId !== params.paymentId.trim() || !params.piPaymentId || params.piPaymentId !== params.piPaymentId.trim())
    return { outcome: 'CONFLICT', error: 'Invalid retirement identity' }
  const cancelledAt = new Date(params.piCancelledAt)
  if (!Number.isFinite(cancelledAt.getTime())) return { outcome: 'CONFLICT', error: 'Invalid canonical cancellation timestamp' }
  try {
    const client = await getPostgresClient(); if (!client) return { outcome: 'INDETERMINATE', error: 'PostgreSQL unavailable' }
    return await client.begin(async (tx:any) => {
      await tx`SELECT pg_advisory_xact_lock(hashtextextended(${params.paymentId}, 0))`
      const rows = await tx`
        SELECT version,stage,u2a_approval_identifier,u2a_approval_claimed_at,u2a_identifier,u2a_txid,payer_uid,u2a_verified_at,u2a_completed_at,
               a2u_payment_id,prepared_tx_hash,a2u_txid,horizon_confirmed_at
        FROM settlement_checkpoints WHERE payment_id=${params.paymentId} FOR UPDATE`
      if (rows.length !== 1) return { outcome:'CONFLICT' as const, error:'Payment authority absent or ambiguous' }
      const r=rows[0] as Record<string,unknown>
      const retired = await tx`SELECT 1 FROM settlement_u2a_approval_retirements WHERE payment_id=${params.paymentId} AND pi_payment_id=${params.piPaymentId}`
      if (r.u2a_approval_identifier == null && retired.length === 1) return { outcome:'REPLAYED' as const, version:Number(r.version) }
      if (r.stage !== 'payment_identity' || r.u2a_approval_identifier !== params.piPaymentId || r.u2a_approval_claimed_at == null || r.u2a_identifier != null || r.u2a_txid != null ||
          r.payer_uid != null || r.u2a_verified_at != null || r.u2a_completed_at != null || r.a2u_payment_id != null ||
          r.prepared_tx_hash != null || r.a2u_txid != null || r.horizon_confirmed_at != null)
        return { outcome:'CONFLICT' as const, error:'Payment progressed or approval owner changed' }
      await tx`
        INSERT INTO settlement_u2a_approval_retirements(payment_id,pi_payment_id,reason,pi_cancelled_at)
        VALUES(${params.paymentId},${params.piPaymentId},'pi_pretransaction_cancelled',${cancelledAt.toISOString()})
        ON CONFLICT(payment_id,pi_payment_id) DO NOTHING`
      const updated = await tx`
        UPDATE settlement_checkpoints SET version=version+1,u2a_approval_identifier=NULL,u2a_approval_claimed_at=NULL,
          u2a_approval_guard_version=NULL,u2a_approval_attempted_at=NULL,u2a_start_lease_token=NULL,u2a_start_lease_expires_at=NULL,updated_at=NOW()
        WHERE payment_id=${params.paymentId} AND stage='payment_identity' AND u2a_approval_identifier=${params.piPaymentId}
          AND u2a_identifier IS NULL AND u2a_txid IS NULL AND payer_uid IS NULL AND u2a_verified_at IS NULL AND u2a_completed_at IS NULL
          AND a2u_payment_id IS NULL AND prepared_tx_hash IS NULL AND a2u_txid IS NULL AND horizon_confirmed_at IS NULL
        RETURNING version`
      if (updated.length !== 1) return { outcome:'CONFLICT' as const, error:'Approval retirement compare-and-swap failed' }
      return { outcome:'RETIRED' as const, version:Number(updated[0].version) }
    })
  } catch(error) {
    console.error('[R4J U2A APPROVAL RETIREMENT] uncertain:', error)
    return { outcome:'INDETERMINATE', error:'Approval retirement uncertain' }
  }
}

export type SettlementU2AApprovalOwnershipRead =
  | { outcome: 'UNCLAIMED' }
  | { outcome: 'CLAIMED' }
  | { outcome: 'INDETERMINATE'; error: string }

/** DR87: public-safe durable readback of whether a Pi U2A approval owner exists.
 * Never returns the Pi identifier. PostgreSQL uncertainty fails closed. */
export async function readSettlementU2AApprovalOwnership(paymentId: string): Promise<SettlementU2AApprovalOwnershipRead> {
  if (typeof paymentId !== 'string' || paymentId.trim() === '' || paymentId !== paymentId.trim())
    return { outcome: 'INDETERMINATE', error: 'Invalid payment identity' }
  try {
    const client = await getPostgresClient()
    if (!client) return { outcome: 'INDETERMINATE', error: 'PostgreSQL unavailable' }
    const rows = await client`SELECT u2a_approval_identifier,u2a_approval_claimed_at FROM settlement_checkpoints WHERE payment_id=${paymentId}`
    if (rows.length !== 1) return { outcome: 'INDETERMINATE', error: 'Payment approval ownership absent or ambiguous' }
    const row = rows[0] as Record<string, unknown>
    if (row.u2a_approval_identifier == null && row.u2a_approval_claimed_at == null) return { outcome: 'UNCLAIMED' }
    if (typeof row.u2a_approval_identifier === 'string' && row.u2a_approval_identifier.trim() !== '' && row.u2a_approval_identifier === row.u2a_approval_identifier.trim() && row.u2a_approval_claimed_at != null) return { outcome: 'CLAIMED' }
    return { outcome: 'INDETERMINATE', error: 'Payment approval ownership contradictory' }
  } catch (error) {
    console.error('[DR87 U2A APPROVAL READBACK] uncertain:', error)
    return { outcome: 'INDETERMINATE', error: 'Payment approval ownership read uncertain' }
  }
}

export type SettlementU2AStartLeaseResult =
  | { outcome: 'ACQUIRED'; token: string; expiresAt: string }
  | { outcome: 'BLOCKED' | 'INDETERMINATE'; error: string }

/** DR88: atomic durable authority to enter Pi.createPayment. One active starter per Flash payment. */
export async function acquireSettlementU2AStartLease(paymentId: string): Promise<SettlementU2AStartLeaseResult> {
  if (typeof paymentId !== 'string' || paymentId.trim() === '' || paymentId !== paymentId.trim())
    return { outcome: 'INDETERMINATE', error: 'Invalid payment identity' }
  try {
    const client = await getPostgresClient()
    if (!client) return { outcome: 'INDETERMINATE', error: 'PostgreSQL unavailable' }
    const token = crypto.randomUUID()
    const rows = await client`
      UPDATE settlement_checkpoints
      SET u2a_start_lease_token=${token},
          u2a_start_lease_expires_at=NOW()+INTERVAL '2 minutes',
          updated_at=NOW()
      WHERE payment_id=${paymentId}
        AND stage='payment_identity'
        AND u2a_approval_identifier IS NULL
        AND u2a_identifier IS NULL
        AND u2a_txid IS NULL
        AND (u2a_start_lease_token IS NULL OR u2a_start_lease_expires_at IS NULL OR u2a_start_lease_expires_at<=NOW())
      RETURNING u2a_start_lease_expires_at
    `
    if (rows.length === 1) return { outcome: 'ACQUIRED', token, expiresAt: new Date(rows[0].u2a_start_lease_expires_at as any).toISOString() }
    const state = await client`SELECT u2a_approval_identifier,u2a_identifier,u2a_txid,u2a_start_lease_token,u2a_start_lease_expires_at FROM settlement_checkpoints WHERE payment_id=${paymentId}`
    if (state.length !== 1) return { outcome: 'INDETERMINATE', error: 'Payment start authority absent or ambiguous' }
    return { outcome: 'BLOCKED', error: 'Payment already initiated or another start is active' }
  } catch (error) {
    console.error('[DR88 U2A START LEASE] uncertain:', error)
    return { outcome: 'INDETERMINATE', error: 'Payment start authority read/write uncertain' }
  }
}

export type SettlementU2AStartApprovalClaimResult =
  | { outcome: 'RECORDED' | 'REPLAYED'; version: number }
  | { outcome: 'CONFLICT' | 'INDETERMINATE'; error: string }

/** DR88: convert the exact active start lease into durable Pi approval ownership atomically. */
export async function recordSettlementU2AApprovalClaimFromStartLease(params: {
  paymentId: string; merchantId: string; merchantUid: string; customerAmount: number; u2aIdentifier: string; startLeaseToken: string
}): Promise<SettlementU2AStartApprovalClaimResult> {
  const canonical = (v:string) => typeof v==='string' && v.trim()!=='' && v===v.trim()
  if(!canonical(params.paymentId)||!canonical(params.merchantId)||!canonical(params.merchantUid)||!canonical(params.u2aIdentifier)||!canonical(params.startLeaseToken)||!Number.isFinite(params.customerAmount)||params.customerAmount<=0)
    return {outcome:'CONFLICT',error:'Invalid U2A start approval claim input'}
  try {
    const client=await getPostgresClient(); if(!client)return{outcome:'INDETERMINATE',error:'PostgreSQL unavailable'}
    return await client.begin(async(tx:any)=>{
      const rows=await tx`
        UPDATE settlement_checkpoints SET
          version=version+1,u2a_approval_identifier=${params.u2aIdentifier},u2a_approval_claimed_at=NOW(),
          u2a_approval_guard_version='fin7_v1',u2a_approval_attempted_at=NULL,
          u2a_start_lease_token=NULL,u2a_start_lease_expires_at=NULL,updated_at=NOW()
        WHERE payment_id=${params.paymentId} AND merchant_id=${params.merchantId} AND merchant_uid=${params.merchantUid}
          AND customer_amount=${params.customerAmount} AND app_commission=0 AND stage='payment_identity'
          AND u2a_approval_identifier IS NULL AND u2a_identifier IS NULL AND u2a_txid IS NULL
          AND u2a_start_lease_token=${params.startLeaseToken} AND u2a_start_lease_expires_at>NOW()
        RETURNING version`
      if(rows.length===1)return{outcome:'RECORDED' as const,version:Number(rows[0].version)}
      const existing=await tx`SELECT version,u2a_approval_identifier FROM settlement_checkpoints WHERE payment_id=${params.paymentId}`
      if(existing.length===1 && existing[0].u2a_approval_identifier===params.u2aIdentifier)return{outcome:'REPLAYED' as const,version:Number(existing[0].version)}
      return{outcome:'CONFLICT' as const,error:'U2A start lease or approval ownership conflict'}
    })
  } catch(error){console.error('[DR88 U2A START->APPROVAL] uncertain:',error);return{outcome:'INDETERMINATE',error:'U2A start approval durability uncertain'}}
}

export type SettlementU2AApprovalAttemptResult =
  | { outcome: 'RECORDED' | 'REPLAYED'; version: number }
  | { outcome: 'CONFLICT' | 'INDETERMINATE'; error: string }

/** FIN7-S2: durable one-shot authorization for the externally visible Pi /approve POST.
 * Ownership and attempt are deliberately separate: a crash after ownership but before
 * this marker may still perform the first attempt; once this marker exists, recovery
 * must reconcile canonical Pi state and must never issue a second /approve POST. */
export async function claimSettlementU2AApprovalAttempt(params: {
  paymentId: string; merchantId: string; merchantUid: string; customerAmount: number; u2aIdentifier: string
}): Promise<SettlementU2AApprovalAttemptResult> {
  const canonical = (v: string) => typeof v === 'string' && v.trim() !== '' && v === v.trim()
  if (!canonical(params.paymentId) || !canonical(params.merchantId) || !canonical(params.merchantUid) || !canonical(params.u2aIdentifier) || !Number.isFinite(params.customerAmount) || params.customerAmount <= 0)
    return { outcome: 'CONFLICT', error: 'Invalid U2A approval attempt input' }
  try {
    const client = await getPostgresClient(); if (!client) return { outcome: 'INDETERMINATE', error: 'PostgreSQL unavailable' }
    return await client.begin(async (tx: any) => {
      await tx`SELECT pg_advisory_xact_lock(hashtextextended(${params.paymentId}, 0))`
      const recorded = await tx`
        UPDATE settlement_checkpoints SET
          version=version+1,u2a_approval_attempted_at=NOW(),updated_at=NOW()
        WHERE payment_id=${params.paymentId} AND merchant_id=${params.merchantId} AND merchant_uid=${params.merchantUid}
          AND customer_amount=${params.customerAmount} AND merchant_amount=${params.customerAmount} AND app_commission=0
          AND stage='payment_identity' AND u2a_approval_identifier=${params.u2aIdentifier}
          AND u2a_approval_claimed_at IS NOT NULL AND u2a_approval_guard_version='fin7_v1' AND u2a_approval_attempted_at IS NULL
          AND u2a_identifier IS NULL AND u2a_txid IS NULL AND payer_uid IS NULL
          AND u2a_verified_at IS NULL AND u2a_completed_at IS NULL
          AND a2u_payment_id IS NULL AND prepared_tx_hash IS NULL AND a2u_txid IS NULL
        RETURNING version`
      if (recorded.length === 1) return { outcome: 'RECORDED' as const, version: Number(recorded[0].version) }
      const existing = await tx`
        SELECT version,stage,merchant_id,merchant_uid,customer_amount,merchant_amount,app_commission,
               u2a_approval_identifier,u2a_approval_claimed_at,u2a_approval_guard_version,u2a_approval_attempted_at,u2a_identifier
        FROM settlement_checkpoints WHERE payment_id=${params.paymentId} FOR UPDATE`
      if (existing.length !== 1) return { outcome: 'CONFLICT' as const, error: 'U2A approval attempt authority absent or ambiguous' }
      const row = existing[0] as Record<string, unknown>
      let ca: number, ma: number, ac: number
      try {
        ca = normalizePostgresNumeric(row.customer_amount, 'settlement.customer_amount')
        ma = normalizePostgresNumeric(row.merchant_amount, 'settlement.merchant_amount')
        ac = normalizePostgresNumeric(row.app_commission, 'settlement.app_commission')
      } catch { return { outcome: 'CONFLICT' as const, error: 'U2A approval attempt accounting invalid' } }
      const version = Number(row.version)
      if (!Number.isSafeInteger(version) || version < 1 || row.stage !== 'payment_identity' || row.merchant_id !== params.merchantId || row.merchant_uid !== params.merchantUid || ca !== params.customerAmount || ma !== params.customerAmount || ac !== 0 || row.u2a_approval_identifier !== params.u2aIdentifier || row.u2a_approval_claimed_at == null || row.u2a_approval_guard_version !== 'fin7_v1' || row.u2a_approval_attempted_at == null || row.u2a_identifier != null)
        return { outcome: 'CONFLICT' as const, error: 'U2A approval attempt durable authority conflict' }
      return { outcome: 'REPLAYED' as const, version }
    })
  } catch (error) {
    console.error('[FIN7-S2 U2A APPROVAL ATTEMPT] uncertain:', error)
    return { outcome: 'INDETERMINATE', error: 'U2A approval attempt durability uncertain' }
  }
}

export type SettlementU2AApprovalClaimResult =
  | { outcome: 'RECORDED' | 'REPLAYED'; version: number }
  | { outcome: 'CONFLICT' | 'INDETERMINATE'; error: string }

/**
 * R101-2: durable one-payment -> one-Pi-U2A approval ownership.
 *
 * The claim is established only after canonical Pi validation and before Pi
 * /approve. It performs no Pi/Horizon/Redis mutation and stores no secret.
 * NULL -> A records atomically; A -> A is replay-safe; A -> B conflicts.
 * PostgreSQL uncertainty is INDETERMINATE so callers fail closed before Pi.
 */
export async function recordSettlementU2AApprovalClaim(params: {
  paymentId: string
  merchantId: string
  merchantUid: string
  customerAmount: number
  u2aIdentifier: string
}): Promise<SettlementU2AApprovalClaimResult> {
  const canonicalText = (value: string) => typeof value === 'string' && value.length > 0 && value === value.trim()
  if (
    !canonicalText(params.paymentId) ||
    !canonicalText(params.merchantId) ||
    !canonicalText(params.merchantUid) ||
    !canonicalText(params.u2aIdentifier) ||
    typeof params.customerAmount !== 'number' ||
    !Number.isFinite(params.customerAmount) ||
    params.customerAmount <= 0
  ) return { outcome: 'CONFLICT', error: 'Settlement U2A approval claim input is invalid' }

  try {
    const client = await getPostgresClient()
    if (!client) return { outcome: 'INDETERMINATE', error: 'PostgreSQL unavailable' }

    const rows = await client.begin(async (tx: any) => {
      // The F2-1 row must already exist. Never create payment identity here.
      const recorded = await tx`
        UPDATE settlement_checkpoints
        SET version=version+1,
            u2a_approval_identifier=${params.u2aIdentifier},
            u2a_approval_claimed_at=NOW(),
            updated_at=NOW()
        WHERE payment_id=${params.paymentId}
          AND stage='payment_identity'
          AND merchant_id=${params.merchantId}
          AND merchant_uid=${params.merchantUid}
          AND customer_amount=${params.customerAmount}
          AND merchant_amount=${params.customerAmount}
          AND app_commission=0
          AND u2a_approval_identifier IS NULL
          AND u2a_approval_claimed_at IS NULL
          AND u2a_identifier IS NULL
          AND u2a_txid IS NULL
          AND payer_uid IS NULL
          AND u2a_verified_at IS NULL
          AND u2a_completed_at IS NULL
          AND a2u_payment_id IS NULL
          AND a2u_from_address IS NULL
          AND a2u_to_address IS NULL
          AND prepared_envelope_xdr IS NULL
          AND prepared_tx_hash IS NULL
          AND prepared_sequence IS NULL
          AND a2u_txid IS NULL
          AND horizon_fee_stroops IS NULL
          AND horizon_confirmed_at IS NULL
          AND pi_completed_at IS NULL
          AND db_finalized_at IS NULL
        RETURNING version
      `
      if (recorded.length === 1) return [{ ...recorded[0], recorded: true }]

      return await tx`
        SELECT version,stage,merchant_id,merchant_uid,customer_amount,merchant_amount,app_commission,
               u2a_approval_identifier,u2a_approval_claimed_at,u2a_identifier
        FROM settlement_checkpoints
        WHERE payment_id=${params.paymentId}
        FOR UPDATE
      `
    })

    if (!Array.isArray(rows) || rows.length !== 1 || typeof rows[0] !== 'object' || rows[0] === null)
      return { outcome: 'CONFLICT', error: 'Settlement U2A approval ownership is absent or ambiguous' }

    const row = rows[0] as Record<string, unknown>
    const version = Number(row.version)
    if (!Number.isSafeInteger(version) || version < 1)
      return { outcome: 'CONFLICT', error: 'Settlement U2A approval durable version is invalid' }
    if (row.recorded === true) return { outcome: 'RECORDED', version }

    let ca:number, ma:number, ac:number
    try {
      ca=normalizePostgresNumeric(row.customer_amount,'settlement.customer_amount')
      ma=normalizePostgresNumeric(row.merchant_amount,'settlement.merchant_amount')
      ac=normalizePostgresNumeric(row.app_commission,'settlement.app_commission')
    } catch { return { outcome:'CONFLICT', error:'Settlement U2A approval durable accounting invalid' } }

    const replayStage = typeof row.stage === 'string' && [
      'payment_identity', 'a2u_created', 'prepared', 'horizon_confirmed', 'pi_completed', 'db_finalized'
    ].includes(row.stage)
    const laterStage = row.stage !== 'payment_identity'
    if (
      !replayStage ||
      row.merchant_id !== params.merchantId ||
      row.merchant_uid !== params.merchantUid ||
      ca !== params.customerAmount || ma !== params.customerAmount || ac !== 0 ||
      row.u2a_approval_identifier !== params.u2aIdentifier ||
      row.u2a_approval_claimed_at == null ||
      (row.u2a_identifier != null && row.u2a_identifier !== params.u2aIdentifier) ||
      (laterStage && row.u2a_identifier !== params.u2aIdentifier)
    ) return { outcome:'CONFLICT', error:'Settlement U2A approval durable ownership conflict' }

    // DR-12: the immutable approval owner remains replay-safe after the payment
    // advances. Stage progression must not turn the same canonical Pi approval
    // identifier into a false conflict; a different/missing later U2A identity
    // remains fail-closed. This path is read-only and performs no Pi mutation.
    return { outcome:'REPLAYED', version }
  } catch (error) {
    console.error('[DB] Settlement U2A approval claim uncertain:', error)
    return { outcome:'INDETERMINATE', error:'Settlement U2A approval claim uncertain' }
  }
}

export type SettlementPiMutationAttemptResult =
  | { outcome: 'RECORDED'; attemptedAt: string }
  | { outcome: 'REPLAYED' | 'CONFLICT' | 'INDETERMINATE'; error: string }

/** FIN7-S3: one-shot Pi mutation claim for Settlement-owned lifecycles.
 * RECORDED is the only outcome that authorizes the caller's POST. REPLAYED means
 * a prior runtime crossed the attempt boundary and must reconcile only. */
export async function claimSettlementPiMutationAttempt(params: {
  kind: 'u2a_cancel' | 'u2a_complete' | 'a2u_complete'
  paymentId: string
  externalPaymentId: string
  txid?: string
}): Promise<SettlementPiMutationAttemptResult> {
  const text=(v:string)=>typeof v==='string'&&v.trim()!==''&&v===v.trim()
  if(!text(params.paymentId)||!text(params.externalPaymentId)||(params.txid!==undefined&&!/^[0-9a-f]{64}$/.test(params.txid)))
    return{outcome:'CONFLICT',error:'Settlement Pi mutation attempt input invalid'}
  try{
    if(!await ensureSettlementCheckpointTable())return{outcome:'INDETERMINATE',error:'Settlement durable schema unavailable'}
    const client=await getPostgresClient();if(!client)return{outcome:'INDETERMINATE',error:'PostgreSQL unavailable'}
    return await client.begin(async(tx:any)=>{
      await tx`SELECT pg_advisory_xact_lock(hashtextextended(${params.paymentId},0))`
      const owner=await tx`SELECT stage,pi_mutation_guard_version,u2a_approval_identifier,u2a_identifier,u2a_txid,u2a_verified_at,a2u_payment_id,a2u_txid,horizon_confirmed_at
        FROM settlement_checkpoints WHERE payment_id=${params.paymentId} FOR UPDATE`
      if(owner.length!==1)return{outcome:'CONFLICT' as const,error:'Settlement Pi mutation owner absent or ambiguous'}
      const r=owner[0] as Record<string,unknown>
      if(r.pi_mutation_guard_version!=='fin7_v2')return{outcome:'CONFLICT' as const,error:'Settlement Pi mutation lifecycle is legacy or unguarded'}
      const exact=params.kind==='u2a_cancel'
        ? r.stage==='payment_identity'&&r.u2a_approval_identifier===params.externalPaymentId&&r.u2a_identifier==null&&r.u2a_txid==null
        : params.kind==='u2a_complete'
          ? r.stage==='payment_identity'&&r.u2a_identifier===params.externalPaymentId&&r.u2a_txid===params.txid&&r.u2a_verified_at!=null
          : ['horizon_confirmed','pi_completed','db_finalized'].includes(String(r.stage))&&r.a2u_payment_id===params.externalPaymentId&&r.a2u_txid===params.txid&&r.horizon_confirmed_at!=null
      if(!exact)return{outcome:'CONFLICT' as const,error:'Settlement Pi mutation durable identity mismatch'}
      const inserted=await tx`INSERT INTO financial_pi_mutation_attempts(mutation_kind,payment_id,external_payment_id,txid)
        VALUES(${params.kind},${params.paymentId},${params.externalPaymentId},${params.txid??null}) ON CONFLICT DO NOTHING RETURNING attempted_at`
      if(inserted.length===1){const at=inserted[0].attempted_at;return{outcome:'RECORDED' as const,attemptedAt:at instanceof Date?at.toISOString():String(at)}}
      const prior=await tx`SELECT txid FROM financial_pi_mutation_attempts WHERE mutation_kind=${params.kind} AND payment_id=${params.paymentId} AND external_payment_id=${params.externalPaymentId}`
      if(prior.length===1&&prior[0].txid===(params.txid??null))return{outcome:'REPLAYED' as const,error:'Settlement Pi mutation attempt already recorded'}
      return{outcome:'CONFLICT' as const,error:'Settlement Pi mutation attempt conflict'}
    })
  }catch(error){console.error('[FIN7-S3 SETTLEMENT PI MUTATION] uncertain:',error);return{outcome:'INDETERMINATE',error:'Settlement Pi mutation attempt uncertain'}}
}

export type SettlementU2AIngressCheckpointResult =
  | { outcome: 'RECORDED' | 'REPLAYED'; version: number }
  | { outcome: 'CONFLICT' | 'INDETERMINATE'; error: string }

/**
 * F2-2: persist authoritative U2A blockchain identity before Pi /complete.
 *
 * This checkpoint records no access token and authorizes no A2U/Refund movement.
 * New F2-1 rows advance from version 1 while legacy rows may be backfilled only
 * when the supplied payment/merchant/accounting identity is exact. Replays are
 * accepted only when the durable U2A identifier, txid and payer UID are exact.
 */
export async function recordSettlementU2AVerifiedCheckpoint(params: {
  paymentId: string
  merchantId: string
  merchantUid: string
  customerAmount: number
  u2aIdentifier: string
  u2aTxid: string
  payerUid: string
}): Promise<SettlementU2AIngressCheckpointResult> {
  const canonicalText = (value: string) => typeof value === 'string' && value.length > 0 && value === value.trim()
  if (
    !canonicalText(params.paymentId) ||
    !canonicalText(params.merchantId) ||
    !canonicalText(params.merchantUid) ||
    !canonicalText(params.u2aIdentifier) ||
    !/^[0-9a-f]{64}$/.test(params.u2aTxid) ||
    !canonicalText(params.payerUid) ||
    typeof params.customerAmount !== 'number' ||
    !Number.isFinite(params.customerAmount) ||
    params.customerAmount <= 0
  ) return { outcome: 'CONFLICT', error: 'Settlement U2A verified input is invalid' }

  try {
    const client = await getPostgresClient()
    if (!client) return { outcome: 'INDETERMINATE', error: 'PostgreSQL unavailable' }

    const rows = await client.begin(async (tx: any) => {
      // New F2-1 flow: bind the blockchain U2A identity to the immutable payment row.
      const advanced = await tx`
        UPDATE settlement_checkpoints
        SET version=version+1,
            u2a_identifier=${params.u2aIdentifier},
            u2a_txid=${params.u2aTxid},
            payer_uid=${params.payerUid},
            u2a_verified_at=NOW(),
            updated_at=NOW()
        WHERE payment_id=${params.paymentId}
          AND stage='payment_identity'
          AND merchant_id=${params.merchantId}
          AND merchant_uid=${params.merchantUid}
          AND customer_amount=${params.customerAmount}
          AND merchant_amount=${params.customerAmount}
          AND app_commission=0
          AND (u2a_approval_identifier IS NULL OR u2a_approval_identifier=${params.u2aIdentifier})
          AND u2a_identifier IS NULL
          AND u2a_txid IS NULL
          AND payer_uid IS NULL
          AND u2a_verified_at IS NULL
          AND u2a_completed_at IS NULL
          AND a2u_payment_id IS NULL
          AND a2u_from_address IS NULL
          AND a2u_to_address IS NULL
          AND prepared_envelope_xdr IS NULL
          AND prepared_tx_hash IS NULL
          AND prepared_sequence IS NULL
          AND a2u_txid IS NULL
          AND horizon_fee_stroops IS NULL
          AND horizon_confirmed_at IS NULL
          AND pi_completed_at IS NULL
          AND db_finalized_at IS NULL
        RETURNING version
      `
      if (advanced.length === 1) return [{ ...advanced[0], recorded: true }]

      // Backward-compatible evidence enrichment for an older durable Settlement row.
      // Only exact pre-existing U2A identity may gain the payer/verified timestamp.
      const enriched = await tx`
        UPDATE settlement_checkpoints
        SET version=version+1,
            payer_uid=${params.payerUid},
            u2a_verified_at=NOW(),
            updated_at=NOW()
        WHERE payment_id=${params.paymentId}
          AND stage IN ('a2u_created','prepared','horizon_confirmed','pi_completed','db_finalized')
          AND merchant_id=${params.merchantId}
          AND merchant_uid=${params.merchantUid}
          AND customer_amount=${params.customerAmount}
          AND merchant_amount=${params.customerAmount}
          AND app_commission=0
          AND u2a_identifier=${params.u2aIdentifier}
          AND u2a_txid=${params.u2aTxid}
          AND payer_uid IS NULL
          AND u2a_verified_at IS NULL
        RETURNING version
      `
      if (enriched.length === 1) return [{ ...enriched[0], recorded: true }]

      // Legacy pre-F2-1 payment: establish the durable identity at U2A verification.
      const inserted = await tx`
        INSERT INTO settlement_checkpoints (
          payment_id,version,stage,merchant_id,merchant_uid,
          customer_amount,merchant_amount,app_commission,
          u2a_identifier,u2a_txid,payer_uid,u2a_verified_at
        ) VALUES (
          ${params.paymentId},2,'payment_identity',${params.merchantId},${params.merchantUid},
          ${params.customerAmount},${params.customerAmount},0,
          ${params.u2aIdentifier},${params.u2aTxid},${params.payerUid},NOW()
        )
        ON CONFLICT DO NOTHING
        RETURNING version
      `
      if (inserted.length === 1) return [{ ...inserted[0], recorded: true }]

      return await tx`
        SELECT version,stage,merchant_id,merchant_uid,customer_amount,merchant_amount,app_commission,
               u2a_approval_identifier,u2a_identifier,u2a_txid,payer_uid,u2a_verified_at,u2a_completed_at
        FROM settlement_checkpoints
        WHERE payment_id=${params.paymentId}
        FOR UPDATE
      `
    })

    if (!Array.isArray(rows) || rows.length !== 1 || !rows[0])
      return { outcome: 'CONFLICT', error: 'Settlement U2A verified durable identity is ambiguous' }
    const row = rows[0] as Record<string, unknown>
    const version = Number(row.version)
    if (!Number.isSafeInteger(version) || version < 2)
      return { outcome: 'CONFLICT', error: 'Settlement U2A verified durable version is invalid' }
    if (row.recorded === true) return { outcome: 'RECORDED', version }

    let ca:number, ma:number, ac:number
    try {
      ca=normalizePostgresNumeric(row.customer_amount,'settlement.customer_amount')
      ma=normalizePostgresNumeric(row.merchant_amount,'settlement.merchant_amount')
      ac=normalizePostgresNumeric(row.app_commission,'settlement.app_commission')
    } catch { return { outcome: 'CONFLICT', error: 'Settlement U2A verified durable accounting invalid' } }
    if (
      !['payment_identity','a2u_created','prepared','horizon_confirmed','pi_completed','db_finalized'].includes(String(row.stage)) ||
      row.merchant_id!==params.merchantId || row.merchant_uid!==params.merchantUid || ca!==params.customerAmount || ma!==params.customerAmount || ac!==0 ||
      (row.u2a_approval_identifier!=null && row.u2a_approval_identifier!==params.u2aIdentifier) ||
      row.u2a_identifier!==params.u2aIdentifier || row.u2a_txid!==params.u2aTxid || row.payer_uid!==params.payerUid || row.u2a_verified_at==null
    ) return { outcome: 'CONFLICT', error: 'Settlement U2A verified durable identity mismatch' }
    return { outcome: 'REPLAYED', version }
  } catch (error) {
    console.error('[DB] Settlement U2A verified checkpoint uncertain:', error)
    return { outcome: 'INDETERMINATE', error: 'Settlement U2A verified checkpoint uncertain' }
  }
}

/**
 * F2-2: acknowledge Pi developer completion durably before Redis projection.
 * The exact verified U2A identity must already exist; this function never
 * creates or changes blockchain movement and never invents a payment identity.
 */
export async function recordSettlementU2ACompletedCheckpoint(params: {
  paymentId: string
  merchantId: string
  merchantUid: string
  customerAmount: number
  u2aIdentifier: string
  u2aTxid: string
  payerUid: string
}): Promise<SettlementU2AIngressCheckpointResult> {
  const canonicalText = (value: string) => typeof value === 'string' && value.length > 0 && value === value.trim()
  if (
    !canonicalText(params.paymentId) || !canonicalText(params.merchantId) || !canonicalText(params.merchantUid) ||
    !canonicalText(params.u2aIdentifier) || !/^[0-9a-f]{64}$/.test(params.u2aTxid) || !canonicalText(params.payerUid) ||
    typeof params.customerAmount !== 'number' || !Number.isFinite(params.customerAmount) || params.customerAmount <= 0
  ) return { outcome: 'CONFLICT', error: 'Settlement U2A completed input is invalid' }

  try {
    const client=await getPostgresClient()
    if(!client)return{outcome:'INDETERMINATE',error:'PostgreSQL unavailable'}
    const rows=await client.begin(async(tx:any)=>{
      const updated=await tx`
        UPDATE settlement_checkpoints
        SET version=version+1,u2a_completed_at=NOW(),updated_at=NOW()
        WHERE payment_id=${params.paymentId}
          AND stage IN ('payment_identity','a2u_created','prepared','horizon_confirmed','pi_completed','db_finalized')
          AND merchant_id=${params.merchantId} AND merchant_uid=${params.merchantUid}
          AND customer_amount=${params.customerAmount} AND merchant_amount=${params.customerAmount} AND app_commission=0
          AND u2a_identifier=${params.u2aIdentifier} AND u2a_txid=${params.u2aTxid}
          AND payer_uid=${params.payerUid} AND u2a_verified_at IS NOT NULL AND u2a_completed_at IS NULL
        RETURNING version
      `
      if(updated.length===1)return[{...updated[0],recorded:true}]
      return await tx`
        SELECT version,stage,merchant_id,merchant_uid,customer_amount,merchant_amount,app_commission,
               u2a_identifier,u2a_txid,payer_uid,u2a_verified_at,u2a_completed_at
        FROM settlement_checkpoints WHERE payment_id=${params.paymentId} FOR UPDATE
      `
    })
    if(!Array.isArray(rows)||rows.length!==1||!rows[0])return{outcome:'CONFLICT',error:'Settlement U2A completed durable identity is ambiguous'}
    const row=rows[0] as Record<string,unknown>,version=Number(row.version)
    if(!Number.isSafeInteger(version)||version<3)return{outcome:'CONFLICT',error:'Settlement U2A completed durable version is invalid'}
    if(row.recorded===true)return{outcome:'RECORDED',version}
    let ca:number,ma:number,ac:number
    try{ca=normalizePostgresNumeric(row.customer_amount,'settlement.customer_amount');ma=normalizePostgresNumeric(row.merchant_amount,'settlement.merchant_amount');ac=normalizePostgresNumeric(row.app_commission,'settlement.app_commission')}
    catch{return{outcome:'CONFLICT',error:'Settlement U2A completed durable accounting invalid'}}
    if(!['payment_identity','a2u_created','prepared','horizon_confirmed','pi_completed','db_finalized'].includes(String(row.stage))||
      row.merchant_id!==params.merchantId||row.merchant_uid!==params.merchantUid||ca!==params.customerAmount||ma!==params.customerAmount||ac!==0||
      row.u2a_identifier!==params.u2aIdentifier||row.u2a_txid!==params.u2aTxid||row.payer_uid!==params.payerUid||row.u2a_verified_at==null||row.u2a_completed_at==null)
      return{outcome:'CONFLICT',error:'Settlement U2A completed durable identity mismatch'}
    return{outcome:'REPLAYED',version}
  }catch(error){console.error('[DB] Settlement U2A completed checkpoint uncertain:',error);return{outcome:'INDETERMINATE',error:'Settlement U2A completed checkpoint uncertain'}}
}

export type DurableU2AIngressRead =
  | { outcome:'FOUND'; checkpoint:{
      paymentId:string; version:number; merchantId:string; merchantUid:string; customerAmount:number;
      u2aIdentifier:string; u2aTxid:string; payerUid:string;
      createdAt:string; verifiedAt:string; completedAt:string|null;
    }}
  | { outcome:'ABSENT' }
  | { outcome:'INDETERMINATE'; error:string }

/**
 * F2-3 authoritative pre-A2U read.
 *
 * Only a payment_identity row with exact verified U2A evidence is exposed. A2U
 * movement fields must still be absent, so this authority can rebuild Redis
 * ingress state but can never prove or authorize merchant movement.
 */
export async function getDurableU2AIngressAuthoritative(paymentId:string):Promise<DurableU2AIngressRead>{
  if(typeof paymentId!=='string'||paymentId.trim()===''||paymentId!==paymentId.trim())
    return{outcome:'INDETERMINATE',error:'Invalid durable U2A ingress payment identity'}
  try{
    const client=await getPostgresClient()
    if(!client)return{outcome:'INDETERMINATE',error:'PostgreSQL unavailable'}
    const rows=await client`
      SELECT payment_id,version,stage,merchant_id,merchant_uid,customer_amount,merchant_amount,app_commission,
             u2a_identifier,u2a_txid,payer_uid,u2a_verified_at,u2a_completed_at,created_at,
             a2u_payment_id,a2u_from_address,a2u_to_address,prepared_envelope_xdr,prepared_tx_hash,prepared_sequence,
             a2u_txid,horizon_fee_stroops,horizon_confirmed_at,pi_completed_at,db_finalized_at
      FROM settlement_checkpoints WHERE payment_id=${paymentId}
    `
    if(rows.length===0)return{outcome:'ABSENT'}
    if(rows.length!==1)return{outcome:'INDETERMINATE',error:'Durable U2A ingress identity is ambiguous'}
    const r=rows[0] as Record<string,unknown>
    // Once Stage1+ exists, the existing Settlement durable recovery lane is authoritative.
    if(r.stage!=='payment_identity')return{outcome:'ABSENT'}
    const text=(v:unknown)=>typeof v==='string'&&v.trim()!==''&&v===v.trim()
    const iso=(v:unknown):string|null=>{
      if(v instanceof Date&&!Number.isNaN(v.getTime()))return v.toISOString()
      if(typeof v==='string'&&v.trim()!==''&&Number.isFinite(Date.parse(v)))return new Date(v).toISOString()
      return null
    }
    const version=Number(r.version)
    let ca:number,ma:number,ac:number
    try{ca=normalizePostgresNumeric(r.customer_amount,'settlement.customer_amount');ma=normalizePostgresNumeric(r.merchant_amount,'settlement.merchant_amount');ac=normalizePostgresNumeric(r.app_commission,'settlement.app_commission')}
    catch{return{outcome:'INDETERMINATE',error:'Durable U2A ingress accounting invalid'}}
    const createdAt=iso(r.created_at),verifiedAt=iso(r.u2a_verified_at),completedAt=r.u2a_completed_at==null?null:iso(r.u2a_completed_at)
    if(!Number.isSafeInteger(version)||version<2||!text(r.payment_id)||r.payment_id!==paymentId||!text(r.merchant_id)||!text(r.merchant_uid)||
      ca<=0||ma!==ca||ac!==0||!text(r.u2a_identifier)||typeof r.u2a_txid!=='string'||!/^[0-9a-f]{64}$/.test(r.u2a_txid)||
      !text(r.payer_uid)||createdAt===null||verifiedAt===null||(r.u2a_completed_at!=null&&completedAt===null)||
      r.a2u_payment_id!=null||r.a2u_from_address!=null||r.a2u_to_address!=null||r.prepared_envelope_xdr!=null||r.prepared_tx_hash!=null||
      r.prepared_sequence!=null||r.a2u_txid!=null||r.horizon_fee_stroops!=null||r.horizon_confirmed_at!=null||r.pi_completed_at!=null||r.db_finalized_at!=null)
      return{outcome:'INDETERMINATE',error:'Durable U2A ingress authority invalid'}
    if(completedAt!==null&&version<3)return{outcome:'INDETERMINATE',error:'Durable U2A completed version invalid'}
    return{outcome:'FOUND',checkpoint:{paymentId,version,merchantId:r.merchant_id as string,merchantUid:r.merchant_uid as string,customerAmount:ca,
      u2aIdentifier:r.u2a_identifier as string,u2aTxid:r.u2a_txid as string,payerUid:r.payer_uid as string,createdAt,verifiedAt,completedAt}}
  }catch(error){console.error('[DB] Durable U2A ingress read uncertain:',error);return{outcome:'INDETERMINATE',error:'Durable U2A ingress read uncertain'}}
}

export type DurableU2AIngressOutstandingPage =
  | { outcome:'FOUND'; paymentIds:string[]; nextCursor:string|null; wrapped:boolean }
  | { outcome:'INDETERMINATE'; error:string }

/**
 * F2-3 bounded PostgreSQL rotation over verified pre-A2U ingress rows. The
 * cursor is durable and independent of Redis, so loss of Redis keys/indexes
 * cannot make these rows undiscoverable and a large persistent head cannot
 * permanently starve later rows.
 */
export async function listRecoverableU2AIngressCheckpointIds(limit:number):Promise<DurableU2AIngressOutstandingPage>{
  if(!Number.isSafeInteger(limit)||limit<1||limit>200)return{outcome:'INDETERMINATE',error:'Invalid U2A ingress recovery page limit'}
  try{
    const client=await getPostgresClient()
    if(!client)return{outcome:'INDETERMINATE',error:'PostgreSQL unavailable'}
    const result=await client.begin(async(tx:any)=>{
      const cursorRows=await tx`SELECT last_updated_at,last_payment_id FROM u2a_ingress_recovery_scan_cursor WHERE singleton=TRUE FOR UPDATE`
      if(cursorRows.length!==1)throw new Error('U2A ingress recovery cursor unavailable')
      const cursor=cursorRows[0] as Record<string,unknown>
      const hasCursor=cursor.last_updated_at!=null&&typeof cursor.last_payment_id==='string'&&cursor.last_payment_id.length>0
      let rows=hasCursor
        ? await tx`SELECT payment_id,updated_at FROM settlement_checkpoints
            WHERE stage='payment_identity' AND u2a_identifier IS NOT NULL AND u2a_txid IS NOT NULL AND payer_uid IS NOT NULL AND u2a_verified_at IS NOT NULL
              AND a2u_payment_id IS NULL AND a2u_txid IS NULL AND prepared_tx_hash IS NULL AND prepared_sequence IS NULL
              AND (updated_at,payment_id)>(${cursor.last_updated_at},${cursor.last_payment_id})
            ORDER BY updated_at ASC,payment_id ASC LIMIT ${limit}`
        : await tx`SELECT payment_id,updated_at FROM settlement_checkpoints
            WHERE stage='payment_identity' AND u2a_identifier IS NOT NULL AND u2a_txid IS NOT NULL AND payer_uid IS NOT NULL AND u2a_verified_at IS NOT NULL
              AND a2u_payment_id IS NULL AND a2u_txid IS NULL AND prepared_tx_hash IS NULL AND prepared_sequence IS NULL
            ORDER BY updated_at ASC,payment_id ASC LIMIT ${limit}`
      let wrapped=false
      if(rows.length===0&&hasCursor){
        wrapped=true
        rows=await tx`SELECT payment_id,updated_at FROM settlement_checkpoints
          WHERE stage='payment_identity' AND u2a_identifier IS NOT NULL AND u2a_txid IS NOT NULL AND payer_uid IS NOT NULL AND u2a_verified_at IS NOT NULL
            AND a2u_payment_id IS NULL AND a2u_txid IS NULL AND prepared_tx_hash IS NULL AND prepared_sequence IS NULL
          ORDER BY updated_at ASC,payment_id ASC LIMIT ${limit}`
      }
      if(rows.length===0){
        await tx`UPDATE u2a_ingress_recovery_scan_cursor SET last_updated_at=NULL,last_payment_id=NULL,updated_at=NOW() WHERE singleton=TRUE`
        return{rows,wrapped,nextCursor:null}
      }
      const tail=rows[rows.length-1] as Record<string,unknown>
      if(tail.updated_at==null||typeof tail.payment_id!=='string'||tail.payment_id.trim()===''||tail.payment_id!==tail.payment_id.trim())throw new Error('U2A ingress recovery cursor tail invalid')
      await tx`UPDATE u2a_ingress_recovery_scan_cursor SET last_updated_at=${tail.updated_at},last_payment_id=${tail.payment_id},updated_at=NOW() WHERE singleton=TRUE`
      return{rows,wrapped,nextCursor:String(tail.payment_id)}
    })
    if(!result||!Array.isArray(result.rows))return{outcome:'INDETERMINATE',error:'U2A ingress recovery page invalid'}
    const ids:string[]=[]
    for(const row of result.rows){
      const id=(row as Record<string,unknown>).payment_id
      if(typeof id!=='string'||id.trim()===''||id!==id.trim()||ids.includes(id))return{outcome:'INDETERMINATE',error:'U2A ingress recovery identity invalid'}
      ids.push(id)
    }
    return{outcome:'FOUND',paymentIds:ids,nextCursor:result.nextCursor,wrapped:result.wrapped===true}
  }catch(error){console.error('[DB] U2A ingress durable rotation uncertain:',error);return{outcome:'INDETERMINATE',error:'U2A ingress durable rotation uncertain'}}
}

export type SettlementA2UCreateAttemptClaimResult =
  | { outcome: 'RECORDED'; attemptedAt: string }
  | { outcome: 'CONFLICT' | 'INDETERMINATE'; error: string }

/**
 * FIN-5: durable one-shot boundary immediately before the first Pi A2U create.
 *
 * Only payment identities born under the FIN-5 guard may claim this boundary.
 * Legacy rows deliberately remain unversioned and therefore fail closed: NULL
 * cannot prove that an older runtime never attempted Pi create. The claim is
 * monotonic and never replay-authorizes another POST; a crash after RECORDED
 * must reconcile/manual-review rather than create again.
 */
export async function claimSettlementA2UCreateAttempt(params: {
  paymentId: string
  merchantUid: string
  customerAmount: number
  u2aIdentifier: string
  u2aTxid: string
  payerUid: string
}): Promise<SettlementA2UCreateAttemptClaimResult> {
  const text = (value: string) => typeof value === 'string' && value.trim() !== '' && value === value.trim()
  if (!text(params.paymentId) || !text(params.merchantUid) || !text(params.u2aIdentifier) ||
      !/^[0-9a-f]{64}$/.test(params.u2aTxid) || !text(params.payerUid) ||
      typeof params.customerAmount !== 'number' || !Number.isFinite(params.customerAmount) || params.customerAmount <= 0) {
    return { outcome: 'CONFLICT', error: 'Settlement A2U create attempt input is invalid' }
  }
  try {
    const client = await getPostgresClient()
    if (!client) return { outcome: 'INDETERMINATE', error: 'PostgreSQL unavailable' }
    const rows = await client.begin(async (tx: any) => {
      await tx`SELECT pg_advisory_xact_lock(hashtextextended(${params.paymentId}, 0))`
      const opposite = await tx`SELECT EXISTS(SELECT 1 FROM refund_checkpoints WHERE payment_id=${params.paymentId} ) AS active`
      if (opposite.length !== 1 || typeof opposite[0]?.active !== 'boolean') return [{ indeterminate: true }]
      if (opposite[0].active === true) return [{ conflict: true }]
      const claimed = await tx`
        UPDATE settlement_checkpoints
        SET a2u_create_attempted_at=NOW(), updated_at=NOW()
        WHERE payment_id=${params.paymentId}
          AND stage='payment_identity'
          AND a2u_create_guard_version='fin5_v1'
          AND a2u_create_attempted_at IS NULL
          AND merchant_uid=${params.merchantUid}
          AND customer_amount=${params.customerAmount}
          AND merchant_amount=${params.customerAmount}
          AND app_commission=0
          AND u2a_identifier=${params.u2aIdentifier}
          AND u2a_txid=${params.u2aTxid}
          AND payer_uid=${params.payerUid}
          AND u2a_verified_at IS NOT NULL
          AND u2a_completed_at IS NOT NULL
          AND a2u_payment_id IS NULL AND a2u_from_address IS NULL AND a2u_to_address IS NULL
          AND prepared_envelope_xdr IS NULL AND prepared_tx_hash IS NULL AND prepared_sequence IS NULL
          AND a2u_txid IS NULL AND horizon_fee_stroops IS NULL AND horizon_confirmed_at IS NULL
          AND pi_completed_at IS NULL AND db_finalized_at IS NULL
        RETURNING a2u_create_attempted_at
      `
      if (claimed.length === 1) return [{ ...claimed[0], claimed: true }]
      return await tx`SELECT a2u_create_guard_version,a2u_create_attempted_at,stage,a2u_payment_id,prepared_tx_hash,a2u_txid FROM settlement_checkpoints WHERE payment_id=${params.paymentId} FOR UPDATE`
    })
    if (!Array.isArray(rows) || rows.length !== 1 || !rows[0]) return { outcome:'CONFLICT', error:'Settlement A2U create attempt authority is absent or ambiguous' }
    const row=rows[0] as Record<string,unknown>
    if (row.indeterminate===true) return { outcome:'INDETERMINATE', error:'Settlement/Refund exclusion is indeterminate' }
    if (row.conflict===true) return { outcome:'CONFLICT', error:'Refund authority conflicts with Settlement create' }
    if (row.claimed===true) {
      const attemptedAt=row.a2u_create_attempted_at instanceof Date ? row.a2u_create_attempted_at.toISOString() : typeof row.a2u_create_attempted_at==='string' && Number.isFinite(Date.parse(row.a2u_create_attempted_at)) ? new Date(row.a2u_create_attempted_at).toISOString() : null
      if (attemptedAt===null) return { outcome:'INDETERMINATE', error:'Settlement A2U create attempt timestamp is invalid' }
      return { outcome:'RECORDED', attemptedAt }
    }
    return { outcome:'CONFLICT', error:'Settlement A2U create is legacy, already attempted, or no longer pristine' }
  } catch (error) {
    console.error('[DB] Settlement A2U create attempt claim uncertain:', error)
    return { outcome:'INDETERMINATE', error:'Settlement A2U create attempt claim uncertain' }
  }
}

export type SettlementStage1CheckpointResult =
  | { outcome: 'RECORDED' | 'REPLAYED'; version: number }
  | { outcome: 'CONFLICT' | 'INDETERMINATE'; error: string }

/**
 * N-FIN-10B: first monotonic durable writer.
 *
 * Scope is deliberately limited to the A2U-created boundary. It may create a
 * checkpoint or replay the exact same checkpoint; it can never replace durable
 * identity, regress/advance a later stage, or authorize blockchain movement.
 */
export async function recordSettlementA2UCreatedCheckpoint(params: {
  paymentId: string
  merchantId: string
  merchantUid: string
  customerAmount: number
  merchantAmount: number
  u2aIdentifier: string
  u2aTxid: string
  a2uPaymentId: string
  a2uFromAddress: string
  a2uToAddress: string
}): Promise<SettlementStage1CheckpointResult> {
  const canonicalText = (value: string) => typeof value === 'string' && value.length > 0 && value === value.trim()
  if (
    !canonicalText(params.paymentId) ||
    !canonicalText(params.merchantId) ||
    !canonicalText(params.merchantUid) ||
    !canonicalText(params.u2aIdentifier) ||
    !/^[0-9a-f]{64}$/.test(params.u2aTxid) ||
    !canonicalText(params.a2uPaymentId) ||
    !canonicalText(params.a2uFromAddress) ||
    !canonicalText(params.a2uToAddress) ||
    typeof params.customerAmount !== 'number' ||
    !Number.isFinite(params.customerAmount) ||
    params.customerAmount <= 0 ||
    typeof params.merchantAmount !== 'number' ||
    !Number.isFinite(params.merchantAmount) ||
    params.merchantAmount !== params.customerAmount
  ) {
    return { outcome: 'CONFLICT', error: 'Settlement Stage1 checkpoint input is invalid' }
  }

  try {
    const client = await getPostgresClient()
    if (!client) return { outcome: 'INDETERMINATE', error: 'PostgreSQL unavailable' }

    const rows = await client.begin(async (tx: any) => {
      // DR-6/DR-7: serialize the durable XOR claim in PostgreSQL itself. This
      // remains correct if the shared Redis operation lock expires or is lost.
      await tx`SELECT pg_advisory_xact_lock(hashtextextended(${params.paymentId}, 0))`
      const hold = await tx`SELECT certification_hold,certification_hold_at,certification_hold_expires_at FROM settlement_checkpoints WHERE payment_id=${params.paymentId} FOR UPDATE`
      if(hold.length===1 && (hold[0]?.certification_hold!==null || hold[0]?.certification_hold_at!==null || hold[0]?.certification_hold_expires_at!==null)){
        const expires=hold[0]?.certification_hold_expires_at instanceof Date?hold[0].certification_hold_expires_at.getTime():Date.parse(String(hold[0]?.certification_hold_expires_at??''))
        if(hold[0]?.certification_hold==='dr11_refund' && hold[0]?.certification_hold_at!=null && Number.isFinite(expires) && expires>Date.now()) return [{ authorityConflict: true, certificationHold: true }]
        if(hold[0]?.certification_hold==='dr11_refund' && hold[0]?.certification_hold_at!=null && Number.isFinite(expires) && expires<=Date.now()) await tx`UPDATE settlement_checkpoints SET certification_hold=NULL,certification_hold_at=NULL,certification_hold_expires_at=NULL,updated_at=NOW() WHERE payment_id=${params.paymentId}`
        else return [{ authorityIndeterminate: true }]
      }
      const opposite = await tx`SELECT EXISTS(SELECT 1 FROM refund_checkpoints WHERE payment_id=${params.paymentId} ) AS active`
      if (opposite.length !== 1 || typeof opposite[0]?.active !== 'boolean') return [{ authorityIndeterminate: true }]
      if (opposite[0].active === true) return [{ authorityConflict: true }]

      // F2-2: new flows may enter the movement-capable Settlement stage only after
      // the exact U2A blockchain identity AND Pi developer completion are durable.
      // Legacy pre-F2 rows are still handled by the fallback insert below.
      const advancedFromIdentity = await tx`
        UPDATE settlement_checkpoints
        SET version = version + 1,
            stage = 'a2u_created',
            a2u_payment_id = ${params.a2uPaymentId},
            a2u_from_address = ${params.a2uFromAddress},
            a2u_to_address = ${params.a2uToAddress},
            updated_at = NOW()
        WHERE payment_id = ${params.paymentId}
          AND version >= 3
          AND stage = 'payment_identity'
          AND merchant_id = ${params.merchantId}
          AND merchant_uid = ${params.merchantUid}
          AND customer_amount = ${params.customerAmount}
          AND merchant_amount = ${params.merchantAmount}
          AND app_commission = 0
          AND u2a_identifier = ${params.u2aIdentifier}
          AND u2a_txid = ${params.u2aTxid}
          AND payer_uid IS NOT NULL
          AND u2a_verified_at IS NOT NULL
          AND u2a_completed_at IS NOT NULL
          AND a2u_payment_id IS NULL
          AND a2u_from_address IS NULL
          AND a2u_to_address IS NULL
          AND prepared_envelope_xdr IS NULL
          AND prepared_tx_hash IS NULL
          AND prepared_sequence IS NULL
          AND a2u_txid IS NULL
          AND horizon_fee_stroops IS NULL
          AND horizon_confirmed_at IS NULL
          AND pi_completed_at IS NULL
          AND db_finalized_at IS NULL
        RETURNING version
      `
      if (advancedFromIdentity.length === 1) return [{ ...advancedFromIdentity[0], advancedFromIdentity: true }]

      // Backward compatibility for a payment created before F2-1: if no durable
      // payment_identity exists, retain the prior exact Stage1 insert behavior.
      const inserted = await tx`
        INSERT INTO settlement_checkpoints (
          payment_id, version, stage, merchant_id, merchant_uid,
          customer_amount, merchant_amount, app_commission,
          u2a_identifier, u2a_txid,
          a2u_payment_id, a2u_from_address, a2u_to_address
        )
        VALUES (
          ${params.paymentId}, 1, 'a2u_created', ${params.merchantId}, ${params.merchantUid},
          ${params.customerAmount}, ${params.merchantAmount}, 0,
          ${params.u2aIdentifier}, ${params.u2aTxid},
          ${params.a2uPaymentId}, ${params.a2uFromAddress}, ${params.a2uToAddress}
        )
        ON CONFLICT DO NOTHING
        RETURNING version
      `
      if (inserted.length === 1) return [{ ...inserted[0], inserted: true }]

      // Replay is accepted only when every durable identity/accounting field is exact.
      // A later stage is intentionally accepted only if it carries this exact Stage1 identity.
      return await tx`
        SELECT version, stage, merchant_id, merchant_uid,
               customer_amount, merchant_amount, app_commission,
               u2a_identifier, u2a_txid,
               a2u_payment_id, a2u_from_address, a2u_to_address,
               prepared_envelope_xdr, prepared_tx_hash, prepared_sequence,
               a2u_txid, horizon_fee_stroops, horizon_confirmed_at,
               pi_completed_at, db_finalized_at
        FROM settlement_checkpoints
        WHERE payment_id = ${params.paymentId}
           OR a2u_payment_id = ${params.a2uPaymentId}
        FOR UPDATE
      `
    })

    if (!Array.isArray(rows) || rows.length !== 1 || typeof rows[0] !== 'object' || rows[0] === null) {
      return { outcome: 'CONFLICT', error: 'Settlement Stage1 durable identity is ambiguous or conflicting' }
    }
    const row = rows[0] as Record<string, unknown>
    if (row.authorityIndeterminate === true) return { outcome: 'INDETERMINATE', error: 'Settlement/Refund durable authority could not be proven' }
    if (row.authorityConflict === true) return { outcome: 'CONFLICT', error: row.certificationHold===true ? 'DR11 durable certification hold blocks Settlement authority' : 'Refund durable authority already owns this payment' }
    const version = Number(row.version)
    if (!Number.isSafeInteger(version) || version < 1) {
      return { outcome: 'CONFLICT', error: 'Settlement Stage1 durable version is invalid' }
    }
    if (row.inserted === true || row.advancedFromIdentity === true) return { outcome: 'RECORDED', version }

    let storedCustomerAmount: number
    let storedMerchantAmount: number
    let storedAppCommission: number
    try {
      storedCustomerAmount = normalizePostgresNumeric(row.customer_amount, 'settlement.customer_amount')
      storedMerchantAmount = normalizePostgresNumeric(row.merchant_amount, 'settlement.merchant_amount')
      storedAppCommission = normalizePostgresNumeric(row.app_commission, 'settlement.app_commission')
    } catch {
      return { outcome: 'CONFLICT', error: 'Settlement Stage1 durable accounting is invalid' }
    }

    const validStage = typeof row.stage === 'string' && [
      'a2u_created', 'prepared', 'horizon_confirmed', 'pi_completed', 'db_finalized'
    ].includes(row.stage)
    if (
      !validStage ||
      row.merchant_id !== params.merchantId ||
      row.merchant_uid !== params.merchantUid ||
      storedCustomerAmount !== params.customerAmount ||
      storedMerchantAmount !== params.merchantAmount ||
      storedAppCommission !== 0 ||
      row.u2a_identifier !== params.u2aIdentifier ||
      row.u2a_txid !== params.u2aTxid ||
      row.a2u_payment_id !== params.a2uPaymentId ||
      row.a2u_from_address !== params.a2uFromAddress ||
      row.a2u_to_address !== params.a2uToAddress
    ) {
      return { outcome: 'CONFLICT', error: 'Settlement Stage1 durable identity/accounting mismatch' }
    }
    return { outcome: 'REPLAYED', version }
  } catch (error) {
    console.error('[DB] Settlement Stage1 durable checkpoint outcome is uncertain:', error)
    return { outcome: 'INDETERMINATE', error: 'Settlement Stage1 durable checkpoint outcome is uncertain' }
  }
}

export type SettlementDurableCheckpointRead =
  | { outcome: 'FOUND'; checkpoint: {
      paymentId:string; version:number; stage:'a2u_created'|'prepared'|'horizon_confirmed'|'pi_completed'|'db_finalized';
      merchantId:string; merchantUid:string; customerAmount:number; merchantAmount:number;
      createdAt:string; paidAt:string|null; payerUid?:string; u2aVerifiedAt?:string; a2uCreateAttemptedAt?:string;
      u2aIdentifier:string; u2aTxid:string; a2uPaymentId:string; a2uFromAddress:string; a2uToAddress:string;
      preparedEnvelopeXdr?:string; preparedTxHash?:string; preparedSequence?:string;
      a2uTxid?:string; horizonFeeStroops?:number; horizonConfirmedAt?:string; dbFinalizedAt?:string
    }}
  | { outcome: 'ABSENT' }
  | { outcome: 'INDETERMINATE'; error:string }

export async function getSettlementCheckpointAuthoritative(paymentId:string):Promise<SettlementDurableCheckpointRead>{
  if(typeof paymentId!=='string'||paymentId.trim()===''||paymentId!==paymentId.trim())
    return{outcome:'INDETERMINATE',error:'Invalid settlement payment identity'}
  try{
    const client=await getPostgresClient()
    if(!client)return{outcome:'INDETERMINATE',error:'PostgreSQL unavailable'}
    const rows=await client`
      SELECT payment_id,version,stage,merchant_id,merchant_uid,customer_amount,merchant_amount,app_commission,
        created_at,u2a_completed_at,payer_uid,u2a_verified_at,a2u_create_attempted_at,u2a_identifier,u2a_txid,a2u_payment_id,a2u_from_address,a2u_to_address,
        prepared_envelope_xdr,prepared_tx_hash,prepared_sequence,a2u_txid,horizon_fee_stroops,
        horizon_confirmed_at,pi_completed_at,db_finalized_at,
        CASE WHEN s.stage='db_finalized' THEN EXISTS(
          SELECT 1 FROM transactions t JOIN receipts r ON r.transaction_id=t.id
          WHERE t.payment_id=s.u2a_identifier AND t.merchant_id=s.merchant_id AND t.merchant_uid=s.merchant_uid
            AND t.amount=s.merchant_amount AND t.status='completed' AND t.currency='π'
            AND r.merchant_id=s.merchant_id AND r.merchant_uid=s.merchant_uid AND r.currency='π'
            AND r.amount=s.merchant_amount AND r.customer_amount=s.customer_amount AND r.merchant_amount=s.merchant_amount
            AND r.app_commission=0 AND r.horizon_fee_charged=s.horizon_fee_stroops::numeric/10000000
            AND r.app_net_impact=-s.horizon_fee_stroops::numeric/10000000 AND r.settlement_status='settled_to_merchant'
            AND r.u2a_identifier=s.u2a_identifier AND r.u2a_txid=s.u2a_txid
            AND r.a2u_identifier=s.a2u_payment_id AND r.a2u_txid=s.a2u_txid AND r.txid=s.a2u_txid
        ) ELSE TRUE END AS accounting_valid
      FROM settlement_checkpoints s WHERE payment_id=${paymentId}
    `
    if(rows.length===0)return{outcome:'ABSENT'}
    if(rows.length!==1)return{outcome:'INDETERMINATE',error:'Settlement durable identity is ambiguous'}
    const r=rows[0] as Record<string,unknown>
    const text=(v:unknown)=>typeof v==='string'&&v.trim()!==''&&v===v.trim()
    const iso=(v:unknown):string|null=>{
      if(v instanceof Date&&!Number.isNaN(v.getTime()))return v.toISOString()
      if(typeof v==='string'&&v.trim()!==''&&Number.isFinite(Date.parse(v)))return new Date(v).toISOString()
      return null
    }
    const createdAt=iso(r.created_at),paidAt=r.u2a_completed_at==null?null:iso(r.u2a_completed_at)
    const version=Number(r.version),stage=r.stage
    let ca,ma,ac
    try{ca=normalizePostgresNumeric(r.customer_amount,'settlement.customer_amount');ma=normalizePostgresNumeric(r.merchant_amount,'settlement.merchant_amount');ac=normalizePostgresNumeric(r.app_commission,'settlement.app_commission')}
    catch{return{outcome:'INDETERMINATE',error:'Settlement durable accounting invalid'}}
    if(!Number.isSafeInteger(version)||version<1||!['a2u_created','prepared','horizon_confirmed','pi_completed','db_finalized'].includes(String(stage))||
      !text(r.payment_id)||r.payment_id!==paymentId||!text(r.merchant_id)||!text(r.merchant_uid)||ca<=0||ma!==ca||ac!==0||
      createdAt===null||(r.u2a_completed_at!=null&&paidAt===null)||
      !text(r.u2a_identifier)||typeof r.u2a_txid!=='string'||!/^[0-9a-f]{64}$/.test(r.u2a_txid)||
      !text(r.a2u_payment_id)||!text(r.a2u_from_address)||!text(r.a2u_to_address))
      return{outcome:'INDETERMINATE',error:'Settlement durable base identity invalid'}
    const advanced=['prepared','horizon_confirmed','pi_completed','db_finalized'].includes(String(stage))
    if(advanced&&(!text(r.prepared_envelope_xdr)||typeof r.prepared_tx_hash!=='string'||!/^[0-9a-f]{64}$/.test(r.prepared_tx_hash)||
      !/^[1-9][0-9]*$/.test(String(r.prepared_sequence))))
      return{outcome:'INDETERMINATE',error:'Settlement durable prepared evidence invalid'}
    const moved=['horizon_confirmed','pi_completed','db_finalized'].includes(String(stage))
    let fee:number|undefined
    if(moved){
      if(typeof r.a2u_txid!=='string'||!/^[0-9a-f]{64}$/.test(r.a2u_txid)||r.a2u_txid!==r.prepared_tx_hash||r.horizon_confirmed_at==null)
        return{outcome:'INDETERMINATE',error:'Settlement durable Horizon evidence invalid'}
      try{fee=normalizePostgresNumeric(r.horizon_fee_stroops,'settlement.horizon_fee_stroops')}catch{return{outcome:'INDETERMINATE',error:'Settlement durable Horizon fee invalid'}}
      if(!Number.isSafeInteger(fee)||fee<0)return{outcome:'INDETERMINATE',error:'Settlement durable Horizon fee invalid'}
    }
    if(['pi_completed','db_finalized'].includes(String(stage))&&r.pi_completed_at==null)return{outcome:'INDETERMINATE',error:'Settlement durable Pi finality invalid'}
    const horizonConfirmedAt=iso(r.horizon_confirmed_at),dbFinalizedAt=iso(r.db_finalized_at)
    if(moved&&horizonConfirmedAt===null)return{outcome:'INDETERMINATE',error:'Settlement durable Horizon timestamp invalid'}
    if(stage==='db_finalized'&&(dbFinalizedAt===null||horizonConfirmedAt===null||
      Date.parse(dbFinalizedAt)<Date.parse(horizonConfirmedAt)||r.accounting_valid!==true))return{outcome:'INDETERMINATE',error:'Settlement durable DB finality or accounting evidence invalid'}
    return{outcome:'FOUND',checkpoint:{
      paymentId,version,stage:stage as any,merchantId:r.merchant_id as string,merchantUid:r.merchant_uid as string,
      customerAmount:ca,merchantAmount:ma,createdAt,paidAt,
      ...(text(r.payer_uid)&&iso(r.u2a_verified_at)!==null?{payerUid:r.payer_uid as string,u2aVerifiedAt:iso(r.u2a_verified_at)!}:{}),
      ...(iso(r.a2u_create_attempted_at)!==null?{a2uCreateAttemptedAt:iso(r.a2u_create_attempted_at)!}:{}),u2aIdentifier:r.u2a_identifier as string,u2aTxid:r.u2a_txid as string,
      a2uPaymentId:r.a2u_payment_id as string,a2uFromAddress:r.a2u_from_address as string,a2uToAddress:r.a2u_to_address as string,
      ...(advanced?{preparedEnvelopeXdr:r.prepared_envelope_xdr as string,preparedTxHash:r.prepared_tx_hash as string,preparedSequence:String(r.prepared_sequence)}:{}),
      ...(moved?{a2uTxid:r.a2u_txid as string,horizonFeeStroops:fee,horizonConfirmedAt:horizonConfirmedAt!}:{}),
      ...(stage==='db_finalized'?{dbFinalizedAt:dbFinalizedAt!}:{}),
    }}
  }catch(e){console.error('[DB] Settlement durable read uncertain:',e);return{outcome:'INDETERMINATE',error:'Settlement durable read uncertain'}}
}

export async function recordSettlementA2UOngoingObservation(paymentId:string,a2uPaymentId:string):Promise<'RECORDED'|'REPLAYED'|'CONFLICT'|'INDETERMINATE'>{
  const exact=(v:string)=>typeof v==='string'&&v.trim()!==''&&v===v.trim()
  if(!exact(paymentId)||!exact(a2uPaymentId))return'CONFLICT'
  try{
    const ready=await ensureSettlementCheckpointTable();if(!ready)return'INDETERMINATE'
    const client=await getPostgresClient();if(!client)return'INDETERMINATE'
    return await client.begin(async(tx:any)=>{
      await tx`SELECT pg_advisory_xact_lock(hashtextextended(${paymentId},0))`
      const owner=await tx`SELECT payment_id FROM settlement_checkpoints WHERE payment_id=${paymentId} FOR UPDATE`
      if(owner.length!==1)return'CONFLICT'
      const inserted=await tx`INSERT INTO settlement_a2u_ongoing_observations(payment_id,a2u_payment_id) VALUES(${paymentId},${a2uPaymentId}) ON CONFLICT DO NOTHING RETURNING payment_id`
      if(inserted.length===1)return'RECORDED'
      const replay=await tx`SELECT 1 FROM settlement_a2u_ongoing_observations WHERE payment_id=${paymentId} AND a2u_payment_id=${a2uPaymentId}`
      return replay.length===1?'REPLAYED':'INDETERMINATE'
    })
  }catch{return'INDETERMINATE'}
}

export type SettlementA2UStage1RetirementResult =
  | { outcome:'RETIRED'|'REPLAYED'; version:number }
  | { outcome:'CONFLICT'|'INDETERMINATE'; error:string }

/** R4P: retire only an exact cancelled, unprepared, unmoved Stage1 under the same durable payment authority lock. */
export async function retireCancelledSettlementA2UStage1(params:{paymentId:string;a2uPaymentId:string;piCancelledAt:string;horizonAbsenceProvenAt:string}):Promise<SettlementA2UStage1RetirementResult>{
  const exact=(v:string)=>typeof v==='string'&&v.trim()!==''&&v===v.trim()
  if(!exact(params.paymentId)||!exact(params.a2uPaymentId)||!Number.isFinite(Date.parse(params.piCancelledAt))||!Number.isFinite(Date.parse(params.horizonAbsenceProvenAt)))return{outcome:'CONFLICT',error:'R4P retirement input invalid'}
  try{
    const ready=await ensureSettlementCheckpointTable(); if(!ready)return{outcome:'INDETERMINATE',error:'Settlement schema unavailable'}
    const client=await getPostgresClient(); if(!client)return{outcome:'INDETERMINATE',error:'PostgreSQL unavailable'}
    const result=await client.begin(async(tx:any)=>{
      await tx`SELECT pg_advisory_xact_lock(hashtextextended(${params.paymentId},0))`
      const opposite=await tx`SELECT EXISTS(SELECT 1 FROM refund_checkpoints WHERE payment_id=${params.paymentId} ) AS active`
      if(opposite.length!==1||typeof opposite[0]?.active!=='boolean')return{kind:'INDETERMINATE'}
      if(opposite[0].active===true)return{kind:'CONFLICT'}
      const row=await tx`SELECT version,stage,a2u_payment_id,prepared_envelope_xdr,prepared_tx_hash,prepared_sequence,a2u_txid,horizon_fee_stroops,horizon_confirmed_at,pi_completed_at,db_finalized_at FROM settlement_checkpoints WHERE payment_id=${params.paymentId} FOR UPDATE`
      if(row.length!==1)return{kind:'INDETERMINATE'}
      const r=row[0]
      const replay=await tx`SELECT 1 FROM settlement_a2u_stage1_retirements WHERE payment_id=${params.paymentId} AND a2u_payment_id=${params.a2uPaymentId}`
      if(r.stage==='payment_identity'&&r.a2u_payment_id==null&&replay.length===1)return{kind:'REPLAYED',version:Number(r.version)}
      if(r.stage!=='a2u_created'||r.a2u_payment_id!==params.a2uPaymentId||r.prepared_envelope_xdr!=null||r.prepared_tx_hash!=null||r.prepared_sequence!=null||r.a2u_txid!=null||r.horizon_fee_stroops!=null||r.horizon_confirmed_at!=null||r.pi_completed_at!=null||r.db_finalized_at!=null)return{kind:'CONFLICT'}
      const ins=await tx`INSERT INTO settlement_a2u_stage1_retirements(payment_id,a2u_payment_id,reason,pi_cancelled_at,horizon_absence_proven_at) VALUES(${params.paymentId},${params.a2uPaymentId},'pi_cancelled_before_transaction',${params.piCancelledAt},${params.horizonAbsenceProvenAt}) ON CONFLICT DO NOTHING RETURNING payment_id`
      if(ins.length!==1&&replay.length!==1)return{kind:'INDETERMINATE'}
      const up=await tx`UPDATE settlement_checkpoints SET version=version+1,stage='payment_identity',a2u_payment_id=NULL,a2u_from_address=NULL,a2u_to_address=NULL,updated_at=NOW() WHERE payment_id=${params.paymentId} AND stage='a2u_created' AND a2u_payment_id=${params.a2uPaymentId} AND prepared_envelope_xdr IS NULL AND prepared_tx_hash IS NULL AND prepared_sequence IS NULL AND a2u_txid IS NULL AND horizon_fee_stroops IS NULL AND horizon_confirmed_at IS NULL AND pi_completed_at IS NULL AND db_finalized_at IS NULL RETURNING version`
      if(up.length!==1)throw new Error('R4P retirement CAS failed after evidence insert')
      return{kind:'RETIRED',version:Number(up[0].version)}
    })
    if(result.kind==='RETIRED'||result.kind==='REPLAYED')return{outcome:result.kind,version:result.version}
    return result.kind==='CONFLICT'?{outcome:'CONFLICT',error:'R4P retirement durable authority conflict'}:{outcome:'INDETERMINATE',error:'R4P retirement durable authority indeterminate'}
  }catch(e){console.error('[R4P] Stage1 retirement uncertain',e);return{outcome:'INDETERMINATE',error:'R4P retirement outcome uncertain'}}
}

export type SettlementOutstandingPage =
  | { outcome:'FOUND'; paymentIds:string[]; nextCursor:string|null; wrapped:boolean }
  | { outcome:'INDETERMINATE'; error:string }

/**
 * N-FIN-X1: bounded durable rotation over outstanding Settlement checkpoints.
 * Cursor authority is PostgreSQL, never Redis, so Redis loss cannot reset every
 * wake to the same first 200 rows. Advancement is serialized and wraps only
 * after the ordered outstanding set is exhausted.
 */
export async function listOutstandingSettlementCheckpointIds(limit:number):Promise<SettlementOutstandingPage>{
  if(!Number.isSafeInteger(limit)||limit<1||limit>200)return{outcome:'INDETERMINATE',error:'Invalid Settlement outstanding page limit'}
  try{
    // N-FIN-X1 production schema repair: initialize the already-defined durable
    // settlement schema before the cursor is read. The helper is idempotent
    // (CREATE/ALTER/INDEX IF NOT EXISTS + seed ON CONFLICT DO NOTHING).
    // No financial state or payment status is mutated here.
    const schemaReady=await ensureSettlementCheckpointTable()
    if(!schemaReady)return{outcome:'INDETERMINATE',error:'Settlement durable schema unavailable'}
    const client=await getPostgresClient()
    if(!client)return{outcome:'INDETERMINATE',error:'PostgreSQL unavailable'}
    const result=await client.begin(async(tx:any)=>{
      const cr=await tx`SELECT last_updated_at,last_payment_id FROM settlement_recovery_scan_cursor WHERE singleton=TRUE FOR UPDATE`
      if(cr.length!==1)throw new Error('Settlement recovery cursor unavailable')
      const c=cr[0] as Record<string,unknown>
      const has=c.last_updated_at!=null&&typeof c.last_payment_id==='string'&&c.last_payment_id.length>0
      let rows=has
        ? await tx`SELECT payment_id,updated_at FROM settlement_checkpoints
            WHERE stage IN ('a2u_created','prepared','horizon_confirmed','pi_completed','db_finalized')
              AND (updated_at,payment_id)>(${c.last_updated_at},${c.last_payment_id})
            ORDER BY updated_at ASC,payment_id ASC LIMIT ${limit}`
        : await tx`SELECT payment_id,updated_at FROM settlement_checkpoints
            WHERE stage IN ('a2u_created','prepared','horizon_confirmed','pi_completed','db_finalized')
            ORDER BY updated_at ASC,payment_id ASC LIMIT ${limit}`
      let wrapped=false
      if(rows.length===0&&has){
        wrapped=true
        rows=await tx`SELECT payment_id,updated_at FROM settlement_checkpoints
          WHERE stage IN ('a2u_created','prepared','horizon_confirmed','pi_completed','db_finalized')
          ORDER BY updated_at ASC,payment_id ASC LIMIT ${limit}`
      }
      if(rows.length===0){
        await tx`UPDATE settlement_recovery_scan_cursor SET last_updated_at=NULL,last_payment_id=NULL,updated_at=NOW() WHERE singleton=TRUE`
        return{rows,wrapped,nextCursor:null}
      }
      const tail=rows[rows.length-1] as Record<string,unknown>
      if(tail.updated_at==null||typeof tail.payment_id!=='string'||tail.payment_id.length===0)throw new Error('Settlement recovery cursor tail invalid')
      await tx`UPDATE settlement_recovery_scan_cursor SET last_updated_at=${tail.updated_at},last_payment_id=${tail.payment_id},updated_at=NOW() WHERE singleton=TRUE`
      return{rows,wrapped,nextCursor:String(tail.payment_id)}
    })
    if(!result||!Array.isArray(result.rows))return{outcome:'INDETERMINATE',error:'Settlement outstanding durable read invalid'}
    const ids:string[]=[]
    for(const row of result.rows){
      const id=(row as Record<string,unknown>).payment_id
      if(typeof id!=='string'||id.trim()===''||id!==id.trim()||ids.includes(id))return{outcome:'INDETERMINATE',error:'Settlement outstanding durable identity invalid'}
      ids.push(id)
    }
    return{outcome:'FOUND',paymentIds:ids,nextCursor:result.nextCursor,wrapped:result.wrapped===true}
  }catch(e){console.error('[DB] Settlement outstanding durable read uncertain:',e);return{outcome:'INDETERMINATE',error:'Settlement outstanding durable read uncertain'}}
}

export type SettlementPaymentIdentityPresence =
  | { outcome:'PRESENT' }
  | { outcome:'ABSENT' }
  | { outcome:'INDETERMINATE'; error:string }

/**
 * Pre-review public-read hardening: existence proof only.
 *
 * This read never authorizes Settlement/Refund movement and deliberately does
 * not derive a public payment status. It exists only so a missing Redis
 * projection cannot be mistaken for a globally absent payment. Callers must
 * use the dedicated Settlement/Refund durable authorities for status/finality.
 */
export async function readSettlementPaymentIdentityPresence(paymentId:string):Promise<SettlementPaymentIdentityPresence>{
  if(typeof paymentId!=='string'||paymentId.trim()===''||paymentId!==paymentId.trim())
    return{outcome:'INDETERMINATE',error:'Invalid durable payment identity'}
  try{
    const client=await getPostgresClient()
    if(!client)return{outcome:'INDETERMINATE',error:'PostgreSQL unavailable'}
    const rows=await client`SELECT payment_id,stage FROM settlement_checkpoints WHERE payment_id=${paymentId}`
    if(rows.length===0)return{outcome:'ABSENT'}
    if(rows.length!==1)return{outcome:'INDETERMINATE',error:'Durable payment identity is ambiguous'}
    const row=rows[0] as Record<string,unknown>
    if(row.payment_id!==paymentId||typeof row.stage!=='string'||!['payment_identity','a2u_created','prepared','horizon_confirmed','pi_completed','db_finalized'].includes(row.stage))
      return{outcome:'INDETERMINATE',error:'Durable payment identity is invalid'}
    return{outcome:'PRESENT'}
  }catch(e){console.error('[DB] Durable payment identity presence read uncertain:',e);return{outcome:'INDETERMINATE',error:'Durable payment identity presence read uncertain'}}
}

export type SettlementRefundAuthorityCheck =
  | { outcome:'CLEAR'; settlementActive:boolean; refundActive:boolean }
  | { outcome:'CONFLICT'|'INDETERMINATE'; error:string }

/**
 * N-FIN-X2 durable ownership read. This is deliberately descriptive: callers
 * decide which opposite authority must be absent for the operation they are
 * about to acquire/replay. Any unknown Refund status is treated as active.
 */
export async function readSettlementRefundAuthority(paymentId:string):Promise<SettlementRefundAuthorityCheck>{
  if(typeof paymentId!=='string'||paymentId.trim()===''||paymentId!==paymentId.trim())
    return{outcome:'INDETERMINATE',error:'Invalid payment identity'}
  try{
    const client=await getPostgresClient()
    if(!client)return{outcome:'INDETERMINATE',error:'PostgreSQL unavailable'}
    const rows=await client`
      SELECT
        EXISTS(SELECT 1 FROM settlement_checkpoints WHERE payment_id=${paymentId} AND (stage IN ('a2u_created','prepared','horizon_confirmed','pi_completed','db_finalized') OR a2u_create_attempted_at IS NOT NULL)) AS settlement_active,
        EXISTS(SELECT 1 FROM refund_checkpoints WHERE payment_id=${paymentId} ) AS refund_active
    `
    if(rows.length!==1)return{outcome:'INDETERMINATE',error:'Cross-authority durable read invalid'}
    const settlementActive=(rows[0] as any).settlement_active,refundActive=(rows[0] as any).refund_active
    if(typeof settlementActive!=='boolean'||typeof refundActive!=='boolean')
      return{outcome:'INDETERMINATE',error:'Cross-authority durable flags invalid'}
    if(settlementActive&&refundActive)return{outcome:'CONFLICT',error:'Settlement and Refund durable authorities conflict'}
    return{outcome:'CLEAR',settlementActive,refundActive}
  }catch(e){console.error('[DB] Cross-authority durable read uncertain:',e);return{outcome:'INDETERMINATE',error:'Cross-authority durable read uncertain'}}
}

export async function verifySettlementRefundAuthorityExclusion(paymentId:string):Promise<SettlementRefundAuthorityCheck>{
  return readSettlementRefundAuthority(paymentId)
}

export type SettlementDurableAdvanceResult =
  | { outcome: 'RECORDED' | 'REPLAYED'; version: number }
  | { outcome: 'CONFLICT' | 'INDETERMINATE'; error: string }

export async function withAtomicSettlementPreparedAuthority<T>(
  paymentId: string, work: (tx: any) => Promise<T>
): Promise<T | null> {
  // The protected wallet claim and settlement checkpoint must share the
  // same restricted transaction and payment-scoped advisory lock.
  // Missing restricted credentials fail closed; never use DATABASE_URL here.
  return withR36RestrictedPaymentTransaction(paymentId, work)
}

export async function recordSettlementPreparedCheckpoint(params: {
  paymentId:string; merchantId:string; merchantUid:string; customerAmount:number; merchantAmount:number;
  a2uPaymentId:string; a2uFromAddress:string; a2uToAddress:string;
  preparedEnvelopeXdr:string; preparedTxHash:string; preparedSequence:string
}, transactionClient?: any):Promise<SettlementDurableAdvanceResult>{
  if(!params.paymentId||!params.merchantId||!params.merchantUid||!params.a2uPaymentId||!params.a2uFromAddress||!params.a2uToAddress||
     !params.preparedEnvelopeXdr||params.preparedEnvelopeXdr!==params.preparedEnvelopeXdr.trim()||
     !/^[0-9a-f]{64}$/.test(params.preparedTxHash)||!/^[1-9][0-9]*$/.test(params.preparedSequence)||
     !Number.isFinite(params.customerAmount)||params.customerAmount<=0||!Number.isFinite(params.merchantAmount)||params.merchantAmount!==params.customerAmount)
    return {outcome:'CONFLICT',error:'Settlement prepared checkpoint input is invalid'}
  try{
    const client=transactionClient ? null : await getR36RestrictedClient();if(!client && !transactionClient)return{outcome:'INDETERMINATE',error:'R36 restricted PostgreSQL unavailable'}
    const run = async(tx:any)=>{
      const a=await tx`SELECT version,stage,advanced FROM public.r36_advance_settlement_prepared(
        ${params.paymentId},${params.merchantId},${params.merchantUid},${params.customerAmount},${params.merchantAmount},
        ${params.a2uPaymentId},${params.a2uFromAddress},${params.a2uToAddress},${params.preparedEnvelopeXdr},
        ${params.preparedTxHash},${params.preparedSequence})`
      if(a.length===1)return a
      return await tx`SELECT version,stage,merchant_id,merchant_uid,customer_amount,merchant_amount,app_commission,
        a2u_payment_id,a2u_from_address,a2u_to_address,prepared_envelope_xdr,prepared_tx_hash,prepared_sequence,a2u_txid
        FROM settlement_checkpoints WHERE payment_id=${params.paymentId} OR a2u_payment_id=${params.a2uPaymentId} OR prepared_tx_hash=${params.preparedTxHash}`
    };
    const rows = transactionClient ? await run(transactionClient) : await client!.begin(run)
    if(!Array.isArray(rows)||rows.length!==1||!rows[0])return{outcome:'CONFLICT',error:'Settlement prepared durable identity is ambiguous or conflicting'}
    const r=rows[0] as Record<string,unknown>,v=Number(r.version);if(!Number.isSafeInteger(v)||v<2)return{outcome:'CONFLICT',error:'Settlement prepared durable version is invalid'}
    if(r.advanced===true)return{outcome:'RECORDED',version:v}
    let ca,ma,ac;try{ca=normalizePostgresNumeric(r.customer_amount,'settlement.customer_amount');ma=normalizePostgresNumeric(r.merchant_amount,'settlement.merchant_amount');ac=normalizePostgresNumeric(r.app_commission,'settlement.app_commission')}catch{return{outcome:'CONFLICT',error:'Settlement prepared durable accounting invalid'}}
    if(!(typeof r.stage==='string'&&['prepared','horizon_confirmed','pi_completed','db_finalized'].includes(r.stage))||
      r.merchant_id!==params.merchantId||r.merchant_uid!==params.merchantUid||ca!==params.customerAmount||ma!==params.merchantAmount||ac!==0||
      r.a2u_payment_id!==params.a2uPaymentId||r.a2u_from_address!==params.a2uFromAddress||r.a2u_to_address!==params.a2uToAddress||
      r.prepared_envelope_xdr!==params.preparedEnvelopeXdr||r.prepared_tx_hash!==params.preparedTxHash||String(r.prepared_sequence)!==params.preparedSequence)
      return{outcome:'CONFLICT',error:'Settlement prepared durable identity mismatch'}
    return{outcome:'REPLAYED',version:v}
  }catch(e){console.error('[DB] Settlement prepared checkpoint uncertain:',e);return{outcome:'INDETERMINATE',error:'Settlement prepared checkpoint uncertain'}}
}

export async function recordSettlementHorizonCheckpoint(params:{paymentId:string;a2uPaymentId:string;preparedTxHash:string;preparedSequence:string;a2uTxid:string;horizonFeeStroops:number}):Promise<SettlementDurableAdvanceResult>{
  if(!params.paymentId||!params.a2uPaymentId||!/^[0-9a-f]{64}$/.test(params.preparedTxHash)||!/^[1-9][0-9]*$/.test(params.preparedSequence)||
    params.a2uTxid!==params.preparedTxHash||!Number.isSafeInteger(params.horizonFeeStroops)||params.horizonFeeStroops<0)
    return{outcome:'CONFLICT',error:'Settlement Horizon checkpoint input invalid'}
  try{
    const client=await getPostgresClient();if(!client)return{outcome:'INDETERMINATE',error:'PostgreSQL unavailable'}
    const rows=await client.begin(async(tx:any)=>{
      const a=await tx`UPDATE settlement_checkpoints SET version=version+1,stage='horizon_confirmed',a2u_txid=${params.a2uTxid},
        horizon_fee_stroops=${params.horizonFeeStroops},horizon_confirmed_at=NOW(),updated_at=NOW()
        WHERE payment_id=${params.paymentId} AND stage='prepared' AND a2u_payment_id=${params.a2uPaymentId}
        AND prepared_tx_hash=${params.preparedTxHash} AND prepared_sequence=${params.preparedSequence}
        AND a2u_txid IS NULL AND horizon_fee_stroops IS NULL AND horizon_confirmed_at IS NULL RETURNING version,stage`
      if(a.length===1)return[{...a[0],advanced:true}]
      return await tx`SELECT version,stage,a2u_payment_id,prepared_tx_hash,prepared_sequence,a2u_txid,horizon_fee_stroops
        FROM settlement_checkpoints WHERE payment_id=${params.paymentId} OR a2u_payment_id=${params.a2uPaymentId} OR a2u_txid=${params.a2uTxid} FOR UPDATE`
    })
    if(!Array.isArray(rows)||rows.length!==1||!rows[0])return{outcome:'CONFLICT',error:'Settlement Horizon durable identity ambiguous'}
    const r=rows[0] as Record<string,unknown>,v=Number(r.version);if(!Number.isSafeInteger(v)||v<3)return{outcome:'CONFLICT',error:'Settlement Horizon durable version invalid'}
    if(r.advanced===true)return{outcome:'RECORDED',version:v}
    let fee;try{fee=normalizePostgresNumeric(r.horizon_fee_stroops,'settlement.horizon_fee_stroops')}catch{return{outcome:'CONFLICT',error:'Settlement Horizon durable fee invalid'}}
    if(!(typeof r.stage==='string'&&['horizon_confirmed','pi_completed','db_finalized'].includes(r.stage))||r.a2u_payment_id!==params.a2uPaymentId||
      r.prepared_tx_hash!==params.preparedTxHash||String(r.prepared_sequence)!==params.preparedSequence||r.a2u_txid!==params.a2uTxid||fee!==params.horizonFeeStroops)
      return{outcome:'CONFLICT',error:'Settlement Horizon durable evidence mismatch'}
    return{outcome:'REPLAYED',version:v}
  }catch(e){console.error('[DB] Settlement Horizon checkpoint uncertain:',e);return{outcome:'INDETERMINATE',error:'Settlement Horizon checkpoint uncertain'}}
}

export async function recordSettlementPiCompletedCheckpoint(params:{paymentId:string;a2uPaymentId:string;a2uTxid:string}):Promise<SettlementDurableAdvanceResult>{
  if(!params.paymentId||!params.a2uPaymentId||!/^[0-9a-f]{64}$/.test(params.a2uTxid))
    return{outcome:'CONFLICT',error:'Settlement Pi checkpoint input invalid'}
  try{
    const client=await getPostgresClient();if(!client)return{outcome:'INDETERMINATE',error:'PostgreSQL unavailable'}
    const rows=await client.begin(async(tx:any)=>{
      const a=await tx`UPDATE settlement_checkpoints SET version=version+1,stage='pi_completed',pi_completed_at=NOW(),updated_at=NOW()
        WHERE payment_id=${params.paymentId} AND stage='horizon_confirmed' AND a2u_payment_id=${params.a2uPaymentId}
        AND a2u_txid=${params.a2uTxid} AND prepared_tx_hash=${params.a2uTxid}
        AND horizon_confirmed_at IS NOT NULL AND pi_completed_at IS NULL RETURNING version,stage`
      if(a.length===1)return[{...a[0],advanced:true}]
      return await tx`SELECT version,stage,a2u_payment_id,a2u_txid,prepared_tx_hash,horizon_confirmed_at,pi_completed_at
        FROM settlement_checkpoints WHERE payment_id=${params.paymentId} OR a2u_payment_id=${params.a2uPaymentId} OR a2u_txid=${params.a2uTxid} FOR UPDATE`
    })
    if(!Array.isArray(rows)||rows.length!==1||!rows[0])return{outcome:'CONFLICT',error:'Settlement Pi durable identity ambiguous'}
    const r=rows[0] as Record<string,unknown>,v=Number(r.version);if(!Number.isSafeInteger(v)||v<4)return{outcome:'CONFLICT',error:'Settlement Pi durable version invalid'}
    if(r.advanced===true)return{outcome:'RECORDED',version:v}
    if(!(typeof r.stage==='string'&&['pi_completed','db_finalized'].includes(r.stage))||r.a2u_payment_id!==params.a2uPaymentId||
      r.a2u_txid!==params.a2uTxid||r.prepared_tx_hash!==params.a2uTxid||r.horizon_confirmed_at==null||r.pi_completed_at==null)
      return{outcome:'CONFLICT',error:'Settlement Pi durable evidence mismatch'}
    return{outcome:'REPLAYED',version:v}
  }catch(e){console.error('[DB] Settlement Pi checkpoint uncertain:',e);return{outcome:'INDETERMINATE',error:'Settlement Pi checkpoint uncertain'}}
}

/** Convert a finite Pi fee to exact integer stroops without IEEE-754 multiplication noise.
 * Reject fractional stroops rather than silently rounding them into financial authority. */
function exactHorizonFeeStroops(fee: number): number {
  if (!Number.isFinite(fee) || fee < 0) return NaN
  return fee === 0 ? 0 : numberToExactPositiveStroops(fee) ?? NaN
}

export async function recordSettlementDbFinalizedCheckpoint(params:{
  paymentId:string;u2aIdentifier:string;u2aTxid:string;a2uPaymentId:string;a2uTxid:string;merchantId:string;merchantUid:string;
  customerAmount:number;merchantAmount:number;horizonFeeCharged:number;appCommission:number
}):Promise<SettlementDurableAdvanceResult>{
  const feeStroops=exactHorizonFeeStroops(params.horizonFeeCharged)
  if(!params.paymentId||!params.u2aIdentifier||!/^[0-9a-f]{64}$/.test(params.u2aTxid)||!params.a2uPaymentId||!/^[0-9a-f]{64}$/.test(params.a2uTxid)||!params.merchantId||!params.merchantUid||
    numberToExactPositiveStroops(params.customerAmount)===null||params.merchantAmount!==params.customerAmount||params.appCommission!==0||
    !Number.isSafeInteger(feeStroops)||feeStroops<0)return{outcome:'CONFLICT',error:'Settlement DB-finality input invalid'}
  try{
    const client=await getPostgresClient();if(!client)return{outcome:'INDETERMINATE',error:'PostgreSQL unavailable'}
    const rows=await client.begin(async(tx:any)=>{
      // Serialize finality with accounting and refund authority on the same payment key.
      await tx`SELECT pg_advisory_xact_lock(hashtextextended(${params.paymentId}, 0))`
      const a=await tx`UPDATE settlement_checkpoints SET version=version+1,stage='db_finalized',db_finalized_at=NOW(),updated_at=NOW()
        WHERE payment_id=${params.paymentId} AND stage='pi_completed' AND merchant_id=${params.merchantId} AND merchant_uid=${params.merchantUid}
        AND customer_amount=${params.customerAmount} AND merchant_amount=${params.merchantAmount} AND app_commission=0
        AND a2u_payment_id=${params.a2uPaymentId} AND a2u_txid=${params.a2uTxid} AND prepared_tx_hash=${params.a2uTxid}
        AND horizon_fee_stroops=${feeStroops} AND horizon_confirmed_at IS NOT NULL AND pi_completed_at IS NOT NULL AND db_finalized_at IS NULL
        AND NOT EXISTS(SELECT 1 FROM refund_checkpoints rf WHERE rf.payment_id=${params.paymentId})
        AND EXISTS(SELECT 1 FROM receipts r JOIN transactions t ON t.id=r.transaction_id
          WHERE t.payment_id=${params.u2aIdentifier} AND t.merchant_id=${params.merchantId} AND t.merchant_uid=${params.merchantUid}
          AND t.amount=${params.merchantAmount} AND t.status='completed' AND t.currency='π'
          AND r.merchant_id=${params.merchantId} AND r.merchant_uid=${params.merchantUid} AND r.currency='π'
          AND r.amount=${params.merchantAmount} AND r.txid=${params.a2uTxid}
          AND r.app_net_impact=${-params.horizonFeeCharged} AND r.settlement_status='settled_to_merchant'
          AND r.u2a_identifier=${params.u2aIdentifier} AND r.u2a_txid=${params.u2aTxid}
          AND r.a2u_identifier=${params.a2uPaymentId} AND r.a2u_txid=${params.a2uTxid} AND r.customer_amount=${params.customerAmount} AND r.merchant_amount=${params.merchantAmount}
          AND r.horizon_fee_charged=${params.horizonFeeCharged} AND r.app_commission=0)
        RETURNING version,stage`
      if(a.length===1)return[{...a[0],advanced:true}]
      // R36: replay evidence must be read under the SAME advisory lock and
      // transaction snapshot as the checkpoint. No post-commit TOCTOU read.
      return await tx`SELECT s.version,s.stage,s.merchant_id,s.merchant_uid,s.customer_amount,s.merchant_amount,s.app_commission,
        s.a2u_payment_id,s.a2u_txid,s.prepared_tx_hash,s.horizon_fee_stroops,s.pi_completed_at,s.db_finalized_at,
        EXISTS(SELECT 1 FROM receipts rc JOIN transactions t ON t.id=rc.transaction_id
          WHERE t.payment_id=${params.u2aIdentifier} AND t.merchant_id=${params.merchantId}
            AND t.merchant_uid=${params.merchantUid} AND t.amount=${params.merchantAmount}
            AND t.status='completed' AND t.currency='π'
            AND rc.merchant_id=${params.merchantId} AND rc.merchant_uid=${params.merchantUid} AND rc.currency='π'
            AND rc.amount=${params.merchantAmount} AND rc.txid=${params.a2uTxid}
            AND rc.app_net_impact=${-params.horizonFeeCharged} AND rc.settlement_status='settled_to_merchant'
            AND rc.u2a_identifier=${params.u2aIdentifier}
            AND rc.u2a_txid=${params.u2aTxid} AND rc.a2u_identifier=${params.a2uPaymentId}
            AND rc.a2u_txid=${params.a2uTxid} AND rc.customer_amount=${params.customerAmount}
            AND rc.merchant_amount=${params.merchantAmount} AND rc.horizon_fee_charged=${params.horizonFeeCharged}
            AND rc.app_commission=0) AS accounting_valid,
        NOT EXISTS(SELECT 1 FROM refund_checkpoints WHERE payment_id=${params.paymentId}) AS xor_valid
        FROM settlement_checkpoints s
        WHERE s.payment_id=${params.paymentId} OR s.a2u_payment_id=${params.a2uPaymentId} OR s.a2u_txid=${params.a2uTxid}
        FOR UPDATE OF s`
    })
    if(!Array.isArray(rows)||rows.length!==1||!rows[0])return{outcome:'CONFLICT',error:'Settlement DB-finality durable identity ambiguous'}
    const r=rows[0] as Record<string,unknown>,v=Number(r.version);if(!Number.isSafeInteger(v)||v<5)return{outcome:'CONFLICT',error:'Settlement DB-finality durable version invalid'}
    if(r.advanced===true)return{outcome:'RECORDED',version:v}
    let ca,ma,ac,fs;try{ca=normalizePostgresNumeric(r.customer_amount,'settlement.customer_amount');ma=normalizePostgresNumeric(r.merchant_amount,'settlement.merchant_amount');ac=normalizePostgresNumeric(r.app_commission,'settlement.app_commission');fs=normalizePostgresNumeric(r.horizon_fee_stroops,'settlement.horizon_fee_stroops')}catch{return{outcome:'CONFLICT',error:'Settlement DB-finality durable accounting invalid'}}
    if(r.stage!=='db_finalized'||r.merchant_id!==params.merchantId||r.merchant_uid!==params.merchantUid||ca!==params.customerAmount||ma!==params.merchantAmount||ac!==0||
      r.a2u_payment_id!==params.a2uPaymentId||r.a2u_txid!==params.a2uTxid||r.prepared_tx_hash!==params.a2uTxid||fs!==feeStroops||r.pi_completed_at==null||r.db_finalized_at==null)
      return{outcome:'CONFLICT',error:'Settlement DB-finality durable evidence mismatch'}
    if(r.accounting_valid!==true || r.xor_valid!==true)
      return{outcome:'CONFLICT',error:'Settlement DB-finality replay accounting or XOR evidence missing'}
    return{outcome:'REPLAYED',version:v}
  }catch(e){console.error('[DB] Settlement DB-finality checkpoint uncertain:',e);return{outcome:'INDETERMINATE',error:'Settlement DB-finality checkpoint uncertain'}}
}

export async function ensureRefundCheckpointTables(): Promise<boolean> {
  return r36VerifyTables([
    ['refund_checkpoints',['refund_id','payment_id','idempotency_key','status','stage','payer_uid','amount','pi_mutation_guard_version']],
    ['financial_pi_mutation_attempts',['mutation_kind','payment_id','external_payment_id']],
    ['refund_pi_create_attempts',['refund_id','payment_id','idempotency_key']],
    ['refund_automatic_retirements',['refund_id','payment_id','evidence_code']],
    ['refund_accounting_records',['refund_id','payment_id','refund_txid','amount']],
    ['refund_audit_events',['event_id','refund_id','payment_id','event_type']]
  ])
}

export async function ensureRefundAccountingTable(): Promise<boolean> {
  return r36VerifyColumns('refund_accounting_records', ['refund_id','payment_id','refund_payment_id','refund_txid','payer_uid','amount','horizon_fee_stroops'])
}

export async function initializeSchema() {
  // R36: startup must never create or alter financial schema.
  const ready = await r36VerifyTables([
    ['transactions',['id','payment_id','merchant_id','amount','status']],
    ['receipts',['transaction_id','customer_amount','app_commission','merchant_amount','app_net_impact','settlement_status']],
    ['merchant_balances',['merchant_id']],
    ['settlement_checkpoints',['payment_id','version','stage']],
    ['refund_checkpoints',['refund_id','payment_id','status']]
  ])
  if (!ready || !(await ensureSettlementCheckpointTable()) || !(await ensureRefundCheckpointTables())) {
    throw new Error('R36_SCHEMA_NOT_READY: offline migration and catalog verification required')
  }
}

/**
 * Ensure receipts table has all required accounting columns before transaction
 * MUST fail explicitly if any column cannot be added - not wrapped in try-catch
 * This is called before client.begin() to guarantee schema readiness
 */
export async function ensureReceiptsSchema() {
  const ready = await r36VerifyColumns('receipts', ['customer_amount','horizon_fee_charged','app_commission','merchant_amount','app_net_impact','settlement_status'])
  if (!ready) throw new Error('R36_RECEIPTS_SCHEMA_NOT_READY: offline migration required')
}

/**
 * Get transaction by ID
 */
export async function getTransaction(transactionId: string): Promise<TransactionRow | null> {
  if (!process.env.DATABASE_URL) return null

  try {
    const result = await query(
      'SELECT * FROM transactions WHERE id = $1',
      [transactionId]
    )
    if (!Array.isArray(result) || result.length === 0) return null
    const row = result[0]
    if (typeof row !== 'object' || row === null) return null
    return row as TransactionRow
  } catch (error) {
    console.error('[DB] getTransaction failed:', error)
    return null
  }
}

/**
 * Get receipt by transaction ID (includes transaction reference and description)
 */
export async function getReceipt(transactionId: string): Promise<ReceiptRow | null> {
  if (!process.env.DATABASE_URL) return null

  try {
    const result = await query(
      `SELECT 
        r.*,
        t.reference,
        t.description,
        t.merchant_id,
        t.payment_id
      FROM receipts r
      LEFT JOIN transactions t ON r.transaction_id = t.id
      WHERE r.transaction_id = $1`,
      [transactionId]
    )
    if (!Array.isArray(result) || result.length === 0) return null
    const row = result[0]
    if (typeof row !== 'object' || row === null) return null
    return row as ReceiptRow
  } catch (error) {
    console.error('[DB] getReceipt failed:', error)
    return null
  }
}

/**
 * Get receipt by verified Pi U2A payment identifier.
 * This is an internal linkage helper only; the public/user-facing identifier
 * remains the FlashPay application payment ID.
 */
export async function getReceiptByU2AIdentifier(u2aIdentifier: string): Promise<ReceiptRow | null> {
  if (!process.env.DATABASE_URL) return null

  try {
    const result = await query(
      `SELECT
        r.*,
        t.reference,
        t.description,
        t.merchant_id,
        t.payment_id
      FROM transactions t
      INNER JOIN receipts r ON r.transaction_id = t.id
      WHERE t.payment_id = $1`,
      [u2aIdentifier]
    )
    if (!Array.isArray(result) || result.length === 0) return null
    const row = result[0]
    if (typeof row !== 'object' || row === null) return null
    return row as ReceiptRow
  } catch (error) {
    console.error('[DB] getReceiptByU2AIdentifier failed:', error)
    return null
  }
}

/**
 * Get transactions by merchant with date range
 */
export async function getTransactionsByMerchant(
  merchantId: string,
  options: {
    fromDate?: Date
    toDate?: Date
    limit?: number
    offset?: number
  } = {}
) {
  if (!process.env.DATABASE_URL) return { transactions: [], total: 0 }

  try {
    const limit = options.limit || 50
    const offset = options.offset || 0

    // Build WHERE clause with date filters - qualify all with t
    let whereClause = 'WHERE t.merchant_id = $1'
    const params: any[] = [merchantId]
    let paramIndex = 2

    if (options.fromDate) {
      whereClause += ` AND t.created_at >= $${paramIndex}`
      params.push(options.fromDate)
      paramIndex++
    }

    if (options.toDate) {
      whereClause += ` AND t.created_at <= $${paramIndex}`
      params.push(options.toDate)
      paramIndex++
    }

    // Get total count
    const countQuery = `SELECT COUNT(*) as count FROM transactions t ${whereClause}`
    const countResult = await query(countQuery, params)
    
    // Validate and convert count
    let total = 0
    if (Array.isArray(countResult) && countResult.length > 0) {
      const row = countResult[0] as unknown
      if (typeof row === 'object' && row !== null) {
        const rowObj = row as Record<string, unknown>
        const countNum = Number(rowObj.count)
        if (Number.isFinite(countNum) && countNum >= 0) {
          total = countNum
        }
      }
    }

    // Get paginated results with receipt LEFT JOIN
    const transactionsQuery = `
      SELECT 
        t.id,
        t.payment_id,
        t.merchant_id,
        t.amount,
        t.currency,
        t.description,
        t.reference,
        t.created_at,
        t.completed_at,
        t.status,
        r.settlement_status,
        r.u2a_identifier,
        r.u2a_txid,
        r.a2u_identifier,
        r.a2u_txid
      FROM transactions t
      LEFT JOIN receipts r ON r.transaction_id = t.id
      ${whereClause}
      ORDER BY t.created_at DESC
      LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
    `
    const paginationParams = [...params, limit, offset]
    const transactionsResult = await query(transactionsQuery, paginationParams)

    return {
      transactions: transactionsResult || [],
      total,
    }
  } catch (error) {
    console.error('[DB] getTransactionsByMerchant failed:', error)
    return { transactions: [], total: 0 }
  }
}



/**
 * Get merchant balance
 */
export async function getMerchantBalance(merchantId: string): Promise<MerchantBalanceRow | null> {
  if (!process.env.DATABASE_URL) return null

  try {
    const result = await query(
      'SELECT * FROM merchant_balances WHERE merchant_id = $1',
      [merchantId]
    )
    if (!Array.isArray(result) || result.length === 0) return null
    const row = result[0]
    if (typeof row !== 'object' || row === null) return null
    return row as MerchantBalanceRow
  } catch (error) {
    console.error('[DB] getMerchantBalance failed:', error)
    return null
  }
}

/**
 * Get merchant payment dashboard summary statistics
 * Read-only query: transactions LEFT JOIN receipts for settlement tracking
 * Returns 14 normalized numeric values or null on any error
 */
export async function getMerchantPaymentDashboardSummary(
  merchantId: string
): Promise<{
  total_requests: number
  total_payment_volume: number
  settled_transactions: number
  total_settled_amount: number
  pending_transactions: number
  total_awaiting_amount: number
  failed_transactions: number
  total_failed_amount: number
  cancelled_transactions: number
  total_cancelled_amount: number
  completed_transactions: number
  total_completed_amount: number
  other_transactions: number
  total_other_amount: number
} | null> {
  if (!process.env.DATABASE_URL) return null

  try {
    // Parameterized CTE: transactions LEFT JOIN receipts, use r.settlement_status as single source of truth
    const result = await query(
      `WITH ${financialPresentationIntegrityCTE}, payment_summary AS (
        SELECT 
          COUNT(*) as total_requests,
          COALESCE(SUM(t.amount), 0) as total_payment_volume,
          COUNT(CASE WHEN r.settlement_status = 'settled_to_merchant' THEN 1 END) as settled_transactions,
          COALESCE(SUM(CASE WHEN r.settlement_status = 'settled_to_merchant' THEN t.amount ELSE NULL END), 0) as total_settled_amount,
          COUNT(CASE WHEN r.settlement_status IN ('settlement_pending', 'paid_to_app', 'pending') THEN 1 END) as pending_transactions,
          COALESCE(SUM(CASE WHEN r.settlement_status IN ('settlement_pending', 'paid_to_app', 'pending') THEN t.amount ELSE NULL END), 0) as total_awaiting_amount,
          COUNT(CASE WHEN r.settlement_status IN ('failed', 'settlement_failed') THEN 1 END) as failed_transactions,
          COALESCE(SUM(CASE WHEN r.settlement_status IN ('failed', 'settlement_failed') THEN t.amount ELSE NULL END), 0) as total_failed_amount,
          COUNT(CASE WHEN r.settlement_status = 'cancelled' THEN 1 END) as cancelled_transactions,
          COALESCE(SUM(CASE WHEN r.settlement_status = 'cancelled' THEN t.amount ELSE NULL END), 0) as total_cancelled_amount,
          COUNT(CASE WHEN r.settlement_status = 'completed' THEN 1 END) as completed_transactions,
          COALESCE(SUM(CASE WHEN r.settlement_status = 'completed' THEN t.amount ELSE NULL END), 0) as total_completed_amount,
          COUNT(CASE WHEN r.settlement_status IS NULL OR r.settlement_status NOT IN ('settled_to_merchant', 'pending', 'paid_to_app', 'settlement_pending', 'failed', 'settlement_failed', 'cancelled', 'completed') THEN 1 END) as other_transactions,
          COALESCE(SUM(CASE WHEN r.settlement_status IS NULL OR r.settlement_status NOT IN ('settled_to_merchant', 'pending', 'paid_to_app', 'settlement_pending', 'failed', 'settlement_failed', 'cancelled', 'completed') THEN t.amount ELSE NULL END), 0) as total_other_amount
        FROM transactions t
        LEFT JOIN receipts r ON r.transaction_id = t.id
        WHERE t.merchant_id = $1
      )
      SELECT * FROM payment_summary WHERE (SELECT valid FROM presentation_integrity)`,
      [merchantId]
    )

    // Require array length 1
    if (!Array.isArray(result) || result.length !== 1) {
      console.error('[DB] getMerchantPaymentDashboardSummary: query returned non-array or wrong length')
      return null
    }

    const candidate = result[0]
    // Require row to be non-null object, not array
    if (candidate === null || typeof candidate !== 'object' || Array.isArray(candidate)) {
      console.error('[DB] getMerchantPaymentDashboardSummary: row is null, non-object, or array')
      return null
    }

    const row = candidate as Record<string, unknown>

    // Normalize all 14 values via normalizePostgresNumeric
    try {
      return {
        total_requests: normalizePostgresNumeric(row.total_requests, 'total_requests'),
        total_payment_volume: normalizePostgresNumeric(row.total_payment_volume, 'total_payment_volume'),
        settled_transactions: normalizePostgresNumeric(row.settled_transactions, 'settled_transactions'),
        total_settled_amount: normalizePostgresNumeric(row.total_settled_amount, 'total_settled_amount'),
        pending_transactions: normalizePostgresNumeric(row.pending_transactions, 'pending_transactions'),
        total_awaiting_amount: normalizePostgresNumeric(row.total_awaiting_amount, 'total_awaiting_amount'),
        failed_transactions: normalizePostgresNumeric(row.failed_transactions, 'failed_transactions'),
        total_failed_amount: normalizePostgresNumeric(row.total_failed_amount, 'total_failed_amount'),
        cancelled_transactions: normalizePostgresNumeric(row.cancelled_transactions, 'cancelled_transactions'),
        total_cancelled_amount: normalizePostgresNumeric(row.total_cancelled_amount, 'total_cancelled_amount'),
        completed_transactions: normalizePostgresNumeric(row.completed_transactions, 'completed_transactions'),
        total_completed_amount: normalizePostgresNumeric(row.total_completed_amount, 'total_completed_amount'),
        other_transactions: normalizePostgresNumeric(row.other_transactions, 'other_transactions'),
        total_other_amount: normalizePostgresNumeric(row.total_other_amount, 'total_other_amount'),
      }
    } catch (err) {
      console.error('[DB] getMerchantPaymentDashboardSummary: normalization failed:', err)
      return null
    }
  } catch (error) {
    console.error('[DB] getMerchantPaymentDashboardSummary failed:', error)
    return null
  }
}

/**
 * Get merchant profile summary with transaction statistics
 * Read-only query: transactions LEFT JOIN receipts for settlement tracking
 */
export async function getSettledPaymentIds(merchantId: string, piPaymentIds: string[]): Promise<Set<string>> {
  if (!process.env.DATABASE_URL || piPaymentIds.length === 0) return new Set()

  try {
    const result = await query(
      `SELECT t.payment_id
       FROM transactions t
       JOIN receipts r ON r.transaction_id = t.id
       WHERE t.merchant_id = $1
         AND r.settlement_status = $2
         AND t.payment_id = ANY($3::text[])`,
      [merchantId, "settled_to_merchant", piPaymentIds],
    )

    const settledIds = new Set<string>()
    for (const row of result || []) {
      if (row && typeof row === "object") {
        const paymentId = (row as Record<string, unknown>).payment_id
        if (typeof paymentId === "string") settledIds.add(paymentId)
      }
    }
    return settledIds
  } catch (error) {
    console.error("[DB] getSettledPaymentIds failed:", error)
    return new Set()
  }
}

export async function getMerchantProfileSummary(merchantId: string): Promise<{
  totalTransactions: number
  settledTransactions: number
  totalSettledAmount: number
  pendingTransactions: number
  totalAwaitingAmount: number
  failedTransactions: number
  totalFailedAmount: number
  cancelledTransactions: number
  totalCancelledAmount: number
  completedTransactions: number
  totalCompletedAmount: number
  latestTransaction: {
    transactionId: string
    amount: number
    reference: string
    createdAt: string
    settlementStatus: string | null
  } | null
} | null> {
  if (!process.env.DATABASE_URL) return null

  try {
    // Reuse the dashboard summary as the single raw accounting projection for
    // Profile and Payment Dashboard so their all-time counts/amounts cannot drift.
    const dashboardSummary = await getMerchantPaymentDashboardSummary(merchantId)
    if (!dashboardSummary) return null

    // Get latest transaction
    const latestResult = await query(
      `SELECT 
        t.id as transaction_id,
        t.amount,
        t.reference,
        t.created_at,
        r.settlement_status
      FROM transactions t
      LEFT JOIN receipts r ON r.transaction_id = t.id
      WHERE t.merchant_id = $1
      ORDER BY t.created_at DESC
      LIMIT 1`,
      [merchantId]
    )

    let latestTransaction: {
      transactionId: string
      amount: number
      reference: string
      createdAt: string
      settlementStatus: string | null
    } | null = null

    if (Array.isArray(latestResult) && latestResult.length > 0) {
      const latestRow = latestResult[0] as Record<string, unknown>
      if (typeof latestRow === 'object' && latestRow !== null) {
        // Validate required string fields: transaction_id and reference
        if (
          typeof latestRow.transaction_id !== 'string' ||
          typeof latestRow.reference !== 'string'
        ) {
          return null
        }

        // Validate and convert created_at: Date | string
        const createdAtValue = latestRow.created_at
        if (!(createdAtValue instanceof Date) && typeof createdAtValue !== 'string') {
          return null
        }

        const createdAtTime = createdAtValue instanceof Date
          ? createdAtValue.getTime()
          : new Date(createdAtValue).getTime()

        if (!Number.isFinite(createdAtTime)) {
          return null
        }

        latestTransaction = {
          transactionId: latestRow.transaction_id,
          amount: normalizePostgresNumeric(latestRow.amount, 'latest.amount'),
          reference: latestRow.reference,
          createdAt: new Date(createdAtTime).toISOString(),
          settlementStatus: typeof latestRow.settlement_status === 'string' ? latestRow.settlement_status : null,
        }
      }
    }

    return {
      totalTransactions: dashboardSummary.total_requests,
      settledTransactions: dashboardSummary.settled_transactions,
      totalSettledAmount: dashboardSummary.total_settled_amount,
      pendingTransactions: dashboardSummary.pending_transactions,
      totalAwaitingAmount: dashboardSummary.total_awaiting_amount,
      failedTransactions: dashboardSummary.failed_transactions,
      totalFailedAmount: dashboardSummary.total_failed_amount,
      cancelledTransactions: dashboardSummary.cancelled_transactions,
      totalCancelledAmount: dashboardSummary.total_cancelled_amount,
      completedTransactions: dashboardSummary.completed_transactions,
      totalCompletedAmount: dashboardSummary.total_completed_amount,
      latestTransaction,
    }
  } catch (error) {
    console.error('[DB] getMerchantProfileSummary failed:', error)
    return null
  }
}

/**
 * Record a settlement transfer to merchant
 */
export async function recordSettlementTransfer(
  merchantId: string,
  transactionId: string,
  amount: number,
  txid?: string
): Promise<SettlementRequest | null> {
  if (!process.env.DATABASE_URL) return null

  try {
    const result = await query(
      `INSERT INTO settlement_requests
       (merchant_id, transaction_id, amount, status, created_at)
       VALUES ($1, $2, $3, 'queued', NOW())
       RETURNING *`,
      [merchantId, transactionId, amount]
    )

    console.log('[DB] Settlement request queued', { merchantId, amount })
    if (!Array.isArray(result) || result.length === 0) return null
    const row = result[0]
    if (typeof row !== 'object' || row === null) return null
    return row as SettlementRequest
  } catch (error) {
    console.error('[DB] Settlement request failed:', error)
    return null
  }
}

/**
 * Get pending settlements for a merchant
 * Validates and normalizes each row to SettlementRequest type
 */
export async function getPendingSettlements(merchantId: string): Promise<SettlementRequest[]> {
  if (!process.env.DATABASE_URL) return []

  try {
    const result = await query(
      `SELECT sr.*, t.payment_id 
       FROM settlement_requests sr
       LEFT JOIN transactions t ON sr.transaction_id = t.id
       WHERE sr.merchant_id = $1 AND sr.status IN ('queued', 'processing')
       ORDER BY sr.created_at ASC`,
      [merchantId]
    )

    if (!result || result.length === 0) return []

    // Validate and normalize each row
    const validated: SettlementRequest[] = []
    for (const row of result) {
      const unknown = row as unknown
      
      // Validate required string fields
      if (typeof unknown !== 'object' || unknown === null) continue
      const obj = unknown as Record<string, unknown>
      
      if (typeof obj.id !== 'string') continue
      if (typeof obj.merchant_id !== 'string') continue
      if (typeof obj.transaction_id !== 'string') continue
      if (typeof obj.status !== 'string') continue
      if (typeof obj.created_at !== 'string') continue
      
      // Validate allowed status union
      const status = obj.status as string
      if (!['queued', 'processing', 'completed', 'failed'].includes(status)) continue
      
      // Convert amount with validation
      const amountNum = Number(obj.amount)
      if (!Number.isFinite(amountNum)) continue
      
      // Convert retry_count with validation
      const retryNum = Number(obj.retry_count ?? 0)
      if (!Number.isFinite(retryNum)) continue
      
      validated.push({
        id: obj.id,
        merchant_id: obj.merchant_id,
        transaction_id: obj.transaction_id,
        amount: amountNum,
        status: status as 'queued' | 'processing' | 'completed' | 'failed',
        created_at: obj.created_at,
        completed_at: typeof obj.completed_at === 'string' ? obj.completed_at : undefined,
        txid: typeof obj.txid === 'string' ? obj.txid : undefined,
        error_message: typeof obj.error_message === 'string' ? obj.error_message : undefined,
        retry_count: retryNum,
        payment_id: typeof obj.payment_id === 'string' ? obj.payment_id : undefined,
      })
    }

    return validated
  } catch (error) {
    console.error('[DB] getPendingSettlements failed:', error)
    return []
  }
}

/**
 * Update settlement status and txid
 */
export async function updateSettlementStatus(
  settlementId: string,
  status: 'queued' | 'processing' | 'completed' | 'failed',
  txid?: string,
  errorMessage?: string
): Promise<SettlementRequest | null> {
  if (!process.env.DATABASE_URL) return null

  try {
    const updates: string[] = ['status = $2', 'retry_count = retry_count + 1']
    const params: unknown[] = [settlementId, status]
    let paramIndex = 3

    if (status === 'completed') {
      updates.push(`completed_at = NOW()`)
      if (txid) {
        updates.push(`txid = $${paramIndex}`)
        params.push(txid)
        paramIndex++
      }
    }

    if (status === 'failed' && errorMessage) {
      updates.push(`error_message = $${paramIndex}`)
      params.push(errorMessage)
      paramIndex++
    }

    const result = await query(
      `UPDATE settlement_requests 
       SET ${updates.join(', ')}
       WHERE id = $1
       RETURNING *`,
      params
    )

    console.log('[DB] Settlement status updated:', { settlementId, status, txid })
    if (!Array.isArray(result) || result.length === 0) return null
    const row = result[0]
    if (typeof row !== 'object' || row === null) return null
    return row as SettlementRequest
  } catch (error) {
    console.error('[DB] updateSettlementStatus failed:', error)
    return null
  }
}

/**
 * Get settlement history for merchant
 */
export async function getSettlementHistory(merchantId: string, limit: number = 50) {
  if (!process.env.DATABASE_URL) return []

  try {
    const result = await query(
      `SELECT sr.*, t.payment_id, t.created_at as payment_date
       FROM settlement_requests sr
       LEFT JOIN transactions t ON sr.transaction_id = t.id
       WHERE sr.merchant_id = $1
       ORDER BY sr.created_at DESC
       LIMIT $2`,
      [merchantId, limit]
    )
    return result || []
  } catch (error) {
    console.error('[DB] getSettlementHistory failed:', error)
    return []
  }
}

/**
 * Record A2U transaction atomically after funds reach merchant wallet
 * Inserts transaction, receipt, updates merchant balance, and stores payment IDs/txids
 * Uses transaction-scoped client for true ACID guarantees - all or nothing
 */
export async function recordA2UTransactionAtomic(params: {
  paymentId: string          // Canonical internal payment ID; financial authority lock key
  u2aIdentifier: string      // U2A identifier from Pi webhook (identifier field)
  u2aTxid: string            // clientTxid from U2A flow
  a2uIdentifier: string      // A2U identifier from A2U response
  a2uTxid: string            // Horizon transaction ID from A2U flow
  merchantId: string
  merchantUid: string
  customerAmount: number     // Verified U2A amount (what customer sent)
  merchantAmount: number     // Actual amount in A2U blockchain transfer (what was sent on Stellar)
  horizonFeeCharged: number  // Actual submitResult.fee_charged / 10_000_000 (in Pi)
  appCommission: number      // REQUIRED: App commission (must be explicit, no fallback)
  note?: string
  createdAt?: Date
}): Promise<
  | { success: true; transactionId: string; transaction: { u2aIdentifier: string; u2aTxid: string; a2uIdentifier: string; a2uTxid: string; merchantId: string; merchantUid: string } }
  | { success: false; error: string }
> {
  // STRICT VALIDATION: Reject transaction if any required field is missing or invalid
  
  if (typeof params.paymentId !== 'string' || !params.paymentId.trim() || params.paymentId !== params.paymentId.trim()) {
    throw new Error('Canonical paymentId is required for accounting authority')
  }
  // Validate identifiers - must not be empty strings
  if (!params.u2aIdentifier || typeof params.u2aIdentifier !== 'string') {
    throw new Error('u2aIdentifier is required and must be a non-empty string')
  }
  if (!params.u2aTxid || typeof params.u2aTxid !== 'string') {
    throw new Error('u2aTxid is required and must be a non-empty string')
  }
  if (!params.a2uIdentifier || typeof params.a2uIdentifier !== 'string') {
    throw new Error('a2uIdentifier is required and must be a non-empty string')
  }
  if (!params.a2uTxid || typeof params.a2uTxid !== 'string') {
    throw new Error('a2uTxid is required and must be a non-empty string')
  }
  
  // Validate merchant identifiers
  if (!params.merchantId || typeof params.merchantId !== 'string') {
    throw new Error('merchantId is required and must be a non-empty string')
  }
  if (!params.merchantUid || typeof params.merchantUid !== 'string') {
    throw new Error('merchantUid is required and must be a non-empty string')
  }
  
  // CRITICAL: Use actual amounts from blockchain, not calculated amounts
  const customerAmount = params.customerAmount
  const merchantAmount = params.merchantAmount
  const horizonFeeCharged = params.horizonFeeCharged
  
  // Validate all amounts are finite numbers (no NaN, Infinity, or null)
  if (typeof customerAmount !== 'number' || !Number.isFinite(customerAmount)) {
    throw new Error('customerAmount must be a finite number')
  }
  if (typeof merchantAmount !== 'number' || !Number.isFinite(merchantAmount)) {
    throw new Error('merchantAmount must be a finite number')
  }
  if (typeof horizonFeeCharged !== 'number' || !Number.isFinite(horizonFeeCharged)) {
    throw new Error('horizonFeeCharged must be a finite number')
  }
  
  // CRITICAL: appCommission is REQUIRED, no fallback to 0
  // Must be an explicit number (not undefined, not null, not || 0)
  if (typeof params.appCommission !== 'number' || !Number.isFinite(params.appCommission)) {
    throw new Error('appCommission is required and must be a finite number')
  }
  const appCommission = params.appCommission

  // D: reject non-network precision before any SQL write. NUMERIC(18,8)
  // must not round an invalid amount/fee and leave a committed partial result.
  if (numberToExactPositiveStroops(customerAmount) === null ||
      numberToExactPositiveStroops(merchantAmount) === null ||
      !Number.isSafeInteger(exactHorizonFeeStroops(horizonFeeCharged))) {
    throw new Error('Accounting amounts and fee must use exact network stroops')
  }
  
  // Calculate app net impact: what the app absorbs (may be negative if app bears fees)
  // appNetImpact = customerAmount - merchantAmount - horizonFeeCharged
  // The merchant is credited ONLY with merchantAmount (actual blockchain transfer)
  const appNetImpact = customerAmount - merchantAmount - horizonFeeCharged
  
  console.log('[DB] Accounting breakdown:')
  console.log('[DB]   - customerAmount:', customerAmount, '(what customer sent)')
  console.log('[DB]   - merchantAmount:', merchantAmount, '(actual blockchain transfer to merchant)')
  console.log('[DB]   - horizonFeeCharged:', horizonFeeCharged, '(actual Horizon fee)')
  console.log('[DB]   - appCommission:', appCommission)
  console.log('[DB]   - appNetImpact:', appNetImpact, '(app absorbs this: may be negative if app bears fees)')
  if (!process.env.DATABASE_URL) {
    console.error('[DB] PostgreSQL not configured for A2U transaction')
    return { success: false, error: 'Database not configured' }
  }

  try {
    console.log('[DB] Starting atomic A2U transaction:', {
      u2aIdentifier: params.u2aIdentifier,
      a2uIdentifier: params.a2uIdentifier,
      a2uTxid: params.a2uTxid,
      merchantId: params.merchantId,
      customerAmount: customerAmount,
      merchantAmount: merchantAmount,
      horizonFeeCharged: horizonFeeCharged,
    })

    const transactionId = randomUUID()
    const reference = `PAY-${new Date().getFullYear()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`
    const createdAtDate = params.createdAt || new Date()

    // Import postgres and create actual client from DATABASE_URL
    const postgres = await import('postgres')
    const sql = postgres.default
    if (!sql || !process.env.DATABASE_URL) {
      return { success: false, error: 'PostgreSQL client unavailable' }
    }

    const client = sql(process.env.DATABASE_URL)
    
    try {
      // Use postgres transaction callback API (no manual BEGIN/COMMIT/ROLLBACK)
      const result = await client.begin(async (tx) => {
        // G8-F3-R5: Authoritative accounting barrier. Same PostgreSQL transaction and
        // same payment advisory lock as the settlement/refund authority writers.
        // Never use Redis or a prior preflight as accounting authority.
        await tx`SELECT pg_advisory_xact_lock(hashtextextended(${params.paymentId}, 0))`
        const authority = await tx`
          SELECT s.payment_id, s.stage, s.version, s.merchant_id, s.merchant_uid,
                 s.customer_amount, s.merchant_amount, s.app_commission,
                 s.u2a_identifier, s.u2a_txid, s.a2u_payment_id, s.a2u_txid,
                 s.prepared_tx_hash, s.horizon_fee_stroops,
                 s.horizon_confirmed_at, s.pi_completed_at,
                 EXISTS(SELECT 1 FROM refund_checkpoints r WHERE r.payment_id = ${params.paymentId}) AS refund_active
          FROM settlement_checkpoints s WHERE s.payment_id = ${params.paymentId}
          FOR UPDATE OF s
        `
        if (authority.length !== 1) throw new Error('G8_ACCOUNTING_AUTHORITY_ABSENT_OR_AMBIGUOUS')
        const a = authority[0]
        const feeStroops = exactHorizonFeeStroops(params.horizonFeeCharged)
        if (a.refund_active !== false || !['pi_completed', 'db_finalized'].includes(a.stage) ||
            !Number.isSafeInteger(Number(a.version)) || Number(a.version) < 4 ||
            a.merchant_id !== params.merchantId || a.merchant_uid !== params.merchantUid ||
            normalizePostgresNumeric(a.customer_amount, 'authority.customer_amount') !== customerAmount ||
            normalizePostgresNumeric(a.merchant_amount, 'authority.merchant_amount') !== merchantAmount ||
            normalizePostgresNumeric(a.app_commission, 'authority.app_commission') !== 0 ||
            customerAmount <= 0 || customerAmount !== merchantAmount || appCommission !== 0 ||
            a.u2a_identifier !== params.u2aIdentifier || a.u2a_txid !== params.u2aTxid ||
            a.a2u_payment_id !== params.a2uIdentifier || a.a2u_txid !== params.a2uTxid ||
            a.prepared_tx_hash !== params.a2uTxid ||
            !Number.isSafeInteger(feeStroops) || feeStroops < 0 ||
            normalizePostgresNumeric(a.horizon_fee_stroops, 'authority.horizon_fee_stroops') !== feeStroops ||
            a.horizon_confirmed_at == null || a.pi_completed_at == null) {
          throw new Error('G8_ACCOUNTING_AUTHORITY_CONFLICT_OR_UNPROVEN_FINALITY')
        }

        // 0. Check for existing transaction - if found, verify it matches identifiers and amounts (idempotency check)
        const existingTxCheck = await tx`
          SELECT id, merchant_id, merchant_uid, amount, status, currency FROM transactions WHERE payment_id = ${params.u2aIdentifier}
          LIMIT 1
        `
        
        if (a.stage === 'db_finalized' && existingTxCheck.length !== 1) {
          throw new Error('Accounting evidence missing for finalized payment; SAFE_HOLD_NO_RESEND')
        }
        if (existingTxCheck && existingTxCheck.length > 0) {
          const existing = existingTxCheck[0]
          if (existing.status !== 'completed' || existing.currency !== 'π') {
            throw new Error('Idempotency violation: transaction state or currency differs')
          }
          // IDEMPOTENCY: Verify the existing transaction matches merchant identity and canonical amount
          if (existing.merchant_id !== params.merchantId) {
            throw new Error(`Idempotency violation: existing transaction has different merchantId: ${existing.merchant_id} vs ${params.merchantId}`)
          }
          if (existing.merchant_uid !== params.merchantUid) {
            throw new Error(`Idempotency violation: existing transaction has different merchantUid: ${existing.merchant_uid} vs ${params.merchantUid}`)
          }
          // Normalize PostgreSQL NUMERIC to validated number for exact comparison
          const storedAmount = normalizePostgresNumeric(existing.amount, 'existing.amount')
          if (storedAmount !== merchantAmount) {
            throw new Error(`Idempotency violation: existing transaction has different amount: ${storedAmount} vs ${merchantAmount}`)
          }
          console.log('[DB] Idempotency check passed - existing transaction matches all fields, reusing transaction ID')
        }
        
        // 1. Upsert transaction with RETURNING id to get actual ID (new or existing)
        // CRITICAL: Store merchantAmount (actual blockchain transfer), NOT customerAmount
        const txResult = await tx`
          INSERT INTO transactions (
            id, payment_id, merchant_id, merchant_uid, amount, currency, 
            reference, description, status, created_at, completed_at
          ) VALUES (${transactionId}, ${params.u2aIdentifier}, ${params.merchantId}, ${params.merchantUid}, 
                    ${merchantAmount}, ${'π'}, ${reference}, ${params.note || 'A2U Settlement'}, 
                    ${'completed'}, ${createdAtDate.toISOString()}, NOW())
          ON CONFLICT (payment_id) DO UPDATE SET completed_at = NOW()
          RETURNING id
        `
        
        // Get the actual transaction ID (new or existing)
        const actualTransactionId = txResult[0]?.id || transactionId
        
        // 2. Insert receipt idempotently with fee tracking using the actual transaction ID
        // CRITICAL: Store customerAmount, merchantAmount (what was actually sent on blockchain), and horizonFeeCharged
        // On conflict, verify amounts match (idempotency check)
        // All required columns must exist before transaction begins
        const existingReceiptCheck = await tx`
          SELECT id, merchant_id, merchant_uid, amount, currency, txid, app_net_impact, settlement_status,
                 customer_amount, horizon_fee_charged, app_commission, merchant_amount,
                 u2a_identifier, u2a_txid, a2u_identifier, a2u_txid
          FROM receipts
          WHERE transaction_id = ${actualTransactionId} LIMIT 1
        `
        
        // A committed transaction and its receipt were created atomically.
        // Missing evidence is not a new credit opportunity; never repair it by guessing.
        if (existingTxCheck.length > 0 && existingReceiptCheck.length !== 1) {
          throw new Error('Accounting receipt missing; SAFE_HOLD_NO_RESEND')
        }
        if (existingReceiptCheck.length > 0) {
          const existing = existingReceiptCheck[0]
          if (existing.merchant_id !== params.merchantId || existing.merchant_uid !== params.merchantUid ||
              existing.currency !== 'π' || existing.txid !== params.a2uTxid ||
              existing.settlement_status !== 'settled_to_merchant' ||
              normalizePostgresNumeric(existing.amount, 'receipt.amount') !== merchantAmount ||
              normalizePostgresNumeric(existing.app_net_impact, 'receipt.app_net_impact') !== appNetImpact) {
            throw new Error('Idempotency violation: receipt owner, state or accounting differs')
          }
          // IDEMPOTENCY: Verify existing receipt matches every stored accounting amount exactly
          // Normalize all PostgreSQL NUMERIC values to validated numbers for precise comparison
          const storedCustomerAmount = normalizePostgresNumeric(existing.customer_amount, 'existing.customer_amount')
          const storedMerchantAmount = normalizePostgresNumeric(existing.merchant_amount, 'existing.merchant_amount')
          const storedHorizonFeeCharged = normalizePostgresNumeric(existing.horizon_fee_charged, 'existing.horizon_fee_charged')
          const storedAppCommission = normalizePostgresNumeric(existing.app_commission, 'existing.app_commission')


          // N-FIN-9: replay is valid only for the exact same durable financial identity.
          if (existing.u2a_identifier !== params.u2aIdentifier) {
            throw new Error('Idempotency violation: receipt has different u2aIdentifier')
          }
          if (existing.u2a_txid !== params.u2aTxid) {
            throw new Error('Idempotency violation: receipt has different u2aTxid')
          }
          if (existing.a2u_identifier !== params.a2uIdentifier) {
            throw new Error('Idempotency violation: receipt has different a2uIdentifier')
          }
          if (existing.a2u_txid !== params.a2uTxid) {
            throw new Error('Idempotency violation: receipt has different a2uTxid')
          }
          
          if (storedCustomerAmount !== customerAmount) {
            throw new Error(`Idempotency violation: receipt has different customerAmount: ${storedCustomerAmount} vs ${customerAmount}`)
          }
          if (storedMerchantAmount !== merchantAmount) {
            throw new Error(`Idempotency violation: receipt has different merchantAmount: ${storedMerchantAmount} vs ${merchantAmount}`)
          }
          if (storedHorizonFeeCharged !== horizonFeeCharged) {
            throw new Error(`Idempotency violation: receipt has different horizonFeeCharged: ${storedHorizonFeeCharged} vs ${horizonFeeCharged}`)
          }
          if (storedAppCommission !== appCommission) {
            throw new Error(`Idempotency violation: receipt has different appCommission: ${storedAppCommission} vs ${appCommission}`)
          }
          console.log('[DB] Idempotency check passed - existing receipt matches all financial fields exactly, no duplicate credit')
        }
        
        const receiptResult = await tx`
          INSERT INTO receipts (
            transaction_id, merchant_id, merchant_uid, amount, currency, timestamp, txid,
            u2a_identifier, u2a_txid, a2u_identifier, a2u_txid, metadata, created_at,
            customer_amount, horizon_fee_charged, app_commission, merchant_amount, app_net_impact, settlement_status
          ) VALUES (${actualTransactionId}, ${params.merchantId}, ${params.merchantUid}, ${merchantAmount},
                    ${'π'}, NOW(), ${params.a2uTxid}, ${params.u2aIdentifier}, ${params.u2aTxid},
                    ${params.a2uIdentifier}, ${params.a2uTxid},
                    ${JSON.stringify({ u2aIdentifier: params.u2aIdentifier, u2aTxid: params.u2aTxid, a2uIdentifier: params.a2uIdentifier, a2uTxid: params.a2uTxid })},
                    NOW(),
                    ${customerAmount}, ${horizonFeeCharged}, ${appCommission}, ${merchantAmount}, ${appNetImpact}, ${'settled_to_merchant'})
          ON CONFLICT (transaction_id) DO NOTHING
          RETURNING id
        `

        // Only increment settled if receipt was newly inserted (RETURNING returned a row)
        // This ensures merchantAmount credit is applied EXACTLY ONCE, never duplicated on retry
        const receiptWasInserted = receiptResult && receiptResult.length > 0

        // 3. Update merchant balance - only increment if receipt is new
        // CRITICAL: Credit ONLY the actual blockchain transfer amount (merchantAmount), NOT customerAmount
        if (receiptWasInserted) {
          console.log('[DB] Crediting merchant balance:')
          console.log('[DB]   - Merchant ID:', params.merchantId)
          console.log('[DB]   - Credit amount:', merchantAmount, '(actual blockchain transfer)')
          console.log('[DB]   - App absorbs:', appNetImpact)
          
          await tx`
            INSERT INTO merchant_balances (merchant_id, settled, unsettled, last_updated)
            VALUES (${params.merchantId}, ${merchantAmount}, 0, NOW())
            ON CONFLICT (merchant_id) DO UPDATE
            SET settled = merchant_balances.settled + EXCLUDED.settled,
                last_updated = NOW()
          `
          
          console.log('[DB] ✓ Merchant balance updated with actual blockchain transfer amount')
        } else {
          console.log('[DB] Receipt was not newly inserted (idempotent retry) - skipping duplicate merchant balance credit')
        }
        
        return actualTransactionId
      })
      
      console.log('[DB] A2U transaction committed successfully:', { transactionId: result })
      
      // Select the actual committed transaction row from database to verify and return its canonical identifiers
      // This proves the transaction was actually persisted and returns evidence, not echoed params
      // Join transactions to receipts to verify both are committed and retrieve accounting identifiers
      // U2A/A2U identifiers and txids are stored in receipts table, not transactions
      const committedRowResult = await query(
        `SELECT 
           t.id, r.u2a_identifier, r.u2a_txid, r.a2u_identifier, r.a2u_txid, t.merchant_id, t.merchant_uid,
           r.customer_amount, r.horizon_fee_charged, r.app_commission, r.merchant_amount, r.app_net_impact
         FROM transactions t
         INNER JOIN receipts r ON r.transaction_id = t.id
         WHERE t.id = $1`,
        [result]
      )
      
      if (!committedRowResult || committedRowResult.length !== 1) {
        console.error('[DB] CRITICAL: Committed transaction ID not found or multiple rows returned:', result)
        return { success: false, error: 'Transaction committed but not found in database - integrity error' }
      }
      
      const committedRow = committedRowResult[0]
      
      // Type guard: validate row is non-null object with all required properties (strings and numerics)
      // Using 'in' operator checks to narrow type and typeof checks to validate values
      if (
        typeof committedRow !== 'object' ||
        committedRow === null ||
        !('u2a_identifier' in committedRow) ||
        !('u2a_txid' in committedRow) ||
        !('a2u_identifier' in committedRow) ||
        !('a2u_txid' in committedRow) ||
        !('merchant_id' in committedRow) ||
        !('merchant_uid' in committedRow) ||
        !('customer_amount' in committedRow) ||
        !('horizon_fee_charged' in committedRow) ||
        !('app_commission' in committedRow) ||
        !('merchant_amount' in committedRow) ||
        !('app_net_impact' in committedRow)
      ) {
        console.error('[DB] CRITICAL: Committed row missing required fields:', committedRow)
        return { success: false, error: 'Transaction row validation failed - required fields missing' }
      }
      
      // After in-checks above, extract and validate each property type and value
      // Use distinct names to avoid shadowing validated transaction variables
      const committedU2aIdentifier = committedRow['u2a_identifier']
      const committedU2aTxid = committedRow['u2a_txid']
      const committedA2uIdentifier = committedRow['a2u_identifier']
      const committedA2uTxid = committedRow['a2u_txid']
      const committedMerchantId = committedRow['merchant_id']
      const committedMerchantUid = committedRow['merchant_uid']
      const committedCustomerAmountRaw = committedRow['customer_amount']
      const committedHorizonFeeChargedRaw = committedRow['horizon_fee_charged']
      const committedAppCommissionRaw = committedRow['app_commission']
      const committedMerchantAmountRaw = committedRow['merchant_amount']
      const committedAppNetImpactRaw = committedRow['app_net_impact']
      
      // Validate transaction identifier strings are non-empty
      if (
        typeof committedU2aIdentifier !== 'string' || committedU2aIdentifier.trim().length === 0 ||
        typeof committedU2aTxid !== 'string' || committedU2aTxid.trim().length === 0 ||
        typeof committedA2uIdentifier !== 'string' || committedA2uIdentifier.trim().length === 0 ||
        typeof committedA2uTxid !== 'string' || committedA2uTxid.trim().length === 0 ||
        typeof committedMerchantId !== 'string' || committedMerchantId.trim().length === 0 ||
        typeof committedMerchantUid !== 'string' || committedMerchantUid.trim().length === 0
      ) {
        console.error('[DB] CRITICAL: Committed row transaction fields are not non-empty strings')
        return { success: false, error: 'Transaction row validation failed - identifier field types or values invalid' }
      }

      // Validate accounting numeric fields are valid numbers (may be 0, null, or string representations from PostgreSQL)
      const normalizedCommittedCustomerAmount = normalizePostgresNumeric(committedCustomerAmountRaw, 'committedCustomerAmount')
      const normalizedCommittedHorizonFeeCharged = normalizePostgresNumeric(committedHorizonFeeChargedRaw, 'committedHorizonFeeCharged')
      const normalizedCommittedAppCommission = normalizePostgresNumeric(committedAppCommissionRaw, 'committedAppCommission')
      const normalizedCommittedMerchantAmount = normalizePostgresNumeric(committedMerchantAmountRaw, 'committedMerchantAmount')
      const normalizedCommittedAppNetImpact = normalizePostgresNumeric(committedAppNetImpactRaw, 'committedAppNetImpact')


      // N-FIN-9: the authoritative post-COMMIT read must match the expected
      // financial identity and accounting exactly; validity of field types alone is insufficient.
      if (
        committedU2aIdentifier !== params.u2aIdentifier ||
        committedU2aTxid !== params.u2aTxid ||
        committedA2uIdentifier !== params.a2uIdentifier ||
        committedA2uTxid !== params.a2uTxid ||
        committedMerchantId !== params.merchantId ||
        committedMerchantUid !== params.merchantUid
      ) {
        console.error('[DB] CRITICAL: Committed row identity mismatch')
        return { success: false, error: 'Transaction row validation failed - committed identity mismatch' }
      }
      if (
        normalizedCommittedCustomerAmount !== customerAmount ||
        normalizedCommittedHorizonFeeCharged !== horizonFeeCharged ||
        normalizedCommittedAppCommission !== appCommission ||
        normalizedCommittedMerchantAmount !== merchantAmount ||
        normalizedCommittedAppNetImpact !== appNetImpact
      ) {
        console.error('[DB] CRITICAL: Committed row accounting mismatch')
        return { success: false, error: 'Transaction row validation failed - committed accounting mismatch' }
      }
      
      if (
        !Number.isFinite(normalizedCommittedCustomerAmount) ||
        !Number.isFinite(normalizedCommittedHorizonFeeCharged) ||
        !Number.isFinite(normalizedCommittedAppCommission) ||
        !Number.isFinite(normalizedCommittedMerchantAmount) ||
        !Number.isFinite(normalizedCommittedAppNetImpact)
      ) {
        console.error('[DB] CRITICAL: Accounting fields not finite numbers:', {
          customerAmount: normalizedCommittedCustomerAmount,
          horizonFeeCharged: normalizedCommittedHorizonFeeCharged,
          appCommission: normalizedCommittedAppCommission,
          merchantAmount: normalizedCommittedMerchantAmount,
          appNetImpact: normalizedCommittedAppNetImpact
        })
        return { success: false, error: 'Transaction row validation failed - accounting field types or values invalid' }
      }
      
      return { 
        success: true, 
        transactionId: result,
        transaction: {
          u2aIdentifier: committedU2aIdentifier,
          u2aTxid: committedU2aTxid,
          a2uIdentifier: committedA2uIdentifier,
          a2uTxid: committedA2uTxid,
          merchantId: committedMerchantId,
          merchantUid: committedMerchantUid,
        }
      }
    } finally {
      await client.end()
    }
  } catch (error) {
    console.error('[DB] A2U atomic transaction failed:', error)
    return { success: false, error: error instanceof Error ? error.message : 'Unknown error' }
  }
}


/** B-D05-R2: read-only durable identity probe. Absence of a Redis projection
 * must not be represented as absence of a payment when PostgreSQL knows it.
 * This probe never synthesizes a financial status or writes any state.
 */
export async function probeDurablePaymentIdentity(paymentId: string): Promise<'EXISTS' | 'ABSENT' | 'INDETERMINATE'> {
  try {
    const client = await getPostgresClient()
    if (!client) return 'INDETERMINATE'
    // All three durable identity families must be readable before claiming ABSENT.
    // A missing legacy table or any query failure is uncertainty, never a false 404.
    const rows = await client`
      SELECT (
        EXISTS (SELECT 1 FROM payment_create_intents WHERE payment_id = ${paymentId})
        OR EXISTS (SELECT 1 FROM settlement_checkpoints WHERE payment_id = ${paymentId})
        OR EXISTS (SELECT 1 FROM transactions WHERE payment_id = ${paymentId})
      ) AS known
    `
    return rows.length === 1 ? (rows[0].known === true ? 'EXISTS' : 'ABSENT') : 'INDETERMINATE'
  } catch (error) {
    console.error('[FIN100B B-D05-R2] Durable identity probe indeterminate', error)
    return 'INDETERMINATE'
  }
}

// FIN-100B: the create-intent and its financial identity commit atomically.
export async function ensurePaymentCreateIntentTable(): Promise<boolean> {
  // R36 ACL: schema changes belong to an offline migration, never the payment path.
  return r36VerifyColumns('payment_create_intents', [
    'merchant_uid', 'create_intent_id', 'payment_id', 'merchant_id',
    'customer_amount', 'note', 'created_at',
  ])
}

// B-D05-R1: read-only, verified replay classification before the new-flow limiter.
// Never treat a missing/uncertain durable identity as proof of an existing payment.
export async function classifyPaymentCreateIntentReplay(params: {
  createIntentId: string; merchantUid: string; merchantId: string; amount: number; note: string
}): Promise<'NEW' | 'REPLAY' | 'CONFLICT' | 'INDETERMINATE'> {
  try {
    const client = await getPostgresClient()
    if (!client) return 'INDETERMINATE'
    const rows = await client`
      SELECT i.payment_id, i.merchant_id, i.customer_amount, i.note,
             c.payment_id AS checkpoint_payment_id, c.merchant_uid AS checkpoint_merchant_uid,
             c.merchant_id AS checkpoint_merchant_id, c.customer_amount AS checkpoint_customer_amount,
             c.merchant_amount, c.app_commission
      FROM payment_create_intents i
      LEFT JOIN settlement_checkpoints c ON c.payment_id = i.payment_id
      WHERE i.merchant_uid = ${params.merchantUid} AND i.create_intent_id = ${params.createIntentId}
    `
    if (rows.length === 0) return 'NEW'
    if (rows.length !== 1) return 'INDETERMINATE'
    const row = rows[0]
    if (row.merchant_id !== params.merchantId || Number(row.customer_amount) !== params.amount || row.note !== params.note) return 'CONFLICT'
    if (!row.checkpoint_payment_id || row.checkpoint_merchant_uid !== params.merchantUid ||
        row.checkpoint_merchant_id !== params.merchantId ||
        Number(row.checkpoint_customer_amount) !== params.amount ||
        Number(row.merchant_amount) !== params.amount || Number(row.app_commission) !== 0) return 'INDETERMINATE'
    return 'REPLAY'
  } catch (error) {
    console.error('[FIN100B] Create-intent replay classification unavailable', error)
    return 'INDETERMINATE'
  }
}

export type PaymentCreateIntentResult =
  | { outcome: 'CREATED' | 'REPLAYED'; paymentId: string; createdAt: string }
  | { outcome: 'CONFLICT' | 'INDETERMINATE'; error: string }

export async function recordPaymentCreateIntentAtomic(params: {
  createIntentId: string; paymentId: string; merchantUid: string; merchantId: string;
  amount: number; note: string; createdAt: string
}): Promise<PaymentCreateIntentResult> {
  try {
    const client = await getPostgresClient()
    if (!client) return { outcome: 'INDETERMINATE', error: 'PostgreSQL unavailable' }
    return await client.begin(async (tx: any): Promise<PaymentCreateIntentResult> => {
      const inserted = await tx`
        INSERT INTO payment_create_intents
          (merchant_uid, create_intent_id, payment_id, merchant_id, customer_amount, note, created_at)
        VALUES (${params.merchantUid}, ${params.createIntentId}, ${params.paymentId},
                ${params.merchantId}, ${params.amount}, ${params.note}, ${params.createdAt})
        ON CONFLICT (merchant_uid, create_intent_id) DO NOTHING
        RETURNING payment_id, created_at
      `
      if (inserted.length === 1) {
        const checkpoint = await tx`
          INSERT INTO settlement_checkpoints (
            payment_id, version, stage, merchant_id, merchant_uid,
            customer_amount, merchant_amount, app_commission,
            a2u_create_guard_version, pi_mutation_guard_version
          ) VALUES (
            ${params.paymentId}, 1, 'payment_identity', ${params.merchantId}, ${params.merchantUid},
            ${params.amount}, ${params.amount}, 0, 'fin5_v1', 'fin7_v2'
          ) RETURNING payment_id
        `
        if (checkpoint.length !== 1) throw new Error('Financial identity checkpoint not inserted')
        return { outcome: 'CREATED', paymentId: params.paymentId, createdAt: params.createdAt }
      }
      const existing = await tx`
        SELECT payment_id, merchant_id, customer_amount, note, created_at
        FROM payment_create_intents
        WHERE merchant_uid = ${params.merchantUid} AND create_intent_id = ${params.createIntentId}
        FOR UPDATE
      `
      if (existing.length !== 1) return { outcome: 'INDETERMINATE', error: 'Intent identity unavailable' }
      const row = existing[0]
      if (row.merchant_id !== params.merchantId || Number(row.customer_amount) !== params.amount || row.note !== params.note) {
        return { outcome: 'CONFLICT', error: 'Create intent payload mismatch' }
      }
      const checkpoint = await tx`
        SELECT payment_id, merchant_id, merchant_uid, customer_amount, merchant_amount, app_commission
        FROM settlement_checkpoints WHERE payment_id = ${row.payment_id}
      `
      if (checkpoint.length !== 1 || checkpoint[0].merchant_id !== params.merchantId ||
          checkpoint[0].merchant_uid !== params.merchantUid ||
          Number(checkpoint[0].customer_amount) !== params.amount ||
          Number(checkpoint[0].merchant_amount) !== params.amount ||
          Number(checkpoint[0].app_commission) !== 0) {
        return { outcome: 'CONFLICT', error: 'Durable checkpoint identity mismatch' }
      }
      return { outcome: 'REPLAYED', paymentId: row.payment_id, createdAt: new Date(row.created_at).toISOString() }
    })
  } catch (error) {
    console.error('[FIN100B] Create-intent transaction indeterminate', error)
    return { outcome: 'INDETERMINATE', error: 'Create-intent transaction uncertain' }
  }
}


/** FIN100B B-D04: recovery of the initial Redis projection only. PostgreSQL
 * serializes this check against durable financial writers. No payment identity,
 * Pi mutation, or settlement/refund authority is created by this operation.
 * The callback performs the Redis NX+history write while the row is locked.
 */
export async function recoverInitialPaymentProjectionUnderDurableGuard(params: {
  paymentId: string; merchantUid: string; merchantId: string; amount: number;
  note: string; createdAt: string; persist: () => Promise<'CREATED' | 'PRESENT' | 'CONFLICT'>
}): Promise<'CREATED' | 'PRESENT' | 'CONFLICT' | 'INDETERMINATE'> {
  try {
    // B-D04 clean-schema guard: recovery reads Refund authority below, so a
    // clean database must establish that durable authority table before the
    // evidence query. Failure remains fail-closed and performs no Redis write.
    if (!(await ensureRefundCheckpointTables())) return 'INDETERMINATE'
    const client = await getPostgresClient()
    if (!client) return 'INDETERMINATE'
    return await client.begin(async (tx: any) => {
      await tx`SELECT pg_advisory_xact_lock(hashtextextended(${params.paymentId}, 0))`
      const intents = await tx`SELECT payment_id,merchant_uid,merchant_id,customer_amount,note,created_at
        FROM payment_create_intents WHERE payment_id=${params.paymentId} FOR UPDATE`
      const rows = await tx`SELECT * FROM settlement_checkpoints WHERE payment_id=${params.paymentId} FOR UPDATE`
      if (intents.length !== 1 || rows.length !== 1) return 'CONFLICT' as const
      const i = intents[0] as Record<string, unknown>
      const r = rows[0] as Record<string, unknown>
      if (i.payment_id !== params.paymentId || i.merchant_uid !== params.merchantUid ||
          i.merchant_id !== params.merchantId || Number(i.customer_amount) !== params.amount ||
          i.note !== params.note || new Date(i.created_at as string).toISOString() !== params.createdAt ||
          r.payment_id !== params.paymentId || r.merchant_uid !== params.merchantUid ||
          r.merchant_id !== params.merchantId || Number(r.customer_amount) !== params.amount ||
          Number(r.merchant_amount) !== params.amount || Number(r.app_commission) !== 0 ||
          r.stage !== 'payment_identity' || Number(r.version) !== 1 ||
          r.a2u_create_guard_version !== 'fin5_v1' || r.pi_mutation_guard_version !== 'fin7_v2') return 'CONFLICT' as const
      // Stage=payment_identity alone is NOT sufficient: Pi start/approval,
      // ingress, holds, or an external attempt may already exist.
      const mustBeEmpty = [
        'u2a_approval_identifier','u2a_approval_claimed_at','u2a_approval_guard_version',
        'u2a_approval_attempted_at','u2a_start_lease_token','u2a_start_lease_expires_at',
        'u2a_identifier','u2a_txid','payer_uid','u2a_verified_at','u2a_completed_at',
        'a2u_create_attempted_at','a2u_payment_id','a2u_from_address','a2u_to_address',
        'prepared_envelope_xdr','prepared_tx_hash','prepared_sequence','a2u_txid',
        'horizon_fee_stroops','horizon_confirmed_at','pi_completed_at','db_finalized_at',
        'certification_hold','certification_hold_at','certification_hold_expires_at',
      ]
      if (mustBeEmpty.some((field) => r[field] !== null && r[field] !== undefined)) return 'CONFLICT' as const
      // FIN100B B-D05-R4: any append-only financial evidence invalidates an
      // initial pending projection, even if the checkpoint still looks pristine.
      // All evidence writers share this payment's durable advisory lock; query
      // under the same transaction before the Redis persist callback executes.
      // Missing evidence schema/query errors must fail closed (INDETERMINATE).
      const evidence = await tx`SELECT
        EXISTS(SELECT 1 FROM refund_checkpoints WHERE payment_id=${params.paymentId}) AS refund,
        EXISTS(SELECT 1 FROM financial_pi_mutation_attempts WHERE payment_id=${params.paymentId}) AS pi_attempt,
        EXISTS(SELECT 1 FROM settlement_u2a_approval_retirements WHERE payment_id=${params.paymentId}) AS retired,
        EXISTS(SELECT 1 FROM settlement_a2u_stage1_retirements WHERE payment_id=${params.paymentId}) AS a2u_stage1_retired,
        EXISTS(SELECT 1 FROM settlement_a2u_ongoing_observations WHERE payment_id=${params.paymentId}) AS a2u_ongoing_observed`
      if (evidence.length !== 1 || evidence[0].refund !== false ||
          evidence[0].pi_attempt !== false || evidence[0].retired !== false ||
          evidence[0].a2u_stage1_retired !== false ||
          evidence[0].a2u_ongoing_observed !== false) return 'CONFLICT' as const
      return await params.persist()
    })
  } catch (error) {
    console.error('[FIN100B B-D04] guarded initial projection recovery indeterminate', error)
    return 'INDETERMINATE'
  }
}
